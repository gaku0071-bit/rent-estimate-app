$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$packageDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$documentsDir = [Environment]::GetFolderPath("MyDocuments")
$destDir = Join-Path $documentsDir "realpro-estimate-extension"
$backupDir = Join-Path $documentsDir "realpro-estimate-extension-backup"
$localZip = Join-Path $packageDir "realpro-estimate-extension.zip"
$zipUrl = "https://gaku0071-bit.github.io/rent-estimate-web/realpro-estimate-extension.zip"
$workDir = Join-Path $env:TEMP ("realpro-extension-update-" + [Guid]::NewGuid().ToString("N"))

function Step($message) {
  Write-Host ""
  Write-Host ("==> " + $message)
}

function Read-Package($zipPath, $label) {
  $extractDir = Join-Path $workDir $label
  New-Item -ItemType Directory -Force -Path $extractDir | Out-Null
  Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force
  $manifestFile = Get-ChildItem -Path $extractDir -Filter "manifest.json" -Recurse -File |
    Where-Object { $_.FullName -notmatch "__MACOSX" } |
    Select-Object -First 1
  if (-not $manifestFile) { return $null }

  $sourceDir = $manifestFile.DirectoryName
  $requiredFiles = @(
    "manifest.json", "background.js", "realpro-parser.js", "realpro-content.js",
    "estimate-content.js", "popup.html", "popup.js", "popup.css"
  )
  foreach ($file in $requiredFiles) {
    if (-not (Test-Path (Join-Path $sourceDir $file))) {
      throw ("更新用ZIPに " + $file + " がありません。")
    }
  }

  $manifest = Get-Content -Raw -Path $manifestFile.FullName | ConvertFrom-Json
  return [PSCustomObject]@{
    Label = $label
    Version = [Version]$manifest.version
    SourceDir = $sourceDir
  }
}

New-Item -ItemType Directory -Force -Path $workDir | Out-Null

try {
  Write-Host "リアプロ初期費用見積連携を更新します。"
  $packages = @()

  if (Test-Path $localZip) {
    $localPackage = Read-Package $localZip "同梱ZIP"
    if ($localPackage) { $packages += $localPackage }
  }

  Step "公開中の最新版を確認しています"
  $downloadZip = Join-Path $workDir "remote.zip"
  try {
    Invoke-WebRequest -Uri ($zipUrl + "?t=" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) -OutFile $downloadZip -UseBasicParsing
    $remotePackage = Read-Package $downloadZip "公開ZIP"
    if ($remotePackage) { $packages += $remotePackage }
  } catch {
    Write-Host "公開ZIPを取得できないため、同梱ZIPを使用します。"
  }

  if ($packages.Count -eq 0) {
    throw "使用できる更新用ZIPがありません。"
  }

  $selected = $packages | Sort-Object Version -Descending | Select-Object -First 1
  $currentVersion = $null
  $installedManifest = Join-Path $destDir "manifest.json"
  if (Test-Path $installedManifest) {
    $currentManifest = Get-Content -Raw -Path $installedManifest | ConvertFrom-Json
    $currentVersion = [Version]$currentManifest.version
  }

  Write-Host ""
  Write-Host ("現在のバージョン: " + $(if ($currentVersion) { $currentVersion } else { "未導入" }))
  Write-Host ("更新用バージョン: " + $selected.Version + "（" + $selected.Label + "）")

  if ($currentVersion -and $currentVersion -gt $selected.Version) {
    Write-Host "現在のバージョンの方が新しいため、上書きしませんでした。"
  } else {
    if (Test-Path $destDir) {
      Step "現在の拡張機能をバックアップしています"
      if (Test-Path $backupDir) { Remove-Item -Path $backupDir -Recurse -Force }
      Copy-Item -Path $destDir -Destination $backupDir -Recurse -Force
    }

    Step "同じ保存先へ最新版を上書きしています"
    New-Item -ItemType Directory -Force -Path $destDir | Out-Null
    Copy-Item -Path (Join-Path $selected.SourceDir "*") -Destination $destDir -Recurse -Force
  }

  $updatedManifest = Get-Content -Raw -Path (Join-Path $destDir "manifest.json") | ConvertFrom-Json
  Write-Host ""
  Write-Host ("保存先: " + $destDir)
  Write-Host ("更新後バージョン: " + $updatedManifest.version)

  Step "Chromeの拡張機能画面を開きます"
  try {
    Start-Process "chrome.exe" "chrome://extensions/"
  } catch {
    Write-Host "Chromeを自動で開けませんでした。手動で chrome://extensions/ を開いてください。"
  }

  Write-Host ""
  Write-Host "次に『リアプロ初期費用見積連携』の『再読み込み』を押してください。"
  Write-Host "初回導入時だけ『パッケージ化されていない拡張機能を読み込む』から保存先を選びます。"
} finally {
  if (Test-Path $workDir) {
    Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue
  }
}
