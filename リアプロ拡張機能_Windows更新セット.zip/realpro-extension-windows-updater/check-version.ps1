$ErrorActionPreference = "SilentlyContinue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$manifestPath = Join-Path ([Environment]::GetFolderPath("MyDocuments")) "realpro-estimate-extension\manifest.json"
$latestManifestUrl = "https://rent-estimate-app.onrender.com/extension-version.json"

if (Test-Path $manifestPath) {
  $manifest = Get-Content -Raw -Path $manifestPath | ConvertFrom-Json
  Write-Host ("現在のバージョン: " + $manifest.version)
  Write-Host ("保存先: " + (Split-Path -Parent $manifestPath))
} else {
  Write-Host "現在のバージョン: 未導入"
}

try {
  $latest = Invoke-RestMethod -Uri ($latestManifestUrl + "?t=" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) -UseBasicParsing
  Write-Host ("公開中の最新版: " + $latest.version)
} catch {
  Write-Host "公開中の最新版: 確認できません"
}
