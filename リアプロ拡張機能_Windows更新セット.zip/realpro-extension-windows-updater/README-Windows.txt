Run update-extension.bat, then click Reload for the extension on chrome://extensions/.
The fixed install folder is Documents\realpro-estimate-extension.
Only the first installation needs Load unpacked. Saved Chrome rules remain after file updates.

If you use Load unpacked directly, select this realpro-extension-windows-updater folder.
manifest.json and the extension files are included directly in this folder.
