Run update-extension.bat, then click Reload for the extension on chrome://extensions/.
The fixed install folder is Documents\realpro-estimate-extension.
Only the first installation needs Load unpacked. Saved Chrome rules remain after file updates.
