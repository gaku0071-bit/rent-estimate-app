(function initRealproParser(global) {
  const CATEGORY_RULES = [
    ["monthlyGuaranteeFee", /月額保証|月次保証|毎月保証|月々保証|月額手数料|収納代行|支払手数料|集送金手数料|口座振替|引落|決済サービス|決済手数料/i],
    ["acCleaningFee", /エアコン|AC清掃|ＡＣ清掃|空調清掃/i],
    ["stoveMaintenanceFee", /FF|ＦＦ|ストーブ|暖房|冷暖房/i],
    ["waterSanitizingFee", /水廻|水回|水まわ|水周/i],
    ["cleaningFee", /HC料|ＨＣ料|ハウスクリーニング|ルームクリーニング|室内清掃|退去時清掃|退去清掃|清掃料/i],
    ["keyFee", /鍵|カギ|カードキー|シリンダ/i],
    ["antibacterialFee", /抗菌|除菌|消毒|殺菌/i],
    ["supportFee", /24時間|２４時間|緊急電話|夜間受付|夜間緊急|夜間対応|アクセス24|見守り|サポート|リペア|くらし|暮らし|クラブ|駆けつけ|かけつけ/i],
    ["deodorizingFee", /消臭|脱臭|防臭/i],
    ["petFee", /ペット|飼育/i],
    ["waterDrainFee", /水落|水抜|エコジョーズ/i],
    ["gasLeaseFee", /水道料|上下水道|給湯器.*リース|北ガス.*リース|ガス警報器.*リース|ガスリース|設備リース|リース料/i],
    ["townFee", /町内会費|町会費/i],
    ["parkingFee", /駐車場|駐車料金|駐車料/i],
  ];

  const NON_CUSTOMER_PATTERN =
    /契約事務手数料|契約時事務手数料|事務手数料|広告料|業務委託料|仲介手数料|AD\b|更新料|更新手数料|キャンセル料|書類作成|貸主負担|家主負担|オーナー負担|管理会社負担/i;

  const REMARK_FEE_PATTERN =
    /都市ガス|ガス保証金|ガス保証料|ガス料金(?:は)?(?:定額|上限)|北ガス|ガスリース|ガス.*リース|給湯器.*リース|リース料|更新料|更新手数料|更新事務手数料|契約更新事務手数料/i;

  const CUSTOMER_INITIAL_ADMIN_FEE_PATTERN =
    /(?:無料)?インターネット[^。・\n\r]{0,32}?(?:初回|契約時)[^。・\n\r]{0,32}?事務手数料|(?:初回|契約時)[^。・\n\r]{0,32}?(?:無料)?インターネット[^。・\n\r]{0,32}?事務手数料/i;

  const FEE_NAME_SOURCE =
    "HC料|ＨＣ料|ハウスクリーニング(?:料|費)?|ルームクリーニング(?:料|費)?|室内清掃(?:料|費用)?|退去清掃(?:料|費用)?|清掃料|FF(?:分解)?(?:清掃|整備)(?:料|費用)?|ＦＦ(?:分解)?(?:清掃|整備)(?:料|費用)?|ストーブ(?:分解)?(?:清掃|整備)(?:料|費用)?|暖房(?:分解)?(?:清掃|整備)(?:料|費用)?|水廻り?消毒(?:料|費用)?|水回り?消毒(?:料|費用)?|水まわり消毒(?:料|費用)?|抗菌(?:施工)?(?:料|費用)?|除菌(?:消臭)?(?:料|費用)?|消毒(?:料|費用)?|鍵(?:交換)?(?:料|費用)?|カギ(?:交換)?(?:料|費用)?|シリンダ(?:交換)?(?:料|費用)?|カードキー(?:設定)?(?:交換)?(?:料|費用)?|エアコン(?:分解)?(?:清掃|整備)(?:料|費用)?|AC(?:清掃|整備)(?:料|費用)?|ＡＣ(?:清掃|整備)(?:料|費用)?|駐車場(?:料金|料)?|駐車料|24時間[^、。;；\\n\\d]{0,18}(?:料|費用)?|２４時間[^、。;；\\n\\d]{0,18}(?:料|費用)?|[^、。;；\\n\\d]{1,28}(?:料|費|代)";
  const FEE_ENTRY_PATTERN = new RegExp(
    `(${FEE_NAME_SOURCE})\\s*(?:[（(][^）)]{0,24}[）)])?\\s*(契約時(?:または|もしくは|又は)退去時(?:払い)?|退去時(?:または|もしくは|又は)契約時|契約時|入居時|退去時(?:払い|支払|精算)?|月額|毎月)?\\s*(?:[（(][^）)]{0,24}[）)])?\\s*((?:[\\d,]+\\s*円|\\d+(?:\\.\\d+)?\\s*万(?:\\s*円)?))`,
    "g",
  );

  function normalize(value) {
    return String(value || "")
      .normalize("NFKC")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+/g, " ")
      .trim();
  }

  function compact(value) {
    return normalize(value).replace(/\s+/g, "");
  }

  function money(value) {
    const text = normalize(value);
    const manMatch = text.match(/(\d+(?:\.\d+)?)\s*万(?:\s*円)?/);
    if (manMatch) return Math.round(Number(manMatch[1]) * 10000);
    const match = text.match(/([\d,]+)\s*円/);
    return match ? Number(match[1].replace(/,/g, "")) : 0;
  }

  function allMoney(value) {
    const text = normalize(value);
    const yenAmounts = Array.from(text.matchAll(/([\d,]+)\s*円/g), (match) =>
      Number(match[1].replace(/,/g, "")),
    );
    const manAmounts = Array.from(text.matchAll(/(\d+(?:\.\d+)?)\s*万(?:\s*円)?/g), (match) =>
      Math.round(Number(match[1]) * 10000),
    );
    return [...yenAmounts, ...manAmounts];
  }

  function inferInsuranceTiming(text, amount = 0) {
    const value = normalize(text);
    if (/月額|毎月|月払い|月払|月々|\/月|1ヶ月|１ヶ月/.test(value)) return "monthly";
    if (amount > 0 && amount <= 5000) return "monthly";
    return "initial";
  }

  function insuranceLabelForTiming(timing) {
    return timing === "monthly" ? "火災保険料（月額）" : "火災保険料（年払い）";
  }

  function monthAmount(value, rent) {
    const text = normalize(value);
    if (/なし|無し|不要|---/.test(text)) return 0;
    const direct = money(text);
    if (direct) return direct;
    const months = Number(text.match(/(\d+(?:\.\d+)?)\s*(?:ヶ月|か月|月分)/)?.[1] || 0);
    return months && rent ? Math.round(rent * months) : 0;
  }

  function baseDepositKeyMoney(value, rent) {
    const text = normalize(value).replace(/(?:敷金|礼金)備考[:：]?.*$/u, "").trim();
    return {
      deposit: monthAmount(text.match(/敷金[:：]?\s*(.*?)(?=\s*礼金[:：]|$)/u)?.[1], rent),
      keyMoney: monthAmount(text.match(/礼金[:：]?\s*(.*?)$/u)?.[1], rent),
    };
  }

  function publicParkingAmount(value) {
    const text = normalize(value);
    const amount = money(text);
    if (!amount) return 0;
    const amountIndex = text.search(/(?:[\d,]+\s*円|\d+(?:\.\d+)?\s*万(?:\s*円)?)/);
    const beforeAmount = amountIndex >= 0 ? text.slice(0, amountIndex) : text;
    if (/空きなし|満車/.test(beforeAmount)) {
      if (/場合は満車/.test(beforeAmount) && /P\s*[-ー]\s*\d/i.test(text)) return amount;
      return 0;
    }
    return amount;
  }

  function petChargeFromDepositRow(value, rent) {
    const text = normalize(value);
    const note = text.match(/(敷金|礼金)備考[:：]?\s*(.*(?:ペット|飼育).*)$/u);
    if (!note) return null;
    const amount = monthAmount(note[2], rent);
    if (!amount) return null;
    return {
      label: note[1] === "礼金" ? "ペット飼育時礼金" : "ペット飼育時敷金",
      amount,
      timing: "initial",
      type: "optional",
      category: "petFee",
      optional: true,
      confidence: "high",
      sourceSection: `${note[1]}備考`,
      sourceText: note[0],
    };
  }

  function inferTiming(text, section = "") {
    const value = normalize(`${section} ${text}`);
    const initial = /契約時|入居時|初期費用/.test(value);
    const moveout = /退去時|退居時/.test(value);
    if (
      (initial && moveout) ||
      /契約時(?:または|もしくは|又は)(?:退去時|退居時)|(?:退去時|退居時)(?:または|もしくは|又は)契約時|(?:退去時|退居時)払い?(?:可|相談可)/.test(
        value,
      )
    ) {
      return "choice";
    }
    if (/月額|毎月/.test(value)) return "monthly";
    if (moveout || section === "退去時") return "moveout";
    if (initial || section === "初期費用") return "initial";
    return "choice";
  }

  function inferCategory(label, context = "") {
    const value = normalize(`${label} ${context}`);
    for (const [category, pattern] of CATEGORY_RULES) {
      if (pattern.test(value)) return category;
    }
    return "";
  }

  function isOptional(text) {
    return /任意|希望者のみ|利用者のみ|利用の場合|ご利用時|利用時|飼育時|ペット|駐車場利用者|(?:\d+|[０-９]+)歳(?:以上)?(?:の)?(?:加入|利用).{0,12}必須/.test(normalize(text));
  }

  function isNonCustomerFee(text) {
    return NON_CUSTOMER_PATTERN.test(text) && !CUSTOMER_INITIAL_ADMIN_FEE_PATTERN.test(text);
  }

  function rowsFromDocument(doc) {
    const rows = [];
    for (const tr of doc.querySelectorAll("tr")) {
      const cells = Array.from(tr.querySelectorAll(":scope > th, :scope > td"), (cell) =>
        normalize(cell.innerText || cell.textContent),
      ).filter(Boolean);
      if (cells.length >= 2 && cells.length <= 8) rows.push(cells);
    }
    return rows;
  }

  function rowMap(rows) {
    const result = new Map();
    for (const cells of rows) {
      if (cells.length === 2 && !result.has(cells[0])) result.set(cells[0], cells[1]);
    }
    return result;
  }

  function parseLayout(value) {
    const text = normalize(value);
    return {
      layout: text.match(/\b(?:ワンルーム|1R|\d+[SLDKR]+)\b/i)?.[0] || text.split("[")[0].trim(),
      area: text.match(/\d+(?:\.\d+)?\s*(?:m2|㎡)/i)?.[0]?.replace(/m2/i, "㎡") || "",
    };
  }

  function feeSection(text) {
    const start = text.indexOf("諸費用");
    if (start < 0) return "";
    const tail = text.slice(start);
    const endCandidates = ["客付業者様へ", "広告掲載", "仲介手数料:負担", "管理会社情報"]
      .map((marker) => tail.indexOf(marker))
      .filter((index) => index > 0);
    const end = endCandidates.length ? Math.min(...endCandidates) : Math.min(tail.length, 6000);
    return tail.slice(0, end);
  }

  function splitFeeLines(sectionText) {
    const lines = normalize(sectionText)
      .replace(/○\s*(保証会社|保険|初期費用|ランニングコスト|退去時|その他)/g, "\n§$1\n")
      .split(/\n/)
      .map(normalize)
      .filter(Boolean);
    const result = [];
    let section = "";
    for (const line of lines) {
      if (line.startsWith("§")) {
        section = line.slice(1);
        continue;
      }
      if (/^諸費用|^※ データ登録/.test(line)) continue;
      result.push({ section, text: line });
    }
    return result;
  }

  function brokerNoteSection(text) {
    const start = text.indexOf("客付業者様へ");
    if (start < 0) return "";
    const tail = text.slice(start + "客付業者様へ".length);
    const end = tail.indexOf("諸費用");
    return tail.slice(0, end >= 0 ? end : Math.min(tail.length, 4000));
  }

  function timingTextFromTiming(timing) {
    if (timing === "choice" || /契約時(?:または|もしくは|又は)(?:退去時|退居時)|(?:退去時|退居時)(?:または|もしくは|又は)契約時/.test(timing)) return "契約時または退去時";
    if (/退去時|退居時|解約時/.test(timing)) return "退去時";
    if (/契約時|入居時/.test(timing)) return "契約時";
    if (/月額|毎月/.test(timing)) return "月額";
    if (timing === "moveout") return "退去時";
    if (timing === "initial") return "契約時";
    if (timing === "monthly") return "月額";
    return "";
  }

  function nearbyTimingText(rawLine, matchIndex, fallbackTiming) {
    const before = normalize(rawLine.slice(Math.max(0, matchIndex - 48), matchIndex));
    const after = normalize(rawLine.slice(matchIndex, matchIndex + 64));
    const context = `${before} ${after}`;
    if (/契約時(?:または|もしくは|又は)(?:退去時|退居時)|(?:退去時|退居時)(?:または|もしくは|又は)契約時|(?:退去時|退居時)可/.test(context)) return "契約時または退去時";
    if (/退去時費用|退去時|退居時|解約時/.test(context)) return "退去時";
    if (/契約時費用|契約時|入居時/.test(context)) return "契約時";
    if (/月額|毎月/.test(context)) return "月額";
    return timingTextFromTiming(fallbackTiming);
  }

  function explicitTimingText(rawLine) {
    const text = normalize(rawLine);
    if (/契約時(?:または|もしくは|又は)(?:退去時|退居時)|(?:退去時|退居時)(?:または|もしくは|又は)契約時|(?:退去時|退居時)可/.test(text)) return "契約時または退去時";
    if (/退去時費用|退去時|退居時|解約時/.test(text)) return "退去時";
    if (/契約時費用|契約時|入居時/.test(text)) return "契約時";
    if (/月額|毎月/.test(text)) return "月額";
    return "";
  }

  function freeTextFeeDiagnostics(text, sourceSection) {
    const source = normalize(text);
    if (!source) return { fees: [], skippedLines: [] };
    const fees = [];
    const skippedLines = [];
    const seenSkipped = new Set();
    let seasonalGasPending = false;
    const lines = source
      .replace(/[・◆■●]/g, "\n")
      .replace(
        /((?:円|万)[）)]?)\s+(?=[^\s、。;；\n]{1,24}(?:料|費|代|HC|ＨＣ|FF|ＦＦ|抗菌|消毒|清掃|鍵|カギ|24時間|２４時間))/g,
        "$1\n",
      )
      .split(/\n/)
      .flatMap((line) => line.split(/[、，]/))
      .map(normalize)
      .filter(Boolean);

    for (const rawLine of lines) {
      if (!/(?:[\d,]+\s*円|\d+(?:\.\d+)?\s*万(?:\s*円)?)/.test(rawLine)) continue;
      // Historical price-change notes such as "1,600円→1,800円" are not
      // current charges and must not be added to an estimate.
      if (/(?:→|->|⇒)/.test(rawLine) && (rawLine.match(/円/g) || []).length > 1) continue;
      // Guarantee conditions are parsed separately. Do not turn their
      // percentages/minimums into ordinary broker-note fees.
      if (/保証人(?:あり|有|なし|無)|最低保証料|初回保証料|月額保証料|月額更新料|保証委託料|保証料/.test(rawLine)) continue;
      if (/賃料\s*[\d,]+\s*円\s*(?:DOWN|DOWN可|値下げ|値引)/i.test(rawLine)) continue;
      if (
        !/(?:料|費|代|駐車場|清掃|消毒|交換|整備|サポート|サービス|HC|ＨＣ|FF|ＦＦ|抗菌|鍵|カギ|24時間|２４時間)/.test(rawLine)
        && !(seasonalGasPending && /^\d{1,2}月\s*[〜～~-]\s*\d{1,2}月[^。\n]{0,12}?[\d,]+\s*円/.test(rawLine))
      ) continue;

      let specialHandled = false;
      const seasonalGas = rawLine.match(/(ガス料金(?:は)?(?:定額|上限)[^。\n]{0,36}?)([\d,]+)\s*円/)
        || (seasonalGasPending ? rawLine.match(/^((?:\d{1,2}月\s*[〜～~-]\s*\d{1,2}月)[^。\n]{0,12}?)([\d,]+)\s*円/) : null);
      if (seasonalGas) {
        const gasText = `${seasonalGas[1]} ${seasonalGas[2]}円`;
        const gasFee = parseFeeLine(gasText, sourceSection) || {
          label: normalize(seasonalGas[1]),
          amount: Number(seasonalGas[2].replace(/,/g, "")),
          timing: "choice",
          type: "remark",
          category: "remark",
          optional: false,
          noInitialEstimate: true,
          confidence: "high",
          sourceSection,
          sourceText: rawLine,
        };
        if (gasFee.amount) {
          gasFee.label = normalize(seasonalGas[1]);
          gasFee.type = "remark";
          gasFee.category = "remark";
          gasFee.noInitialEstimate = true;
          gasFee.sourceText = rawLine;
          gasFee.sourceSection = sourceSection;
          fees.push(gasFee);
          specialHandled = true;
        }
        seasonalGasPending = /定額/.test(rawLine);
      } else {
        seasonalGasPending = false;
      }

      const secondParking = rawLine.match(/(駐車場\s*(?:2|２)台目)[^。\n]{0,20}?(?:月額|月)?\s*([\d,]+)\s*円/);
      if (secondParking) {
        const parkingFee = parseFeeLine(`${secondParking[1]} 月額 ${secondParking[2]}円`, sourceSection);
        if (parkingFee) {
          parkingFee.optional = true;
          parkingFee.type = "optionalMonthly";
          parkingFee.sourceText = rawLine;
          parkingFee.sourceSection = sourceSection;
          fees.push(parkingFee);
          specialHandled = true;
        }
      }

      const lineTimingText = explicitTimingText(rawLine);
      const sharedTiming = inferTiming(rawLine, "");
      const directPetRent = parseFeeLine(rawLine, sourceSection);
      if (directPetRent?.label === "ペット飼育時賃料増額") {
        directPetRent.sourceText = rawLine;
        directPetRent.sourceSection = sourceSection;
        fees.push(directPetRent);
        continue;
      }
      const matches = Array.from(rawLine.matchAll(FEE_ENTRY_PATTERN));
      if (!matches.length) {
        if (specialHandled) continue;
        if (allMoney(rawLine).length === 1 && sourceSection !== "保証会社") {
          const genericFee = parseFeeLine(rawLine, sourceSection);
          if (genericFee) {
            genericFee.sourceText = rawLine;
            genericFee.sourceSection = sourceSection;
            fees.push(genericFee);
            continue;
          }
        }
        const skipped = skippedFeeLine({ section: sourceSection, text: rawLine });
        const key = `${skipped.reason}|${skipped.text}`;
        if (!seenSkipped.has(key)) {
          skippedLines.push(skipped);
          seenSkipped.add(key);
        }
        continue;
      }

      for (const match of matches) {
        const label = normalize(match[1])
          .replace(/^○\s*/, "")
          .replace(/^[\s:：,，、。・-]+/, "")
          .replace(/^.*?(?:退去時費用|契約時費用|入居時費用)\s*[:：]\s*/, "")
          .replace(/^.*?[:：]\s*/, "")
          .replace(/^(?:退去時|契約時|入居時|月額)\s*/, "")
          .trim();
        const timingText = normalize(lineTimingText || match[2] || nearbyTimingText(rawLine, match.index || 0, sharedTiming));
        const parsed = parseFeeLine(
          `${label} ${timingText} ${match[3]}`,
          sourceSection,
        );
        if (parsed) {
          if (/ペット|飼育/.test(`${label} ${timingText}`)) {
            parsed.category = "petFee";
            parsed.optional = true;
            parsed.type = parsed.timing === "monthly" ? "optionalMonthly" : "optional";
          }
          parsed.sourceText = rawLine;
          parsed.sourceSection = sourceSection;
          fees.push(parsed);
        } else {
          const skipped = skippedFeeLine({ section: sourceSection, text: rawLine });
          const key = `${skipped.reason}|${skipped.text}`;
          if (!seenSkipped.has(key)) {
            skippedLines.push(skipped);
            seenSkipped.add(key);
          }
        }
      }
    }
    return { fees, skippedLines };
  }

  function freeTextFees(text, sourceSection) {
    return freeTextFeeDiagnostics(text, sourceSection).fees;
  }

  function brokerNoteFees(bodyText) {
    const section = brokerNoteSection(bodyText);
    if (!section) return [];
    return freeTextFees(section, "客付業者様へ");
  }

  function parseFeeLine(line, section) {
    const text = normalize(line);
    if (!text) return null;
    const amounts = allMoney(text);
    if (!amounts.length || amounts[0] <= 0) return null;

    if (REMARK_FEE_PATTERN.test(text)) {
      const amountMatch = text.match(/(?:[\d,]+\s*円|\d+(?:\.\d+)?\s*万(?:\s*円)?)/);
      const remarkLabel = normalize(text.slice(0, amountMatch?.index ?? text.length))
        .replace(/契約時(?:または|もしくは|又は)退去時|退去時(?:または|もしくは|又は)契約時/g, " ")
      .replace(/(?:契約時|入居時|退去時(?:払い|支払|精算)?|月額|毎月|年額|更新時|税込|非課税|課税|\(|\)|\/)+/g, " ")
        .replace(/(?:または|もしくは|又は)/g, " ")
        .replace(/\s+/g, " ")
        .trim();
      if (/事務手数料/.test(remarkLabel) && !/更新事務手数料|契約更新事務手数料/.test(remarkLabel)) return null;
      if (remarkLabel && remarkLabel.length <= 50) {
        return {
          label: remarkLabel,
          amount: amounts[0],
          timing: "remark",
          type: "remark",
          category: "remark",
          optional: false,
          noInitialEstimate: true,
          confidence: "high",
          sourceSection: section || "諸費用",
          sourceText: text,
        };
      }
    }

    if (isNonCustomerFee(text)) return null;

    const petRentUp = text.match(/ペット[^。・\n\r]{0,24}?賃料\s*([\d,]+)\s*円\s*(?:UP|増額)/i);
    if (petRentUp) {
      return {
        label: "ペット飼育時賃料増額",
        amount: Number(petRentUp[1].replace(/,/g, "")),
        timing: "monthly",
        type: "optionalMonthly",
        category: "unregistered",
        optional: true,
        confidence: "high",
        sourceSection: section || "諸費用",
        sourceText: text,
      };
    }

    if (/賃料\s*[\d,]+\s*円\s*(?:DOWN|DOWN可|値下げ|値引)/i.test(text)) return null;

    const amountMatch = text.match(/(?:[\d,]+\s*円|\d+(?:\.\d+)?\s*万(?:\s*円)?)/);
    const beforeAmount = normalize(text.slice(0, amountMatch?.index ?? text.length));
    let label = beforeAmount
      .replace(/契約時(?:または|もしくは|又は)退去時|退去時(?:または|もしくは|又は)契約時/g, " ")
      .replace(/(?:契約時|入居時|退去時(?:払い|支払|精算)?|月額|毎月|年額|税込|非課税|課税|\(|\)|\/)+/g, " ")
      .replace(/(?:または|もしくは|又は)/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    if (!label || label.length > 50) return null;

    const category = inferCategory(label, text);
    if (!category && !/[料費代金]|サポート|サービス|クラブ|清掃|消毒|整備|交換|消火剤|防災グッズ|投てき/.test(label)) {
      return null;
    }

    const inferredTiming = category === "remark"
      ? "remark"
      : category === "monthlyGuaranteeFee"
        ? "monthly"
        : inferTiming(text, section);
    const recurringCategory = ["supportFee", "townFee", "gasLeaseFee"].includes(category);
    const timing = recurringCategory && !/(?:契約時|入居時|退去時|解約時)/.test(text) ? "monthly" : inferredTiming;
    const optional = isOptional(text) || category === "petFee";
    const type = timing === "monthly" && optional ? "optionalMonthly" : optional ? "optional" : timing === "monthly" ? "monthly" : "initial";
    const confidence = category ? "high" : "medium";
    return {
      label,
      amount: amounts[0],
      timing,
      type,
      category: category || "unregistered",
      optional,
      confidence,
      sourceSection: section || "諸費用",
      sourceText: text,
    };
  }

  function diagnosticFee(fee) {
    return {
      label: fee.label,
      amount: fee.amount,
      timing: fee.timing,
      type: fee.type,
      category: fee.category || "",
      optional: Boolean(fee.optional),
      confidence: fee.confidence || "",
      sourceSection: fee.sourceSection || "",
      sourceText: fee.sourceText || "",
    };
  }

  function feeDiagnostics(fees) {
    const classifiedFees = fees.map(diagnosticFee);
    return {
      classifiedFees,
      unregisteredFees: classifiedFees.filter((fee) => fee.category === "unregistered"),
      remarkFees: classifiedFees.filter((fee) => fee.category === "remark"),
      choiceFees: classifiedFees.filter((fee) => fee.timing === "choice"),
      moveoutFees: classifiedFees.filter((fee) => fee.timing === "moveout"),
      monthlyFees: classifiedFees.filter((fee) => fee.timing === "monthly"),
    };
  }

  function guaranteeDiagnostics(guarantee) {
    return {
      required: Boolean(guarantee.required),
      fixed: guarantee.fixed || 0,
      initialRate: guarantee.initialRate || 0,
      initialMinimum: guarantee.initialMinimum || 0,
      monthlyRate: guarantee.monthlyRate || 0,
      monthlyMinimum: guarantee.monthlyMinimum || 0,
      monthlyFixed: guarantee.monthlyFixed || 0,
      monthlyFixedExtra: guarantee.monthlyFixedExtra || 0,
      renewalAmount: guarantee.renewalAmount || 0,
      renewalPeriod: guarantee.renewalPeriod || "none",
      needsChoice: Boolean(guarantee.needsChoice),
      alternatives: Array.isArray(guarantee.alternatives) ? guarantee.alternatives : [],
      confidence: guarantee.confidence || "",
      note: guarantee.note || "",
      sourceText: guarantee.note || "",
      warnings: Array.isArray(guarantee.warnings) ? guarantee.warnings : [],
    };
  }

  function skippedFeeLine(line) {
    const text = normalize(line.text || line);
    let reason = "分類対象外";
    if (isNonCustomerFee(text)) reason = "顧客請求対象外";
    else if (!allMoney(text).length) reason = "金額なし";
    return {
      section: line.section || "",
      text,
      reason,
    };
  }

  const GUARANTEE_MONEY_PATTERN = "(?:[\\d,]+\\s*円|\\d+(?:\\.\\d+)?\\s*万(?:\\s*円)?)";
  const GUARANTEE_MONTHLY_WORDS = /月額|月次|毎月|月々|毎月継続|継続保証|口座振替|口振|引落|決済|収納代行|支払手数料|集送金手数料/;
  const GUARANTEE_INITIAL_WORDS = /初回|契約時|保証委託料|初回保証料|初回保証委託料|新規契約時/;

  function firstGuaranteeRate(value, patterns) {
    for (const pattern of patterns) {
      const match = value.match(pattern);
      if (match?.[1]) return Number(match[1]);
    }
    return 0;
  }

  function guaranteeInitialMinimum(value, initialRate, allowDistantMinimum = true) {
    let minimum = 0;
    const patterns = [
      new RegExp(`(?:最低保証料|最低|下限)[^。・\\n\\r]{0,32}?${GUARANTEE_MONEY_PATTERN}`, "g"),
      new RegExp(`${GUARANTEE_MONEY_PATTERN}[^。・\\n\\r]{0,32}?(?:最低保証料|最低|下限)`, "g"),
    ];
    for (const pattern of patterns) {
      for (const match of value.matchAll(pattern)) {
        const amount = money(match[0]);
        if (!amount) continue;
        const local = value.slice(Math.max(0, match.index - 48), match.index + match[0].length + 48);
        const before = value.slice(Math.max(0, match.index - 120), match.index);
        const sameClause = value.slice(Math.max(0, match.index - 120), match.index).split(/[。,，、;；]/).pop() || "";
        // A monthly update fee may follow an initial minimum in the same clause.
        // Only treat the minimum as monthly when the monthly marker is before it.
        const beforeMinimum = value.slice(Math.max(0, match.index - 64), match.index);
        const monthlyNear = GUARANTEE_MONTHLY_WORDS.test(beforeMinimum)
          || /(?:%|パーセント|円)\s*[/／]\s*月/.test(beforeMinimum);
        const initialNear = Boolean(initialRate) || /初回|契約時|保証委託料|保証人(?:あり|有|なし|無)|(?:^|[・\s])保証料/.test(sameClause);
        if (amount < 10000 && monthlyNear) continue;
        if (monthlyNear && !initialNear && !(allowDistantMinimum && initialRate)) continue;
        if (!initialNear && !(allowDistantMinimum && initialRate)) continue;
        if (initialRate || initialNear) minimum = Math.max(minimum, amount);
      }
    }
    return minimum;
  }

  function guaranteeFixedInitial(value, initialRate) {
    if (initialRate) return 0;
    const patterns = [
      new RegExp(`(?:初回保証料|初回保証委託料|初回保証委託事務手数料|基本保証料|基本保証委託料|保証委託料|保証料|保証会社事務手数料)[^。・\\n\\r%]{0,60}?(?:一律|定額)\\s*[:：]?\\s*(${GUARANTEE_MONEY_PATTERN})`, "g"),
      new RegExp(`(?:一律|定額)\\s*(${GUARANTEE_MONEY_PATTERN})[^。・\\n\\r%]{0,60}?(?:初回保証料|初回保証委託料|初回保証委託事務手数料|保証委託料|保証料|保証会社)`, "g"),
      new RegExp(`(?:初回保証料|初回保証委託料|初回保証委託事務手数料|基本保証料|基本保証委託料|保証委託料|保証会社事務手数料)\\s*[】］\\]]?\\s*[:：]?\\s*(${GUARANTEE_MONEY_PATTERN})`, "g"),
    ];
    for (const pattern of patterns) {
      for (const match of value.matchAll(pattern)) {
        const chunk = value.slice(Math.max(0, match.index - 24), match.index + match[0].length);
        if (/最低|下限|%|パーセント/.test(chunk)) continue;
        if (/月額|月次|毎月|月々|更新|年間|年額/.test(chunk) && !/初回|新規契約時|契約時/.test(chunk)) continue;
        const amount = money(match[1]);
        if (amount) return amount;
      }
    }
    return 0;
  }

  function guaranteeMonthlyFixed(value, monthlyRate) {
    if (monthlyRate) return 0;
    const patterns = [
      new RegExp(`(?:月額保証料|月次保証料|月額保証委託料|月次保証委託料|月額保証委託事務手数料|毎月保証料|月々保証料)[^。・\\n\\r%]{0,80}?(${GUARANTEE_MONEY_PATTERN})`, "g"),
      new RegExp(`(?:月額更新保証料|月額更新料|月額継続保証料)[^。・\\n\\r%]{0,40}?(${GUARANTEE_MONEY_PATTERN})`, "g"),
      new RegExp(`月額費用[^。・\\n\\r%]{0,80}?(?:更新保証料|更新料|継続保証料)[^。・\\n\\r%]{0,24}?(${GUARANTEE_MONEY_PATTERN})`, "g"),
      new RegExp(`(?:更新保証料|更新料|継続保証料)[^。・\\n\\r%\\d]{0,40}?(?:月額制|月額|毎月|月々|月\\s*[/／]|[/／]\\s*月)[^。・\\n\\r%]{0,24}?(${GUARANTEE_MONEY_PATTERN})`, "g"),
      new RegExp(`(?:更新保証料|更新料|継続保証料)[^。・\\n\\r%]{0,40}?(${GUARANTEE_MONEY_PATTERN})\\s*(?:[/／]\\s*月|\\(月額\\)|（月額）)`, "g"),
      new RegExp(`月額費用[^。・\\n\\r%]{0,80}?(${GUARANTEE_MONEY_PATTERN})`, "g"),
      new RegExp(`(?:月額|毎月|月々)\\s*[:：]?\\s*(${GUARANTEE_MONEY_PATTERN})`, "g"),
      new RegExp(`(?:^|[（(・\\s])月\\s*(${GUARANTEE_MONEY_PATTERN})`, "g"),
    ];
    for (const pattern of patterns) {
      for (const match of value.matchAll(pattern)) {
        const after = value.slice(match.index + match[0].length, match.index + match[0].length + 12);
        const before = value.slice(Math.max(0, match.index - 56), match.index);
        const choiceWindow = value.slice(Math.max(0, match.index - 120), match.index + match[0].length + 40);
        const monthlyPaymentSyntax = /\/\s*月|／\s*月|月\s*[/／]|\(月額\)|（月額）/.test(
          value.slice(Math.max(0, match.index - 24), match.index + match[0].length + 24),
        );
        const monthlyContext = monthlyPaymentSyntax
          || /月額費用[^。・\n\r]{0,80}$/.test(before)
          || /(?:月額|月次|毎月|月々)[^。・\n\r]{0,24}$/.test(before);
        const updateMatch = /(?:更新保証料|更新料|継続保証料)/.test(match[0]);
        const feeDescriptor = `${before.split(/[+＋。・,，、;；]/).pop() || ""}${match[0]}`;
        if (!updateMatch && /(?:月額手数料|月額事務手数料|支払手数料|集送金手数料|集金代行(?:サービス)?料|収納代行手数料|決済手数料|口座振替|口振|引落(?:し|とし)?手数料|引き落とし手数料)/.test(feeDescriptor)) continue;
        if (/(?:更新保証料|更新料|継続保証料)[^。・\n\r]{0,60}?(?:年額|年間)[^。・\n\r]{0,24}?(?:または|もしくは|又は|\bor\b)[^。・\n\r]{0,24}?月額/i.test(choiceWindow)) continue;
        if (updateMatch && /(?:年間|年次|年額|年毎|1年毎|毎年)[^。・\n\r]{0,16}?(?:更新保証料|更新料|継続保証料)/.test(`${before}${match[0]}`)) continue;
        if (/\/年|／年|年額|年間|年毎/.test(after) && !/月額|月次|毎月|月々|\/月|／月|月\s*[/／]/.test(`${match[0]}${after}`)) continue;
        // "更新料: 年額15,000円もしくは月額1,000円" is an update-fee
        // payment choice, not a monthly guarantee fee.
        if (updateMatch && /更新料|年間|年額|年次|年毎/.test(`${before}${match[0]}`) && !monthlyContext && !/(?:月額|月次|毎月|月々)(?:保証|更新料)|月\s*[/／]|月額手数料|月額事務手数料|引落|口振|決済/.test(`${before}${match[0]}`)) continue;
        if (
          /最低|下限|家賃等|賃料等|賃料総額/.test(match[0]) ||
          (updateMatch && /更新|年間|年額/.test(match[0]) && !monthlyContext && !/(?:月額|月次|毎月|月々|\\(月額\\)|（月額）|\/月|月\s*[/／])/.test(match[0]))
        ) continue;
        const amount = money(match[1]);
        if (amount) return amount;
      }
    }
    return 0;
  }

  function guaranteeMonthlyMinimum(value, monthlyRate) {
    if (!monthlyRate) return 0;
    const patterns = [
      new RegExp(
        `(?:月額保証料|月次保証料|月額保証委託料|月次保証委託料|毎月保証料|月々保証料|毎月継続保証料|継続保証料)`
        + `[^。・\\n\\r]{0,100}?(?:最低保証料|最低額|最低|下限)[^。・\\n\\r]{0,24}?(${GUARANTEE_MONEY_PATTERN})`,
        "g",
      ),
      new RegExp(
        `\\d+(?:\\.\\d+)?\\s*(?:%|パーセント)\\s*[/／]\\s*月\\s*(?:\\(|（)?`
        + `(?:最低保証料|最低額|最低|下限)[^。・\\n\\r]{0,24}?(${GUARANTEE_MONEY_PATTERN})`,
        "g",
      ),
      new RegExp(
        `(?:月更新|月額更新|月次更新)[^。・\\n\\r%]{0,80}?\\d+(?:\\.\\d+)?\\s*(?:%|パーセント)`
        + `[^。・\\n\\r]{0,40}?(?:最低保証料|最低額|最低|下限)[^。・\\n\\r]{0,24}?(${GUARANTEE_MONEY_PATTERN})`,
        "g",
      ),
    ];
    return patterns.reduce(
      (maximum, pattern) => Array.from(value.matchAll(pattern)).reduce(
        (current, match) => Math.max(current, money(match[1])),
        maximum,
      ),
      0,
    );
  }

  function guaranteeMonthlyFixedExtra(value, monthlyRate) {
    // Account-debit fees are an extra monthly charge whether the provider
    // uses a percentage plan or only an initial guarantee plan.
    const directPattern = new RegExp(`(?:月額手数料|月額事務手数料|支払手数料|集送金手数料|集金代行(?:サービス)?料|収納代行手数料|決済手数料|[A-Za-zＡ-Ｚ一-龠ぁ-んァ-ヶー]{0,24}利用手数料\\s*(?:\\(月額\\)|（月額）)|口座振替(?:時に)?(?:サービス)?(?:利用)?(?:時に)?(?:手数料|料)|口振手数料|口振(?:サービス)?(?:利用)?料|引落(?:し|とし)?手数料|引き落とし手数料|引落(?:サービス)?(?:利用)?料)[^。・\\n\\r%]{0,80}?(${GUARANTEE_MONEY_PATTERN})`, "g");
    const directAmount = Array.from(value.matchAll(directPattern)).reduce((sum, match) => sum + money(match[1]), 0);
    if (directAmount) return directAmount;
    const pattern = new RegExp(`(?:\\+|＋)\\s*[^+＋\\d円]{0,16}?(${GUARANTEE_MONEY_PATTERN})`, "g");
    return Array.from(value.matchAll(pattern)).reduce((sum, match) => {
      if (/継続保証料|月額保証料|月次保証料|毎月保証料|月々保証料|年間更新料|年更新料|更新保証料|更新料/.test(match[0])) return sum;
      return sum + money(match[1]);
    }, 0);
  }

  function guaranteeRenewalAmount(value) {
    const barePattern = /(?:年間更新料|年更新料|年更新|年次更新|更新時|年間保証料|更新保証料|更新料)\s*[:：]?\s*((?:[1-9]\d{0,2}(?:,\d{3})+)|(?:[1-9]\d{3,5}))(?![\d.%])/g;
    for (const bareAmount of value.matchAll(barePattern)) {
      const before = value.slice(Math.max(0, bareAmount.index - 24), bareAmount.index);
      if (/(?:月額|月次|毎月|月々)\s*$/.test(before)) continue;
      return Number(bareAmount[1].replace(/,/g, ""));
    }
    const patterns = [
      new RegExp(`(?:年間更新料|年更新料|年更新|年次更新|更新時|更新料)\\s*[:：]?[^。・\\n\\r]{0,12}?(${GUARANTEE_MONEY_PATTERN})`, "g"),
      new RegExp(`(?:年間更新料|年次保証料|年間保証料|更新保証料|更新料|更新)[^。・\\n\\r]{0,28}?(${GUARANTEE_MONEY_PATTERN})[^。・\\n\\r]{0,16}?(?:[/／]\\s*年|1年(?:毎|ごと)|年(?:毎|ごと)|年間|年額|年次)`, "g"),
      new RegExp(`(?:年間|年次)[^。・\\n\\r]{0,20}?(?:更新料|保証料)[^。・\\n\\r]{0,28}?(${GUARANTEE_MONEY_PATTERN})`, "g"),
      new RegExp(`(?:年間更新料|年次保証料|年間保証料|更新保証料|継続保証委託料|継続保証料|更新料|更新)[^。・\\n\\r]{0,28}?(?:毎年|1年(?:毎|ごと)|年(?:毎|ごと)|年間|年額|年次)[^。・\\n\\r]{0,28}?(${GUARANTEE_MONEY_PATTERN})`, "g"),
      new RegExp(`(?:毎年|1年(?:毎|ごと)|年(?:毎|ごと)|年間|年額|年次)[^。・\\n\\r]{0,28}?(?:年間更新料|年次保証料|年間保証料|更新保証料|継続保証委託料|継続保証料|更新料|更新)[^。・\\n\\r]{0,28}?(${GUARANTEE_MONEY_PATTERN})`, "g"),
      new RegExp(`(?:更新保証料|継続保証料|更新料)[^。・\\n\\r]{0,28}?(${GUARANTEE_MONEY_PATTERN})(?=\\s*(?:or|または|もしくは|又は))`, "gi"),
      // Compact forms often put the annual amount after a monthly amount:
      // "継続保証料:毎月800円・毎年12,000円".
      new RegExp(`(?:毎年|1年(?:毎|ごと)|年(?:毎|ごと)|年額|年次)\\s*(${GUARANTEE_MONEY_PATTERN})`, "g"),
    ];
    for (const pattern of patterns) {
      for (const match of value.matchAll(pattern)) {
        const before = value.slice(Math.max(0, match.index - 24), match.index);
        if (
          /月額|月次|毎月|月々|\\(月額\\)|（月額）/.test(match[0])
          || /(?:月額|月次|毎月|月々)\s*$/.test(before)
        ) continue;
        const amount = money(match[1]);
        if (amount) return amount;
      }
    }
    return 0;
  }

  function guaranteeMonthlyRate(value) {
    const rentMonthlyPattern = /(?:賃料総額|賃料合計|月額賃料等|月額家賃等|総賃料|賃料等|家賃等)\s*(\d+(?:\.\d+)?)\s*%(?:\s*[〜～~\-]\s*\d+(?:\.\d+)?\s*%)?[^初回%。・\n\r]{0,24}?\s*(?:月次|月額|毎月|月々)/;
    const explicitPatterns = [
      /(?:月更新|月額更新|月次更新)[^。・\n\r%]{0,80}?(\d+(?:\.\d+)?)\s*(?:%|パーセント)/,
      /(?:月額総支払額|総支払額|支払総額|賃料総額|賃料合計|月額賃料等|月額家賃等|総賃料|賃料等|家賃等|総額)(?:の)?\s*(\d+(?:\.\d+)?)\s*(?:%|パーセント)\s*[/／]\s*月/,
      /(?:月額総支払額|総支払額|支払総額|賃料総額|賃料合計|月額賃料等|月額家賃等|総賃料|賃料等|家賃等|総額)(?:の)?\s*(\d+(?:\.\d+)?)\s*(?:%|パーセント)(?:(?!初回|契約時|月額保証|月次保証|毎月保証|月々保証)[^。・\n\r]){0,48}?(?:毎月かかり|毎月発生|毎月請求|月額請求|月次請求)/,
      /(?:更新保証料|継続保証料|更新料)[^。・\n\r%]{0,80}?(\d+(?:\.\d+)?)\s*(?:%|パーセント)\s*(?:[/／]\s*)?(?:毎月払い|月払い|毎月|月額)/,
      /(?:月額保証料|月次保証料|月額保証委託料|月次保証委託料|月額保証委託事務手数料|毎月保証委託料|月額手数料|月額事務手数料|\[毎月\]保証料|毎月保証料|月々保証料|毎月継続保証料|継続保証料|支払手数料|収納代行手数料|決済手数料|月々決済手数料|毎月決済手数料|月額(?=\s*[:：])|月額\s*\/)(?:(?!初回(?:保証|\s*保証)?|契約時保証|基本保証|【|［|\[)[^。・\n\r%]){0,100}?(\d+(?:\.\d+)?)\s*(?:%|パーセント)/,
      /(?:毎月|月額|月次)\s*(?:の)?(?:総支払額|支払総額|賃料合計|賃料総額|総賃料|家賃等|賃料等)[^。・\n\r%]{0,24}?(\d+(?:\.\d+)?)\s*(?:%|パーセント)/,
      rentMonthlyPattern,
    ];
    for (const pattern of explicitPatterns) {
      const match = value.match(pattern);
      if (!match?.[1]) continue;
      const before = value.slice(Math.max(0, (match.index || 0) - 80), match.index || 0);
      const sameClause = before.split(/[。・,，、;；]/).pop() || "";
      if (
        /初回|契約時/.test(sameClause)
        && !/(?:月更新|月額更新|月次更新|月額保証|月次保証|毎月保証|更新保証|継続保証|[/／]\s*月)/.test(match[0])
      ) continue;
      if (pattern === rentMonthlyPattern) {
        if (/初回|契約時|保証人(?:有|無)/.test(sameClause)) continue;
      }
      return Number(match[1]);
    }

    // This fallback supports compact forms such as "初回50%・月額1.5%".
    // Do not cross another initial-guarantee marker, otherwise a second
    // company's 50% can be mistaken for the first company's monthly rate.
    const fallback = value.match(
      /(?:初回|初回保証料|契約時)[^。・\n\r]{0,50}?(?:%|パーセント)[^。・\n\r]{0,30}?(?:月額|毎月|月々)(?![^。・\n\r]{0,32}(?:初回|保証会社))[^。・\n\r%]{0,60}?(\d+(?:\.\d+)?)\s*(?:%|パーセント)/,
    );
    return fallback?.[1] ? Number(fallback[1]) : 0;
  }

  function guaranteeBlock(value, required, allowDistantMinimum = true) {
    // Remove a monthly "保証委託料" clause before detecting the initial rate.
    // Some providers write "契約時保証委託料:22,000円/月額保証委託料:2.2%",
    // and a broad initial-rate pattern must not cross into the monthly clause.
    const initialSource = value.replace(
      /(?:月額|月次|毎月|月々)\s*保証委託料[^。・\n\r]*/g,
      " ",
    );
    let initialRate = firstGuaranteeRate(initialSource, [
      /(?:賃料総額|賃料合計|月額賃料等|月額家賃等|総賃料|賃料等|家賃等)\s*(\d+(?:\.\d+)?)\s*%(?:\s*[〜～\-]\s*\d+(?:\.\d+)?\s*%)?[^初回。・\n\r]{0,24}?\s*(?:初回|契約時)/,
      /(?:初回|毎年|年間)(?:[^%\n\r]{0,24})?(?:賃料総額|賃料合計|月額賃料等|月額家賃等|総賃料|賃料等|家賃等)[^%\n\r]{0,24}?(\d+(?:\.\d+)?)\s*(?:%|パーセント)/,
      /(?:賃料総額|賃料合計|月額賃料等|月額家賃等|総賃料|賃料等|家賃等)\s*(\d+(?:\.\d+)?)\s*%(?:\s*[〜～\-]\s*\d+(?:\.\d+)?\s*%)?[^。・\n\r]{0,24}?\s*(?:初回|契約時)/,
      /(?:初回保証料|初回保証委託料|初回保証委託事務手数料|基本保証料|基本保証委託料|契約時保証料|初回保証会社保証料|保証委託料|初回|契約時)(?![^。・\n\r]{0,80}?(?:月額|月次|毎月|月々)保証委託料)[^。・\n\r/%円]{0,80}?(\d+(?:\.\d+)?)\s*(?:%|パーセント)/,
      /(?:^|[・\s])保証料\s*(\d+(?:\.\d+)?)\s*(?:%|パーセント)/,
      /(?:^|[■〇○●])[^。・\n\r]{0,48}?保証料\s*[:：]?\s*(\d+(?:\.\d+)?)\s*(?:%|パーセント)/,
      /(?:^|[■〇○●\s])保証料\s*[:：]?\s*(\d+(?:\.\d+)?)\s*(?:%|パーセント)/,
      /連帯保証人(?:あり|有)[^。・\n\r%]{0,12}?(\d+(?:\.\d+)?)\s*(?:%|パーセント)/,
      /保証人(?:あり|有|なし|無)[^。・\n\r%]{0,32}?(?:家賃等全額|賃料総額|賃料等|家賃等)?[^。・\n\r%]{0,16}?(\d+(?:\.\d+)?)\s*(?:%|パーセント)/,
      /(?:初回|契約時)[^。・\n\r]{0,80}?(?:月額賃料等|月額家賃等|賃料合計|賃料総額|総賃料|賃料等|家賃等)[^。・\n\r%]{0,40}?(\d+(?:\.\d+)?)\s*(?:%|パーセント)/,
      /(?:月額賃料等|月額家賃等|賃料合計|賃料総額|総賃料|賃料等|家賃等)[^。・\n\r%]{0,40}?(\d+(?:\.\d+)?)\s*(?:%|パーセント)[^。・\n\r]{0,40}?(?:初回|契約時)/,
    ]);
    if (/(?:初回保証料|初回保証委託料|初回委託料)\s*[:：]?\s*(?:無|なし|不要)/.test(value)) {
      initialRate = 0;
    }
    const directInitialFixed = new RegExp(
      `(?:初回保証料|初回保証委託料|初回保証委託事務手数料|基本保証料|基本保証委託料|契約時保証料)`
      + `\\s*[】］\\]]?\\s*[:：]?\\s*${GUARANTEE_MONEY_PATTERN}`,
    ).test(value);
    if (directInitialFixed) initialRate = 0;
    const fixed = guaranteeFixedInitial(value, initialRate);
    const monthlyRate = guaranteeMonthlyRate(value);
    const initialRateThenMonthlyMoney = new RegExp(
      `初回\\s*\\d+(?:\\.\\d+)?\\s*(?:%|パーセント)[^。\\n\\r]{0,40}?(?:月|月額)\\s*${GUARANTEE_MONEY_PATTERN}`,
    ).test(value);
    const explicitPercentPerMonth = /\\d+(?:\\.\\d+)?\\s*(?:%|パーセント)\\s*[/／]\\s*月/.test(value);
    const safeMonthlyRate = initialRateThenMonthlyMoney && !explicitPercentPerMonth ? 0 : monthlyRate;
    const monthlyMinimum = guaranteeMonthlyMinimum(value, safeMonthlyRate);
    const monthlyFixed = guaranteeMonthlyFixed(value, safeMonthlyRate);
    const renewalAmount = guaranteeRenewalAmount(value);
    return {
      required,
      fixed,
      initialRate,
      initialMinimum: guaranteeInitialMinimum(value, initialRate, allowDistantMinimum),
      monthlyRate: safeMonthlyRate,
      monthlyMinimum,
      monthlyFixed,
      monthlyFixedExtra: guaranteeMonthlyFixedExtra(value, safeMonthlyRate),
      renewalAmount,
      renewalPeriod: renewalAmount ? "annual" : "none",
      confidence: value ? "medium" : "low",
      note: value,
      warnings: guaranteeWarnings(value, {
        initialRate,
        fixed,
        monthlyRate: safeMonthlyRate,
        monthlyMinimum,
        monthlyFixed,
        renewalAmount,
      }),
    };
  }

  function guaranteeWarnings(value, terms) {
    const source = String(value || "");
    const warnings = [];
    const initialClause = source.split(/更新|年間更新|月額|月次|毎月|月々/)[0];
    if (terms.initialRate && /(?:初回|契約時)[^。・\n\r]{0,32}(?:一律|定額)[^。・\n\r]{0,24}(?:円|万\s*円)/.test(initialClause)) {
      warnings.push("初回保証料に料率と定額の両方の表記があります。定額か料率か確認してください。");
    }
    if (terms.monthlyRate && terms.monthlyFixed && !/[+＋]/.test(source)) {
      warnings.push("月額保証料に料率と定額の両方の表記があります。合算条件か別プランか確認してください。");
    }
    if (terms.monthlyMinimum) {
      warnings.push("月額保証料の最低額を読み取りました。適用条件を確認してください。");
    }
    if (terms.monthlyRate && /(?:更新料|年間更新料|年次保証料|年間保証料)/.test(source)) {
      warnings.push("更新料・年額保証料の記載があります。月額保証料とは分離して扱っています。");
    }
    if (terms.renewalAmount && (terms.monthlyRate || terms.monthlyFixed)
      && /いずれか|または|もしくは|又は/.test(source)) {
      warnings.push("月額払いと年額払いの選択条件があります。利用する支払方法を確認してください。");
    }
    return warnings;
  }

  function guaranteeAlternativeLabel(value, position) {
    const source = normalize(value);
    const diamondProvider = source.match(
      /^◆\s*([^◆\[\]［］【】]{2,48}?)(?=\s*(?:\[|［|【|初回|契約時|月額|月次|保証料|保証委託))/,
    );
    if (diamondProvider?.[1]) return diamondProvider[1].trim();
    if (/^(?:尚[、,]\s*)?(?:二次|2次)審査/.test(source)) {
      return /毎年プラン|年間プラン|年払いプラン/.test(source)
        ? "二次審査（年払いプラン）"
        : "二次審査";
    }
    const fallbackProvider = source.match(
      /^(?:[1-6①②③④⑤⑥]\s*)?[^。・\n\r]{0,36}?(?:不可|利用不可)(?:の場合)?[、，,]\s*([一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ][一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ0-9０-９ _-]{1,31}?)(?=\s+(?:初回|契約時|月額|月次|保証料|保証委託))/,
    );
    if (fallbackProvider?.[1]) return fallbackProvider[1].trim();

    const bracketProvider = source.match(
      /[【［\[]([^】］\]]{2,32})[】］\]](?=[^。・\n\r]{0,64}?(?:初回|契約時|月額|月次|保証料|保証委託))/,
    );
    if (bracketProvider?.[1]
      && !/(?:初回保証|月額保証|月次保証|更新保証|更新料|月額費用|支払手数料|収納代行手数料)/.test(bracketProvider[1])) {
      return bracketProvider[1].trim();
    }
    const angleProvider = source.match(
      /≪([^≫]{2,32})≫(?=[^。・\n\r]{0,64}?(?:初回|契約時|月額|月次|保証料|保証委託))/,
    );
    if (angleProvider?.[1]) return angleProvider[1].trim();

    const requiredProvider = source.match(
      /保証会社利用(?:必須|可能)?\s+([^:：。・]{2,32}?)(?=\s+(?:[【［\[])?(?:初回|契約時|月額|月次|保証料|保証委託))/,
    );
    if (requiredProvider?.[1]) return requiredProvider[1].trim();

    const compactNumberedProvider = source.match(
      /^(?:[1-6①②③④⑤⑥]\s*)?([一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ][一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ0-9０-９ _-]{1,31}?)\s*[:：]\s*(?=(?:初回|契約時|月額|月次|保証料|保証委託))/,
    );
    if (compactNumberedProvider?.[1]
      && !/(?:初回|契約時|月額|月次|保証料|保証委託)/.test(compactNumberedProvider[1])) {
      return compactNumberedProvider[1].trim();
    }

    const numberedProvider = source.match(
      /^(?:[1-6①②③④⑤⑥]\s*)?([一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ][一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ0-9０-９ _-]{1,31}?)(?=\s+(?:初回|契約時|月額|月次|保証料|保証委託))/,
    );
    if (numberedProvider?.[1]) return numberedProvider[1].trim();

    const bulletProvider = source.match(
      /^(?:[●○〇]\s*)?([一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ][一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ0-9０-９ _-]{1,31}?)\s*[:：]?\s*(?=(?:初回|契約時|月額|月次|保証料|保証委託))/,
    );
    if (bulletProvider?.[1]) return bulletProvider[1].trim();

    const colonProvider = source.match(
      /^([一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ][一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ0-9０-９ _-]{1,31}?)\s*[:：]\s*(?=(?:初回|契約時|月額|月次|保証))/,
    );
    if (colonProvider?.[1]) return colonProvider[1].trim();

    const planMarker = source.match(/^([A-ZＡ-Ｚ])\s*(?=(?:初回|契約時|保証料))/);
    if (planMarker?.[1]) return `プラン${planMarker[1]}`;
    const suretyMarker = source.match(/^(保証人(?:あり|有|なし|無))/);
    if (suretyMarker?.[1]) return suretyMarker[1];
    return `候補${position + 1}`;
  }

  function guaranteeBlocks(value) {
    // Do not split at "最低初回保証料 20,000円". Only a sentence start
    // or a list marker denotes a separate guarantee plan.
    const planMarkers = [
      ...Array.from(value.matchAll(/(?:^|[。]|[〇○●])\s*(?:初回保証料|初回保証委託料|契約時保証料|初回保証会社保証料|(?:<|〈|\(|（)初回(?:>|〉|\)|）)|[1-6](?=(?:初回|毎年|年間|[^\s]{0,6}プラン))|(?:[A-ZＡ-Ｚ]|保証人(?:あり|有|なし|無))(?=[:：]))/g)).map((match) => match.index),
      ...Array.from(value.matchAll(
        /(?:^|[。・、，,\s])([〇○●])\s*[一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ][一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ0-9０-９ _-]{1,31}\s*[:：]?\s*(?=(?:初回|契約時|月額保証|月次保証|保証料|保証委託))/g,
      )).map((match) => match.index + match[0].lastIndexOf(match[1])),
      ...Array.from(value.matchAll(
        /(?:^|[。・、，,\s])([1-6])\s*[一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ][一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ0-9０-９ _-]{1,31}\s*[:：]\s*(?=月額\s*\d+(?:\.\d+)?\s*(?:%|パーセント))/g,
      )).map((match) => match.index + match[0].lastIndexOf(match[1])),
      ...Array.from(value.matchAll(
        /(?:^|[。・、，,\s])([1-6])\s*[一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ][一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ0-9０-９ _-]{1,31}\s*[:：]\s*(?=(?:初回|契約時|月額|月次|保証料|保証委託))/g,
      )).map((match) => match.index + match[0].lastIndexOf(match[1])),
      ...Array.from(value.matchAll(
        /(?:^|[。・、，,\s])(◆)\s*[^◆\[\]［］【】]{2,48}?(?=\s*(?:\[|［|【|初回|契約時|月額|月次|保証料|保証委託))/g,
      )).map((match) => match.index + match[0].lastIndexOf(match[1])),
      ...Array.from(value.matchAll(/(?:[■〇○●]\s*)?[1-6][)）](?=[^。・\n\r]{0,48}?保証料\s*[:：]?\s*\d)/g)).map((match) => match.index),
      ...Array.from(value.matchAll(/[1-6](?=\s*(?:【|［|\[|初回|契約時|保証料))/g)).map((match) => match.index),
      ...Array.from(value.matchAll(/[1-6](?=(?:初回|毎年|年間|[^\s]{0,10}プラン))/g)).map((match) => match.index),
      ...Array.from(value.matchAll(/[①②③④⑤⑥](?=\s*(?:【|［|\[|初回|契約時|保証料))/g)).map((match) => match.index),
      // NFKC normalization changes circled list numbers to ASCII digits.
      // RealPro frequently writes a second provider as
      // "②日本セーフティー 初回保証料...". Split at that provider name.
      ...Array.from(value.matchAll(/(?:^|[。・、，,\s])([1-6])(?=\s*[一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ][一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ0-9０-９ _-]{1,31}\s+(?:初回|契約時|月額|月次|保証料|保証委託))/g))
        .map((match) => match.index + match[0].lastIndexOf(match[1])),
      // A fallback provider is often written as
      // "2エポス不可の場合、Casa 初回保証料...". The comma inside this
      // marker prevented the second provider from becoming a selectable plan.
      ...Array.from(value.matchAll(
        /(?:^|[。・、，,\s])([1-6])(?=\s*[^。・\n\r]{0,48}?(?:不可|利用不可)(?:の場合)?[、，,]\s*[一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ][一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ0-9０-９ _-]{1,31}\s+(?:初回|契約時|月額|月次|保証料|保証委託))/g,
      )).map((match) => match.index + match[0].lastIndexOf(match[1])),
      // RealPro also uses compact A/B plans such as
      // "A初回60% ... B初回80% ..." without a colon after the marker.
      ...Array.from(value.matchAll(/(?:^|[。・\s])(?:[A-ZＡ-Ｚ])\s*(?=(?:初回|契約時|保証料|賃料(?:総額|合計|等)|基本保証))/g)).map((match) => match.index),
      ...Array.from(value.matchAll(/(?:【(?!初回保証|月額保証|月次保証|年間更新|年次保証|年間保証|更新保証|更新料)[^】]{1,32}】|［(?!初回保証|月額保証|月次保証|年間更新|年次保証|年間保証|更新保証|更新料)[^］]{1,32}］|\[(?!初回保証|月額保証|月次保証|年間更新|年次保証|年間保証|更新保証|更新料)[^\]]{1,32}\])(?=[^。・\n\r]{0,64}?(?:初回保証|初回保証委託|保証料|保証委託))/g))
        .filter((match) => !/[【［\[](?:月額費用|初回費用|支払手数料|収納代行手数料|月額手数料|決済手数料|口座振替)[】］\]]/.test(match[0]))
        .map((match) => match.index),
      ...Array.from(value.matchAll(/≪(?!初回保証|月額保証|月次保証|年間更新|年次保証|年間保証|更新保証|更新料)[^≫]{1,32}≫(?=[^。・\n\r]{0,64}?(?:初回保証|初回保証委託|保証料|保証委託))/g))
        .filter((match) => !/≪(?:月額費用|初回費用|支払手数料|収納代行手数料|月額手数料|決済手数料|口座振替)≫/.test(match[0]))
        .map((match) => match.index),
      ...Array.from(value.matchAll(/[A-ZＡ-Ｚ](?=[:：]\s*(?:初回|契約時|保証料))/g)).map((match) => match.index),
      ...Array.from(value.matchAll(/保証人(?:あり|有|なし|無)(?=[:：])/g)).map((match) => match.index),
      ...Array.from(value.matchAll(/[A-Za-zＡ-Ｚ][A-Za-zＡ-Ｚ0-9０-９ _-]{1,20}(?:通常|分割|プラン)\s*[:：](?=[^。・\n\r]{0,120}?(?:初回保証|月額保証|月額費用|集送金|支払手数料))/g)).map((match) => match.index),
      ...Array.from(value.matchAll(/(?:^|[)）\s])(?:[一-龠ぁ-んァ-ヶA-Za-zＡ-Ｚ][一-龠ぁ-んァ-ヶA-Za-zＡ-Ｚ0-9０-９ _-]{0,20})(?:プラン|保証)\s*[:：](?=[^。・\n\r]{0,120}?(?:初回保証|月額保証|月額\s*[:：]))/g)).map((match) => match.index),
      ...Array.from(value.matchAll(/(?:尚[、,]\s*)?(?:二次|2次)審査[^。・\n\r]{0,48}?(?:毎年プラン|年間プラン|年払いプラン|初回保証委託料)/g)).map((match) => match.index),
      // Multiple providers are often written on one line, for example
      // "Casa:初回...、日本セーフティー:初回...". Treat each provider
      // name as the beginning of a separate selectable guarantee condition.
      ...Array.from(value.matchAll(/(?:^|[、，,。・\s])(?:[A-Za-zＡ-Ｚ][A-Za-zＡ-Ｚ0-9０-９ _-]{1,24}|[一-龠ぁ-んァ-ヶー・]{2,24})\s*[:：]\s*(?=(?:初回|契約時|月額|月次|更新|保証))/g))
        .filter((match) => !/(?:初回|月額|月次|基本|保証料|保証委託|更新|引落|手数料)/.test(match[0]))
        .map((match) => match.index),
    ];
    // A qualification such as "高齢者・生活保護受給者" belongs to the
    // following plan. Start at the qualification so an immediately following
    // monthly fixed amount (for example 2,500円) is not lost.
    const qualifiedPlanMarkers = Array.from(
      value.matchAll(/(?:高齢者|生活保護(?:受給)?者|外国籍|学生|法人(?:契約)?者)[^。・\n\r]{0,36}?(?:プラン|保証)\s*[:：](?=[^。・\n\r]{0,120}?(?:初回保証|月額保証|月額\s*[:：]))/g),
      (match) => ({ index: match.index, end: match.index + match[0].length }),
    );
    const isMoneyFragment = (index) => {
      const at = value[index] || "";
      const before = value[index - 1] || "";
      const after = value[index + 1] || "";
      return /[0-9０-９]/.test(at) && /[0-9０-９,，]/.test(before + after);
    };
    const markers = Array.from(new Set([
      ...planMarkers.filter(
        (index) => !isMoneyFragment(index) && !qualifiedPlanMarkers.some((qualified) => qualified.index < index && index < qualified.end),
      ),
      ...qualifiedPlanMarkers.map((qualified) => qualified.index),
    ])).sort((a, b) => a - b);
    const starts = markers[0] === 0 ? markers : [0, ...markers];
    if (starts.length <= 1) return [value];
    return starts.map((index, position) => value.slice(index, starts[position + 1] || value.length).trim());
  }

  function expandGuaranteeOptions(block, position) {
    const providerLabel = guaranteeAlternativeLabel(block, position);
    const studentMatch = block.match(/(?:学生専用プラン|学生プラン)/);
    let entries = [{ block, label: providerLabel }];

    if (studentMatch?.index > 0) {
      const studentStart = studentMatch.index;
      const primarySource = block.slice(0, studentStart).trim();
     const studentRemainder = block.slice(studentStart);
      const studentProvider = studentRemainder.match(/(?:学生専用プラン|学生プラン)\s*[（(]([^）)]{2,32})[）)]/)?.[1]?.trim();
     const sharedMatch = studentRemainder.match(
        /(?:支払手数料|月額手数料|月額事務手数料|月額保証料|月次保証料|※?\s*更新料\s*月額制)/,
      );
      const sharedSource = sharedMatch?.index > 0 ? studentRemainder.slice(sharedMatch.index) : "";
      const primaryHasMonthlyTerms = /(?:月額費用|月額保証料|月次保証料|支払手数料|月額手数料|月額事務手数料|収納代行手数料|決済手数料)/.test(primarySource);
      entries = [
        {
          block: `${primarySource} ${primaryHasMonthlyTerms ? "" : sharedSource}`.trim(),
          label: providerLabel,
        },
        {
          block: `${providerLabel && !/^候補\d+$/.test(providerLabel) ? `${providerLabel} ` : ""}${studentRemainder}`.trim(),
          label: studentProvider
            ? `${studentProvider}（学生プラン）`
            : providerLabel && !/^候補\d+$/.test(providerLabel)
              ? `${providerLabel}（学生プラン）`
              : "学生プラン",
        },
      ];
    }

    return entries.flatMap((entry) => {
      const choice = entry.block.match(
        /(初回保証(?:料|委託料)?[^。・\n\r%]{0,80}?)(\d+(?:\.\d+)?)\s*%([^。・\n\r]{0,80}?)(?:もしくは|または|又は|\bor\b)\s*(?:初回保証(?:料|委託料)?[^。・\n\r%]{0,30}?)?(\d+(?:\.\d+)?)\s*%/i,
      );
      if (!choice) return [entry];
      const prefix = entry.block.slice(0, choice.index);
      const suffix = entry.block.slice(choice.index + choice[0].length);
      const firstRate = Number(choice[2]);
      const secondRate = Number(choice[4]);
      const baseLabel = entry.label && !/^候補\d+$/.test(entry.label)
        ? entry.label
        : guaranteeAlternativeLabel(prefix, position);
      return [
        {
          block: `${prefix}${choice[1]}${firstRate}%${choice[3]} ${suffix}`.trim(),
          label: baseLabel && !/^候補\d+$/.test(baseLabel) ? `${baseLabel}（${firstRate}%）` : `初回${firstRate}%`,
        },
        {
          block: `${baseLabel && !/^候補\d+$/.test(baseLabel) ? `${baseLabel}: ` : ""}初回保証料 ${secondRate}% ${suffix}`.trim(),
          label: baseLabel && !/^候補\d+$/.test(baseLabel) ? `${baseLabel}（${secondRate}%）` : `初回${secondRate}%`,
        },
      ];
    });
  }

  function parseGuarantee(sectionText, bodyText) {
    const sectionSource = splitFeeLines(sectionText)
      .filter((line) => line.section === "保証会社")
      .map((line) => line.text)
      .join(" ");

    // RealPro sometimes shows the detailed guarantee terms as neighbouring
    // plain-text rows, while the formal "保証会社" field only has a summary.
    // Keep the surrounding rows so alternative guarantee plans remain visible.
    const bodyLines = String(bodyText || "")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean);
    const guaranteeSectionStart = bodyLines.findIndex((line) => /^○\s*保証会社/.test(line));
    const guaranteeSectionEnd = guaranteeSectionStart >= 0
      ? bodyLines.findIndex(
          (line, index) =>
            index > guaranteeSectionStart
            && /^○\s*(?:保険|初期費用|ランニングコスト|退去時|その他|広告掲載)/.test(line),
        )
      : -1;
    const guaranteeLineIndexes = bodyLines
      .map((line, index) => (/(?:保証会社|保証委託|初回保証|月額保証|最低(?:初回)?保証|更新保証|保証料|日本セーフティ|ライフあんしん)/.test(line) ? index : -1))
      .filter((index) => index >= 0);
    const bodySource = guaranteeSectionStart >= 0
      ? bodyLines.slice(
          guaranteeSectionStart,
          guaranteeSectionEnd >= 0 ? guaranteeSectionEnd : bodyLines.length,
        ).join(" ")
      : guaranteeLineIndexes.length
        ? bodyLines.slice(
            guaranteeLineIndexes[0],
            Math.min(bodyLines.length, guaranteeLineIndexes.at(-1) + 2),
          ).join(" ")
        : "";
    const source = bodySource || sectionSource || normalize(bodyText.match(/保証会社[^。]{0,500}/)?.[0] || "");
    const normalized = normalize(source)
      .replace(/％/g, "%")
      .replace(/(\d),(\d)(?=\s*(?:%|パーセント))/g, "$1.$2");
    // Business-only guarantee terms are not part of a residential estimate.
    // Exclude them before splitting providers so their minimum/rate cannot
    // overwrite the residential provider immediately before them.
    const calculationSource = normalized.split(/(?:※\s*)?事業用(?:契約)?(?:の場合)?(?:は|、|:|：|\s)/)[0].trim();
    const listedProviderLabels = Array.from(
      calculationSource.matchAll(/[1-6]\s*[【［\[]([^】］\]]{2,32})[】］\]]/g),
      (match) => match[1].trim(),
    ).filter((label) => !/(?:初回|月額|月次|年間|年次|更新|保証料|保証委託|最低)/.test(label));
    const numberedTermStarts = Array.from(
      calculationSource.matchAll(/[1-6]\s*(?=[【［\[](?:初回保証|初回保証委託|契約時保証)[^】］\]]*[】］\]])/g),
      (match) => match.index,
    );
    const bracketedInitialStarts = Array.from(
      calculationSource.matchAll(/[【［\[](?:初回保証|初回保証委託|契約時保証)[^】］\]]*[】］\]]/g),
      (match) => match.index,
    );
    const listedTermStarts = numberedTermStarts.length >= listedProviderLabels.length
      ? numberedTermStarts
      : bracketedInitialStarts;
    const blocks = listedProviderLabels.length > 1 && listedTermStarts.length >= listedProviderLabels.length
      ? listedTermStarts.slice(0, listedProviderLabels.length).map(
          (index, position, starts) => calculationSource.slice(index, starts[position + 1] || calculationSource.length).trim(),
        )
      : guaranteeBlocks(calculationSource);
    const compactInitialHeader = /(?:^|\s)初回保証料\s+(?=[1-6]\s*[一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ])/.test(calculationSource);
    const normalizedBlocks = compactInitialHeader
      ? blocks.map((block) => block.replace(
          /^(\s*[1-6]\s*[一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ][一-龠ぁ-んァ-ヶー・A-Za-zＡ-Ｚ0-9０-９ _-]{1,31}\s*[:：]\s*)月額(?=\s*\d+(?:\.\d+)?\s*(?:%|パーセント))/,
          "$1初回保証料 ",
        ))
      : blocks;
    const optionEntries = normalizedBlocks.flatMap((block, position) => expandGuaranteeOptions(block, position));
    // A term introduced by "各プラン" is shared by every alternative. Without
    // this, it ends up in only the final B plan after the text is split.
    const sharedPlanTerms = [
      calculationSource.match(/(?:※\s*)?(?:各プラン|全プラン|共通)\s*[^。・\n\r]{0,160}/)?.[0],
      calculationSource.match(/(?:月額手数料|月額事務手数料|支払手数料|集送金手数料|収納代行手数料|決済手数料|口座振替手数料|口座振替(?:サービス)?(?:利用)?料|口振手数料|口振(?:サービス)?(?:利用)?料|引落(?:し|とし)?手数料|引き落とし手数料|引落(?:サービス)?(?:利用)?料)[^。・\n\r]{0,80}?(?:\(|（)?(?:共通|各社共通|各プラン)(?:\)|）)?/)?.[0],
      calculationSource.match(/(?:年間更新料|年更新料?|更新保証料|更新料)[^。・\n\r]{0,40}?(?:全て|共通)[^。・\n\r]{0,24}?(?:円|万円)/)?.[0],
    ].filter(Boolean).join(" ");
    const required = /利用必須|必須/.test(calculationSource);
    const candidateBlocks = optionEntries
      .map((entry) => ({
        ...entry,
        candidate: guaranteeBlock(entry.block, required, optionEntries.length === 1),
      }))
      .filter(({ candidate }) => candidate.initialRate || candidate.initialMinimum || candidate.fixed || candidate.monthlyRate || candidate.monthlyFixed || candidate.monthlyFixedExtra);
    const alternatives = candidateBlocks
      .map(({ block, label }, position) => {
        const alreadyHasSharedTerms = /(?:各プラン|全プラン|共通|月額手数料|月額事務手数料|支払手数料|集送金手数料|収納代行手数料|決済手数料|口座振替|口振|引落(?:し|とし)?手数料|引き落とし手数料)/.test(block);
        const source = alreadyHasSharedTerms ? block : `${block} ${sharedPlanTerms}`.trim();
        const listedLabel = optionEntries.length === listedProviderLabels.length
          ? listedProviderLabels[position]
          : "";
        return {
          ...guaranteeBlock(source, required, optionEntries.length === 1),
          label: listedLabel || (label && !/^候補\d+$/.test(label)
            ? label
            : guaranteeAlternativeLabel(block, position)),
        };
      });
    const selected = alternatives[0] || guaranteeBlock(calculationSource, /利用必須|必須/.test(calculationSource));
    const guaranteeChoiceSource = calculationSource.split(/(?:※|リアプロ内|客付業者様へ)/)[0];
    let choiceAlternatives = alternatives;
    const inlineChoicePattern = /(?:または|もしくは|又は|\bor\b)/i;
    const hasInlineChoice = inlineChoicePattern.test(guaranteeChoiceSource);
    if (choiceAlternatives.length <= 1 && hasInlineChoice) {
      const chunks = guaranteeChoiceSource.split(inlineChoicePattern)
        .map((chunk) => guaranteeBlock(chunk.trim(), /利用必須|必須/.test(calculationSource)))
        .filter((candidate) => candidate.initialRate || candidate.initialMinimum || candidate.fixed || candidate.monthlyRate || candidate.monthlyFixed || candidate.monthlyFixedExtra);
      if (chunks.length > 1) {
        choiceAlternatives = chunks.map((candidate, position) => ({
          ...candidate,
          fixed: candidate.fixed || selected.fixed,
          initialRate: candidate.initialRate || selected.initialRate,
          initialMinimum: candidate.initialMinimum || selected.initialMinimum,
          renewalAmount: candidate.renewalAmount || (position === 0 ? selected.renewalAmount : 0),
          renewalPeriod: candidate.renewalAmount || (position === 0 && selected.renewalAmount) ? "annual" : "none",
        }));
      }
      const monthlyRateChoice = guaranteeChoiceSource.match(
        /(?:月額保証料|月次保証料|月額保証委託料|月次保証委託料)[^。・\n\r%]{0,100}?(\d+(?:\.\d+)?)\s*%[^。・\n\r]{0,12}?(?:または|もしくは|又は|\bor\b)\s*(\d+(?:\.\d+)?)\s*%/i,
      );
      if (monthlyRateChoice) {
        choiceAlternatives = [
          { ...selected, monthlyRate: Number(monthlyRateChoice[1]), monthlyFixed: 0 },
          { ...selected, monthlyRate: Number(monthlyRateChoice[2]), monthlyFixed: 0 },
        ];
      }
    }
    return {
      note: calculationSource,
      required: /利用必須|必須/.test(calculationSource),
      fixed: selected.fixed,
      initialRate: selected.initialRate,
      initialMinimum: selected.initialMinimum,
      monthlyRate: selected.monthlyRate,
      monthlyMinimum: selected.monthlyMinimum || 0,
      monthlyFixed: selected.monthlyFixed,
      monthlyFixedExtra: selected.monthlyFixedExtra,
      renewalAmount: selected.renewalAmount || 0,
      renewalPeriod: selected.renewalPeriod || "none",
      alternatives: choiceAlternatives.length > 1 ? choiceAlternatives : [],
      needsChoice: choiceAlternatives.length > 1,
      confidence: normalized ? (choiceAlternatives.length > 1 ? "low" : selected.confidence) : "low",
      warnings: Array.from(new Set([
        ...(selected.warnings || []),
        ...(choiceAlternatives.length > 1 ? ["保証会社または保証プランが複数あります。利用する条件を選択してください。"] : []),
      ])),
    };
  }

  function formControls(doc) {
    return Array.from(doc.querySelectorAll?.("input, select, textarea") || []);
  }

  function fieldElement(doc, name) {
    return formControls(doc).find((element) => (element.name || element.getAttribute?.("name") || "") === name) || null;
  }

  function selectedOptionText(element) {
    if (!element || String(element.tagName || "").toUpperCase() !== "SELECT") return "";
    return normalize(element.options?.[element.selectedIndex]?.textContent || element.value);
  }

  function usefulSelectText(value) {
    const text = normalize(value);
    return /^(?:[-‐ー―]+|--------|-------------)$/.test(text) ? "" : text;
  }

  function fieldValue(doc, name) {
    const element = fieldElement(doc, name);
    if (!element) return "";
    return normalize(element.value);
  }

  function selectedFieldText(doc, name) {
    return usefulSelectText(selectedOptionText(fieldElement(doc, name)));
  }

  function numberValue(value) {
    const text = normalize(value).replace(/,/g, "");
    const number = Number(text.match(/-?\d+(?:\.\d+)?/)?.[0] || 0);
    return Number.isFinite(number) ? number : 0;
  }

  function adminUnitAmount(value, unitText, rent) {
    const numeric = numberValue(value);
    if (!numeric) return 0;
    const unit = normalize(unitText);
    if (/ヶ月|か月|月分/.test(unit)) return rent ? Math.round(rent * numeric) : 0;
    if (/％|%/.test(unit)) return rent ? Math.round(rent * (numeric / 100)) : 0;
    return Math.round(numeric);
  }

  function adminPaymentTiming(paymentType) {
    const text = normalize(paymentType);
    if (/契約時(?:または|もしくは|又は)退去時|入居時(?:または|もしくは|又は)退去時/.test(text)) return "choice";
    if (/月額/.test(text)) return "monthly";
    if (/退去時|解約時/.test(text)) return "moveout";
    if (/申込時|契約時|入居時/.test(text)) return "initial";
    if (/年額|更新時/.test(text)) return "choice";
    return "choice";
  }

  function adminCategory(typeText, label, context = "") {
    const value = normalize(`${typeText} ${label} ${context}`);
    if (REMARK_FEE_PATTERN.test(value)) return "remark";
    const typeRules = [
      ["guaranteePersonal", /保証人代行費用|保証会社|保証委託|初回保証/i],
      ["townFee", /町内会費|町会費/i],
      ["cleaningFee", /室内清掃費用|室内清掃|ハウスクリーニング|ルームクリーニング|HC料|ＨＣ料/i],
      ["stoveMaintenanceFee", /FF分解清掃費用|FF|ＦＦ|ストーブ分解清掃費用|ストーブ|暖房/i],
      ["waterSanitizingFee", /水廻り消毒料|水廻|水回|水まわ|水周/i],
      ["keyFee", /カギ交換費用|鍵|カギ|カードキー|シリンダ/i],
      ["supportFee", /入居者サービス料|24時間|２４時間|夜間受付|夜間緊急|夜間対応|アクセス24|見守り|サポート|リペア|くらし|暮らし|クラブ|駆けつけ|かけつけ/i],
      ["gasLeaseFee", /水道料金|水道料|上下水道|給湯器.*リース|北ガス.*リース|ガス警報器.*リース|設備リース|リース料/i],
      ["petFee", /ペット|飼育/i],
    ];
    for (const [category, pattern] of typeRules) {
      if (pattern.test(value)) return category;
    }
    return inferCategory(label || typeText, value) || "unregistered";
  }

  function adminOtherCostIndexes(doc) {
    const indexes = new Set();
    for (const element of formControls(doc)) {
      const name = element.name || element.getAttribute?.("name") || "";
      const match = name.match(/^other_cost\[(\d+)]/);
      if (match) indexes.add(Number(match[1]));
    }
    return Array.from(indexes).sort((a, b) => a - b);
  }

  function adminOtherCostRow(doc, index) {
    const prefix = `other_cost[${index}]`;
    return {
      index,
      typeText: selectedFieldText(doc, `${prefix}[cost_type_id]`),
      label: fieldValue(doc, `${prefix}[cost_name]`),
      value: fieldValue(doc, `${prefix}[cost_value]`),
      unitText: selectedFieldText(doc, `${prefix}[cost_unit_id]`),
      taxText: selectedFieldText(doc, `${prefix}[cost_tax_unit_id]`),
      paymentText: selectedFieldText(doc, `${prefix}[payment_type_id]`),
      remarks: fieldValue(doc, `${prefix}[cost_remarks]`),
    };
  }

  function adminOtherCostDiagnostics(doc, rent) {
    const fees = [];
    const rows = [];
    for (const index of adminOtherCostIndexes(doc)) {
      const row = adminOtherCostRow(doc, index);
      const label = normalize(row.label || row.typeText);
      const sourceText = normalize(
        [row.typeText, row.label, row.paymentText, `${row.value}${row.unitText}`, row.taxText, row.remarks].filter(Boolean).join(" "),
      );

      const category = adminCategory(row.typeText, label, sourceText);
      const timing = category === "monthlyGuaranteeFee" ? "monthly" : adminPaymentTiming(row.paymentText);
      const amount = adminUnitAmount(row.value, row.unitText, rent);
      const numeric = numberValue(row.value);
      let status = "included";
      let reason = category === "unregistered" ? "未登録項目として取得" : "見積対象";

      if (!label && !numeric) {
        status = "empty";
        reason = "空欄";
      } else if (!label) {
        status = "ignored";
        reason = "項目名なし";
      } else if (!numeric) {
        status = "ignored";
        reason = "金額なし";
      } else if (NON_CUSTOMER_PATTERN.test(sourceText)) {
        status = "excluded";
        reason = "顧客請求対象外";
      } else if (category === "guaranteePersonal" && /％|%/.test(row.unitText)) {
        status = "guarantee-hint";
        reason = "保証料率として使用";
      } else if (!amount) {
        status = "ignored";
        reason = "金額換算不可";
      }

      rows.push({
        index,
        typeText: row.typeText,
        label,
        value: row.value,
        unitText: row.unitText,
        taxText: row.taxText,
        paymentText: row.paymentText,
        amount,
        category,
        timing,
        status,
        reason,
        sourceText,
      });

      if (status !== "included") continue;

      fees.push({
        label,
        amount,
        timing,
        type: timing === "monthly" && (isOptional(sourceText) || category === "petFee") ? "optionalMonthly" : isOptional(sourceText) || category === "petFee" ? "optional" : timing === "monthly" ? "monthly" : "initial",
        category,
        optional: isOptional(sourceText) || category === "petFee",
        confidence: row.typeText || category !== "unregistered" ? "high" : "medium",
        sourceSection: "管理画面:その他費用",
        sourceText,
      });
    }
    return { fees, rows };
  }

  function adminOtherCostFees(doc, rent) {
    return adminOtherCostDiagnostics(doc, rent).fees;
  }

  function adminGuaranteeHints(doc) {
    const hint = {
      fixed: 0,
      initialRate: 0,
      initialMinimum: 0,
      monthlyRate: 0,
      monthlyFixed: 0,
    };
    for (const index of adminOtherCostIndexes(doc)) {
      const row = adminOtherCostRow(doc, index);
      const label = normalize(row.label || row.typeText);
      const sourceText = normalize([row.typeText, row.label, row.paymentText, `${row.value}${row.unitText}`, row.remarks].join(" "));
      if (adminCategory(row.typeText, label, sourceText) !== "guaranteePersonal") continue;
      const numeric = numberValue(row.value);
      if (!numeric) continue;
      const timing = adminPaymentTiming(row.paymentText);
      if (/％|%/.test(row.unitText)) {
        if (timing === "monthly") hint.monthlyRate ||= numeric;
        else hint.initialRate ||= numeric;
      } else if (/円/.test(row.unitText) || !row.unitText) {
        if (timing === "monthly") hint.monthlyFixed ||= Math.round(numeric);
        else hint.fixed ||= Math.round(numeric);
      }
    }
    return hint;
  }

  function mergeGuarantee(primary, fallback) {
    return {
      ...primary,
      fixed: primary.fixed || fallback.fixed || 0,
      initialRate: primary.initialRate || fallback.initialRate || 0,
      initialMinimum: primary.initialMinimum || fallback.initialMinimum || 0,
      monthlyRate: primary.monthlyRate || fallback.monthlyRate || 0,
      monthlyMinimum: primary.monthlyMinimum || fallback.monthlyMinimum || 0,
      monthlyFixed: primary.monthlyFixed || fallback.monthlyFixed || 0,
      monthlyFixedExtra: primary.monthlyFixedExtra || fallback.monthlyFixedExtra || 0,
      renewalAmount: primary.renewalAmount || fallback.renewalAmount || 0,
      renewalPeriod: primary.renewalPeriod || fallback.renewalPeriod || "none",
      alternatives: primary.alternatives?.length ? primary.alternatives : fallback.alternatives || [],
      needsChoice: Boolean(primary.needsChoice || fallback.needsChoice),
      confidence: primary.note || fallback.fixed || fallback.initialRate ? "medium" : "low",
    };
  }

  function adminBaseAmount(doc, valueName, unitName, rent) {
    return adminUnitAmount(fieldValue(doc, valueName), selectedFieldText(doc, unitName), rent);
  }

  function checkedField(doc, name, value = "") {
    return formControls(doc).some((element) => {
      const elementName = element.name || element.getAttribute?.("name") || "";
      if (elementName !== name || element.type !== "checkbox" && element.type !== "radio") return false;
      if (value && String(element.value) !== value) return false;
      return Boolean(element.checked);
    });
  }

  function adminProperty(doc) {
    const room = normalize(
      [fieldValue(doc, "go_number"), selectedFieldText(doc, "floor_number") ? `(${selectedFieldText(doc, "floor_number")}部分)` : ""]
        .filter(Boolean)
        .join(""),
    );
    const area = fieldValue(doc, "square_meter");
    return {
      title: "",
      room,
      address: "",
      access: "",
      layout: selectedFieldText(doc, "room_layout_id"),
      area: area ? `${area}㎡` : "",
      built: "",
      moveIn: "",
      inquiry: fieldValue(doc, "building_id") || new URL(doc.location.href).searchParams.get("building_id") || "",
    };
  }

  function isAdminPage(doc) {
    const href = doc.location?.href || "";
    const kanriRoomPage = /kanri\.realnetpro\.com/.test(href) && /[?&]method=room(?:&|$)/.test(href);
    return kanriRoomPage || Boolean(fieldElement(doc, "surety_company_remarks")) || adminOtherCostIndexes(doc).length > 0;
  }

  function extractAdmin(doc) {
    const rent = numberValue(fieldValue(doc, "rental_cost"));
    const commonFee = numberValue(fieldValue(doc, "fee_common_service"));
    const deposit = checkedField(doc, "deposit_flag", "N") ? 0 : adminBaseAmount(doc, "deposit_value", "deposit_unit", rent);
    const keyMoney = checkedField(doc, "recompense_flag", "N") ? 0 : adminBaseAmount(doc, "recompense_value", "recompense_unit", rent);
    const insuranceFee = /不要|なし|無し/.test(selectedFieldText(doc, "insurance_flag"))
      ? 0
      : numberValue(fieldValue(doc, "insurance_premium"));
    const insuranceText = normalize(
      [
        selectedFieldText(doc, "insurance_flag"),
        fieldValue(doc, "insurance_premium"),
        selectedFieldText(doc, "insurance_premium_unit"),
        selectedFieldText(doc, "insurance_payment_type_id"),
        fieldValue(doc, "insurance_remarks"),
      ].join(" "),
    );
    const insuranceTiming = inferInsuranceTiming(insuranceText, insuranceFee);
    const availableParking = selectedFieldText(doc, "available_parking_flag");
    const parkingFee = /なし|無し|空きなし/.test(availableParking)
      ? 0
      : numberValue(fieldValue(doc, "parking_cost_min")) || numberValue(fieldValue(doc, "parking_cost_max"));
    const suretyRemarks = fieldValue(doc, "surety_company_remarks");
    const accountComment = fieldValue(doc, "comment_for_account");
    const accountCommentDiagnostics = freeTextFeeDiagnostics(accountComment, "管理画面:客付コメント");
    const guarantee = mergeGuarantee(parseGuarantee("", `保証会社 ${suretyRemarks} ${accountComment}`), adminGuaranteeHints(doc));
    const otherCostDiagnostics = adminOtherCostDiagnostics(doc, rent);
    const fees = dedupeFees(otherCostDiagnostics.fees.concat(accountCommentDiagnostics.fees));
    const warnings = [];
    const feeBuckets = feeDiagnostics(fees);

    if (accountComment && !accountCommentDiagnostics.fees.length) warnings.push("管理画面の客付コメントに補足があります。任意・貸主負担・キャンペーン条件は見積反映を確認してください。");
    if (accountCommentDiagnostics.fees.length) warnings.push("管理画面の客付コメントから費用を取得しました。転送前に支払時期と請求対象を確認してください。");
    if (!rent) warnings.push("管理画面から賃料を取得できませんでした。");
    if (!fees.length) warnings.push("管理画面のその他費用から見積対象項目を取得できませんでした。");
    if (!suretyRemarks) warnings.push("管理画面の保証会社備考が空です。");
    if (feeBuckets.unregisteredFees.length) warnings.push("未登録の費用項目があります。見積に含める前に分類を確認してください。");
    if (feeBuckets.choiceFees.length) warnings.push("契約時または退去時の選択が必要な費用があります。");

    const extracted = {
      property: adminProperty(doc),
      base: {
        rent,
        commonFee,
        deposit,
        keyMoney,
        parkingFee,
        insuranceFee,
        insuranceTiming,
        insuranceLabel: insuranceLabelForTiming(insuranceTiming),
      },
      fees: fees.filter((fee) => fee.category !== "monthlyGuaranteeFee"),
      guarantee,
      diagnostics: {
        sourceUrl: doc.location.href,
        sourceType: "realpro-admin-room",
        rowCount: 0,
        feeSectionFound: fees.length > 0,
        feeLineCount: adminOtherCostIndexes(doc).length,
        extractedFeeCount: fees.length,
        adminAccountComment: accountComment,
        adminOtherCostRows: otherCostDiagnostics.rows,
        accountCommentFeeCount: accountCommentDiagnostics.fees.length,
        skippedFeeLines: otherCostDiagnostics.rows
          .filter((row) => ["excluded", "ignored", "guarantee-hint"].includes(row.status))
          .map((row) => ({
            section: "管理画面:その他費用",
            text: row.sourceText,
            reason: row.reason,
          }))
          .concat(accountCommentDiagnostics.skippedLines),
        guaranteeParsed: guaranteeDiagnostics(guarantee),
        ...feeBuckets,
        warnings,
      },
    };

    return {
      extracted,
      estimateData: toEstimateData(extracted),
    };
  }

  function feeKey(fee) {
    return `${compact(fee.label)}|${fee.amount}|${fee.timing}`;
  }

  function dedupeFees(fees) {
    const seen = new Set();
    return fees.filter((fee) => {
      const key = feeKey(fee);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function toEstimateData(extracted) {
    const amounts = {
      rent: extracted.base.rent,
      commonFee: extracted.base.commonFee,
      deposit: extracted.base.deposit,
      keyMoney: extracted.base.keyMoney,
      parkingFee: extracted.base.parkingFee,
      insuranceFee: extracted.base.insuranceFee,
    };
    const feeLabels = {};
    const feeTimings = {};
    const feeTypes = {};
    const extraFees = [];
    const remarkFees = [];

    for (const fee of extracted.fees) {
      if (fee.category === "remark") {
        remarkFees.push({
          label: fee.label,
          amount: fee.amount,
          timing: fee.timing,
          sourceSection: fee.sourceSection,
          sourceText: fee.sourceText,
        });
      } else if (["asExtra", "optional", "optionalMonthly"].includes(fee.category)) {
        extraFees.push({
          id: `realpro-${extraFees.length + 1}`,
          label: fee.label,
          amount: fee.amount,
          timing: fee.category === "optionalMonthly" ? "monthly" : fee.timing,
          type: ["optional", "optionalMonthly"].includes(fee.category) ? "optional" : fee.type,
          guaranteeTarget: false,
          noProrate: fee.category === "optionalMonthly" || fee.timing === "monthly",
          noInitialEstimate: false,
          sourceSection: fee.sourceSection,
          confidence: fee.confidence,
          optional: fee.category === "optionalMonthly" || fee.optional,
        });
      } else if (
        fee.category
        && fee.category !== "unregistered"
        && amounts[fee.category] == null
        && (!(["supportFee", "townFee", "gasLeaseFee"].includes(fee.category)) || fee.timing === "monthly")
      ) {
        amounts[fee.category] = fee.amount;
        feeLabels[fee.category] = fee.label;
        feeTimings[fee.category] = fee.timing;
        if (fee.timing === "monthly" || fee.category === "monthlyGuaranteeFee") {
          feeTypes[fee.category] = "monthly";
        } else if (fee.type && fee.type !== "optional") {
          feeTypes[fee.category] = fee.type;
        }
      } else {
        extraFees.push({
          id: `realpro-${extraFees.length + 1}`,
          label: fee.label,
          amount: fee.amount,
          timing: fee.timing,
          type: ["optional", "optionalMonthly"].includes(fee.type) ? "optional" : fee.type,
          guaranteeTarget: false,
          noProrate: fee.timing === "monthly",
          noInitialEstimate: fee.category === "monthlyGuaranteeFee",
          sourceSection: fee.sourceSection,
          confidence: fee.confidence,
          optional: fee.optional,
        });
      }
    }

    if (extracted.guarantee.fixed) {
      amounts.guaranteePersonal = extracted.guarantee.fixed;
    }
    if (extracted.guarantee.monthlyFixed || extracted.guarantee.monthlyFixedExtra) {
      amounts.monthlyGuaranteeFee = extracted.guarantee.monthlyFixed
        + extracted.guarantee.monthlyFixedExtra;
      feeLabels.monthlyGuaranteeFee = "月額保証料";
      feeTimings.monthlyGuaranteeFee = "monthly";
      feeTypes.monthlyGuaranteeFee = "monthly";
    }

    const insuranceTiming = extracted.base.insuranceTiming || "initial";
    feeLabels.insuranceFee = extracted.base.insuranceLabel || insuranceLabelForTiming(insuranceTiming);
    feeTimings.insuranceFee = insuranceTiming;
    feeTypes.insuranceFee = insuranceTiming === "monthly" ? "monthly" : "initial";

    return {
      source: "realpro-extension",
      version: 3,
      property: extracted.property,
      amounts,
      settings: {
        feeLabels,
        feeTimings,
        feeTypes,
        guaranteeMode: extracted.guarantee.fixed
          ? "fixed"
          : extracted.guarantee.initialRate
            ? "percent"
            : "none",
        guaranteeRate: extracted.guarantee.initialRate || 0,
        guaranteeMinimum: extracted.guarantee.initialMinimum || 0,
        guaranteeFixedAmount: extracted.guarantee.fixed || 0,
        guaranteeNote: extracted.guarantee.note,
        guaranteeOriginalSourceText: extracted.guarantee.originalNote || "",
        guaranteeNeedsChoice: Boolean(extracted.guarantee.needsChoice),
        guaranteeAlternatives: Array.isArray(extracted.guarantee.alternatives) ? extracted.guarantee.alternatives : [],
        guaranteeSourceText: extracted.guarantee.note,
        guaranteeWarnings: Array.isArray(extracted.guarantee.warnings) ? extracted.guarantee.warnings : [],
        guaranteeSelectedLabel: extracted.guarantee.selectedLabel || "",
        guaranteeConfidence: extracted.guarantee.confidence || "",
        guaranteeParserVersion: 3,
        guaranteeRenewalAmount: extracted.guarantee.renewalAmount || 0,
        guaranteeRenewalPeriod: extracted.guarantee.renewalPeriod || "none",
        monthlyGuaranteeMode: extracted.guarantee.monthlyRate
          ? "percent"
          : extracted.guarantee.monthlyFixed || extracted.guarantee.monthlyFixedExtra
            ? "fixed"
            : "none",
        monthlyGuaranteeRate: extracted.guarantee.monthlyRate || 0,
        monthlyGuaranteeMinimum: extracted.guarantee.monthlyMinimum || 0,
        monthlyGuaranteeFixed: extracted.guarantee.monthlyFixed || 0,
        monthlyGuaranteeFixedExtra: extracted.guarantee.monthlyFixedExtra || 0,
        includeParking: false,
        includeAcCleaning: false,
        includePetFee: false,
        issueDate: new Date().toISOString().slice(0, 10).replaceAll("-", "/"),
        extraFees,
        remarkFees,
        extractionDiagnostics: extracted.diagnostics,
      },
      capturedAt: new Date().toISOString(),
    };
  }

  function extract(doc) {
    if (isAdminPage(doc)) return extractAdmin(doc);

    const rows = rowsFromDocument(doc);
    const map = rowMap(rows);
    const bodyText = normalize(doc.body?.innerText || "");
    const layout = parseLayout(map.get("間取") || "");
    const rentRow = map.get("賃料 / 管理費・共益費") || "";
    const rentValues = allMoney(rentRow);
    const rent = rentValues[0] || money(map.get("賃料"));
    const commonFee = rentValues[1] || money(map.get("共益費・ 管理費"));
    const depositKeyMoney = map.get("敷金 / 礼金") || "";
    const parkingText = map.get("駐車場") || "";
    const parkingFee = publicParkingAmount(parkingText);
    const sectionText = feeSection(bodyText);
    const sectionLines = splitFeeLines(sectionText);
    const petCharge = petChargeFromDepositRow(depositKeyMoney, rent);
    const brokerDiagnostics = freeTextFeeDiagnostics(brokerNoteSection(bodyText), "客付業者様へ");
    const brokerFees = brokerDiagnostics.fees;
    const guaranteeRemarkDiagnostics = freeTextFeeDiagnostics(
      sectionLines
        .filter((line) => line.section === "保証会社")
        .map((line) => line.text)
        .join("\n"),
      "保証会社",
    );
    const feeCandidateLines = sectionLines.filter((line) => !["保証会社", "保険"].includes(line.section));
    const parsedFeeLines = feeCandidateLines.map((line) => ({
      line,
      fee: parseFeeLine(line.text, line.section),
    }));
    const skippedFeeLines = parsedFeeLines
      .filter(
        ({ line, fee }) =>
          !fee &&
          allMoney(line.text).length &&
          /(?:料|費|代|金|清掃|消毒|交換|整備|サポート|サービス|クラブ)/.test(line.text),
      )
      .map(({ line }) => skippedFeeLine(line))
      .concat(brokerDiagnostics.skippedLines)
      .concat(guaranteeRemarkDiagnostics.skippedLines);
    const fees = dedupeFees(
      parsedFeeLines
        .map(({ fee }) => fee)
        .filter(Boolean)
        .concat(brokerFees)
        .concat(guaranteeRemarkDiagnostics.fees)
        .concat(petCharge ? [petCharge] : []),
    );
    const insuranceLine = sectionLines.find((line) => line.section === "保険" && money(line.text));
    const insuranceFee = insuranceLine ? money(insuranceLine.text) : 0;
    const insuranceTiming = insuranceLine ? inferInsuranceTiming(insuranceLine.text, insuranceFee) : "initial";
    const guarantee = parseGuarantee(sectionText, bodyText);
    const baseCharges = baseDepositKeyMoney(depositKeyMoney, rent);
    const feeBuckets = feeDiagnostics(fees);

    const extracted = {
      property: {
        title: map.get("物件名") || "",
        room: map.get("号室名") || "",
        address: (map.get("所在地") || "").replace(/地図を見る$/, ""),
        access: map.get("交通") || "",
        layout: layout.layout,
        area: layout.area,
        built: map.get("築年月") || "",
        moveIn: `${map.get("状態") || ""} / ${map.get("入居可能時期") || ""}`.replace(/^ \/ | \/ $/g, ""),
        inquiry: new URL(doc.location.href).searchParams.get("id") || "",
      },
      base: {
        rent,
        commonFee,
        deposit: baseCharges.deposit,
        keyMoney: baseCharges.keyMoney,
        parkingFee,
        insuranceFee,
        insuranceTiming,
        insuranceLabel: insuranceLabelForTiming(insuranceTiming),
      },
      fees: fees.filter((fee) => fee.category !== "monthlyGuaranteeFee"),
      guarantee,
      diagnostics: {
        sourceUrl: doc.location.href,
        sourceType: "realpro-public-room",
        rowCount: rows.length,
        feeSectionFound: Boolean(sectionText),
        feeLineCount: sectionLines.length,
        extractedFeeCount: fees.length,
        brokerFeeCount: brokerFees.length,
        skippedFeeLines,
        guaranteeParsed: guaranteeDiagnostics(guarantee),
        ...feeBuckets,
        warnings: [],
      },
    };

    if (!extracted.property.title) extracted.diagnostics.warnings.push("物件名を取得できませんでした。");
    if (!extracted.property.room) extracted.diagnostics.warnings.push("号室を取得できませんでした。");
    if (!rent) extracted.diagnostics.warnings.push("賃料を取得できませんでした。");
    if (!sectionText) extracted.diagnostics.warnings.push("諸費用欄を取得できませんでした。");
    if (feeBuckets.unregisteredFees.length) extracted.diagnostics.warnings.push("未登録の費用項目があります。見積に含める前に分類を確認してください。");
    if (feeBuckets.choiceFees.length) extracted.diagnostics.warnings.push("契約時または退去時の選択が必要な費用があります。");
    if (guarantee.needsChoice) extracted.diagnostics.warnings.push("保証会社が複数候補あります。利用する保証会社を確認してください。");
    if (skippedFeeLines.length) extracted.diagnostics.warnings.push("金額はありますが見積対象外または分類対象外にした行があります。");

    return {
      extracted,
      estimateData: toEstimateData(extracted),
    };
  }

  global.RealproEstimateParser = {
    extract,
    inferCategory,
    inferTiming,
    money,
    normalize,
    toEstimateData,
  };
})(globalThis);
