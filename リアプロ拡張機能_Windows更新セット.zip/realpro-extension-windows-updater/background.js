const PENDING_KEY = "rentEstimatePendingTransfer";
const CLOUD_ESTIMATE_URL = "https://gaku0071-bit.github.io/rent-estimate-web/?source=realpro-extension";
const DEFAULT_ESTIMATE_URL = CLOUD_ESTIMATE_URL;
const REALPRO_URLS = [
  "https://www.realnetpro.com/room_detail.php*",
  "https://kanri.realnetpro.com/main.php*",
];
const ESTIMATE_URLS = [
  "https://gaku0071-bit.github.io/rent-estimate-web/*",
];

async function injectIntoOpenRealproTabs() {
  const tabs = await chrome.tabs.query({ url: REALPRO_URLS });
  await Promise.allSettled(
    tabs
      .filter((tab) => Number.isInteger(tab.id))
      .map(async (tab) => {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            document.getElementById("rent-estimate-extension-button")?.remove();
            document.getElementById("rent-estimate-extension-overlay")?.remove();
          },
        });
        await chrome.scripting.insertCSS({
          target: { tabId: tab.id },
          files: ["realpro-content.css"],
        });
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["realpro-parser.js", "realpro-content.js"],
        });
      }),
  );
}

chrome.runtime.onInstalled.addListener(() => {
  injectIntoOpenRealproTabs().catch(() => {});
});

injectIntoOpenRealproTabs().catch(() => {});

function estimateUrlWithTransfer(url, transferId) {
  try {
    const nextUrl = new URL(url || DEFAULT_ESTIMATE_URL);
    nextUrl.searchParams.set("source", "realpro-extension");
    nextUrl.searchParams.set("transfer", transferId);
    nextUrl.searchParams.set("t", Date.now().toString());
    return nextUrl.toString();
  } catch (_error) {
    return DEFAULT_ESTIMATE_URL;
  }
}

async function preferredEstimateUrl(requestedUrl) {
  return requestedUrl || CLOUD_ESTIMATE_URL;
}

async function findEstimateTab() {
  const tabs = await chrome.tabs.query({ url: ESTIMATE_URLS });
  return tabs[0] || null;
}

async function focusTab(tab) {
  if (!Number.isInteger(tab?.id)) return;
  await chrome.tabs.update(tab.id, { active: true });
  if (Number.isInteger(tab.windowId)) {
    await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
  }
}

async function openOrReuseEstimateTab(transfer, requestedUrl) {
  const fallbackUrl = await preferredEstimateUrl(requestedUrl);
  const existingTab = await findEstimateTab();
  if (existingTab?.id) {
    await focusTab(existingTab);
    try {
      await chrome.tabs.sendMessage(existingTab.id, {
        type: "DELIVER_RENT_ESTIMATE_TRANSFER",
        transferId: transfer.id,
      });
      return { tabId: existingTab.id, reused: true };
    } catch (_error) {
      const url = estimateUrlWithTransfer(existingTab.url || fallbackUrl, transfer.id);
      await chrome.tabs.update(existingTab.id, { url, active: true });
      return { tabId: existingTab.id, reused: true, reloaded: true };
    }
  }

  const tab = await chrome.tabs.create({
    url: estimateUrlWithTransfer(fallbackUrl, transfer.id),
  });
  return { tabId: tab.id, reused: false };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "OPEN_RENT_ESTIMATE" || !message.payload) return;

  const transfer = {
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    payload: message.payload,
  };

  chrome.storage.local
    .set({ [PENDING_KEY]: transfer })
    .then(() => openOrReuseEstimateTab(transfer, message.estimateUrl))
    .then((result) => sendResponse({ ok: true, transferId: transfer.id, ...result }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));

  return true;
});
