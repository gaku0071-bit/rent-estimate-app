@echo off
setlocal
echo Realpro estimate extension version check
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0check-version.ps1"
echo.
pause
