const PENDING_KEY = "rentEstimatePendingTransfer";
const MAX_TRANSFER_AGE_MS = 10 * 60 * 1000;

function deliverExtensionStatus() {
  window.postMessage(
    {
      type: "RENT_ESTIMATE_EXTENSION_STATUS",
      currentVersion: chrome.runtime.getManifest().version,
    },
    window.location.origin,
  );
}

async function deliverPendingTransfer() {
  const stored = await chrome.storage.local.get(PENDING_KEY);
  const transfer = stored[PENDING_KEY];
  if (!transfer?.payload) return;

  const age = Date.now() - new Date(transfer.createdAt || 0).getTime();
  if (!Number.isFinite(age) || age > MAX_TRANSFER_AGE_MS) {
    await chrome.storage.local.remove(PENDING_KEY);
    return;
  }

  window.postMessage(
    {
      type: "RENT_ESTIMATE_EXTENSION_DATA",
      transferId: transfer.id,
      payload: transfer.payload,
    },
    window.location.origin,
  );
}

window.addEventListener("message", async (event) => {
  if (event.source !== window || event.origin !== window.location.origin) return;
  if (event.data?.type === "RENT_ESTIMATE_APP_READY") {
    deliverExtensionStatus();
    await deliverPendingTransfer();
    return;
  }
  if (event.data?.type === "RENT_ESTIMATE_EXTENSION_ACK") {
    await chrome.storage.local.remove(PENDING_KEY);
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "DELIVER_RENT_ESTIMATE_TRANSFER") return;
  deliverPendingTransfer()
    .then(() => sendResponse({ ok: true }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});

deliverPendingTransfer().catch(() => {});
deliverExtensionStatus();
setTimeout(() => deliverPendingTransfer().catch(() => {}), 800);
