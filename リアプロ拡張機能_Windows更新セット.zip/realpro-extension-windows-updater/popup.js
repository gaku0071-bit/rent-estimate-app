const LATEST_MANIFEST_URL =
  "https://gaku0071-bit.github.io/rent-estimate-web/extension-version.json";

const currentVersion = chrome.runtime.getManifest().version;
const currentVersionElement = document.getElementById("currentVersion");
const latestVersionElement = document.getElementById("latestVersion");
const updateStatusElement = document.getElementById("updateStatus");
const statusMessageElement = document.getElementById("statusMessage");
const checkButton = document.getElementById("checkButton");
const extensionsButton = document.getElementById("extensionsButton");

function compareVersions(left, right) {
  const leftParts = String(left).split(".").map((part) => Number.parseInt(part, 10) || 0);
  const rightParts = String(right).split(".").map((part) => Number.parseInt(part, 10) || 0);
  const length = Math.max(leftParts.length, rightParts.length);
  for (let index = 0; index < length; index += 1) {
    const difference = (leftParts[index] || 0) - (rightParts[index] || 0);
    if (difference !== 0) return difference;
  }
  return 0;
}

function setStatus(label, className, message) {
  updateStatusElement.textContent = label;
  updateStatusElement.className = `status ${className}`;
  statusMessageElement.textContent = message;
}

async function checkLatestVersion() {
  checkButton.disabled = true;
  latestVersionElement.textContent = "確認中";
  setStatus("確認中", "checking", "公開中の最新版を確認しています。");

  try {
    const response = await fetch(`${LATEST_MANIFEST_URL}?t=${Date.now()}`, { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const manifest = await response.json();
    if (!/^\d+(?:\.\d+){1,3}$/.test(manifest.version || "")) {
      throw new Error("invalid version");
    }

    const latestVersion = manifest.version;
    latestVersionElement.textContent = latestVersion;
    const comparison = compareVersions(currentVersion, latestVersion);
    if (comparison < 0) {
      setStatus("更新あり", "update", `最新版 ${latestVersion} へ更新できます。`);
    } else if (comparison === 0) {
      setStatus("最新版", "current", "現在の拡張機能は最新版です。");
    } else {
      setStatus("確認版", "current", "公開中の版より新しい確認版を使用しています。");
    }
  } catch (_error) {
    latestVersionElement.textContent = "確認できません";
    setStatus("通信エラー", "update", "最新版を確認できません。現在の機能はそのまま使用できます。");
  } finally {
    checkButton.disabled = false;
  }
}

currentVersionElement.textContent = currentVersion;
checkButton.addEventListener("click", checkLatestVersion);
extensionsButton.addEventListener("click", () => chrome.tabs.create({ url: "chrome://extensions/" }));
checkLatestVersion();
