& (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "update-extension.ps1")
