@echo off
setlocal
title Realpro Estimate Extension Updater

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0update-extension.ps1"
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if "%EXIT_CODE%"=="0" (
  echo Update finished. Click Reload on chrome://extensions/.
) else (
  echo Update failed. Check the error message above.
)
echo.
pause
exit /b %EXIT_CODE%
