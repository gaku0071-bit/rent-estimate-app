@echo off
call "%~dp0update-extension.bat"
