(function initRealproEstimateContent() {
  const PREFIX = "rent-estimate-extension-";
  const UNKNOWN_STORE_KEY = "rentEstimateUnregisteredFeeItemsV1";
  const CUSTOM_RULES_STORE_KEY = "rentEstimateCustomFeeRulesV1";
  const CUSTOM_CATEGORY_OPTIONS = [
    ["asExtra", "追加項目のまま保存"],
    ["optional", "任意"],
    ["cleaningFee", "清掃料"],
    ["waterSanitizingFee", "水廻消毒"],
    ["keyFee", "鍵交換"],
    ["antibacterialFee", "抗菌・消毒"],
    ["supportFee", "24時間サポート"],
    ["stoveMaintenanceFee", "ストーブ・暖房整備"],
    ["acCleaningFee", "エアコン清掃"],
    ["monthlyGuaranteeFee", "月額保証料"],
    ["petFee", "ペット"],
    ["townFee", "町内会費"],
    ["gasLeaseFee", "水道・リース"],
    ["waterDrainFee", "水落・水抜"],
    ["deodorizingFee", "消臭"],
    ["remark", "備考"],
  ];
  if (document.getElementById(`${PREFIX}button`)) return;

  const state = {
    result: null,
    learnedItems: [],
    customRules: [],
  };

  function yen(value) {
    return new Intl.NumberFormat("ja-JP", {
      style: "currency",
      currency: "JPY",
      maximumFractionDigits: 0,
    }).format(Number(value || 0));
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;");
  }

  function timingLabel(value) {
    return {
      initial: "契約時",
      monthly: "月額",
      moveout: "退去時",
      choice: "要確認",
      remark: "備考",
    }[value] || "要確認";
  }

  function categoryLabel(value) {
    return {
      monthlyGuaranteeFee: "月額保証料",
      acCleaningFee: "エアコン清掃",
      stoveMaintenanceFee: "ストーブ・暖房整備",
      waterSanitizingFee: "水廻消毒",
      cleaningFee: "清掃料",
      keyFee: "鍵交換",
      antibacterialFee: "抗菌・消毒",
      supportFee: "24時間サポート",
      deodorizingFee: "消臭",
      petFee: "ペット",
      waterDrainFee: "水落・水抜",
      gasLeaseFee: "水道・リース",
      townFee: "町内会費",
      remark: "備考",
      guaranteePersonal: "初回保証料",
      unregistered: "未登録",
    }[value] || value || "未分類";
  }

  function sourceTypeLabel(value) {
    return {
      "realpro-admin-room": "リアプロ管理画面",
      "realpro-public-room": "リアプロ公開詳細",
    }[value] || "リアプロ";
  }

  function truncate(value, length = 92) {
    const text = String(value || "");
    return text.length > length ? `${text.slice(0, length)}...` : text;
  }

  function compactKey(value) {
    return String(value || "")
      .normalize("NFKC")
      .replace(/\s+/g, "")
      .toLowerCase();
  }

  function storageGet(key, fallback) {
    return new Promise((resolve) => {
      try {
        if (typeof chrome === "undefined" || !chrome.storage?.local) {
          resolve(fallback);
          return;
        }
        chrome.storage.local.get({ [key]: fallback }, (items) => {
          resolve(items?.[key] || fallback);
        });
      } catch (_error) {
        resolve(fallback);
      }
    });
  }

  function storageSet(key, value) {
    return new Promise((resolve) => {
      try {
        if (typeof chrome === "undefined" || !chrome.storage?.local) {
          resolve(false);
          return;
        }
        chrome.storage.local.set({ [key]: value }, () => resolve(true));
      } catch (_error) {
        resolve(false);
      }
    });
  }

  async function rememberUnregisteredItems(items) {
    const existing = await storageGet(UNKNOWN_STORE_KEY, []);
    const map = new Map((Array.isArray(existing) ? existing : []).map((item) => [item.key, item]));
    const seenNow = new Set();
    const now = new Date().toISOString();

    for (const fee of items || []) {
      const label = String(fee.label || "").trim();
      if (!label) continue;
      const key = compactKey(label);
      if (!key || seenNow.has(key)) continue;
      seenNow.add(key);
      const current = map.get(key) || {
        key,
        label,
        count: 0,
        firstSeen: now,
        lastSeen: now,
        amounts: [],
        sourceSections: [],
        examples: [],
      };
      current.label = current.label || label;
      current.count = Number(current.count || 0) + 1;
      current.lastSeen = now;
      if (fee.amount && !current.amounts.includes(fee.amount)) {
        current.amounts = current.amounts.concat(fee.amount).slice(-5);
      }
      if (fee.sourceSection && !current.sourceSections.includes(fee.sourceSection)) {
        current.sourceSections = current.sourceSections.concat(fee.sourceSection).slice(-5);
      }
      if (fee.sourceText && !current.examples.includes(fee.sourceText)) {
        current.examples = current.examples.concat(fee.sourceText).slice(-3);
      }
      map.set(key, current);
    }

    const next = Array.from(map.values())
      .sort((a, b) => String(b.lastSeen).localeCompare(String(a.lastSeen)))
      .slice(0, 300);
    await storageSet(UNKNOWN_STORE_KEY, next);
    return next;
  }

  function feeDiagnostic(fee) {
    return {
      label: fee.label,
      amount: fee.amount,
      timing: fee.timing,
      type: fee.type,
      category: fee.category || "",
      optional: Boolean(fee.optional),
      confidence: fee.confidence || "",
      sourceSection: fee.sourceSection || "",
      sourceText: fee.sourceText || "",
    };
  }

  function refreshFeeDiagnostics(extracted, appliedRules = []) {
    const diagnostics = extracted.diagnostics || {};
    const classifiedFees = (extracted.fees || []).map(feeDiagnostic);
    const unregisteredFees = classifiedFees.filter((fee) => fee.category === "unregistered");
    const warnings = Array.isArray(diagnostics.warnings) ? diagnostics.warnings.slice() : [];
    const nextWarnings = unregisteredFees.length
      ? warnings
      : warnings.filter((warning) => !String(warning).includes("未登録の費用項目"));
    if (appliedRules.length) {
      nextWarnings.push("端末内の分類ルールを適用しました。分類内容を確認してください。");
    }
    extracted.diagnostics = {
      ...diagnostics,
      extractedFeeCount: extracted.fees?.length || 0,
      classifiedFees,
      unregisteredFees,
      choiceFees: classifiedFees.filter((fee) => fee.timing === "choice"),
      moveoutFees: classifiedFees.filter((fee) => fee.timing === "moveout"),
      monthlyFees: classifiedFees.filter((fee) => fee.timing === "monthly"),
      customRuleCount: state.customRules.length,
      appliedCustomRuleCount: appliedRules.length,
      appliedCustomRules: appliedRules,
      warnings: nextWarnings,
    };
  }

  function applyCustomRulesToExtracted(extracted) {
    const ruleMap = new Map((state.customRules || []).map((rule) => [rule.key, rule]));
    const appliedRules = [];
    for (const fee of extracted.fees || []) {
      if (fee.category !== "unregistered") continue;
      const rule = ruleMap.get(compactKey(fee.label));
      if (!rule?.category) continue;
      fee.category = rule.category;
      fee.confidence = "custom";
      fee.customRule = true;
      if (rule.category === "monthlyGuaranteeFee") {
        fee.timing = "monthly";
        fee.type = "monthly";
      }
      if (["optional", "optionalMonthly"].includes(rule.category)) {
        fee.type = "optional";
        fee.optional = true;
      }
      if (rule.category === "remark") {
        fee.noInitialEstimate = true;
      }
      appliedRules.push({
        label: fee.label,
        category: rule.category,
        ruleLabel: rule.label || fee.label,
      });
    }
    refreshFeeDiagnostics(extracted, appliedRules);
  }

  async function loadCustomRules() {
    const rules = await storageGet(CUSTOM_RULES_STORE_KEY, []);
    return Array.isArray(rules) ? rules : [];
  }

  async function saveCustomRule(label, category) {
    const rules = await loadCustomRules();
    const now = new Date().toISOString();
    const key = compactKey(label);
    const nextRules = rules.filter((rule) => rule.key !== key);
    nextRules.unshift({
      key,
      label,
      category,
      count: Number(rules.find((rule) => rule.key === key)?.count || 0) + 1,
      createdAt: rules.find((rule) => rule.key === key)?.createdAt || now,
      updatedAt: now,
    });
    const sorted = nextRules.slice(0, 300);
    await storageSet(CUSTOM_RULES_STORE_KEY, sorted);
    state.customRules = sorted;
    return sorted;
  }

  function categoryOptionsHtml(selected = "") {
    return CUSTOM_CATEGORY_OPTIONS.map(
      ([value, label]) => `<option value="${escapeHtml(value)}" ${selected === value ? "selected" : ""}>${escapeHtml(label)}</option>`,
    ).join("");
  }

  function feeDiagnosticList(title, items, emptyText) {
    if (!items?.length) {
      return `
        <div class="${PREFIX}diagnostic-card">
          <h3>${escapeHtml(title)} <span>0件</span></h3>
          <p class="${PREFIX}diagnostic-empty">${escapeHtml(emptyText)}</p>
        </div>
      `;
    }
    return `
      <div class="${PREFIX}diagnostic-card">
        <h3>${escapeHtml(title)} <span>${items.length}件</span></h3>
        <ul class="${PREFIX}diagnostic-list">
          ${items.slice(0, 20).map((fee) => `
            <li>
              <span>
                <strong>${escapeHtml(fee.label)}</strong>
                <small>${escapeHtml(categoryLabel(fee.category))} / ${escapeHtml(timingLabel(fee.timing))} / ${escapeHtml(fee.sourceSection || "")}</small>
              </span>
              <b>${yen(fee.amount)}</b>
            </li>
          `).join("")}
        </ul>
        ${items.length > 20 ? `<p class="${PREFIX}diagnostic-note">ほか ${items.length - 20}件</p>` : ""}
      </div>
    `;
  }

  function unregisteredEditorHtml(items) {
    if (!items?.length) {
      return `
        <div class="${PREFIX}diagnostic-card">
          <h3>未登録項目 <span>0件</span></h3>
          <p class="${PREFIX}diagnostic-empty">未登録の費用項目はありません。</p>
        </div>
      `;
    }
    return `
      <div class="${PREFIX}diagnostic-card ${PREFIX}diagnostic-card-full">
        <h3>未登録項目 <span>${items.length}件</span></h3>
        <ul class="${PREFIX}unknown-editor-list">
          ${items.slice(0, 20).map((fee) => `
            <li>
              <span>
                <strong>${escapeHtml(fee.label)}</strong>
                <small>${escapeHtml(timingLabel(fee.timing))} / ${escapeHtml(fee.sourceSection || "")} / ${yen(fee.amount)}</small>
                ${fee.sourceText ? `<em>${escapeHtml(truncate(fee.sourceText))}</em>` : ""}
              </span>
              <select data-unknown-category="${escapeHtml(fee.label)}" aria-label="${escapeHtml(fee.label)}の分類">
                ${categoryOptionsHtml()}
              </select>
              <button type="button" data-save-unknown-rule="${escapeHtml(fee.label)}">次回からこの分類にする</button>
            </li>
          `).join("")}
        </ul>
        ${items.length > 20 ? `<p class="${PREFIX}diagnostic-note">ほか ${items.length - 20}件</p>` : ""}
      </div>
    `;
  }

  function customRulesHtml(items) {
    if (!items?.length) return "";
    return `
      <div class="${PREFIX}diagnostic-card ${PREFIX}diagnostic-card-full">
        <h3>端末内の分類ルール <span>${items.length}件</span></h3>
        <ul class="${PREFIX}diagnostic-list">
          ${items.slice(0, 20).map((rule) => `
            <li>
              <span>
                <strong>${escapeHtml(rule.label)}</strong>
                <small>${escapeHtml(categoryLabel(rule.category))} / 登録 ${Number(rule.count || 0)}回</small>
              </span>
            </li>
          `).join("")}
        </ul>
        ${items.length > 20 ? `<p class="${PREFIX}diagnostic-note">ほか ${items.length - 20}件</p>` : ""}
      </div>
    `;
  }

  function skippedLineList(items) {
    if (!items?.length) return "";
    return `
      <div class="${PREFIX}diagnostic-card">
        <h3>除外・未分類にした行 <span>${items.length}件</span></h3>
        <ul class="${PREFIX}diagnostic-list">
          ${items.slice(0, 25).map((item) => `
            <li>
              <span>
                <strong>${escapeHtml(item.reason)}</strong>
                <small>${escapeHtml(item.section || "")}</small>
                <em>${escapeHtml(truncate(item.text))}</em>
              </span>
            </li>
          `).join("")}
        </ul>
        ${items.length > 25 ? `<p class="${PREFIX}diagnostic-note">ほか ${items.length - 25}件</p>` : ""}
      </div>
    `;
  }

  function learnedItemsHtml(items) {
    if (!items?.length) {
      return `
        <div class="${PREFIX}diagnostic-card">
          <h3>端末内の未登録履歴 <span>0件</span></h3>
          <p class="${PREFIX}diagnostic-empty">まだ未登録項目の履歴はありません。</p>
        </div>
      `;
    }
    return `
      <div class="${PREFIX}diagnostic-card ${PREFIX}diagnostic-card-full">
        <h3>端末内の未登録履歴 <span>${items.length}件</span></h3>
        <ul class="${PREFIX}diagnostic-list">
          ${items.slice(0, 20).map((item) => `
            <li>
              <span>
                <strong>${escapeHtml(item.label)}</strong>
                <small>出現 ${Number(item.count || 0)}回 / ${escapeHtml((item.sourceSections || []).join("、") || "取得元不明")}</small>
                ${(item.examples || []).slice(0, 1).map((example) => `<em>${escapeHtml(truncate(example))}</em>`).join("")}
              </span>
              <b>${(item.amounts || []).length ? item.amounts.map(yen).join(" / ") : "-"}</b>
            </li>
          `).join("")}
        </ul>
        ${items.length > 20 ? `<p class="${PREFIX}diagnostic-note">ほか ${items.length - 20}件</p>` : ""}
      </div>
    `;
  }

  function adminRowsTable(rows) {
    if (!rows?.length) return "";
    return `
      <details class="${PREFIX}diagnostic-details">
        <summary>管理画面のその他費用 全行ログ <span>${rows.length}行</span></summary>
        <div class="${PREFIX}diagnostic-table-wrap">
          <table class="${PREFIX}diagnostic-table">
            <thead>
              <tr>
                <th>No</th>
                <th>項目</th>
                <th>分類</th>
                <th>支払</th>
                <th>金額</th>
                <th>判定</th>
              </tr>
            </thead>
            <tbody>
              ${rows.slice(0, 80).map((row) => `
                <tr>
                  <td>${row.index}</td>
                  <td>
                    <strong>${escapeHtml(row.label || row.typeText || "空欄")}</strong>
                    <small>${escapeHtml(truncate(row.sourceText, 70))}</small>
                  </td>
                  <td>${escapeHtml(categoryLabel(row.category))}</td>
                  <td>${escapeHtml(timingLabel(row.timing))}</td>
                  <td>${row.amount ? yen(row.amount) : "-"}</td>
                  <td>
                    <span class="${PREFIX}status ${PREFIX}status-${escapeHtml(row.status)}">${escapeHtml(row.reason || row.status)}</span>
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
        ${rows.length > 80 ? `<p class="${PREFIX}diagnostic-note">ほか ${rows.length - 80}行</p>` : ""}
      </details>
    `;
  }

  function diagnosticsHtml(extracted) {
    const diagnostics = extracted.diagnostics || {};
    const guarantee = diagnostics.guaranteeParsed || extracted.guarantee || {};
    const guaranteeTargets = guaranteeTargetSummary(extracted);
    return `
      <section class="${PREFIX}section ${PREFIX}diagnostics">
        <details open>
          <summary>
            <span>読込診断</span>
            <small>${escapeHtml(sourceTypeLabel(diagnostics.sourceType))} / 費用 ${diagnostics.extractedFeeCount || 0}件</small>
          </summary>
          <div class="${PREFIX}diagnostic-toolbar">
            <div>
              <span>読込元</span>
              <strong>${escapeHtml(sourceTypeLabel(diagnostics.sourceType))}</strong>
            </div>
            <div>
              <span>費用行</span>
              <strong>${diagnostics.feeLineCount || 0}行</strong>
            </div>
            <div>
              <span>未登録</span>
              <strong>${diagnostics.unregisteredFees?.length || 0}件</strong>
            </div>
            <div class="${PREFIX}diagnostic-actions">
              <button type="button" data-copy-diagnostics>診断内容をコピー</button>
              <button type="button" data-copy-unknowns ${state.learnedItems.length ? "" : "disabled"}>未登録履歴をコピー</button>
            </div>
          </div>
          <div class="${PREFIX}diagnostic-grid">
            <div class="${PREFIX}diagnostic-card">
              <h3>基本情報</h3>
              <dl class="${PREFIX}diagnostic-kv">
                <div><dt>賃料</dt><dd>${yen(extracted.base.rent)}</dd></div>
                <div><dt>管理費・共益費</dt><dd>${yen(extracted.base.commonFee)}</dd></div>
                <div><dt>敷金</dt><dd>${yen(extracted.base.deposit)}</dd></div>
                <div><dt>礼金</dt><dd>${yen(extracted.base.keyMoney)}</dd></div>
                <div><dt>保険料</dt><dd>${yen(extracted.base.insuranceFee)}</dd></div>
                <div><dt>駐車場</dt><dd>${yen(extracted.base.parkingFee)}</dd></div>
              </dl>
            </div>
            <div class="${PREFIX}diagnostic-card">
              <h3>保証会社</h3>
              <dl class="${PREFIX}diagnostic-kv">
                <div><dt>初回一律</dt><dd>${guarantee.fixed ? yen(guarantee.fixed) : "-"}</dd></div>
                <div><dt>初回率</dt><dd>${guarantee.initialRate ? `${guarantee.initialRate}%` : "-"}</dd></div>
                <div><dt>最低保証料</dt><dd>${guarantee.initialMinimum ? yen(guarantee.initialMinimum) : "-"}</dd></div>
                <div><dt>月額率</dt><dd>${guarantee.monthlyRate ? `${guarantee.monthlyRate}%` : "-"}</dd></div>
                <div><dt>月額最低額</dt><dd>${guarantee.monthlyMinimum ? yen(guarantee.monthlyMinimum) : "-"}</dd></div>
                <div><dt>月額固定</dt><dd>${guarantee.monthlyFixed ? yen(guarantee.monthlyFixed) : "-"}</dd></div>
                <div><dt>月額加算</dt><dd>${guarantee.monthlyFixedExtra ? yen(guarantee.monthlyFixedExtra) : "-"}</dd></div>
                <div><dt>計算対象</dt><dd>${escapeHtml(guaranteeTargets.defaultLabels || "なし")}</dd></div>
                <div><dt>対象合計</dt><dd>${yen(guaranteeTargets.defaultTotal)}</dd></div>
                <div><dt>追加候補</dt><dd>${escapeHtml(guaranteeTargets.optionalLabels || "なし")}</dd></div>
                ${guarantee.needsChoice ? `<div><dt>保証会社候補</dt><dd>${guarantee.alternatives?.length || 0}候補 / 要選択</dd></div>` : ""}
              </dl>
            </div>
            ${unregisteredEditorHtml(diagnostics.unregisteredFees || [])}
            ${learnedItemsHtml(state.learnedItems)}
            ${customRulesHtml(state.customRules)}
            ${feeDiagnosticList("契約時/退去時の選択が必要", diagnostics.choiceFees || [], "選択が必要な費用はありません。")}
            ${feeDiagnosticList("退去時費用", diagnostics.moveoutFees || [], "退去時費用はありません。")}
            ${feeDiagnosticList("月額費用", diagnostics.monthlyFees || [], "月額費用はありません。")}
            ${skippedLineList(diagnostics.skippedFeeLines || [])}
          </div>
          ${adminRowsTable(diagnostics.adminOtherCostRows || [])}
        </details>
      </section>
    `;
  }

  function firstMonthlyFeeByCategory(extracted, category) {
    return (extracted.fees || []).find((fee) =>
      fee.category === category
      && fee.timing === "monthly"
      && !fee.optional
      && Number(fee.amount || 0) > 0
    );
  }

  function guaranteeTargetSummary(extracted) {
    const defaultTargets = [
      ["賃料", extracted.base?.rent],
      ["管理費・共益費", extracted.base?.commonFee],
      ["24時間サポート", firstMonthlyFeeByCategory(extracted, "supportFee")?.amount],
      ["町内会費", firstMonthlyFeeByCategory(extracted, "townFee")?.amount],
      ["水道・リース", firstMonthlyFeeByCategory(extracted, "gasLeaseFee")?.amount],
    ].filter(([, amount]) => Number(amount || 0) > 0);

    const optionalTargets = [
      ["駐車場", extracted.base?.parkingFee],
    ].filter(([, amount]) => Number(amount || 0) > 0);

    return {
      defaultLabels: defaultTargets.map(([label]) => label).join("、"),
      optionalLabels: optionalTargets.map(([label]) => `${label}（見積画面でチェック時）`).join("、"),
      defaultTotal: defaultTargets.reduce((sum, [, amount]) => sum + Number(amount || 0), 0),
      optionalTotal: optionalTargets.reduce((sum, [, amount]) => sum + Number(amount || 0), 0),
    };
  }

  function copyDiagnostics(event) {
    if (!state.result) return;
    const payload = {
      property: state.result.extracted.property,
      base: state.result.extracted.base,
      guarantee: state.result.extracted.guarantee,
      diagnostics: state.result.extracted.diagnostics,
      customRules: state.customRules,
    };
    const text = JSON.stringify(payload, null, 2);
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
    const button = event.currentTarget;
    button.textContent = "コピーしました";
    setTimeout(() => {
      button.textContent = "診断内容をコピー";
    }, 1200);
  }

  function copyUnknownItems(event) {
    const payload = {
      exportedAt: new Date().toISOString(),
      source: "realpro-extension-local-unknowns",
      items: state.learnedItems,
      customRules: state.customRules,
    };
    const textarea = document.createElement("textarea");
    textarea.value = JSON.stringify(payload, null, 2);
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
    const button = event.currentTarget;
    button.textContent = "コピーしました";
    setTimeout(() => {
      button.textContent = "未登録履歴をコピー";
    }, 1200);
  }

  function guaranteeOptionText(option) {
    const initial = option.fixed ? `初回一律 ${yen(option.fixed)}` : `初回 ${option.initialRate || 0}%`;
    const minimum = option.initialMinimum ? `（最低 ${yen(option.initialMinimum)}）` : "";
    const recurring = [];
    if (option.monthlyRate) recurring.push(
      `月額 ${option.monthlyRate}%${option.monthlyMinimum ? `（最低 ${yen(option.monthlyMinimum)}）` : ""}`
      + `${option.monthlyFixedExtra ? ` + ${yen(option.monthlyFixedExtra)}` : ""}`,
    );
    else if (option.monthlyFixed) recurring.push(`月額 ${yen(option.monthlyFixed)}${option.monthlyFixedExtra ? ` + ${yen(option.monthlyFixedExtra)}` : ""}`);
    if (option.renewalAmount) recurring.push(`年額 ${yen(option.renewalAmount)}`);
    const recurringChoice = option.renewalAmount && (option.monthlyRate || option.monthlyFixed)
      && /いずれか|または|もしくは|又は|\bor\b/i.test(option.note || "")
      ? "（月額・年額の選択要確認）"
      : "";
    const label = option.label && !/^候補\d+$/.test(option.label) ? `${option.label}: ` : "";
    return `${label}${initial}${minimum}${recurring.length ? ` / ${recurring.join(" / ")}` : ""}${recurringChoice}`;
  }

  function guaranteeSelectionHtml(guarantee) {
    const alternatives = Array.isArray(guarantee?.alternatives) ? guarantee.alternatives : [];
    if (alternatives.length < 2) return "";
    return `
      <fieldset class="${PREFIX}guarantee-options">
        <legend>保証会社を選択してください</legend>
        ${alternatives.map((option, index) => `
          <label>
            <input type="radio" name="rent-estimate-guarantee-option" value="${index}" data-guarantee-option="${index}">
            <span>候補${index + 1}: ${escapeHtml(guaranteeOptionText(option))}</span>
          </label>
        `).join("")}
      </fieldset>
    `;
  }

  async function saveUnknownRule(event) {
    const label = event.currentTarget.dataset.saveUnknownRule;
    const select = Array.from(document.querySelectorAll("[data-unknown-category]")).find(
      (element) => element.dataset.unknownCategory === label,
    );
    const category = select?.value;
    if (!label || !category) return;
    const button = event.currentTarget;
    button.disabled = true;
    button.textContent = "保存中";
    await saveCustomRule(label, category);
    button.textContent = "保存しました";
    setTimeout(() => {
      closeModal();
      renderModal();
    }, 350);
  }

  function closeModal() {
    document.getElementById(`${PREFIX}overlay`)?.remove();
  }

  async function renderModal() {
    state.result = globalThis.RealproEstimateParser.extract(document);
    const { extracted } = state.result;
    state.customRules = await loadCustomRules();
    applyCustomRulesToExtracted(extracted);
    state.result.estimateData = globalThis.RealproEstimateParser.toEstimateData(extracted);
    state.learnedItems = await rememberUnregisteredItems(extracted.diagnostics?.unregisteredFees || []);
    const overlay = document.createElement("div");
    overlay.id = `${PREFIX}overlay`;
    overlay.innerHTML = `
      <section class="${PREFIX}modal" role="dialog" aria-modal="true" aria-label="初期費用見積へ送る">
        <header class="${PREFIX}header">
          <div>
            <strong>初期費用見積へ送る</strong>
            <span>${escapeHtml(extracted.property.title)} ${escapeHtml(extracted.property.room)}</span>
          </div>
          <button type="button" class="${PREFIX}icon-button" data-close aria-label="閉じる">×</button>
        </header>
        <div class="${PREFIX}body">
          ${extracted.diagnostics.warnings.length ? `
            <div class="${PREFIX}warning">
              ${extracted.diagnostics.warnings.map((warning) => `<p>${escapeHtml(warning)}</p>`).join("")}
            </div>
          ` : ""}
          <section class="${PREFIX}summary">
            <div><span>賃料</span><strong>${yen(extracted.base.rent)}</strong></div>
            <div><span>管理費・共益費</span><strong>${yen(extracted.base.commonFee)}</strong></div>
            <div><span>敷金</span><strong>${yen(extracted.base.deposit)}</strong></div>
            <div><span>礼金</span><strong>${yen(extracted.base.keyMoney)}</strong></div>
          </section>
          <section class="${PREFIX}section">
            <h2>取得した費用</h2>
            <div class="${PREFIX}fees">
              ${extracted.fees.length ? extracted.fees.map((fee, index) => `
                <label class="${PREFIX}fee-row">
                  <input type="checkbox" data-fee-enabled="${index}" ${fee.optional ? "" : "checked"}>
                  <span class="${PREFIX}fee-name">
                    <strong>${escapeHtml(fee.label)}</strong>
                    <small>${escapeHtml(fee.sourceSection)} / 信頼度 ${fee.confidence === "high" ? "高" : "要確認"}</small>
                  </span>
                  <select data-fee-timing="${index}" aria-label="${escapeHtml(fee.label)}の支払時期" ${fee.category === "remark" ? "disabled" : ""}>
                    ${(fee.category === "remark" ? ["remark"] : ["initial", "monthly", "moveout", "choice"]).map((timing) =>
                      `<option value="${timing}" ${fee.timing === timing ? "selected" : ""}>${timingLabel(timing)}</option>`
                    ).join("")}
                  </select>
                  <strong>${yen(fee.amount)}</strong>
                </label>
              `).join("") : `<p class="${PREFIX}empty">金額付き費用は見つかりませんでした。</p>`}
            </div>
          </section>
          <section class="${PREFIX}section">
            <h2>保証会社</h2>
            <p class="${PREFIX}guarantee">${escapeHtml(extracted.guarantee.note || "保証会社の詳細条件は取得できませんでした。")}</p>
            ${guaranteeSelectionHtml(extracted.guarantee)}
          </section>
          ${diagnosticsHtml(extracted)}
        </div>
        <footer class="${PREFIX}footer">
          <span>転送前に金額と支払時期を確認してください。</span>
          <div>
            <button type="button" data-close>キャンセル</button>
            <button type="button" class="${PREFIX}primary" data-send>見積を作成</button>
          </div>
        </footer>
      </section>
    `;

    overlay.addEventListener("click", (event) => {
      if (event.target === overlay || event.target.closest("[data-close]")) closeModal();
    });
    overlay.querySelector("[data-send]").addEventListener("click", sendToEstimate);
    overlay.querySelector("[data-copy-diagnostics]")?.addEventListener("click", copyDiagnostics);
    overlay.querySelector("[data-copy-unknowns]")?.addEventListener("click", copyUnknownItems);
    overlay.querySelectorAll("[data-save-unknown-rule]").forEach((button) => {
      button.addEventListener("click", saveUnknownRule);
    });
    document.body.appendChild(overlay);
  }

  function sendToEstimate() {
    if (!state.result) return;
    const guarantee = state.result.extracted.guarantee;
    const alternatives = Array.isArray(guarantee.alternatives) ? guarantee.alternatives : [];
    if (alternatives.length > 1) {
      const selected = document.querySelector("[data-guarantee-option]:checked");
      if (!selected) {
        alert("保証会社を1社選択してください。");
        return;
      }
      const option = alternatives[Number(selected.value)];
      if (option) {
        const originalNote = guarantee.originalNote || guarantee.note || "";
        Object.assign(guarantee, {
          fixed: option.fixed || 0,
          initialRate: option.initialRate || 0,
          initialMinimum: option.initialMinimum || 0,
          monthlyRate: option.monthlyRate || 0,
          monthlyMinimum: option.monthlyMinimum || 0,
          monthlyFixed: option.monthlyFixed || 0,
          monthlyFixedExtra: option.monthlyFixedExtra || 0,
          renewalAmount: option.renewalAmount || 0,
          renewalPeriod: option.renewalPeriod || "none",
          warnings: Array.isArray(option.warnings) ? option.warnings : [],
          selectedLabel: option.label || "",
          note: option.note || guarantee.note || "",
          originalNote,
          needsChoice: false,
        });
      }
    }
    const enabledFees = state.result.extracted.fees.filter((fee, index) => {
      const enabled = document.querySelector(`[data-fee-enabled="${index}"]`)?.checked;
      if (enabled) {
        const selectedTiming = document.querySelector(`[data-fee-timing="${index}"]`)?.value || fee.timing;
        fee.timing = selectedTiming;
        if (selectedTiming === "monthly") {
          fee.type = fee.optional || fee.type === "optionalMonthly" ? "optional" : "monthly";
        } else if (fee.type === "optionalMonthly") {
          fee.type = "optional";
        }
      }
      return enabled;
    });
    state.result.extracted.fees = enabledFees;
    state.result.estimateData = globalThis.RealproEstimateParser.toEstimateData(state.result.extracted);

    const sendButton = document.querySelector("[data-send]");
    sendButton.disabled = true;
    sendButton.textContent = "転送中";
    chrome.runtime.sendMessage(
      {
        type: "OPEN_RENT_ESTIMATE",
        payload: state.result.estimateData,
      },
      (response) => {
        if (response?.ok) {
          sendButton.textContent = "転送しました";
          setTimeout(closeModal, 700);
        } else {
          sendButton.disabled = false;
          sendButton.textContent = "見積を作成";
          alert(response?.error || "見積アプリを開けませんでした。");
        }
      },
    );
  }

  const button = document.createElement("button");
  button.id = `${PREFIX}button`;
  button.type = "button";
  button.textContent = "初期費用見積へ送る";
  button.addEventListener("click", renderModal);
  document.body.appendChild(button);
})();
