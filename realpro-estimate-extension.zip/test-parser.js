const assert = require("node:assert/strict");
const { JSDOM } = require("jsdom");

require("./realpro-parser.js");

function cell(text) {
  return { innerText: text, textContent: text };
}

function row(values) {
  return {
    querySelectorAll() {
      return values.map(cell);
    },
  };
}

function documentFixture(rows, bodyText, url = "https://www.realnetpro.com/room_detail.php?id=1153846&type=room") {
  return {
    body: { innerText: bodyText },
    location: { href: url },
    querySelectorAll(selector) {
      return selector === "tr" ? rows.map(row) : [];
    },
  };
}

const rows = [
  ["物件名", "ウィスティリア宮の沢"],
  ["号室名", "202（2階部分）"],
  ["所在地", "北海道札幌市西区発寒六条１０丁目3-22地図を見る"],
  ["交通", "地下東西線「宮の沢」徒歩1分"],
  ["賃料 / 管理費・共益費", "70,000円 / 3,000円"],
  ["敷金 / 礼金", "敷金:1ヶ月 礼金:なし 礼金備考： ペット飼育時1ヶ月"],
  ["間取", "2LDK [ 10.3LDx3.1Kx7.1洋x5.3洋 ] 59.95m2"],
  ["状態", "空室"],
  ["入居可能時期", "相談"],
  ["築年月", "2015年03月"],
  ["駐車場", "空きなし 12月～3月まで RH料3,000円"],
];

const bodyText = `
物件名 ウィスティリア宮の沢
諸費用
※ データ登録のあるものをリストしています。
○ 保証会社
保証会社利用必須 エポスカード 初回保証料 月額賃料等の50%(最低20,000円)
月額保証料 月額賃料等の1.5%(最低700円)
○ 保険
保険要加入 東京海上ミレア少額短期保険 2年契約 21,500円
○ ランニングコスト
緊急電話対応費 月額 1,980円(税込)
町内会費 月額 300円
○ 退去時
水廻り消毒料 退去時 33,000円(税込)
○ その他
エアコン清掃料 希望者のみ 16,500円(税込)
客付業者様へ
○ 退去時費用:室内清掃料27,500円(税込) ストーブ清掃料16,500円(税込) エアコン清掃料16,500円(税込)
○ 普通借家（2年間）
諸費用
広告掲載
`;

const result = globalThis.RealproEstimateParser.extract(documentFixture(rows, bodyText));

assert.equal(result.extracted.property.title, "ウィスティリア宮の沢");
assert.equal(result.extracted.property.room, "202(2階部分)");
assert.equal(result.extracted.property.area, "59.95㎡");
assert.equal(result.extracted.base.rent, 70000);
assert.equal(result.extracted.base.commonFee, 3000);
assert.equal(result.extracted.base.deposit, 70000);
assert.equal(result.extracted.base.keyMoney, 0);
assert.equal(result.extracted.base.parkingFee, 0);
assert.equal(result.extracted.base.insuranceFee, 21500);
assert.equal(result.extracted.base.insuranceTiming, "initial");
assert.equal(result.estimateData.settings.feeTimings.insuranceFee, "initial");
assert.equal(result.estimateData.settings.feeTypes.insuranceFee, "initial");
assert.equal(result.extracted.guarantee.initialRate, 50);
assert.equal(result.extracted.guarantee.initialMinimum, 20000);
assert.equal(result.extracted.guarantee.fixed, 0);
assert.equal(result.extracted.guarantee.monthlyRate, 1.5);
assert.equal(result.extracted.guarantee.monthlyFixed, 0);

const support = result.extracted.fees.find((fee) => fee.label.includes("緊急電話対応費"));
const town = result.extracted.fees.find((fee) => fee.category === "townFee");
const cleaning = result.extracted.fees.find((fee) => fee.category === "waterSanitizingFee");
const optionalAc = result.extracted.fees.find((fee) => fee.category === "acCleaningFee");
const optionalPet = result.extracted.fees.find((fee) => fee.category === "petFee");
const brokerRoomCleaning = result.extracted.fees.find(
  (fee) => fee.label === "室内清掃料" && fee.amount === 27500,
);
const brokerStoveCleaning = result.extracted.fees.find(
  (fee) => fee.label === "ストーブ清掃料" && fee.amount === 16500,
);

assert.equal(support.amount, 1980);
assert.equal(support.timing, "monthly");
assert.equal(support.category, "supportFee");
assert.equal(town.amount, 300);
assert.equal(town.timing, "monthly");
assert.equal(cleaning.amount, 33000);
assert.equal(cleaning.timing, "moveout");
assert.equal(optionalAc.amount, 16500);
assert.equal(optionalAc.optional, true);
assert.equal(optionalPet.label, "ペット飼育時礼金");
assert.equal(optionalPet.amount, 70000);
assert.equal(optionalPet.optional, true);
assert.equal(brokerRoomCleaning.timing, "moveout");
assert.equal(brokerRoomCleaning.sourceSection, "客付業者様へ");
assert.equal(brokerStoveCleaning.timing, "moveout");

assert.equal(result.estimateData.amounts.supportFee, 1980);
assert.equal(result.estimateData.amounts.townFee, 300);
assert.equal(result.estimateData.amounts.waterSanitizingFee, 33000);
assert.equal(result.estimateData.settings.feeTypes.acCleaningFee, undefined);
assert.equal(result.estimateData.settings.guaranteeMode, "percent");
assert.equal(result.estimateData.settings.guaranteeMinimum, 20000);

const optionalMonthlyTransfer = globalThis.RealproEstimateParser.toEstimateData({
  property: { title: "任意費用テスト", room: "101" },
  base: { rent: 50000, commonFee: 3000, deposit: 0, keyMoney: 0, parkingFee: 0, insuranceFee: 0 },
  guarantee: { fixed: 0, initialRate: 50, initialMinimum: 0, monthlyRate: 0, monthlyFixed: 0, monthlyFixedExtra: 0, note: "" },
  fees: [
    { label: "駐輪場利用料", amount: 550, timing: "monthly", type: "optionalMonthly", optional: true, category: "unregistered", sourceSection: "その他" },
  ],
});
assert.equal(optionalMonthlyTransfer.version, 3);
assert.equal(optionalMonthlyTransfer.settings.extraFees[0].type, "optional");
assert.equal(optionalMonthlyTransfer.settings.extraFees[0].timing, "monthly");

const providerOnlyTransfer = globalThis.RealproEstimateParser.toEstimateData({
  property: { title: "保証条件未記載テスト", room: "102" },
  base: { rent: 50000, commonFee: 0, deposit: 0, keyMoney: 0, parkingFee: 0, insuranceFee: 0 },
  guarantee: { fixed: 0, initialRate: 0, initialMinimum: 0, monthlyRate: 0, monthlyFixed: 0, monthlyFixedExtra: 0, note: "保証会社利用必須 全保連" },
  fees: [],
});
assert.equal(providerOnlyTransfer.settings.guaranteeMode, "none");
assert.equal(providerOnlyTransfer.settings.guaranteeRate, 0);
assert.equal(providerOnlyTransfer.settings.monthlyGuaranteeMode, "none");

const alternativeGuaranteeText = `
諸費用
○ 保証会社
保証会社利用必須 ジェイリース
初回・月額保証料:借主負担(初回80%・月400円または初回50%・月800円)年間更新料:無し
広告掲載
`;
const alternativeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(rows, alternativeGuaranteeText),
);
assert.equal(alternativeResult.extracted.guarantee.initialRate, 80);
assert.equal(alternativeResult.extracted.guarantee.fixed, 0);
assert.equal(alternativeResult.extracted.guarantee.monthlyFixed, 400);
assert.equal(alternativeResult.estimateData.settings.guaranteeMode, "percent");

const manYenGuaranteeText = `
諸費用
○ 保証会社
保証会社利用必須 株式会社Liverex ・初回保証料50%(更新料なし・最低保証料2万円) ・毎月継続保証料として月額賃料等の1.95%が毎月かかります。
広告掲載
`;
const manYenResult = globalThis.RealproEstimateParser.extract(
  documentFixture(rows, manYenGuaranteeText),
);
assert.equal(manYenResult.extracted.guarantee.initialRate, 50);
assert.equal(manYenResult.extracted.guarantee.initialMinimum, 20000);
assert.equal(manYenResult.extracted.guarantee.monthlyRate, 1.95);

const slashMonthlyGuaranteeText = `
諸費用
○ 保証会社
保証会社利用必須 エポスカード 初回50% 更新10,000円/年 月額/賃料総額の1.5%
広告掲載
`;
const slashMonthlyResult = globalThis.RealproEstimateParser.extract(
  documentFixture(rows, slashMonthlyGuaranteeText),
);
assert.equal(slashMonthlyResult.extracted.guarantee.initialRate, 50);
assert.equal(slashMonthlyResult.extracted.guarantee.monthlyRate, 1.5);
assert.equal(slashMonthlyResult.extracted.guarantee.renewalAmount, 10000);
assert.equal(slashMonthlyResult.estimateData.settings.guaranteeRenewalAmount, 10000);

const laterMinimumText = `
諸費用
○ 保証会社
保証会社利用必須 オリコフォレントインシュア 初回保証料50%、月額保証料総支払額の1%のみ。オリコフォレントも最低保証料20,000円になりました。
広告掲載
`;
const laterMinimumResult = globalThis.RealproEstimateParser.extract(
  documentFixture(rows, laterMinimumText),
);
assert.equal(laterMinimumResult.extracted.guarantee.initialRate, 50);
assert.equal(laterMinimumResult.extracted.guarantee.initialMinimum, 20000);
assert.equal(laterMinimumResult.extracted.guarantee.monthlyRate, 1);

const satelliteRows = [
  ["物件名", "サテライトコート22"],
  ["号室名", "201（3階部分）"],
  ["所在地", "北海道札幌市西区宮の沢二条2丁目6-16"],
  ["交通", "地下東西線「宮の沢」徒歩10分"],
  ["賃料 / 管理費・共益費", "65,000円 / 0円"],
  ["敷金 / 礼金", "敷金:1ヶ月 礼金:なし"],
  ["間取", "2LDK 52m2"],
  ["状態", "空室"],
  ["築年月", "1990年"],
  ["駐車場", "空きなし"],
];
const satelliteText = `
諸費用
○ 保証会社
保証会社利用必須 Casa 初回保証料 賃料合計の50%(最低20,000円) 月額保証料 賃料合計の1.5%(最低700円)
○ ランニングコスト
24時間管理費 月額 1,320円
広告掲載
`;
const satelliteResult = globalThis.RealproEstimateParser.extract(
  documentFixture(satelliteRows, satelliteText),
);
assert.equal(satelliteResult.estimateData.settings.guaranteeMode, "percent");
assert.equal(satelliteResult.estimateData.settings.guaranteeRate, 50);
assert.equal(satelliteResult.estimateData.settings.guaranteeMinimum, 20000);
assert.equal(satelliteResult.extracted.guarantee.fixed, 0);

const monthlyMinimumOnlyText = `
諸費用
○ 保証会社
保証会社利用必須 Casa 月額保証料 賃料合計の1.5%(最低20,000円)
広告掲載
`;
const monthlyMinimumOnlyResult = globalThis.RealproEstimateParser.extract(
  documentFixture(satelliteRows, monthlyMinimumOnlyText),
);
assert.equal(monthlyMinimumOnlyResult.extracted.guarantee.initialMinimum, 0);
assert.equal(monthlyMinimumOnlyResult.extracted.guarantee.monthlyRate, 1.5);

const companySpecificRateText = `
諸費用
○ 保証会社
保証会社利用必須 Casa 初回保証料 総賃料の30% 月額保証料 総賃料の2%
広告掲載
`;
const companySpecificRateResult = globalThis.RealproEstimateParser.extract(
  documentFixture(satelliteRows, companySpecificRateText),
);
assert.equal(companySpecificRateResult.extracted.guarantee.initialRate, 30);
assert.equal(companySpecificRateResult.extracted.guarantee.monthlyRate, 2);

const monthlyRatePlusFixedText = `
諸費用
○ 保証会社
保証会社利用必須 オリコ 初回保証料50% 月額保証料 総賃料の1.5%＋月額手数料330円
広告掲載
`;
const monthlyRatePlusFixedResult = globalThis.RealproEstimateParser.extract(
  documentFixture(satelliteRows, monthlyRatePlusFixedText),
);
assert.equal(monthlyRatePlusFixedResult.extracted.guarantee.initialRate, 50);
assert.equal(monthlyRatePlusFixedResult.extracted.guarantee.monthlyRate, 1.5);
assert.equal(monthlyRatePlusFixedResult.extracted.guarantee.monthlyFixedExtra, 330);

const multipleProviderFixedGuaranteeText = `
諸費用
○ 保証会社
保証会社利用必須 あんしん保証→全保連の順で審査します
【あんしん保証】初回保証料:賃料総額の50%、月額費用:880円、年間更新料:10,000円
【全保連】初回保証料:賃料総額の100%、月額費用:330円、年間更新料:13,000円
広告掲載
`;
const multipleProviderFixedGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(satelliteRows, multipleProviderFixedGuaranteeText),
);
assert.equal(multipleProviderFixedGuaranteeResult.extracted.guarantee.initialRate, 50);
assert.equal(multipleProviderFixedGuaranteeResult.extracted.guarantee.monthlyRate, 0);
assert.equal(multipleProviderFixedGuaranteeResult.extracted.guarantee.monthlyFixed, 880);
assert.equal(multipleProviderFixedGuaranteeResult.extracted.guarantee.needsChoice, true);
assert.equal(multipleProviderFixedGuaranteeResult.extracted.guarantee.alternatives.length, 2);

const splitPlanGuaranteeText = `
諸費用
○ 保証会社
保証会社利用必須 JID通常:初回保証料50%、更新保証料30%/2年、集送金手数料330円(税込) JID分割:初回保証料50%、月額保証料1.0%、集送金手数料330円(税込)
広告掲載
`;
const splitPlanGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(satelliteRows, splitPlanGuaranteeText),
);
assert.equal(splitPlanGuaranteeResult.extracted.guarantee.monthlyFixed, 0);
assert.equal(splitPlanGuaranteeResult.extracted.guarantee.monthlyFixedExtra, 330);
assert.equal(splitPlanGuaranteeResult.extracted.guarantee.monthlyRate, 0);
assert.equal(splitPlanGuaranteeResult.extracted.guarantee.needsChoice, true);
assert.equal(splitPlanGuaranteeResult.extracted.guarantee.alternatives.length, 2);
assert.equal(splitPlanGuaranteeResult.extracted.guarantee.alternatives[1].monthlyRate, 1);
assert.equal(splitPlanGuaranteeResult.extracted.guarantee.alternatives[1].monthlyFixedExtra, 330);

const protectionPlanGuaranteeText = `
諸費用
○ 保証会社
保証会社利用必須 全保連 初回保証料:賃料の50%、月額:880円、更新時:13,000円(保証人あり) 高齢者・生活保護受給者:見守りプラン:初回保証料:賃料の50%、月額保証料:2,500円(保証人なし) ライフあんしん保証:初回保証料:賃料の50%、月額880円、更新時:10,000円
広告掲載
`;
const protectionPlanGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(satelliteRows, protectionPlanGuaranteeText),
);
assert.equal(protectionPlanGuaranteeResult.extracted.guarantee.monthlyRate, 0);
assert.equal(protectionPlanGuaranteeResult.extracted.guarantee.monthlyFixed, 880);
assert.equal(protectionPlanGuaranteeResult.extracted.guarantee.needsChoice, true);
assert.equal(protectionPlanGuaranteeResult.extracted.guarantee.alternatives.length, 3);
assert.equal(protectionPlanGuaranteeResult.extracted.guarantee.alternatives.some((item) => item.monthlyFixed === 2500), true);

assert.equal(monthlyRatePlusFixedResult.estimateData.settings.monthlyGuaranteeFixedExtra, 330);

const pierlessRows = [
  ["物件名", "ピアレス麻生"],
  ["号室名", "407(4階部分)"],
  ["所在地", "北海道札幌市北区北三十七条西9丁目1-10"],
  ["交通", "地下南北線「麻生」徒歩8分"],
  ["賃料 / 管理費・共益費", "67,000円 / 3,000円"],
  ["敷金 / 礼金", "敷金:1ヶ月 礼金:なし"],
  ["間取", "2LDK 50.06m2"],
  ["状態", "退去予定"],
  ["築年月", "1989年03月"],
  ["駐車場", "敷地内駐車場/空きなし/11,000円(税込)"],
];
const pierlessText = `
諸費用
○ 保証会社
保証会社利用必須 日本セーフティー 初回保証委託料:60%(保証人あり50%)・更新料:1万円・月々決済手数料:300円
○ 保険
保険要加入 2年契約 22,000円
○ 初期費用
契約事務手数料 契約時 11,000円(税込)
○ ランニングコスト
夜間緊急サポート 月額 1,100円(税込)
○ その他
ハウスクリーニング料 契約時または退去時 38,500円(税込)
エアコン分解整備料 契約時または退去時 19,800円(税込)
広告掲載
`;
const pierlessResult = globalThis.RealproEstimateParser.extract(
  documentFixture(pierlessRows, pierlessText),
);
assert.equal(pierlessResult.extracted.guarantee.initialRate, 60);
assert.equal(pierlessResult.extracted.guarantee.monthlyFixed, 0);
assert.equal(pierlessResult.extracted.guarantee.monthlyFixedExtra, 300);
assert.equal(pierlessResult.extracted.diagnostics.sourceType, "realpro-public-room");
assert.equal(pierlessResult.extracted.diagnostics.guaranteeParsed.monthlyFixed, 0);
assert.equal(
  pierlessResult.extracted.diagnostics.skippedFeeLines.some((line) => line.text.includes("契約事務手数料") && line.reason === "顧客請求対象外"),
  true,
);
assert.equal(
  pierlessResult.extracted.diagnostics.choiceFees.some((fee) => fee.label === "ハウスクリーニング料"),
  true,
);
assert.equal(pierlessResult.estimateData.amounts.monthlyGuaranteeFee, 300);
assert.equal(pierlessResult.estimateData.settings.monthlyGuaranteeMode, "fixed");
assert.equal(pierlessResult.estimateData.settings.feeTimings.monthlyGuaranteeFee, "monthly");
assert.equal(pierlessResult.extracted.fees.some((fee) => fee.label === "契約事務手数料"), false);

const monthlyInsuranceText = `
諸費用
○ 保険
火災保険 月額 900円
○ ランニングコスト
24時間管理費 月額 1,100円
広告掲載
`;
const monthlyInsuranceResult = globalThis.RealproEstimateParser.extract(
  documentFixture(rows, monthlyInsuranceText),
);
assert.equal(monthlyInsuranceResult.extracted.base.insuranceFee, 900);
assert.equal(monthlyInsuranceResult.extracted.base.insuranceTiming, "monthly");
assert.equal(monthlyInsuranceResult.estimateData.settings.feeTimings.insuranceFee, "monthly");
assert.equal(monthlyInsuranceResult.estimateData.settings.feeTypes.insuranceFee, "monthly");
assert.equal(monthlyInsuranceResult.estimateData.settings.feeLabels.insuranceFee, "火災保険料（月額）");

const withdrawalFeeGuaranteeText = `
諸費用
○ 保証会社
保証会社利用必須 日本セーフティー 初回保証料:月額合計の50% 月額保証料:800円 ※引落手数料440円(税込)/月
広告掲載
`;
const withdrawalFeeGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(rows, withdrawalFeeGuaranteeText),
);
assert.equal(withdrawalFeeGuaranteeResult.extracted.guarantee.monthlyFixed, 800);
assert.equal(withdrawalFeeGuaranteeResult.extracted.guarantee.monthlyFixedExtra, 440);
assert.equal(withdrawalFeeGuaranteeResult.estimateData.amounts.monthlyGuaranteeFee, 1240);

function adminDocumentFixture(html) {
  const dom = new JSDOM(html, { url: "https://kanri.realnetpro.com/main.php?method=room&building_id=620266" });
  return dom.window.document;
}

const adminResult = globalThis.RealproEstimateParser.extract(
  adminDocumentFixture(`
    <form>
      <input name="building_id" value="620266">
      <input name="go_number" value="202">
      <select name="floor_number"><option>-------------</option><option selected>2階</option></select>
      <select name="room_layout_id"><option>-------------</option><option selected>1LDK</option></select>
      <input name="square_meter" value="33.75">
      <input name="rental_cost" value="43,000">
      <input name="fee_common_service" value="2,000">
      <input name="deposit_value" value="1">
      <select name="deposit_unit"><option>-------------</option><option selected>ヶ月</option><option>円</option></select>
      <input name="recompense_value" value="0">
      <select name="recompense_unit"><option selected>-------------</option><option>ヶ月</option><option>円</option></select>
      <select name="insurance_flag"><option>不要</option><option selected>必要</option></select>
      <input name="insurance_premium" value="18,000">
      <select name="available_parking_flag"><option selected>なし</option><option>あり</option></select>
      <input name="parking_cost_min" value="15,000">
      <textarea name="surety_company_remarks">全保連:初回50%(更新10,000円、学生プラン初回10,000円)or初回のみ100%</textarea>
      <textarea name="comment_for_account">初期費用軽減キャンペーン! 客付業者様へ 退去時費用:ルームクリーニング料27,500円 FF分解清掃料16,500円 契約時:抗菌施工料11,000円 火災保険料は貸主負担</textarea>

      <select name="other_cost[1][cost_type_id]"><option selected>-------------</option><option>入居者サービス料</option></select>
      <input name="other_cost[1][cost_name]" value="24時間安心サポート">
      <input name="other_cost[1][cost_value]" value="16,500">
      <select name="other_cost[1][cost_unit_id]"><option>------</option><option selected>円</option><option>ヶ月</option><option>%</option></select>
      <select name="other_cost[1][cost_tax_unit_id]"><option>--------</option><option selected>税込</option></select>
      <select name="other_cost[1][payment_type_id]"><option>-------------</option><option selected>契約時</option><option>月額</option></select>
      <input name="other_cost[1][cost_remarks]" value="">

      <select name="other_cost[2][cost_type_id]"><option>-------------</option><option selected>室内清掃費用</option></select>
      <input name="other_cost[2][cost_name]" value="">
      <input name="other_cost[2][cost_value]" value="22,000">
      <select name="other_cost[2][cost_unit_id]"><option>------</option><option selected>円</option></select>
      <select name="other_cost[2][cost_tax_unit_id]"><option>--------</option><option selected>税込</option></select>
      <select name="other_cost[2][payment_type_id]"><option>-------------</option><option selected>契約時または退去時</option></select>
      <input name="other_cost[2][cost_remarks]" value="">

      <select name="other_cost[3][cost_type_id]"><option>-------------</option><option selected>契約事務手数料</option></select>
      <input name="other_cost[3][cost_name]" value="契約事務手数料">
      <input name="other_cost[3][cost_value]" value="11,000">
      <select name="other_cost[3][cost_unit_id]"><option selected>円</option></select>
      <select name="other_cost[3][payment_type_id]"><option selected>契約時</option></select>
    </form>
  `),
);

assert.equal(adminResult.extracted.diagnostics.sourceType, "realpro-admin-room");
assert.equal(adminResult.extracted.property.room, "202(2階部分)");
assert.equal(adminResult.extracted.property.layout, "1LDK");
assert.equal(adminResult.extracted.property.area, "33.75㎡");
assert.equal(adminResult.extracted.base.rent, 43000);
assert.equal(adminResult.extracted.base.commonFee, 2000);
assert.equal(adminResult.extracted.base.deposit, 43000);
assert.equal(adminResult.extracted.base.keyMoney, 0);
assert.equal(adminResult.extracted.base.insuranceFee, 18000);
assert.equal(adminResult.extracted.base.parkingFee, 0);
assert.equal(adminResult.extracted.guarantee.initialRate, 50);
assert.equal(adminResult.extracted.guarantee.fixed, 0);

const adminSupport = adminResult.extracted.fees.find((fee) => fee.label === "24時間安心サポート");
const adminCleaning = adminResult.extracted.fees.find((fee) => fee.label === "室内清掃費用");
const adminOfficeFee = adminResult.extracted.fees.find((fee) => fee.label === "契約事務手数料");
const adminCommentCleaning = adminResult.extracted.fees.find((fee) => fee.label === "ルームクリーニング料");
const adminCommentStove = adminResult.extracted.fees.find((fee) => fee.label === "FF分解清掃料");
const adminCommentAntibacterial = adminResult.extracted.fees.find((fee) => fee.label === "抗菌施工料");

assert.equal(adminSupport.amount, 16500);
assert.equal(adminSupport.category, "supportFee");
assert.equal(adminSupport.timing, "initial");
assert.equal(adminCleaning.amount, 22000);
assert.equal(adminCleaning.category, "cleaningFee");
assert.equal(adminCleaning.timing, "choice");
assert.equal(adminOfficeFee, undefined);
assert.equal(adminCommentCleaning.amount, 27500);
assert.equal(adminCommentCleaning.timing, "moveout");
assert.equal(adminCommentCleaning.sourceSection, "管理画面:客付コメント");
assert.equal(adminCommentStove.amount, 16500);
assert.equal(adminCommentStove.category, "stoveMaintenanceFee");
assert.equal(adminCommentAntibacterial.amount, 11000);
assert.equal(adminCommentAntibacterial.category, "antibacterialFee");
assert.equal(adminResult.extracted.diagnostics.accountCommentFeeCount, 3);
assert.equal(
  adminResult.extracted.diagnostics.adminOtherCostRows.some(
    (row) => row.label === "契約事務手数料" && row.status === "excluded" && row.reason === "顧客請求対象外",
  ),
  true,
);
assert.equal(
  adminResult.extracted.diagnostics.choiceFees.some((fee) => fee.label === "室内清掃費用"),
  true,
);
assert.equal(adminResult.estimateData.amounts.supportFee, undefined);
assert.ok(
  adminResult.estimateData.settings.extraFees.some(
    (fee) => fee.label === "24時間安心サポート" && fee.amount === 16500 && fee.timing === "initial" && fee.guaranteeTarget === false,
  ),
);
assert.equal(adminResult.estimateData.amounts.cleaningFee, 22000);
assert.equal(adminResult.estimateData.settings.feeTimings.cleaningFee, "choice");

const adminGuaranteeFallback = globalThis.RealproEstimateParser.extract(
  adminDocumentFixture(`
    <form>
      <input name="rental_cost" value="50,000">
      <input name="fee_common_service" value="5,000">
      <select name="other_cost[1][cost_type_id]"><option>-------------</option><option selected>保証人代行費用</option></select>
      <input name="other_cost[1][cost_name]" value="保証委託料">
      <input name="other_cost[1][cost_value]" value="50">
      <select name="other_cost[1][cost_unit_id]"><option>円</option><option selected>%</option></select>
      <select name="other_cost[1][payment_type_id]"><option selected>契約時</option></select>
    </form>
  `),
);

assert.equal(adminGuaranteeFallback.extracted.guarantee.initialRate, 50);
assert.equal(adminGuaranteeFallback.extracted.fees.some((fee) => fee.label === "保証委託料"), false);
assert.equal(
  adminGuaranteeFallback.extracted.diagnostics.adminOtherCostRows.some(
    (row) => row.label === "保証委託料" && row.status === "guarantee-hint",
  ),
  true,
);

// Realpro public-page regression cases captured from live property details.
const sanstageReal = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "サンステージ二十四軒1-2"],
      ["号室名", "302（3階部分）"],
      ["賃料 / 管理費・共益費", "56,000円 / 5,000円"],
      ["敷金 / 礼金", "敷金:なし 礼金:なし"],
      ["駐車場", "敷地内駐車場／空きなし"],
    ],
    `諸費用
○ 保証会社
保証会社利用必須 オリコフォレントインシュア
初回保証料:月額合計の50%/月額保証料:月額合計の1.5%
○ 保険
保険要加入 ステラ保険 2年契約 15,000円
○ 初期費用
水廻り消毒料 契約時 27,500円（税込）
○ ランニングコスト
町内会費 月額 200円（非課税）
24時間緊急通報システム料 月額 1,100円（税込）
広告掲載`,
    "https://www.realnetpro.com/room_detail.php?id=4738731",
  ),
);
assert.equal(sanstageReal.extracted.guarantee.initialRate, 50);
assert.equal(sanstageReal.extracted.guarantee.monthlyRate, 1.5);
assert.equal(sanstageReal.extracted.guarantee.needsChoice, false);
assert.equal(sanstageReal.extracted.fees.find((fee) => fee.label === "水廻り消毒料").amount, 27500);

const bareGuaranteeRate = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "保証料単独表記テスト"],
      ["号室名", "3"],
      ["賃料 / 管理費・共益費", "50,000円 / 3,000円"],
    ],
    `諸費用
○ 保証会社
保証会社利用必須 日本セーフティー 保証料50%(連帯保証人無) 40%(連帯保証人有) 年次保証料10,000円/年 月次保証料800円/月
広告掲載`,
  ),
);
assert.equal(bareGuaranteeRate.extracted.guarantee.initialRate, 50);
assert.equal(bareGuaranteeRate.extracted.guarantee.monthlyFixed, 800);

const houseleaseSplitGuarantee = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "ハウスリーブ表記テスト"],
      ["号室名", "102"],
      ["賃料 / 管理費・共益費", "60,000円 / 2,000円"],
    ],
    `諸費用
○ 保証会社
保証会社利用必須 ハウスリーブ株式会社 (契約時保証委託料:22,000円/月額保証委託料:賃料総額の2.2%又は5.5%)
広告掲載`,
  ),
);
assert.equal(houseleaseSplitGuarantee.extracted.guarantee.fixed, 22000);
assert.equal(houseleaseSplitGuarantee.extracted.guarantee.initialRate, 0);
assert.equal(houseleaseSplitGuarantee.extracted.guarantee.monthlyRate, 2.2);

const suretyPersonOption = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "連帯保証人料率テスト"],
      ["号室名", "3"],
      ["賃料 / 管理費・共益費", "30,000円 / 0円"],
    ],
    `諸費用
○ 保証会社
保証会社利用必須 日本セーフティー 連帯保証人あり50%なし60% 更新料800円/月
広告掲載`,
  ),
);
assert.equal(suretyPersonOption.extracted.guarantee.initialRate, 50);
assert.equal(suretyPersonOption.extracted.guarantee.monthlyFixed, 800);

const letterPlanGuarantee = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "保証会社A・Bプランテスト"],
      ["号室名", "103"],
      ["賃料 / 管理費・共益費", "50,000円 / 2,000円"],
    ],
    `諸費用
○ 保証会社
保証会社利用必須 ジェイリース A:初回50%+継続保証料(月額)1,000円 B:初回80%+継続保証料(月額)440円
広告掲載`,
  ),
);
assert.equal(letterPlanGuarantee.extracted.guarantee.needsChoice, true);
assert.equal(letterPlanGuarantee.extracted.guarantee.alternatives.length, 2);
assert.equal(letterPlanGuarantee.extracted.guarantee.alternatives[0].initialRate, 50);
assert.equal(letterPlanGuarantee.extracted.guarantee.alternatives[0].monthlyFixed, 1000);
assert.equal(letterPlanGuarantee.extracted.guarantee.alternatives[1].initialRate, 80);
assert.equal(letterPlanGuarantee.extracted.guarantee.alternatives[1].monthlyFixed, 440);

const parentheticalMonthlyUpdate = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "月額更新料表記テスト"],
      ["号室名", "602"],
      ["賃料 / 管理費・共益費", "60,000円 / 2,000円"],
    ],
    `諸費用
○ 保証会社
保証会社利用可能 日本セーフティー 初回保証料60%(下限24,000円) 更新料800円(月額)もしくは年間12,000円
広告掲載`,
  ),
);
assert.equal(parentheticalMonthlyUpdate.extracted.guarantee.initialRate, 60);
assert.equal(parentheticalMonthlyUpdate.extracted.guarantee.initialMinimum, 24000);
assert.equal(parentheticalMonthlyUpdate.extracted.guarantee.monthlyFixed, 800);

const suretyChoiceGuarantee = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "保証人有無プランテスト"],
      ["号室名", "102"],
      ["賃料 / 管理費・共益費", "45,000円 / 1,000円"],
    ],
    `諸費用
○ 保証会社
保証会社利用必須 日本セーフティー 保証人有:家賃等全額×40%(最低保証料20,000円) 月額更新料800円 保証人無:家賃等全額×60%(最低保証料30,000円) 月額更新料800円
広告掲載`,
  ),
);
assert.equal(suretyChoiceGuarantee.extracted.guarantee.needsChoice, true);
assert.equal(suretyChoiceGuarantee.extracted.guarantee.alternatives.length, 2);
assert.equal(suretyChoiceGuarantee.extracted.guarantee.alternatives[0].initialRate, 40);
assert.equal(suretyChoiceGuarantee.extracted.guarantee.alternatives[0].initialMinimum, 20000);
assert.equal(suretyChoiceGuarantee.extracted.guarantee.alternatives[0].monthlyFixed, 800);
assert.equal(suretyChoiceGuarantee.extracted.guarantee.alternatives[1].initialRate, 60);
assert.equal(suretyChoiceGuarantee.extracted.guarantee.alternatives[1].initialMinimum, 30000);
assert.equal(suretyChoiceGuarantee.extracted.guarantee.alternatives[1].monthlyFixed, 800);

const belistaReal = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "BELISTA南郷7丁目 (ベリスタ南郷7丁目)"],
      ["号室名", "405（4階部分）"],
      ["賃料 / 管理費・共益費", "59,000円 / 4,000円"],
      ["敷金 / 礼金", "敷金:なし 礼金:1ヶ月"],
      ["駐車場", "なし"],
    ],
    `諸費用
○ 保証会社
保証会社利用必須 ①【あんしん保証株式会社】②【株式会社Casa】
①
【初回保証料】50%
【月額保証料】880円(税込)
②
【初回保証料】50%(最低保証料20,000円)
【月額保証料】300円(税込)
○ 保険
保険要加入 日本共済株式会社 2年契約 20,000円
○ 初期費用
駐輪場登録料 契約時 550円（税込） ※ご利用時初回のみ
○ ランニングコスト
24時間管理料 月額 1,430円（税込）
町内会費 月額 300円（非課税）
○ その他
ハウスクリーニング料 契約時または退去時 33,000円（税込）
鍵交換料 契約時または退去時 13,200円（税込）
エアコン整備料 契約時または退去時 18,700円（税込）
広告掲載`,
    "https://www.realnetpro.com/room_detail.php?id=9318128",
  ),
);
assert.equal(belistaReal.extracted.guarantee.needsChoice, true);
assert.equal(belistaReal.extracted.guarantee.alternatives.length, 2);
assert.equal(belistaReal.extracted.guarantee.monthlyFixed, 880);
assert.equal(belistaReal.extracted.guarantee.alternatives[1].initialMinimum, 20000);
assert.equal(belistaReal.extracted.guarantee.alternatives[1].monthlyFixed, 300);
// Selecting a guarantee plan must carry the selected monthly fee through to the app.
const selectedBelistaPlan = JSON.parse(JSON.stringify(belistaReal.extracted));
Object.assign(selectedBelistaPlan.guarantee, belistaReal.extracted.guarantee.alternatives[1]);
const selectedBelistaTransfer = globalThis.RealproEstimateParser.toEstimateData(selectedBelistaPlan);
assert.equal(selectedBelistaTransfer.amounts.monthlyGuaranteeFee, 300);
assert.equal(selectedBelistaTransfer.settings.monthlyGuaranteeMode, "fixed");
assert.equal(selectedBelistaTransfer.settings.monthlyGuaranteeFixed, 300);
assert.equal(selectedBelistaTransfer.settings.guaranteeMinimum, 20000);
assert.equal(belistaReal.extracted.fees.find((fee) => fee.label === "駐輪場登録料").optional, true);
assert.equal(
  belistaReal.extracted.diagnostics.warnings.some((warning) => warning.includes("保証会社が複数候補")),
  true,
);

const renewalAndOptionalMonthly = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "実データ回帰テスト"],
      ["号室名", "102"],
      ["賃料 / 管理費・共益費", "32,000円 / 2,000円"],
      ["敷金 / 礼金", "敷金:なし 礼金:なし"],
      ["駐車場", "なし"],
    ],
    `諸費用
○ 保証会社
保証会社利用必須 賃料総額60%～100%(初回)、賃料総額1.5%～2%(月次)
○ ランニングコスト
更新事務手数料 更新時 16,500円（税込）
ガス警報器リース料 月額 330円（税込）
○ 客付業者様へ
ペット飼育可 要ペット消臭料&賃料2,000円UP
広告掲載`,
    "https://www.realnetpro.com/room_detail.php?id=6021784",
  ),
);
assert.equal(renewalAndOptionalMonthly.extracted.guarantee.initialRate, 60);
assert.equal(renewalAndOptionalMonthly.extracted.guarantee.monthlyRate, 1.5);
assert.equal(
  renewalAndOptionalMonthly.extracted.fees.find((fee) => fee.label.includes("更新事務手数料")).timing,
  "remark",
);
assert.equal(
  renewalAndOptionalMonthly.extracted.fees.find((fee) => fee.label === "ガス警報器リース料").category,
  "remark",
);
assert.equal(renewalAndOptionalMonthly.estimateData.settings.remarkFees[0].label, "更新事務手数料");
assert.equal(renewalAndOptionalMonthly.estimateData.settings.remarkFees[1].label, "ガス警報器リース料");
const optionalPetRent = renewalAndOptionalMonthly.extracted.fees.find(
  (fee) => fee.label === "ペット飼育時賃料増額",
);
assert.equal(optionalPetRent.amount, 2000);
assert.equal(optionalPetRent.timing, "monthly");
assert.equal(optionalPetRent.type, "optionalMonthly");

const numberedGuaranteePlans = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "保証プラン回帰テスト"],
      ["号室名", "1"],
      ["賃料 / 管理費・共益費", "47,000円 / 2,000円"],
    ],
    `諸費用
○ 保証会社
保証会社利用可能 全保連 ①初回のみプラン・賃料合計の120%(下限4万円) ②毎年プラン・賃料合計の50%(下限2万円)
広告掲載`,
  ),
);
assert.equal(numberedGuaranteePlans.extracted.guarantee.needsChoice, true);
assert.equal(numberedGuaranteePlans.extracted.guarantee.alternatives.length, 2);
assert.equal(numberedGuaranteePlans.extracted.guarantee.alternatives[0].initialRate, 120);
assert.equal(numberedGuaranteePlans.extracted.guarantee.alternatives[1].initialRate, 50);

const mixedBrokerFeeLine = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "客付欄複数費用テスト"],
      ["号室名", "5"],
      ["賃料 / 管理費・共益費", "52,000円 / 0円"],
      ["敷金 / 礼金", "敷金:1ヶ月 礼金:なし"],
      ["駐車場", "空きなし"],
    ],
    `諸費用
客付業者様へ
○ 水廻り消毒料35,000円/税別、契約事務手数料15,000円/税別、駐車場6,000円/税別(屋外)、24時間管理費1,000円/税別
諸費用`,
    "https://www.realnetpro.com/room_detail.php?id=263222",
  ),
);
assert.equal(
  mixedBrokerFeeLine.extracted.fees.find((fee) => fee.category === "waterSanitizingFee")?.amount,
  35000,
);
assert.equal(
  mixedBrokerFeeLine.extracted.fees.find((fee) => fee.category === "parkingFee")?.amount,
  6000,
);
assert.equal(
  mixedBrokerFeeLine.extracted.fees.find((fee) => fee.category === "supportFee")?.amount,
  1000,
);
assert.deepEqual(
  mixedBrokerFeeLine.extracted.diagnostics.skippedFeeLines.map((line) => line.text),
  ["契約事務手数料15,000円/税別"],
);

const plainOfficeFee = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "通常事務手数料除外テスト"],
      ["号室名", "1"],
      ["賃料 / 管理費・共益費", "50,000円 / 2,000円"],
    ],
    `諸費用
○ その他
事務手数料 契約時 16,500円（税込）
更新手数料 更新時 11,000円（税込）
都市ガスリース料 月額 330円（税込）
広告掲載`,
  ),
);
assert.equal(
  plainOfficeFee.extracted.fees.some((fee) => fee.label === "事務手数料"),
  false,
);
assert.deepEqual(
  plainOfficeFee.estimateData.settings.remarkFees.map((fee) => fee.label),
  ["更新手数料", "都市ガスリース料"],
);

const inlineRenewalFee = globalThis.RealproEstimateParser.extract(
  documentFixture(
    [
      ["物件名", "万円表記更新料テスト"],
      ["号室名", "2"],
      ["賃料 / 管理費・共益費", "50,000円 / 2,000円"],
    ],
    `諸費用
○ 保証会社
ほくせん初回保証料無料・月額770円(税込)・更新料1.3万
広告掲載`,
  ),
);
assert.equal(
  inlineRenewalFee.estimateData.settings.remarkFees.find((fee) => fee.label === "更新料")?.amount,
  13000,
);

const optionalMonthlyClassification = globalThis.RealproEstimateParser.toEstimateData({
  property: { title: "任意月額分類テスト", room: "1" },
  base: { rent: 50000, commonFee: 2000, deposit: 0, keyMoney: 0, parkingFee: 0, insuranceFee: 0 },
  fees: [{ label: "トランクルーム利用料", amount: 550, timing: "monthly", type: "optionalMonthly", category: "optionalMonthly", optional: true }],
  guarantee: {},
});
assert.equal(optionalMonthlyClassification.settings.extraFees[0].type, "optional");
assert.equal(optionalMonthlyClassification.settings.extraFees[0].timing, "monthly");
assert.equal(optionalMonthlyClassification.settings.extraFees[0].optional, true);

const delegatedGuaranteeText = `
諸費用
○ 保証会社
保証会社利用必須 らくらくパートナー 初回保証委託事務手数料:33,000円/月額保証料:月額支払料の2%
広告掲載
`;
const delegatedGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(rows, delegatedGuaranteeText),
);
assert.equal(delegatedGuaranteeResult.extracted.guarantee.fixed, 33000);
assert.equal(delegatedGuaranteeResult.extracted.guarantee.initialRate, 0);
assert.equal(delegatedGuaranteeResult.extracted.guarantee.monthlyRate, 2);
assert.equal(delegatedGuaranteeResult.extracted.guarantee.monthlyFixed, 0);

const monthlyLowerBoundText = `
諸費用
○ 保証会社
保証会社利用必須 Casa 初回保証料50%(最低20,000円) 月次保証料1.5%(下限300円)
広告掲載
`;
const monthlyLowerBoundResult = globalThis.RealproEstimateParser.extract(
  documentFixture(rows, monthlyLowerBoundText),
);
assert.equal(monthlyLowerBoundResult.extracted.guarantee.initialMinimum, 20000);
assert.equal(monthlyLowerBoundResult.extracted.guarantee.monthlyRate, 1.5);

const nightSupportResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ ランニングコスト
夜間受付費 月額 1,650円(税込)
広告掲載`,
  ),
);
const nightSupport = nightSupportResult.extracted.fees.find((fee) => fee.label === "夜間受付費");
assert.equal(nightSupport.amount, 1650);
assert.equal(nightSupport.timing, "monthly");
assert.equal(nightSupport.category, "supportFee");

const shortManMinimumText = `
諸費用
○ 保証会社
保証会社利用必須 ほくせん 初回月額賃料の50%(下限2万)・月額550円(税込)・更新料1.3万/年
広告掲載
`;
const shortManMinimumResult = globalThis.RealproEstimateParser.extract(
  documentFixture(rows, shortManMinimumText),
);
assert.equal(shortManMinimumResult.extracted.guarantee.initialRate, 50);
assert.equal(shortManMinimumResult.extracted.guarantee.initialMinimum, 20000);
assert.equal(shortManMinimumResult.extracted.guarantee.monthlyFixed, 550);

const annualRenewalText = `
諸費用
○ 保証会社
保証会社利用必須 保証料:請求月額の1ヶ月分(最低保証料2万円)継続保証料1万円/年
広告掲載
`;
const annualRenewalResult = globalThis.RealproEstimateParser.extract(
  documentFixture(rows, annualRenewalText),
);
assert.equal(annualRenewalResult.extracted.guarantee.monthlyFixed, 0);

const inlineMonthlyChoiceResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社 ハウスリーブ株式会社 契約時保証委託料:22,000円/月額保証委託料:賃料総額の2.2%又は5.5%
広告掲載`,
  ),
);
assert.equal(inlineMonthlyChoiceResult.extracted.guarantee.needsChoice, true);
assert.equal(inlineMonthlyChoiceResult.extracted.guarantee.alternatives.length, 2);
assert.equal(inlineMonthlyChoiceResult.extracted.guarantee.alternatives[0].monthlyRate, 2.2);
assert.equal(inlineMonthlyChoiceResult.extracted.guarantee.alternatives[1].monthlyRate, 5.5);

const compactMonthlyRateResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 オリコフォレントインシュア 初回:賃料総額の50%、月額:賃料総額の1.5% 年間更新料:10000円
広告掲載`,
  ),
);
assert.equal(compactMonthlyRateResult.extracted.guarantee.initialRate, 50);
assert.equal(compactMonthlyRateResult.extracted.guarantee.monthlyRate, 1.5);
assert.equal(compactMonthlyRateResult.extracted.guarantee.monthlyFixed, 0);
assert.equal(compactMonthlyRateResult.estimateData.settings.monthlyGuaranteeMode, "percent");
assert.equal(compactMonthlyRateResult.estimateData.settings.monthlyGuaranteeFixed, 0);

const basicGuaranteeRateResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 エポスカード 基本保証料:総額の60% 月次保証料:月額の1.5%(引落手数料税込)
広告掲載`,
  ),
);
assert.equal(basicGuaranteeRateResult.extracted.guarantee.initialRate, 60);
assert.equal(basicGuaranteeRateResult.extracted.guarantee.monthlyRate, 1.5);

const pathosMaruyamaGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 JPMCファイナンス
A初回60%(最低額30000円)・年間更新料10000円 B初回80%(最低額40000円)※各プラン月額事務手数料440円(税込)
広告掲載`,
  ),
);
assert.equal(pathosMaruyamaGuaranteeResult.extracted.guarantee.needsChoice, true);
assert.equal(pathosMaruyamaGuaranteeResult.extracted.guarantee.alternatives.length, 2);
assert.deepEqual(
  pathosMaruyamaGuaranteeResult.extracted.guarantee.alternatives.map((item) => ({
    rate: item.initialRate,
    minimum: item.initialMinimum,
    monthlyFixed: item.monthlyFixed,
    monthlyExtra: item.monthlyFixedExtra,
    renewal: item.renewalAmount,
  })),
  [
    { rate: 60, minimum: 30000, monthlyFixed: 0, monthlyExtra: 440, renewal: 10000 },
    { rate: 80, minimum: 40000, monthlyFixed: 0, monthlyExtra: 440, renewal: 0 },
  ],
);

const meniesCourtGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 Casa・日本セーフティー
Casa:初回保証委託料 月額賃料50%(最低保証料20,000円)、月次保証料 月額賃料1.5%(最低保証料700円/月) 、日本セーフティー:初回保証委託料 月額賃料60%(最低保証料24,000円)、更新料→年額15,000円もしくは月額1,000円、引落手数料:440円(共通)
広告掲載`,
  ),
);
assert.equal(meniesCourtGuaranteeResult.extracted.guarantee.needsChoice, true);
assert.deepEqual(
  meniesCourtGuaranteeResult.extracted.guarantee.alternatives.map((item) => ({
    rate: item.initialRate,
    minimum: item.initialMinimum,
    monthlyRate: item.monthlyRate,
    monthlyFixed: item.monthlyFixed,
    monthlyExtra: item.monthlyFixedExtra,
    renewal: item.renewalAmount,
  })),
  [
    { rate: 50, minimum: 20000, monthlyRate: 1.5, monthlyFixed: 0, monthlyExtra: 440, renewal: 0 },
    { rate: 60, minimum: 24000, monthlyRate: 0, monthlyFixed: 0, monthlyExtra: 440, renewal: 15000 },
  ],
);

const numberedProviderGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 ジェイリース
初回保証料:総賃料の50%(最低保証料20,000円) 継続保証料:毎月800円
②日本セーフティー
初回保証料:総賃料の50%(最低保証料20,000円) 継続保証料:毎月800円・毎年12,000円※いずれか 口座振替手数料440円/月
広告掲載`,
  ),
);
assert.equal(numberedProviderGuaranteeResult.extracted.guarantee.needsChoice, true);
assert.match(
  numberedProviderGuaranteeResult.extracted.guarantee.alternatives[1].warnings.join("\n"),
  /月額払いと年額払いの選択条件/,
);
assert.deepEqual(
  numberedProviderGuaranteeResult.extracted.guarantee.alternatives.map((item) => ({
    label: item.label,
    rate: item.initialRate,
    minimum: item.initialMinimum,
    monthlyFixed: item.monthlyFixed,
    monthlyExtra: item.monthlyFixedExtra,
    renewal: item.renewalAmount,
  })),
  [
    { label: "ジェイリース", rate: 50, minimum: 20000, monthlyFixed: 800, monthlyExtra: 0, renewal: 0 },
    { label: "日本セーフティー", rate: 50, minimum: 20000, monthlyFixed: 800, monthlyExtra: 440, renewal: 12000 },
  ],
);

const annualGuaranteeTermsResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 ジェイリース 初回保証料:月額賃料等の50% 月額保証料:月額賃料等の1% 更新保証料:1年毎10,000円
広告掲載`,
  ),
);
assert.equal(annualGuaranteeTermsResult.extracted.guarantee.renewalAmount, 10000);
assert.equal(annualGuaranteeTermsResult.extracted.guarantee.renewalPeriod, "annual");

const businessOnlyProviderExcludedResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 ジェイリース
初回保証料:総賃料の50%(最低保証料20,000円) 継続保証料:毎月800円
②日本セーフティー
初回保証料:総賃料の50%(最低保証料20,000円) 継続保証料:毎月800円・毎年12,000円※いずれか 口座振替手数料440円/月
※事業用の場合は、オリコフォレントインシュア 初回保証料:総賃料の50%(最低保証料50,000円) 継続保証料:毎月の支払総額の1%
広告掲載`,
  ),
);
assert.equal(businessOnlyProviderExcludedResult.extracted.guarantee.needsChoice, true);
assert.deepEqual(
  businessOnlyProviderExcludedResult.extracted.guarantee.alternatives.map((item) => ({
    label: item.label,
    rate: item.initialRate,
    minimum: item.initialMinimum,
    monthlyRate: item.monthlyRate,
    monthlyFixed: item.monthlyFixed,
    monthlyExtra: item.monthlyFixedExtra,
    renewal: item.renewalAmount,
  })),
  [
    { label: "ジェイリース", rate: 50, minimum: 20000, monthlyRate: 0, monthlyFixed: 800, monthlyExtra: 0, renewal: 0 },
    { label: "日本セーフティー", rate: 50, minimum: 20000, monthlyRate: 0, monthlyFixed: 800, monthlyExtra: 440, renewal: 12000 },
  ],
);

const bracketProviderGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 ●1番手 【エポス】初回保証料:賃料の50%(最低保証料15,000円) 年間更新料:なし 月次保証料1.5%(下限300円) ●2番手 【全保連】初回保証料:賃料の50%(下限20,000円)年間更新料:10,000円 月次保証料550円
広告掲載`,
  ),
);
assert.equal(bracketProviderGuaranteeResult.extracted.guarantee.needsChoice, true);
assert.deepEqual(
  bracketProviderGuaranteeResult.extracted.guarantee.alternatives.map((item) => ({
    label: item.label,
    rate: item.initialRate,
    minimum: item.initialMinimum,
    monthlyRate: item.monthlyRate,
    monthlyFixed: item.monthlyFixed,
    renewal: item.renewalAmount,
  })),
  [
    { label: "エポス", rate: 50, minimum: 15000, monthlyRate: 1.5, monthlyFixed: 0, renewal: 0 },
    { label: "全保連", rate: 50, minimum: 20000, monthlyRate: 0, monthlyFixed: 550, renewal: 10000 },
  ],
);

const selectedSecondAlternative = bracketProviderGuaranteeResult.extracted.guarantee.alternatives[1];
const selectedSecondProvider = {
  ...bracketProviderGuaranteeResult.extracted,
  guarantee: {
    ...bracketProviderGuaranteeResult.extracted.guarantee,
    ...selectedSecondAlternative,
    originalNote: bracketProviderGuaranteeResult.extracted.guarantee.note,
    note: selectedSecondAlternative.note,
    selectedLabel: selectedSecondAlternative.label,
    needsChoice: false,
  },
};
const selectedSecondProviderEstimate = globalThis.RealproEstimateParser.toEstimateData(selectedSecondProvider);
assert.equal(selectedSecondProviderEstimate.settings.guaranteeSelectedLabel, "全保連");
assert.equal(selectedSecondProviderEstimate.settings.guaranteeNeedsChoice, false);
assert.equal(selectedSecondProviderEstimate.settings.guaranteeMinimum, 20000);
assert.equal(selectedSecondProviderEstimate.settings.monthlyGuaranteeMode, "fixed");
assert.equal(selectedSecondProviderEstimate.settings.monthlyGuaranteeRate, 0);
assert.equal(selectedSecondProviderEstimate.settings.monthlyGuaranteeFixed, 550);
assert.equal(selectedSecondProviderEstimate.settings.guaranteeRenewalAmount, 10000);
assert.doesNotMatch(selectedSecondProviderEstimate.settings.guaranteeNote, /エポス/);
assert.match(selectedSecondProviderEstimate.settings.guaranteeOriginalSourceText, /エポス/);

const numberedFallbackProviderResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 エポスカード
1エポスカード 初回保証料:月額賃料の50%(最低保証料15,000円)、月額保証料:月額賃料の1.5%(変動費別)年間更新料無し
2エポスカード不可の場合、Casaダイレクトワイド 初回保証料:賃料等総額の50% 年間更新料:10,000円 決済手数料:月額330円
個人契約は必須、法人契約は要相談
広告掲載`,
  ),
);
assert.equal(numberedFallbackProviderResult.extracted.guarantee.needsChoice, true);
assert.deepEqual(
  numberedFallbackProviderResult.extracted.guarantee.alternatives.map((item) => ({
    label: item.label,
    rate: item.initialRate,
    minimum: item.initialMinimum,
    monthlyRate: item.monthlyRate,
    monthlyFixed: item.monthlyFixed,
    monthlyExtra: item.monthlyFixedExtra,
    renewal: item.renewalAmount,
  })),
  [
    { label: "エポスカード", rate: 50, minimum: 15000, monthlyRate: 1.5, monthlyFixed: 0, monthlyExtra: 0, renewal: 0 },
    { label: "Casaダイレクトワイド", rate: 50, minimum: 0, monthlyRate: 0, monthlyFixed: 0, monthlyExtra: 330, renewal: 10000 },
  ],
);

const englishOrGuaranteePlanResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 株式会社オリコフォレントインシュア 初回50% 毎月総支払額の1.5% 更新保証料10,000円or毎月総支払額の2% 更新料なし 初回保証料は初回家賃引落時に徴収となります。
広告掲載`,
  ),
);
assert.equal(englishOrGuaranteePlanResult.extracted.guarantee.needsChoice, true);
assert.deepEqual(
  englishOrGuaranteePlanResult.extracted.guarantee.alternatives.map((item) => ({
    rate: item.initialRate,
    monthlyRate: item.monthlyRate,
    renewal: item.renewalAmount,
  })),
  [
    { rate: 50, monthlyRate: 1.5, renewal: 10000 },
    { rate: 50, monthlyRate: 2, renewal: 0 },
  ],
);

const recurringGuaranteeTermsResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 全保連 初回保証委託料:月額料金の50%(下限2万円)、継続保証委託料:毎年1.3万円、口座振替サービス利用料:330円(税込)
広告掲載`,
  ),
);
assert.equal(recurringGuaranteeTermsResult.extracted.guarantee.initialRate, 50);
assert.equal(recurringGuaranteeTermsResult.extracted.guarantee.initialMinimum, 20000);
assert.equal(recurringGuaranteeTermsResult.extracted.guarantee.renewalAmount, 13000);
assert.equal(recurringGuaranteeTermsResult.extracted.guarantee.monthlyFixed, 0);
assert.equal(recurringGuaranteeTermsResult.extracted.guarantee.monthlyFixedExtra, 330);
assert.equal(recurringGuaranteeTermsResult.estimateData.settings.monthlyGuaranteeMode, "fixed");
assert.equal(recurringGuaranteeTermsResult.estimateData.settings.monthlyGuaranteeFixed, 0);
assert.equal(recurringGuaranteeTermsResult.estimateData.settings.monthlyGuaranteeFixedExtra, 330);

const moveoutChoiceResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 初期費用
ハウスクリーニング 契約時 38,500円（税込）退居時可
暖房分解清掃料 契約時 22,000円（税込）退去時可
広告掲載`,
  ),
);
assert.equal(moveoutChoiceResult.extracted.fees.find((fee) => fee.label === "ハウスクリーニング")?.timing, "choice");
assert.equal(moveoutChoiceResult.extracted.fees.find((fee) => fee.label === "暖房分解清掃料")?.timing, "choice");

const internetInitialOfficeFeeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 初期費用
無料インターネット初回事務手数料 契約時 3,300円（税込）
契約事務手数料 契約時 11,000円（税込）
広告掲載`,
  ),
);
assert.equal(
  internetInitialOfficeFeeResult.extracted.fees.find((fee) => fee.label === "無料インターネット初回事務手数料")?.amount,
  3300,
);
assert.equal(internetInitialOfficeFeeResult.extracted.fees.some((fee) => fee.label === "契約事務手数料"), false);

const conditionalMonthlyResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ ランニングコスト
見守りサービス 月額 1,980円（税込）70歳以上加入必須
広告掲載`,
  ),
);
assert.equal(conditionalMonthlyResult.extracted.fees[0]?.timing, "monthly");
assert.equal(conditionalMonthlyResult.extracted.fees[0]?.optional, true);

const compactAnnualRenewalResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 あんしん保証株式会社 初回:月額合計の50%~ 年更新:1万円〜 月額:880円
広告掲載`,
  ),
);
assert.equal(compactAnnualRenewalResult.extracted.guarantee.initialRate, 50);
assert.equal(compactAnnualRenewalResult.extracted.guarantee.monthlyRate, 0);
assert.equal(compactAnnualRenewalResult.extracted.guarantee.monthlyFixed, 880);
assert.equal(compactAnnualRenewalResult.extracted.guarantee.renewalAmount, 10000);

const monthlyPaidRenewalRateResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 オリコフォレントインシュア
【初回保証料:月額総賃料50% 更新保証料:月額総賃料の1.5%/毎月払い】
広告掲載`,
  ),
);
assert.equal(monthlyPaidRenewalRateResult.extracted.guarantee.initialRate, 50);
assert.equal(monthlyPaidRenewalRateResult.extracted.guarantee.monthlyRate, 1.5);
assert.equal(monthlyPaidRenewalRateResult.extracted.guarantee.monthlyFixed, 0);

const numberedProviderHeaderResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 ①【あんしん保証株式会社】②【株式会社Casa】
①
【初回保証料】50%
【月額保証料】880円(税込)
【年間更新料】10,000円
②
【初回保証料】50%(最低保証料20,000円)
【月額保証料】300円(税込)
【年間更新料】10,000円
広告掲載`,
  ),
);
assert.deepEqual(
  numberedProviderHeaderResult.extracted.guarantee.alternatives.map((item) => ({
    label: item.label,
    rate: item.initialRate,
    minimum: item.initialMinimum,
    monthlyFixed: item.monthlyFixed,
    renewal: item.renewalAmount,
  })),
  [
    { label: "あんしん保証株式会社", rate: 50, minimum: 0, monthlyFixed: 880, renewal: 10000 },
    { label: "株式会社Casa", rate: 50, minimum: 20000, monthlyFixed: 300, renewal: 10000 },
  ],
);
assert.equal(numberedProviderHeaderResult.extracted.guarantee.needsChoice, true);

const collectionAndRenewalMonthlyResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 日本セーフティー
【初回保証料:月額総賃料50% 月額費用:集金代行サービス料440円(税込)+更新保証料800円】
広告掲載`,
  ),
);
assert.equal(collectionAndRenewalMonthlyResult.extracted.guarantee.initialRate, 50);
assert.equal(collectionAndRenewalMonthlyResult.extracted.guarantee.monthlyRate, 0);
assert.equal(collectionAndRenewalMonthlyResult.extracted.guarantee.monthlyFixed, 800);
assert.equal(collectionAndRenewalMonthlyResult.extracted.guarantee.monthlyFixedExtra, 440);

const transferFeeWordingResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 日本賃貸保証（JID）
初回保証料月額総額の30%(最低保証料12,000円)、月額保証料月額総額の1.5%(最低保証料600円)、別途口座振替時に手数料300円(税別)
広告掲載`,
  ),
);
assert.equal(transferFeeWordingResult.extracted.guarantee.initialRate, 30);
assert.equal(transferFeeWordingResult.extracted.guarantee.initialMinimum, 12000);
assert.equal(transferFeeWordingResult.extracted.guarantee.monthlyRate, 1.5);
assert.equal(transferFeeWordingResult.extracted.guarantee.monthlyFixedExtra, 300);

const secondaryAnnualPlanResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 全保連 初回保証委託料:月額賃料の60%(最低保証委託料15,000円)・月額費用:(税込)1,400円・引き落としに間に合わなかった方は別途手数料として全保連から(税別)2,700円。
尚、二次審査で通った方は毎年プラン初回保証委託料100%の継続保証委託料(年)(税込)13,000円になる場合がございます。毎月口座振替手数料(税別)300円がかかります。
広告掲載`,
  ),
);
assert.equal(secondaryAnnualPlanResult.extracted.guarantee.needsChoice, true);
assert.deepEqual(
  secondaryAnnualPlanResult.extracted.guarantee.alternatives.map((item) => ({
    label: item.label,
    rate: item.initialRate,
    minimum: item.initialMinimum,
    monthlyFixed: item.monthlyFixed,
    monthlyExtra: item.monthlyFixedExtra,
    renewal: item.renewalAmount,
  })),
  [
    { label: "全保連", rate: 60, minimum: 15000, monthlyFixed: 1400, monthlyExtra: 0, renewal: 0 },
    { label: "二次審査（年払いプラン）", rate: 100, minimum: 0, monthlyFixed: 0, monthlyExtra: 300, renewal: 13000 },
  ],
);

const guaranteeSectionBoundaryResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `書類ダウンロード
家賃保証会社のご案内
エンドユーザー向けPR
ペット飼育時はペット管理費毎月2,000円
諸費用
○ 保証会社
保証会社利用必須 詳細別紙参照
●1番手
【エポス】初回保証料:賃料の50%(最低保証料15,000円) 年間更新料:なし
●2番手
【全保連】初回保証料:賃料の50% 年間更新料:10,000円
○ 保険
保険要加入 2年契約 19,000円
○ ランニングコスト
町内会費 月額 300円
広告掲載`,
  ),
);
assert.equal(guaranteeSectionBoundaryResult.extracted.guarantee.monthlyFixed, 0);
assert.equal(guaranteeSectionBoundaryResult.extracted.guarantee.alternatives[0]?.initialRate, 50);
assert.equal(guaranteeSectionBoundaryResult.extracted.guarantee.alternatives[0]?.initialMinimum, 15000);
assert.equal(guaranteeSectionBoundaryResult.extracted.guarantee.alternatives[1]?.renewalAmount, 10000);

const decisionFeeIsExtraOnlyResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 エポスカード
1エポスカード 初回保証料:月額賃料の50%(最低保証料15,000円)、月額保証料:月額賃料の1.5% 年間更新料無し
2エポスカード不可の場合、Casaダイレクトワイド 初回保証料:賃料等総額の50% 年間更新料:10,000円 決済手数料:月額330円
○ 保険
保険要加入 2年契約 20,000円
広告掲載`,
  ),
);
assert.equal(decisionFeeIsExtraOnlyResult.extracted.guarantee.needsChoice, true);
assert.equal(decisionFeeIsExtraOnlyResult.extracted.guarantee.alternatives[1]?.monthlyFixed, 0);
assert.equal(decisionFeeIsExtraOnlyResult.extracted.guarantee.alternatives[1]?.monthlyFixedExtra, 330);

const fixedAndPercentProviderResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 らくらくパートナー又は日本セーフティ
●らくらくパートナー 初回保証委託事務手数料:33,000円/月額保証料:月額支払料の2%
●日本セーフティ 初回保証料:月額支払料の50%/年間保証料:10,000円
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.equal(fixedAndPercentProviderResult.extracted.guarantee.needsChoice, true);
assert.deepEqual(
  fixedAndPercentProviderResult.extracted.guarantee.alternatives.map((item) => ({
    label: item.label,
    fixed: item.fixed,
    rate: item.initialRate,
    monthlyRate: item.monthlyRate,
    renewal: item.renewalAmount,
  })),
  [
    { label: "らくらくパートナー", fixed: 33000, rate: 0, monthlyRate: 2, renewal: 0 },
    { label: "日本セーフティ", fixed: 0, rate: 50, monthlyRate: 0, renewal: 10000 },
  ],
);

const compactFixedGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 あんしん保証株式会社
初回保証料 30,000円(一律)月額保証料500円(一律)更新保証料10,000円(1年毎)
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.equal(compactFixedGuaranteeResult.extracted.guarantee.fixed, 30000);
assert.equal(compactFixedGuaranteeResult.extracted.guarantee.monthlyFixed, 500);
assert.equal(compactFixedGuaranteeResult.extracted.guarantee.renewalAmount, 10000);

const monthlyMinimumGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 Casa
初回保証料:賃料等合計額50%(最低額20,000円)
月額保証料:賃料等合計額1.5%(最低額700円)
引落手数料:なし(月額保証料に含む)
年間保証料:なし
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.equal(monthlyMinimumGuaranteeResult.extracted.guarantee.initialMinimum, 20000);
assert.equal(monthlyMinimumGuaranteeResult.extracted.guarantee.monthlyRate, 1.5);
assert.equal(monthlyMinimumGuaranteeResult.extracted.guarantee.monthlyMinimum, 700);
assert.equal(monthlyMinimumGuaranteeResult.estimateData.settings.monthlyGuaranteeMinimum, 700);

const compactInitialPlanHeaderResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 エポス/ライフ/ほっと
初回保証料
1エポス:月額50%
2ライフ:月額50%
3ほっと:月額80%
年更新料:全て1万円
※エポス審査不承認に限り、2年一括払い¥22,000)初回保証料
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.equal(compactInitialPlanHeaderResult.extracted.guarantee.needsChoice, true);
assert.deepEqual(
  compactInitialPlanHeaderResult.extracted.guarantee.alternatives.map((item) => ({
    label: item.label,
    rate: item.initialRate,
    monthlyRate: item.monthlyRate,
    renewal: item.renewalAmount,
  })),
  [
    { label: "エポス", rate: 50, monthlyRate: 0, renewal: 10000 },
    { label: "ライフ", rate: 50, monthlyRate: 0, renewal: 10000 },
    { label: "ほっと", rate: 80, monthlyRate: 0, renewal: 10000 },
  ],
);

const studentAndMonthlyUpdatePlansResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 優先順位① オリコフォレントインシュア 優先順位② 日本セーフティ
①オリコフォレントインシュア
初回保証料 月額賃料合計の50%(最初の家賃引落時に請求) 更新料10,000円
学生専用プラン 初回保証料 10,000円 更新料なし
支払手数料 月額賃料合計の1.5%(月々)
②日本セーフティー
初回保証料 月額賃料合計の50%もしくは100%
学生プラン 初回保証料 10,000円
※更新料 月額制 月/800円
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.equal(studentAndMonthlyUpdatePlansResult.extracted.guarantee.needsChoice, true);
assert.deepEqual(
  studentAndMonthlyUpdatePlansResult.extracted.guarantee.alternatives.map((item) => ({
    label: item.label,
    rate: item.initialRate,
    fixed: item.fixed,
    monthlyRate: item.monthlyRate,
    monthlyFixed: item.monthlyFixed,
    renewal: item.renewalAmount,
  })),
  [
    { label: "オリコフォレントインシュア", rate: 50, fixed: 0, monthlyRate: 1.5, monthlyFixed: 0, renewal: 10000 },
    { label: "オリコフォレントインシュア（学生プラン）", rate: 0, fixed: 10000, monthlyRate: 1.5, monthlyFixed: 0, renewal: 0 },
    { label: "日本セーフティー（50%）", rate: 50, fixed: 0, monthlyRate: 0, monthlyFixed: 800, renewal: 0 },
    { label: "日本セーフティー（100%）", rate: 100, fixed: 0, monthlyRate: 0, monthlyFixed: 800, renewal: 0 },
    { label: "日本セーフティー（学生プラン）", rate: 0, fixed: 10000, monthlyRate: 0, monthlyFixed: 800, renewal: 0 },
  ],
);

const monthlyCombinedRenewalAndDebitResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 全保連
全保連:初回50%見守りプラン(毎月更新料、引落手数料合わせて2,000円)
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.equal(monthlyCombinedRenewalAndDebitResult.extracted.guarantee.initialRate, 50);
assert.equal(monthlyCombinedRenewalAndDebitResult.extracted.guarantee.monthlyFixed, 0);
assert.equal(monthlyCombinedRenewalAndDebitResult.extracted.guarantee.monthlyFixedExtra, 2000);
assert.equal(monthlyCombinedRenewalAndDebitResult.extracted.guarantee.renewalAmount, 0);

const decimalCommaAndProviderChoicesResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 オリコフォレントインシュア又はライフあんしん保証又は全保連
①オリコフォレントインシュア:初回保証料50%+月額支払総額の1,5%(変動費含む)
②ライフあんしん保証:初回保証料50%+更新料10,000円(1年毎)、月額880円(税込)
③全保連:初回保証料50%+年間更新料10,000円 or 初回保証料100%
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.deepEqual(
  decimalCommaAndProviderChoicesResult.extracted.guarantee.alternatives.map((item) => ({
    label: item.label,
    rate: item.initialRate,
    monthlyRate: item.monthlyRate,
    monthlyFixed: item.monthlyFixed,
    renewal: item.renewalAmount,
  })),
  [
    { label: "オリコフォレントインシュア", rate: 50, monthlyRate: 1.5, monthlyFixed: 0, renewal: 0 },
    { label: "ライフあんしん保証", rate: 50, monthlyRate: 0, monthlyFixed: 880, renewal: 10000 },
    { label: "全保連（50%）", rate: 50, monthlyRate: 0, monthlyFixed: 0, renewal: 10000 },
    { label: "全保連（100%）", rate: 100, monthlyRate: 0, monthlyFixed: 0, renewal: 0 },
  ],
);

const providerHeadingAndPaymentChoicesResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 日本セーフティー・JACCS・アイスマイル
◆日本セーフティー
[保証人有] 初回保証料:月額賃料等+固定変動費合計50%、年更新10,000円、最低保証20,000円
[保証人無] 初回保証料:月額賃料等+固定変動費合計70%、年更新10,000円、最低保証30,000円
◆JACCS(集金代行)
初回保証料:30,000円、年更新10,500円、JACCS利用手数料(月額)500円+税
◆アイスマイル
[毎月払い]初回保証料:無、月額保証料:賃料等変動費4.25%
[併用払い]初回保証料:月額賃料等変動費50%、月額保証料:賃料等変動費2.6%
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.deepEqual(
  providerHeadingAndPaymentChoicesResult.extracted.guarantee.alternatives.map((item) => ({
    label: item.label,
    rate: item.initialRate,
    minimum: item.initialMinimum,
    fixed: item.fixed,
    monthlyRate: item.monthlyRate,
    monthlyExtra: item.monthlyFixedExtra,
    renewal: item.renewalAmount,
  })),
  [
    { label: "保証人有", rate: 50, minimum: 20000, fixed: 0, monthlyRate: 0, monthlyExtra: 0, renewal: 10000 },
    { label: "保証人無", rate: 70, minimum: 30000, fixed: 0, monthlyRate: 0, monthlyExtra: 0, renewal: 10000 },
    { label: "JACCS(集金代行)", rate: 0, minimum: 0, fixed: 30000, monthlyRate: 0, monthlyExtra: 500, renewal: 10500 },
    { label: "毎月払い", rate: 0, minimum: 0, fixed: 0, monthlyRate: 4.25, monthlyExtra: 0, renewal: 0 },
    { label: "併用払い", rate: 50, minimum: 0, fixed: 0, monthlyRate: 2.6, monthlyExtra: 0, renewal: 0 },
  ],
);

const doubleAngleProviderResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 ジェイリース or Casa
≪ジェイリース≫
初回保証料50% 総額1.5%/月(最低600円) 年更新なし
≪Casa≫
初回保証料50% 総額1.5%/月(最低700円) 年更新なし
○ 保険
保険要加入 2年契約 17,000円`,
  ),
);
assert.deepEqual(
  doubleAngleProviderResult.extracted.guarantee.alternatives.map((item) => ({
    label: item.label,
    initialRate: item.initialRate,
    initialMinimum: item.initialMinimum,
    monthlyRate: item.monthlyRate,
    monthlyMinimum: item.monthlyMinimum,
  })),
  [
    { label: "ジェイリース", initialRate: 50, initialMinimum: 0, monthlyRate: 1.5, monthlyMinimum: 600 },
    { label: "Casa", initialRate: 50, initialMinimum: 0, monthlyRate: 1.5, monthlyMinimum: 700 },
  ],
);

const trailingMonthlyWordingResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 オリコフォレントインシュア
初回家賃引落時に50%の初回保証費用、家賃総額の1.5%引き落とし手数料が毎月かかります。
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.equal(trailingMonthlyWordingResult.extracted.guarantee.initialRate, 50);
assert.equal(trailingMonthlyWordingResult.extracted.guarantee.monthlyRate, 1.5);

const monthlyUpdateResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 保証会社
保証会社利用必須 賃住保証サービス
【1契約毎に】初回:支払総額の50%(部屋の契約は下限20,000円 その他の契約は下限なし) 月更新:月額支払の1.5%(部屋の契約は下限1,000円/月 その他の契約は下限なし) 年更新:なし
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.equal(monthlyUpdateResult.extracted.guarantee.initialRate, 50);
assert.equal(monthlyUpdateResult.extracted.guarantee.initialMinimum, 20000);
assert.equal(monthlyUpdateResult.extracted.guarantee.monthlyRate, 1.5);
assert.equal(monthlyUpdateResult.extracted.guarantee.monthlyMinimum, 1000);

const genericUnregisteredItemsResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `諸費用
○ 初期費用
消火剤+防災グッズ 契約時 16,500円
投てき消火剤 契約時 6,930円
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.deepEqual(
  genericUnregisteredItemsResult.extracted.fees
    .filter((fee) => fee.category === "unregistered")
    .map((fee) => fee.amount),
  [16500, 6930],
);

const shuwaActualResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows.map((row) => row[0] === "賃料 / 管理費・共益費" ? [row[0], "63,000円 / 0円"] : row),
    `諸費用
○ 保証会社
保証会社利用必須 エポス指定 保証会社エポスN 初回月額賃料等の50%(最低保証料20,000円)、月額総支払額の2%/月
○ 保険
保険要加入 月額 1,200円
○ 初期費用
消毒代 契約時 25,300円
入居者サポート費用 契約時 22,000円
消火剤+防災グッズ 契約時 16,500円
投てき消火剤 契約時 6,930円
○ ランニングコスト
更新事務手数料 更新時 11,000円（税込）
広告掲載`,
  ),
);
assert.equal(shuwaActualResult.extracted.guarantee.initialRate, 50);
assert.equal(shuwaActualResult.extracted.guarantee.initialMinimum, 20000);
assert.equal(shuwaActualResult.extracted.guarantee.monthlyRate, 2);
assert.equal(shuwaActualResult.extracted.guarantee.warnings.length, 0);
assert.equal(shuwaActualResult.extracted.base.insuranceFee, 1200);
assert.equal(shuwaActualResult.extracted.base.insuranceTiming, "monthly");
assert.deepEqual(
  shuwaActualResult.extracted.fees
    .filter((fee) => fee.category === "unregistered")
    .map((fee) => fee.amount),
  [16500, 6930],
);
assert.ok(
  shuwaActualResult.estimateData.settings.extraFees.some(
    (fee) => fee.label === "入居者サポート費用" && fee.amount === 22000 && fee.guaranteeTarget === false,
  ),
);
assert.equal(shuwaActualResult.estimateData.amounts.supportFee, undefined);
assert.ok(
  shuwaActualResult.estimateData.settings.remarkFees.some(
    (fee) => fee.label === "更新事務手数料" && fee.amount === 11000,
  ),
);
assert.equal(shuwaActualResult.extracted.diagnostics.choiceFees.length, 0);

// Live RealPro regression: 和Misawa 403 exposes two plans from one company.
const misawaGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows.map((row) => row[0] === "賃料 / 管理費・共益費" ? [row[0], "60,000円 / 3,000円"] : row),
    `諸費用
○ 保証会社
保証会社利用必須 初回50% 毎月総支払額の1.5% 更新保証料10,000円or毎月総支払額の2% 更新料なし
○ ランニングコスト
24時間管理費 月額 1,650円
広告掲載`,
  ),
);
assert.equal(misawaGuaranteeResult.extracted.guarantee.needsChoice, true);
assert.equal(misawaGuaranteeResult.extracted.guarantee.alternatives.length, 2);
assert.equal(misawaGuaranteeResult.extracted.guarantee.alternatives[0].initialRate, 50);
assert.equal(misawaGuaranteeResult.extracted.guarantee.alternatives[0].monthlyRate, 1.5);
assert.equal(misawaGuaranteeResult.extracted.guarantee.alternatives[0].renewalAmount, 10000);
assert.equal(misawaGuaranteeResult.extracted.guarantee.alternatives[1].initialRate, 50);
assert.equal(misawaGuaranteeResult.extracted.guarantee.alternatives[1].monthlyRate, 2);
assert.equal(misawaGuaranteeResult.extracted.guarantee.alternatives[1].renewalAmount, 0);

// Live RealPro regression: room guarantees must not absorb parking-only terms.
const northlandGuaranteeResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows.map((row) => row[0] === "賃料 / 管理費・共益費" ? [row[0], "43,000円 / 6,000円"] : row),
    `諸費用
○ 保証会社
保証会社利用必須 エポス/ライフ/ほっと
初回保証料
①エポス:月額50%
②ライフ:月額50%
③ほっと:月額80%
年更新料:全て1万円
○ その他
<駐車場のみのご契約の場合> 保証会社加入必須
ライフ 初回保証料5,000円 月額保証料5.25%
ほっと 初回保証料100% 月額保証料880円
広告掲載`,
  ),
);
assert.equal(northlandGuaranteeResult.extracted.guarantee.needsChoice, true);
assert.equal(northlandGuaranteeResult.extracted.guarantee.alternatives.length, 3);
assert.deepEqual(
  northlandGuaranteeResult.extracted.guarantee.alternatives.map((plan) => plan.initialRate),
  [50, 50, 80],
);
assert.deepEqual(
  northlandGuaranteeResult.extracted.guarantee.alternatives.map((plan) => plan.renewalAmount),
  [10000, 10000, 10000],
);
assert.equal(northlandGuaranteeResult.extracted.guarantee.alternatives.some((plan) => plan.fixed === 5000), false);
assert.equal(northlandGuaranteeResult.extracted.guarantee.alternatives.some((plan) => plan.monthlyRate === 5.25), false);
assert.equal(northlandGuaranteeResult.extracted.guarantee.alternatives.some((plan) => plan.monthlyFixed === 880), false);

const brokerSpecialCostResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows,
    `客付業者様へ
ロードヒーティング料(1シーズン):40,000円(税別)
エアコン1基付き。ガス料金定額5月〜10月6,600円
11月〜4月13,200円。ペット応相談。
ガス料金は上限22,000円。駐車場2台目月14,300円。
諸費用
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.ok(brokerSpecialCostResult.extracted.fees.some((fee) => fee.amount === 40000 && fee.category === "unregistered"));
assert.ok(brokerSpecialCostResult.extracted.fees.some((fee) => fee.amount === 6600 && fee.category === "remark"));
assert.ok(brokerSpecialCostResult.extracted.fees.some((fee) => fee.amount === 13200 && fee.category === "remark"));
assert.ok(brokerSpecialCostResult.extracted.fees.some((fee) => fee.amount === 22000 && fee.category === "remark"));
assert.ok(brokerSpecialCostResult.extracted.fees.some((fee) => fee.amount === 14300 && fee.category === "parkingFee" && fee.optional));

const conditionalParkingResult = globalThis.RealproEstimateParser.extract(
  documentFixture(
    rows.map((row) => row[0] === "駐車場"
      ? ["駐車場", "敷地内駐車場\nP番号の記載がない場合は満車です。ご了承ください。\nP-2(軽専用)番:7,700円/月(税込)"]
      : row),
    `諸費用
○ 保険
保険要加入 2年契約 20,000円`,
  ),
);
assert.equal(conditionalParkingResult.extracted.base.parkingFee, 7700);

console.log("realpro parser test: ok");
