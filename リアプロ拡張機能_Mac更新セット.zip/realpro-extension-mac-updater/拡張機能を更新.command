#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOCAL_ZIP="$SCRIPT_DIR/realpro-estimate-extension.zip"
REMOTE_ZIP_URL="https://rent-estimate-gaku-202609.netlify.app/realpro-estimate-extension.zip"
TARGET_DIR="$HOME/Downloads/realpro-estimate-extension"
BACKUP_DIR="$HOME/Downloads/realpro-estimate-extension-backup"
TMP_DIR="$(mktemp -d)"

cleanup() {
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT

version_from_manifest() {
  /usr/bin/plutil -extract version raw -o - "$1" 2>/dev/null || echo "0.0.0"
}

is_newer() {
  /usr/bin/awk -v left="$1" -v right="$2" 'BEGIN {
    split(left, a, "."); split(right, b, ".");
    for (i = 1; i <= 4; i++) {
      av = (a[i] == "" ? 0 : a[i] + 0);
      bv = (b[i] == "" ? 0 : b[i] + 0);
      if (av > bv) exit 0;
      if (av < bv) exit 1;
    }
    exit 1;
  }'
}

prepare_package() {
  local zip_file="$1"
  local destination="$2"
  mkdir -p "$destination"
  /usr/bin/unzip -q "$zip_file" -d "$destination"
  find "$destination" -name manifest.json -not -path '*/__MACOSX/*' -print -quit
}

echo "リアプロ初期費用見積連携を更新します。"
echo

selected_manifest=""
selected_version="0.0.0"
selected_source=""

if [ -f "$LOCAL_ZIP" ]; then
  local_manifest="$(prepare_package "$LOCAL_ZIP" "$TMP_DIR/local")"
  if [ -n "$local_manifest" ]; then
    selected_manifest="$local_manifest"
    selected_version="$(version_from_manifest "$local_manifest")"
    selected_source="同梱ZIP"
  fi
fi

echo "公開中の最新版を確認しています。"
if /usr/bin/curl --fail --location --silent --show-error --connect-timeout 10 \
  "$REMOTE_ZIP_URL?t=$(date +%s)" -o "$TMP_DIR/remote.zip"; then
  remote_manifest="$(prepare_package "$TMP_DIR/remote.zip" "$TMP_DIR/remote")"
  if [ -n "$remote_manifest" ]; then
    remote_version="$(version_from_manifest "$remote_manifest")"
    if [ -z "$selected_manifest" ] || is_newer "$remote_version" "$selected_version"; then
      selected_manifest="$remote_manifest"
      selected_version="$remote_version"
      selected_source="公開ZIP"
    fi
  fi
else
  echo "公開ZIPを取得できないため、同梱ZIPを使用します。"
fi

if [ -z "$selected_manifest" ]; then
  echo "更新用ZIPにmanifest.jsonが見つかりません。"
  read -r -p "終了するにはEnterキーを押してください。"
  exit 1
fi

SOURCE_DIR="$(dirname "$selected_manifest")"
for required in manifest.json background.js realpro-parser.js realpro-content.js estimate-content.js popup.html popup.js popup.css; do
  if [ ! -f "$SOURCE_DIR/$required" ]; then
    echo "更新用ZIPに $required がありません。"
    read -r -p "終了するにはEnterキーを押してください。"
    exit 1
  fi
done

current_version="未導入"
if [ -f "$TARGET_DIR/manifest.json" ]; then
  current_version="$(version_from_manifest "$TARGET_DIR/manifest.json")"
fi

echo
echo "現在のバージョン: $current_version"
echo "更新用バージョン: ${selected_version}（${selected_source}）"

if [ "$current_version" != "未導入" ] && is_newer "$current_version" "$selected_version"; then
  echo "現在のバージョンの方が新しいため、上書きしませんでした。"
else
  if [ -d "$TARGET_DIR" ]; then
    rm -rf "$BACKUP_DIR"
    cp -R "$TARGET_DIR" "$BACKUP_DIR"
  fi

  mkdir -p "$TARGET_DIR"
  cp -R "$SOURCE_DIR/." "$TARGET_DIR/"
  chmod -R u+rwX "$TARGET_DIR"
  echo "拡張機能ファイルを同じ保存先へ上書きしました。"
fi

echo
echo "保存先: $TARGET_DIR"
echo "更新後バージョン: $(version_from_manifest "$TARGET_DIR/manifest.json")"
echo
echo "次にChromeで『リアプロ初期費用見積連携』の『再読み込み』を押してください。"
echo "初回導入時だけ『パッケージ化されていない拡張機能を読み込む』から保存先を選びます。"

open -a "Google Chrome" "chrome://extensions/" >/dev/null 2>&1 || true
read -r -p "終了するにはEnterキーを押してください。"
