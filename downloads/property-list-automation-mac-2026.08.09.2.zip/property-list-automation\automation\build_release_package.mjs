import fs from "node:fs/promises";
import path from "node:path";
import { createReadStream } from "node:fs";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const distRoot = path.join(projectRoot, "dist");
const versionPath = path.join(projectRoot, "app-version.json");

const skipDirectoryNames = new Set([
  ".git",
  ".idea",
  ".vscode",
  "__pycache__",
  "backups",
  "downloads",
  "node_modules",
  "dist",
  "exports",
  "outputs",
  "staged",
]);

const skipFileNames = new Set([
  ".DS_Store",
  "Thumbs.db",
  "desktop.ini",
  "server.log",
  "chrome-bridge-windows.log",
  "chrome-bridge-windows-error.log",
]);

const dataFilesToKeep = new Set([
  "performance_baseline.json",
  "performance_latest.json",
  "sample_capture.json",
  "sample_structured_capture.json",
  "verification_rules.json",
  "verification_sample.json",
]);

const baseUrl = readArgumentValue("--base-url") || "https://example.com/downloads";
const manifestUrl = readArgumentValue("--manifest-url") || inferManifestUrl(baseUrl);

async function main() {
  const version = await readJson(versionPath);
  const versionName = String(version.version || "").trim();
  if (!versionName) throw new Error("app-version.json の version が空です。");
  if (manifestUrl && !/^https?:\/\//.test(manifestUrl)) {
    throw new Error("--manifest-url は http または https のURLにしてください。");
  }

  const releaseRoot = path.join(distRoot, "releases", versionName);
  const workRoot = path.join(releaseRoot, "_work");
  const downloadsDir = path.join(releaseRoot, "downloads");
  const macPackageRoot = path.join(workRoot, "mac", "property-list-automation");
  const macZipName = `property-list-automation-mac-${versionName}.zip`;
  const macZipPath = path.join(downloadsDir, macZipName);
  const windowsExeName = `property-list-automation-windows-${versionName}.exe`;
  const windowsExeSource = path.join(distRoot, windowsExeName);
  const windowsExeTarget = path.join(downloadsDir, windowsExeName);
  const windowsSourceZipName = `property-list-automation-windows-installer-source-${versionName}.zip`;
  const windowsSourceZipPath = path.join(downloadsDir, windowsSourceZipName);
  const windowsPortableZipName = `property-list-automation-windows-portable-${versionName}.zip`;
  const windowsPortableZipPath = path.join(downloadsDir, windowsPortableZipName);

  await fs.rm(releaseRoot, { recursive: true, force: true });
  await fs.mkdir(downloadsDir, { recursive: true });

  await copyProjectForRelease(projectRoot, macPackageRoot);
  await writeUpdateSettings(macPackageRoot, manifestUrl);
  await createZipArchive(path.dirname(macPackageRoot), path.basename(macPackageRoot), macZipPath);
  const macSha256 = await sha256File(macZipPath);

  runNodeScript("automation/build_windows_installer_source.mjs");
  const windowsStagingRoot = path.join(distRoot, "windows-installer-source", "property-list-automation");
  await writeUpdateSettings(windowsStagingRoot, manifestUrl);
  await writeWindowsPortableGuide(windowsStagingRoot, versionName);
  await createZipArchive(path.join(distRoot, "windows-installer-source"), "property-list-automation", windowsSourceZipPath);
  const windowsSourceSha256 = await sha256File(windowsSourceZipPath);
  await createZipArchive(path.join(distRoot, "windows-installer-source"), "property-list-automation", windowsPortableZipPath);
  const windowsPortableSha256 = await sha256File(windowsPortableZipPath);

  let windowsExe = null;
  if (await pathExists(windowsExeSource)) {
    await fs.copyFile(windowsExeSource, windowsExeTarget);
    windowsExe = {
      name: windowsExeName,
      sha256: await sha256File(windowsExeTarget),
      url: joinUrl(baseUrl, windowsExeName),
      packageType: "exe",
      fileName: windowsExeName,
    };
  }

  const manifest = buildManifest({
    versionName,
    macZipName,
    macSha256,
    windowsExe,
  });
  await fs.writeFile(path.join(releaseRoot, "update-manifest.template.json"), `${JSON.stringify(manifest, null, 2)}\n`, "utf8");

  const summary = {
    version: versionName,
    releaseRoot,
    downloadsDir,
    mac: {
      file: macZipPath,
      sha256: macSha256,
      url: joinUrl(baseUrl, macZipName),
    },
    updateSettings: {
      manifestUrl,
    },
    windows: windowsExe || {
      file: "",
      sha256: "",
      url: joinUrl(baseUrl, windowsExeName),
      note: "Windowsインストーラーexeは未作成です。WindowsでBUILD_WINDOWS_INSTALLER.batを実行してからdownloadsへ置いてください。",
    },
    windowsInstallerSource: {
      file: windowsSourceZipPath,
      sha256: windowsSourceSha256,
      url: joinUrl(baseUrl, windowsSourceZipName),
    },
    windowsPortable: {
      file: windowsPortableZipPath,
      sha256: windowsPortableSha256,
      url: joinUrl(baseUrl, windowsPortableZipName),
    },
  };

  await writeUploadGuide(releaseRoot, summary);
  await fs.rm(workRoot, { recursive: true, force: true });

  console.log("サーバー掲載用リリース配布物を作成しました。");
  console.log(JSON.stringify(summary, null, 2));
}

async function copyProjectForRelease(sourceRoot, destinationRoot) {
  await fs.rm(destinationRoot, { recursive: true, force: true });
  await fs.mkdir(destinationRoot, { recursive: true });
  await copyDirectory(sourceRoot, destinationRoot);
  await ensureRuntimeFolders(destinationRoot);
  await copyAllowedDataFiles(sourceRoot, destinationRoot);
}

async function copyDirectory(sourceDir, destinationDir, relativeBase = "") {
  const entries = await fs.readdir(sourceDir, { withFileTypes: true });
  for (const entry of entries) {
    const sourcePath = path.join(sourceDir, entry.name);
    const relativePath = path.join(relativeBase, entry.name);
    const destinationPath = path.join(destinationDir, entry.name);

    if (shouldSkipEntry(relativePath, entry)) continue;

    if (entry.isDirectory()) {
      await fs.mkdir(destinationPath, { recursive: true });
      await copyDirectory(sourcePath, destinationPath, relativePath);
    } else if (entry.isFile()) {
      await fs.mkdir(path.dirname(destinationPath), { recursive: true });
      await fs.copyFile(sourcePath, destinationPath);
    }
  }
}

function shouldSkipEntry(relativePath, entry) {
  const parts = relativePath.split(path.sep).filter(Boolean);
  const rootName = parts[0] || entry.name;

  if (entry.isDirectory()) {
    if (skipDirectoryNames.has(entry.name) || skipDirectoryNames.has(rootName)) return true;
    if (rootName === "data") return true;
  }

  if (entry.isFile()) {
    if (skipFileNames.has(entry.name)) return true;
    if (rootName === "data") return true;
  }

  return false;
}

async function ensureRuntimeFolders(root) {
  for (const name of ["data", "exports", "outputs", path.join("updates", "downloads"), path.join("updates", "staged")]) {
    await fs.mkdir(path.join(root, name), { recursive: true });
  }
}

async function copyAllowedDataFiles(sourceRoot, destinationRoot) {
  const sourceDataDir = path.join(sourceRoot, "data");
  const destinationDataDir = path.join(destinationRoot, "data");
  await fs.mkdir(destinationDataDir, { recursive: true });

  let entries = [];
  try {
    entries = await fs.readdir(sourceDataDir, { withFileTypes: true });
  } catch {
    return;
  }

  for (const entry of entries) {
    if (!entry.isFile() || !dataFilesToKeep.has(entry.name)) continue;
    await fs.copyFile(path.join(sourceDataDir, entry.name), path.join(destinationDataDir, entry.name));
  }
}

async function writeUpdateSettings(packageRoot, url) {
  const settingsPath = path.join(packageRoot, "updates", "update-settings.json");
  const settings = {
    schemaVersion: 1,
    manifestUrl: String(url || "").trim(),
    updatedAt: new Date().toISOString(),
    notes: url
      ? "このPCは起動時に指定URLの update-manifest.json を確認します。"
      : "manifestUrl が空のため、ローカルの updates/update-manifest.json を確認します。",
  };
  await fs.mkdir(path.dirname(settingsPath), { recursive: true });
  await fs.writeFile(settingsPath, `${JSON.stringify(settings, null, 2)}\n`, "utf8");
}

async function writeWindowsPortableGuide(packageRoot, versionName) {
  const guide = `物件候補リスト作成システム Windows ZIP版

バージョン: ${versionName}

インストーラーEXEがWindows Defender / SmartScreenで開かない場合の予備版です。

使い方:

1. このZIPを右クリックして「プロパティ」を開きます。
2. 「許可する」または「ブロックの解除」があればチェックしてOKします。
3. ZIPを右クリックして「すべて展開」します。
4. 展開した property-list-automation フォルダを開きます。
5. START_WINDOWS.bat をダブルクリックします。

必要なもの:

- Google Chrome

Node.jsとPythonはこのフォルダ内の runtime に入っています。
Windows本体へNode.js/Pythonを別途入れる必要はありません。
`;
  await fs.writeFile(path.join(packageRoot, "WINDOWS_ZIP版_起動手順.txt"), guide, "utf8");
}

function buildManifest({ versionName, macZipName, macSha256, windowsExe }) {
  const windowsInfo = windowsExe
    ? {
        version: versionName,
        url: windowsExe.url,
        sha256: windowsExe.sha256,
        packageType: "exe",
        fileName: windowsExe.name,
        required: false,
        notes: [
          "Windows版インストーラー更新",
          "更新ボタンから自動インストールし、完了後にシステムを再起動",
          "コード署名なしのため、PCによってはWindowsの許可操作が必要",
        ],
      }
    : {
        version: versionName,
        url: joinUrl(baseUrl, `property-list-automation-windows-${versionName}.exe`),
        sha256: "WINDOWS_EXE_SHA256_AFTER_BUILD",
        packageType: "exe",
        fileName: `property-list-automation-windows-${versionName}.exe`,
        required: false,
        notes: ["Windowsでインストーラーexeを作成後、このURLとSHA-256を確定してください。"],
      };

  return {
    schemaVersion: 1,
    publishedAt: new Date().toISOString(),
    windows: windowsInfo,
    mac: {
      version: versionName,
      url: joinUrl(baseUrl, macZipName),
      sha256: macSha256,
      packageType: "zip",
      fileName: macZipName,
      required: false,
      notes: ["Mac版更新ZIP"],
    },
  };
}

async function writeUploadGuide(releaseRoot, summary) {
  const windowsBlock = summary.windows.file
    ? `- Windows exe: downloads/${summary.windows.name}
  URL: ${summary.windows.url}
  SHA-256: ${summary.windows.sha256}`
    : `- Windows exe: 未作成
  Windowsで BUILD_WINDOWS_INSTALLER.bat を実行し、dist/property-list-automation-windows-${summary.version}.exe を downloads へ置いてください。
  その後、SHA-256を計算して update-manifest.template.json の WINDOWS_EXE_SHA256_AFTER_BUILD を置き換えてください。`;

  const guide = `サーバー掲載用リリース配布物

バージョン: ${summary.version}
作成日: ${new Date().toISOString()}
更新manifest URL: ${summary.updateSettings.manifestUrl || "未設定"}

アップロードするファイル:

- Mac ZIP: downloads/${path.basename(summary.mac.file)}
  URL: ${summary.mac.url}
  SHA-256: ${summary.mac.sha256}

${windowsBlock}

- Windowsインストーラー配布元ZIP: downloads/${path.basename(summary.windowsInstallerSource.file)}
  URL: ${summary.windowsInstallerSource.url}
  SHA-256: ${summary.windowsInstallerSource.sha256}

- Windows ZIP版: downloads/${path.basename(summary.windowsPortable.file)}
  URL: ${summary.windowsPortable.url}
  SHA-256: ${summary.windowsPortable.sha256}

手順:

1. downloads フォルダ内のファイルをサーバーの downloads 配下へアップロードします。
2. update-manifest.template.json のURLを本番URLに合わせます。
3. Windows exeが未作成の場合は、Windowsでインストーラーを作ってからSHA-256を入れます。
4. 完成したJSONをサーバーの update-manifest.json として配置します。
5. 各PCのシステムを起動し、アップデート通知が出るか確認します。

注意:

- data、exports、outputs、backups、updates/downloads、updates/staged は配布物に実務データとして含めません。
- Windowsインストーラー配布元ZIPはメンテナンス用です。通常利用者へ配る本命は Windows exe です。
- Windows exeがSmartScreenで開かない場合は、Windows ZIP版を予備として使います。
`;
  await fs.writeFile(path.join(releaseRoot, "UPLOAD_TO_SERVER.txt"), guide, "utf8");
}

function runNodeScript(scriptPath) {
  const result = spawnSync(process.execPath, [scriptPath], {
    cwd: projectRoot,
    encoding: "utf8",
  });
  if (result.status !== 0) {
    throw new Error((result.stderr || result.stdout || `${scriptPath} の実行に失敗しました。`).trim());
  }
}

async function createZipArchive(parentDir, packageDirName, zipPath) {
  await fs.rm(zipPath, { force: true });
  await fs.mkdir(path.dirname(zipPath), { recursive: true });

  if (process.platform === "win32") {
    const powershell = findPowerShellCommand();
    if (!powershell) throw new Error("PowerShellが見つからないため、ZIPを作成できません。");
    const result = spawnSync(powershell, [
      "-NoProfile",
      "-ExecutionPolicy",
      "Bypass",
      "-Command",
      "Compress-Archive -LiteralPath $env:PROPERTY_RELEASE_SOURCE -DestinationPath $env:PROPERTY_RELEASE_ZIP -Force",
    ], {
      encoding: "utf8",
      windowsHide: true,
      env: {
        ...process.env,
        PROPERTY_RELEASE_SOURCE: path.join(parentDir, packageDirName),
        PROPERTY_RELEASE_ZIP: zipPath,
      },
    });
    if (result.status !== 0) {
      throw new Error((result.stderr || result.stdout || "ZIP作成に失敗しました。").trim());
    }
    return;
  }

  const result = spawnSync("zip", ["-qr", zipPath, packageDirName], {
    cwd: parentDir,
    encoding: "utf8",
  });
  if (result.status !== 0) {
    throw new Error((result.stderr || result.stdout || "ZIP作成に失敗しました。").trim());
  }
}

function findPowerShellCommand() {
  for (const command of ["powershell", "pwsh"]) {
    const result = spawnSync(command, ["-NoProfile", "-Command", "$PSVersionTable.PSVersion.ToString()"], {
      encoding: "utf8",
      windowsHide: true,
    });
    if (result.status === 0) return command;
  }
  return "";
}

async function sha256File(filePath) {
  const hash = createHash("sha256");
  await new Promise((resolve, reject) => {
    const stream = createReadStream(filePath);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.on("error", reject);
    stream.on("end", resolve);
  });
  return hash.digest("hex");
}

async function readJson(filePath) {
  return JSON.parse(await fs.readFile(filePath, "utf8"));
}

function readArgumentValue(name) {
  const prefix = `${name}=`;
  const found = process.argv.find((arg) => arg.startsWith(prefix));
  return found ? found.slice(prefix.length).trim() : "";
}

function inferManifestUrl(downloadsUrl) {
  const value = String(downloadsUrl || "").trim();
  if (!value || value.includes("example.com")) return "";
  try {
    const url = new URL(value);
    url.pathname = url.pathname.replace(/\/+$/, "").replace(/\/downloads$/i, "");
    url.pathname = `${url.pathname.replace(/\/+$/, "")}/update-manifest.json`;
    url.search = "";
    url.hash = "";
    return url.toString();
  } catch {
    return "";
  }
}

function joinUrl(root, fileName) {
  return `${String(root || "").replace(/\/+$/, "")}/${encodeURIComponent(fileName)}`;
}

async function pathExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
