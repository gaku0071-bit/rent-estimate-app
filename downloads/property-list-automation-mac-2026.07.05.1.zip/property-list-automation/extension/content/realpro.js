(() => {
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "REALPRO_STATUS") {
      sendResponse(realproStatus());
      return false;
    }

    if (message?.type === "REALPRO_CAPTURE") {
      captureRealpro({
        pages: clamp(Number(message.pages || 1), 1, 200),
        startPage: clamp(Number(message.startPage || 0), 0, 10000),
        withDetails: message.withDetails !== false,
      })
        .then((realpro) => sendResponse({ ok: true, realpro }))
        .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
      return true;
    }

    return false;
  });

  function realproStatus() {
    const text = document.body?.innerText || "";
    return {
      ok: isRealproResultPage(),
      kind: "realpro",
      title: document.title || "",
      url: location.href,
      summary: summaryFromText(text),
      roomRows: document.querySelectorAll("tr.room_info_tr").length,
    };
  }

  async function captureRealpro({ pages, startPage, withDetails }) {
    if (!isRealproResultPage()) {
      throw new Error("リアプロのリスト検索結果画面ではありません。");
    }

    emitProgress("list", 0, pages, "リアプロ一覧を取得しています...");
    const listResult = await captureRealproPages(pages, startPage);
    let rooms = dedupeRooms(listResult.rooms);
    if (withDetails) {
      rooms = await enrichRealproDetails(rooms);
    }

    return {
      title: document.title || "リアプロ",
      url: location.href,
      rawText: listResult.rawText,
      summary: listResult.summary,
      rooms,
      pageCaptures: listResult.pageCaptures,
      startPage: listResult.startPage + 1,
    };
  }

  async function captureRealproPages(requestedPages, requestedStartPage = 0) {
    const baseUrl = new URL(location.href);
    const explicitFirstPage = Number(requestedStartPage) > 0 ? Number(requestedStartPage) - 1 : 0;
    const firstPage = Number(requestedStartPage) > 0
      ? explicitFirstPage
      : (Number(baseUrl.searchParams.get("page") || "0") || 0);
    const pagerPages = Array.from(document.querySelectorAll("td.pager"))
      .map((el) => (el.getAttribute("onclick") || "").match(/pager\('([^']+)','([^']+)'\)/))
      .filter(Boolean)
      .map((match) => Number(match[2]))
      .filter(Number.isFinite);
    const maxPage = Math.max(firstPage, ...pagerPages);
    const lastPage = Math.min(firstPage + requestedPages - 1, maxPage);
    const pageIndexes = Array.from(
      { length: Math.max(0, lastPage - firstPage + 1) },
      (_item, index) => firstPage + index
    );
    if (!pageIndexes.length) throw new Error("リアプロの取得ページを判定できませんでした。");

    const pageResults = [];
    for (let offset = 0; offset < pageIndexes.length; offset += 5) {
      const batch = pageIndexes.slice(offset, offset + 5);
      const results = await Promise.all(batch.map(fetchRealproPage));
      pageResults.push(...results);
      const roomCount = pageResults.reduce((sum, page) => sum + page.rooms.length, 0);
      emitProgress("list", pageResults.length, pageIndexes.length, `リアプロ一覧 ${pageResults.length}/${pageIndexes.length}ページ / ${roomCount}戸`);
    }

    const rooms = [];
    const pageCaptures = [];
    const rawTextParts = [];
    for (const result of pageResults.sort((a, b) => a.pageIndex - b.pageIndex)) {
      if (result.loginDetected) throw new Error("リアプロがログイン画面です。ログインし直してください。");
      rooms.push(...result.rooms);
      rawTextParts.push([result.summary, `DOM取得戸数 ${result.rooms.length}件`].filter(Boolean).join("\n"));
      pageCaptures.push({
        pageNumber: result.pageIndex + 1,
        url: result.pageUrl,
        lineCount: 2,
        textLength: Math.max(Number(result.textLength || 0), 1),
        expandedRoomButtons: 0,
        roomCount: result.rooms.length,
        roomRowCount: result.rooms.length,
        roomAnchorCount: result.rooms.filter((room) => room.realproRoomId).length,
        loginDetected: false,
        captureMode: "chrome-extension",
        summary: result.summary,
      });
    }
    if (pageCaptures.length) {
      const finalPage = pageCaptures.at(-1).pageNumber - 1;
      pageCaptures.at(-1).stopReason = finalPage >= maxPage ? "last-page-reached" : "requested-pages-reached";
    }

    return {
      rooms,
      pageCaptures,
      rawText: mergeText(rawTextParts),
      summary: pageResults.find((page) => page.summary)?.summary || "",
      startPage: firstPage,
    };
  }

  async function fetchRealproPage(pageIndex) {
    const pageUrl = new URL(location.href);
    pageUrl.searchParams.set("method", "estate");
    pageUrl.searchParams.set("display", "building");
    pageUrl.searchParams.set("page", String(pageIndex));
    const response = await fetchWithTimeout(pageUrl.href, { credentials: "include" }, 30000);
    if (!response.ok) throw new Error(`リアプロ一覧 HTTP ${response.status}: ${pageIndex + 1}ページ`);
    const html = await response.text();
    const doc = new DOMParser().parseFromString(html, "text/html");
    return {
      pageIndex,
      pageUrl: pageUrl.href,
      ...parseRealproDocument(doc, pageUrl.href),
    };
  }

  function parseRealproDocument(doc, pageUrl) {
    const rooms = [];
    let building = { building: "", address: "", line: "", station: "", accessMethod: "徒歩", walkMinutes: 0 };

    for (const tr of Array.from(doc.querySelectorAll("tr"))) {
      const text = textOf(tr).trim();
      const lines = text.split(/\n+/).map((line) => line.trim()).filter(Boolean);
      const addressIndex = lines.findIndex((line) => line.startsWith("住所："));
      const accessIndex = lines.findIndex((line) => line.startsWith("沿線："));
      if (!tr.classList.contains("room_info_tr") && addressIndex > 0 && accessIndex > addressIndex) {
        building = {
          building: normalize(lines[addressIndex - 1]),
          address: normalize(lines[addressIndex].replace(/^住所：/, "")),
          ...parseAccess(lines[accessIndex]),
        };
        continue;
      }
      if (!tr.classList.contains("room_info_tr") || !building.building) continue;

      const cells = Array.from(tr.querySelectorAll("td"));
      const roomAnchor = tr.querySelector("a.room_number");
      const onclick = roomAnchor?.getAttribute("onclick") || "";
      const id = onclick.match(/go_detail\(event,'([^']+)'/)?.[1] || "";
      const roomLabel = normalize(textOf(roomAnchor) || textOf(cells[0]) || "");
      const status = Array.from(tr.querySelectorAll(".st")).map((el) => normalize(textOf(el))).filter(Boolean).join(" ");
      const dateLines = splitCell(cells[5]);
      const layoutLines = splitCell(cells[6]);
      const rentLines = splitCell(cells[7]);
      const equipmentText = normalize(textOf(cells[1]) || "");

      rooms.push({
        ...building,
        room: cleanRoom(roomLabel),
        roomLabel,
        realproRoomId: id,
        layout: normalize(layoutLines[0]),
        area: normalize(layoutLines[1]).replace("m2", "㎡"),
        rent: yen(rentLines[0]),
        fee: yen(rentLines[1]),
        status,
        availableDate: normalize(dateLines[0]),
        adFee: "",
        equipment: equipmentMarkers().filter((marker) => equipmentText.includes(marker)),
        webAd: "判定不可",
        imageReuse: "判定不可",
        floorPlanReuse: "判定不可",
        priorContact: "判定不可",
        applicationCount: 0,
        detailCaptureStatus: id ? "未取得" : "詳細IDなし",
        detailCaptureReason: id ? "詳細取得前" : "一覧から詳細IDを取得できませんでした",
        detailHttpStatus: "",
        detailTextLength: 0,
        url: id ? `${location.origin}/room_detail.php?id=${encodeURIComponent(id)}&type=room` : "",
      });
    }

    const text = doc.body?.innerText || "";
    return {
      rooms,
      textLength: text.length,
      summary: summaryFromText(text),
      loginDetected: /ログインID|パスワード/.test(text) && !/検索結果|部屋番号|空室|退去予定/.test(text),
      pageUrl,
    };
  }

  async function enrichRealproDetails(rooms) {
    const targets = rooms.filter((room) => room.realproRoomId);
    const details = [];
    for (let index = 0; index < targets.length; index += 2) {
      const chunk = targets.slice(index, index + 2);
      const chunkDetails = await Promise.all(chunk.map((room) => captureRealproDetail(room.realproRoomId)));
      details.push(...chunkDetails);
      const checked = Math.min(index + chunk.length, targets.length);
      const candidates = countPossibleCandidates(rooms, details);
      emitProgress("details", checked, targets.length, `リアプロ詳細 ${checked}/${targets.length}戸 / 候補見込み${candidates}件`);
    }

    const detailsById = new Map(details.map((detail) => [String(detail.realproRoomId || ""), detail]));
    return rooms.map((room) => {
      const detail = detailsById.get(String(room.realproRoomId || ""));
      if (!detail) return room;
      return {
        ...room,
        webAd: detail.webAd || room.webAd,
        equipment: [...new Set([...(room.equipment || []), ...(detail.equipment || [])])].sort(),
        applicationCount: Number(detail.applicationCount || 0),
        detailTitle: detail.title || "",
        url: detail.url || room.url,
        detailCaptureStatus: detail.detailCaptureStatus || (detail.webAd === "判定不可" ? "詳細確認不完全" : "取得OK"),
        detailCaptureReason: detail.detailCaptureReason || "",
        detailHttpStatus: detail.status || "",
        detailTextLength: detail.detailTextLength || 0,
      };
    });
  }

  async function captureRealproDetail(id) {
    const url = `${location.origin}/room_detail.php?id=${encodeURIComponent(id)}&type=room`;
    try {
      const response = await fetchWithTimeout(url, { credentials: "include" }, 30000);
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const text = (doc.body?.innerText || "").normalize("NFKC");
      const adSection = (text.match(/広告掲載[\s\S]{0,260}/) || [""])[0];
      const webAd = extractWebAd(adSection || text);
      const applicationCount = await fetchApplicationCount(doc);
      return {
        realproRoomId: id,
        title: (doc.querySelector("title")?.innerText || "").trim(),
        url,
        status: response.status,
        webAd,
        equipment: extractEquipment(text),
        applicationCount,
        detailCaptureStatus: response.ok && webAd !== "判定不可" ? "取得OK" : "詳細確認不完全",
        detailCaptureReason: detailCaptureReason({ response, text, adSection, webAd }),
        detailTextLength: text.length,
      };
    } catch (error) {
      return {
        realproRoomId: id,
        title: "",
        url,
        status: 0,
        webAd: "判定不可",
        equipment: [],
        applicationCount: 0,
        detailCaptureStatus: "取得エラー",
        detailCaptureReason: String(error),
        detailTextLength: 0,
      };
    }
  }

  async function fetchApplicationCount(doc) {
    try {
      const value = (selector) => doc.querySelector(selector)?.value || "";
      const displayFlag = value("#njc_apply_display_flag") || "N";
      if (displayFlag !== "Y") return extractApplicationCount(doc.body?.innerText || "");
      const body = new URLSearchParams();
      body.set("bk_type", "1");
      body.set("rnp_bk_id", value("#building_id"));
      body.set("rnp_hy_id", value("#room_id"));
      body.set("residence_type", value("#residence_type") || "room");
      body.set("company_id", value("#company_id"));
      body.set("user_id", value("#user_id"));
      body.set("func", "request");
      body.set("option_break_flag", value("#mylist_njc_apply_option_break_flag") || "0");
      const response = await fetchWithTimeout(`${location.origin}/ajax/starfruit_auth_tyukai.php`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
        body: body.toString(),
      }, 10000);
      const result = JSON.parse(await response.text());
      return Number(result?.count || 0);
    } catch {
      return extractApplicationCount(doc.body?.innerText || "");
    }
  }

  function extractWebAd(text) {
    const webSection = (String(text || "").match(/webサービスにこの物件の広告を掲載[\s\S]{0,80}/) || [String(text || "")])[0];
    if (/許可されていません|不可/.test(webSection)) return "許可されていません";
    if (/管理会社に確認|要確認|管理会社へご確認|掲載希望の場合は管理会社/.test(webSection)) return "管理会社に確認";
    if (/[［\[]?\s*可\s*[］\]]?|許可されています/.test(webSection)) return "可";
    return "判定不可";
  }

  function detailCaptureReason({ response, text, adSection, webAd }) {
    if (!response.ok) return `HTTP ${response.status}`;
    if (!text) return "詳細本文が空です";
    if (!adSection) return "広告掲載欄を検出できませんでした";
    if (webAd === "判定不可") return "WEB広告掲載可否の文言を検出できませんでした";
    return "";
  }

  function extractApplicationCount(text) {
    const match = String(text || "").match(/(?:申込|申し込み)\s*([0-9]+)\s*件/);
    return Number(match?.[1] || 0);
  }

  function extractEquipment(text) {
    const value = String(text || "").normalize("NFKC");
    const rules = [
      ["バス・トイレ別", /バス・トイレ別|BT別|セパレート/],
      ["独立洗面台", /独立洗面|洗面化粧台|シャンプードレッサー/],
      ["エアコン", /エアコン/],
      ["暖房", /暖房/],
      ["オートロック", /オートロック/],
      ["宅配ボックス", /宅配ボックス|宅配BOX/],
      ["インターネット無料", /インターネット無料|ネット無料/],
      ["Wi-Fi無料", /Wi-?Fi無料|Wifi無料|ワイファイ無料/i],
      ["駐輪場あり", /駐輪場(?:有り|あり|可)/],
      ["ペット相談", /ペット相談|ペット可|ペット飼育/],
      ["灯油暖房", /灯油暖房|灯油FF/],
      ["都市ガス", /都市ガス/],
      ["プロパンガス", /プロパンガス|LPガス/],
      ["エレベーター", /エレベーター/],
      ["防犯カメラ", /防犯カメラ/],
    ];
    const equipment = rules.filter(([, pattern]) => pattern.test(value)).map(([label]) => label);
    const parkingText = (value.match(/駐車場[\s\S]{0,80}/) || [""])[0];
    if (parkingText && !/空きなし|無し|なし|無|不可|要確認/.test(parkingText) && /空きあり|空有|有り|あり|可/.test(parkingText)) {
      equipment.push("駐車場空きあり");
    }
    return equipment;
  }

  async function fetchWithTimeout(url, options = {}, timeoutMs = 10000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
  }

  function countPossibleCandidates(rooms, details) {
    const detailById = new Map(details.map((detail) => [String(detail.realproRoomId || ""), detail]));
    return rooms.filter((room) => {
      const detail = detailById.get(String(room.realproRoomId || ""));
      const webAd = detail?.webAd || room.webAd;
      const applicationCount = Number(detail?.applicationCount || room.applicationCount || 0);
      return webAd !== "許可されていません" &&
        webAd !== "判定不可" &&
        applicationCount === 0 &&
        !/(商談中|審査中|申込あり)/.test(String(room.status || ""));
    }).length;
  }

  function dedupeRooms(rooms) {
    const seen = new Set();
    const deduped = [];
    for (const room of rooms) {
      const key = room.realproRoomId
        ? `id:${room.realproRoomId}`
        : [room.building, room.room, room.layout, room.rent, room.address].map((value) => String(value || "").replace(/\s+/g, "")).join("|");
      if (seen.has(key)) continue;
      seen.add(key);
      deduped.push(room);
    }
    return deduped;
  }

  function emitProgress(phase, current, total, text) {
    try {
      chrome.runtime.sendMessage({
        type: "REALPRO_EXTENSION_PROGRESS",
        phase,
        current,
        total,
        text,
      });
    } catch {
      // Popupが閉じていても取得は続ける。
    }
  }

  function isRealproResultPage() {
    return location.hostname.includes("realnetpro.com") &&
      location.pathname.includes("main.php") &&
      location.search.includes("method=estate");
  }

  function normalize(value) {
    return String(value || "").normalize("NFKC").replace(/\s+/g, " ").trim();
  }

  function cleanRoom(value) {
    return String(value || "").normalize("NFKC").match(/^[A-Za-z0-9-]+/)?.[0] || normalize(value);
  }

  function yen(value) {
    return Number(String(value || "").normalize("NFKC").replace(/[^0-9]/g, "")) || 0;
  }

  function parseAccess(value) {
    const match = String(value || "").match(/^沿線：(.+?)「(.+?)」(徒歩|バス|自動車|車|自転車)([0-9０-９]+)分/);
    if (!match) return { line: "", station: "", accessMethod: "徒歩", walkMinutes: 0 };
    return {
      line: normalize(match[1]),
      station: normalize(match[2]),
      accessMethod: match[3] === "自動車" ? "車" : match[3],
      walkMinutes: Number(String(match[4]).normalize("NFKC")),
    };
  }

  function textOf(element) {
    return String(element?.textContent || "");
  }

  function splitCell(td) {
    return textOf(td).split(/\n+/).map((line) => line.trim()).filter(Boolean);
  }

  function equipmentMarkers() {
    return ["家電", "家具", "駐車場有り", "ペット", "ネット無料", "エアコン", "オートロック", "宅配BOX"];
  }

  function summaryFromText(text) {
    return (String(text || "").normalize("NFKC").match(/[0-9,]+\s*棟\s*[0-9,]+\s*戸/) || [""])[0];
  }

  function mergeText(parts) {
    const seen = new Set();
    return parts.map((part) => String(part || "").trim()).filter((part) => {
      if (!part || seen.has(part)) return false;
      seen.add(part);
      return true;
    }).join("\n\n");
  }

  function clamp(value, min, max) {
    if (!Number.isFinite(value)) return min;
    return Math.min(Math.max(Math.trunc(value), min), max);
  }
})();
