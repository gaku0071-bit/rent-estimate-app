import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const distRoot = path.join(projectRoot, "dist");
const versionPath = path.join(projectRoot, "app-version.json");

const versionArg = readArgumentValue("--version");
const releaseDirArg = readArgumentValue("--release-dir");
const siteUrl = normalizeSiteUrl(readArgumentValue("--site-url") || "https://example.com");

async function main() {
  const appVersion = await readJson(versionPath);
  const versionName = String(versionArg || appVersion.version || "").trim();
  if (!versionName) throw new Error("バージョンを特定できません。app-version.json または --version を確認してください。");

  const releaseRoot = releaseDirArg
    ? path.resolve(releaseDirArg)
    : path.join(distRoot, "releases", versionName);
  const releaseDownloadsDir = path.join(releaseRoot, "downloads");
  const publicRoot = path.join(distRoot, "update-server-public");
  const publicDownloadsDir = path.join(publicRoot, "downloads");
  const finalManifestPath = path.join(releaseRoot, "update-manifest.json");
  const templateManifestPath = path.join(releaseRoot, "update-manifest.template.json");

  if (!await pathExists(releaseDownloadsDir)) {
    throw new Error(`リリースdownloadsが見つかりません: ${releaseDownloadsDir}`);
  }

  await fs.rm(publicRoot, { recursive: true, force: true });
  await fs.mkdir(publicDownloadsDir, { recursive: true });
  await copyDirectory(releaseDownloadsDir, publicDownloadsDir);

  const hasFinalManifest = await pathExists(finalManifestPath);
  const manifestSource = hasFinalManifest ? finalManifestPath : templateManifestPath;
  if (!await pathExists(manifestSource)) {
    throw new Error("update-manifest.json または update-manifest.template.json が見つかりません。");
  }

  const manifestTargetName = hasFinalManifest ? "update-manifest.json" : "update-manifest.template.json";
  await fs.copyFile(manifestSource, path.join(publicRoot, manifestTargetName));

  const downloads = await listFiles(publicDownloadsDir);
  const checksumRows = [];
  for (const filePath of downloads) {
    checksumRows.push({
      file: path.relative(publicRoot, filePath).replaceAll(path.sep, "/"),
      sha256: await sha256File(filePath),
    });
  }
  checksumRows.push({
    file: manifestTargetName,
    sha256: await sha256File(path.join(publicRoot, manifestTargetName)),
  });

  await fs.writeFile(
    path.join(publicRoot, "checksums.txt"),
    checksumRows.map((row) => `${row.sha256}  ${row.file}`).join("\n") + "\n",
    "utf8",
  );

  const summary = {
    version: versionName,
    readyToPublish: hasFinalManifest,
    publicRoot,
    siteUrl,
    pageUrl: inferHumanPageUrl(siteUrl),
    manifest: manifestTargetName,
    downloads: downloads.map((filePath) => path.relative(publicRoot, filePath).replaceAll(path.sep, "/")),
    createdAt: new Date().toISOString(),
  };

  await fs.writeFile(path.join(publicRoot, "SERVER_PUBLIC_STATUS.json"), `${JSON.stringify(summary, null, 2)}\n`, "utf8");
  await fs.writeFile(path.join(publicRoot, "SERVER_PUBLIC_README.txt"), buildReadme(summary), "utf8");
  await fs.writeFile(path.join(publicRoot, "UPLOAD_CHECKLIST.txt"), buildUploadChecklist(summary), "utf8");
  await fs.writeFile(path.join(publicRoot, "index.html"), buildIndexHtml(summary, checksumRows), "utf8");
  await fs.writeFile(path.join(publicRoot, ".nojekyll"), "", "utf8");

  console.log(hasFinalManifest
    ? "サーバー公開用フォルダを作成しました。"
    : "サーバー公開用フォルダを作成しました。ただしmanifestは未確定です。");
  console.log(JSON.stringify(summary, null, 2));
}

async function copyDirectory(sourceDir, destinationDir) {
  const entries = await fs.readdir(sourceDir, { withFileTypes: true });
  for (const entry of entries) {
    const sourcePath = path.join(sourceDir, entry.name);
    const destinationPath = path.join(destinationDir, entry.name);
    if (entry.isDirectory()) {
      await fs.mkdir(destinationPath, { recursive: true });
      await copyDirectory(sourcePath, destinationPath);
    } else if (entry.isFile()) {
      await fs.mkdir(path.dirname(destinationPath), { recursive: true });
      await fs.copyFile(sourcePath, destinationPath);
    }
  }
}

async function listFiles(dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...await listFiles(fullPath));
    } else if (entry.isFile()) {
      files.push(fullPath);
    }
  }
  return files.sort((a, b) => a.localeCompare(b));
}

function buildReadme(summary) {
  return `物件候補リスト作成システム サーバー公開用フォルダ

バージョン: ${summary.version}
作成日: ${summary.createdAt}
公開準備: ${summary.readyToPublish ? "OK" : "未完了"}
想定URL: ${summary.siteUrl}
導入ページ: ${summary.pageUrl}
manifest: ${summary.manifest}

アップロード方法:

1. このフォルダ内のファイルをサーバーの公開ディレクトリへアップロードします。
2. downloads フォルダもそのままアップロードします。
3. 公開後、次のURLをブラウザで確認します。
   ${summary.pageUrl}
4. 更新通知用URLを確認します。
   ${summary.siteUrl}/update-manifest.json
5. 各PCで更新サーバーURLを設定します。
   npm run update:set-url -- --url=${summary.siteUrl}/update-manifest.json

注意:

${summary.readyToPublish
  ? "- update-manifest.json があるため、アップデート通知用として公開できます。"
  : "- update-manifest.json が未確定です。Windows exe作成後に manifest を確定してから公開してください。"}
- 実務データ、CSV、バックアップ、Chromeログイン情報は含めていません。
`;
}

function buildUploadChecklist(summary) {
  const manifestCheck = summary.readyToPublish
    ? `□ ${summary.siteUrl}/update-manifest.json を開ける
□ MacまたはWindowsで更新通知が出る`
    : `□ Windows exe作成後に update-manifest.json を確定する
□ 確定後にこの公開用フォルダを作り直す`;
  return `アップロード前チェックリスト

□ downloads フォルダがある
□ Mac ZIPが downloads にある
□ Windows exeが必要な場合は downloads にある
□ ${summary.readyToPublish ? "update-manifest.json がある" : "update-manifest.json はまだ未確定"}
□ checksums.txt がある
□ index.html がある
□ サーバーにアップロードした
□ ${summary.pageUrl} を開ける
${manifestCheck}
`;
}

function buildIndexHtml(summary, checksumRows) {
  const windowsInstaller = summary.downloads.find((file) => /windows-\d{4}\.\d{2}\.\d{2}\.\d+\.exe$/i.test(file));
  const windowsPortable = summary.downloads.find((file) => /windows-portable-\d{4}\.\d{2}\.\d{2}\.\d+\.zip$/i.test(file));
  const macZip = summary.downloads.find((file) => /mac-\d{4}\.\d{2}\.\d{2}\.\d+\.zip$/i.test(file));
  const technicalDownloads = summary.downloads.filter((file) => file !== windowsInstaller && file !== windowsPortable && file !== macZip);
  const checksumItems = checksumRows.map((row) => (
    `<tr><td>${escapeHtml(row.file)}</td><td><code>${row.sha256}</code></td></tr>`
  )).join("\n");
  const manifestUrl = `${summary.siteUrl}/update-manifest.json`;
  const windowsHref = windowsInstaller ? `${summary.siteUrl}/${encodeURI(windowsInstaller)}` : "";
  const windowsPortableHref = windowsPortable ? `${summary.siteUrl}/${encodeURI(windowsPortable)}` : "";
  const macHref = macZip ? `${summary.siteUrl}/${encodeURI(macZip)}` : "";
  const technicalItems = technicalDownloads.length
    ? technicalDownloads.map((file) => `<li><a href="${summary.siteUrl}/${encodeURI(file)}">${escapeHtml(file)}</a></li>`).join("\n")
    : "<li>管理用ファイルはありません。</li>";

  return `<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>物件候補リスト作成システム 配布ページ</title>
  <style>
    :root { color-scheme: light; --ink: #14211b; --muted: #5f6f67; --line: #d9e3dd; --green: #197245; --blue: #155ea8; --amber: #9b6200; --panel: #ffffff; --wash: #f4f7f5; }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; color: var(--ink); background: var(--wash); }
    main { width: min(1120px, calc(100% - 48px)); margin: 0 auto; padding: 40px 0 56px; }
    header { display: grid; grid-template-columns: 1fr auto; gap: 24px; align-items: start; margin-bottom: 20px; }
    section { background: var(--panel); border: 1px solid var(--line); border-radius: 8px; padding: 28px; margin-top: 18px; }
    h1 { font-size: 34px; line-height: 1.18; margin: 0 0 10px; letter-spacing: 0; }
    h2 { font-size: 21px; margin: 0 0 16px; letter-spacing: 0; }
    h3 { font-size: 17px; margin: 0 0 8px; letter-spacing: 0; }
    p, li { line-height: 1.8; }
    p { margin: 0; }
    .lead { color: var(--muted); font-size: 17px; }
    .status { display: inline-flex; align-items: center; gap: 8px; padding: 8px 12px; border-radius: 999px; font-weight: 700; background: ${summary.readyToPublish ? "#e5f7eb" : "#fff4dc"}; color: ${summary.readyToPublish ? "#146b38" : "#8a5a00"}; white-space: nowrap; }
    .download-grid { display: grid; grid-template-columns: minmax(0, 1.1fr) minmax(320px, .9fr); gap: 18px; align-items: stretch; }
    .download-panel { border: 1px solid var(--line); border-radius: 8px; padding: 24px; background: #fbfdfc; }
    .primary-panel { border-color: #b7d8c5; background: #f1faf5; }
    .button-row { display: flex; gap: 12px; flex-wrap: wrap; margin-top: 18px; }
    .button { display: inline-flex; align-items: center; justify-content: center; min-height: 48px; padding: 12px 18px; border-radius: 8px; border: 1px solid currentColor; text-decoration: none; font-weight: 800; line-height: 1.3; }
    .button.primary { background: var(--green); border-color: var(--green); color: #fff; }
    .button.secondary { color: var(--blue); background: #eef6ff; border-color: #b8d2ef; }
    .steps { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; margin: 18px 0 0; padding: 0; list-style: none; }
    .steps li { border: 1px solid var(--line); border-radius: 8px; padding: 16px; background: #fff; min-height: 128px; }
    .step-no { display: inline-flex; width: 28px; height: 28px; align-items: center; justify-content: center; border-radius: 50%; background: var(--green); color: #fff; font-weight: 800; margin-bottom: 10px; }
    .note-box { border: 1px solid #f0cf91; background: #fff8ea; color: #5f3c00; border-radius: 8px; padding: 16px; margin-top: 16px; }
    .small { color: var(--muted); font-size: 14px; }
    details { border: 1px solid var(--line); border-radius: 8px; padding: 16px; background: #fff; }
    details + details { margin-top: 12px; }
    summary { cursor: pointer; font-weight: 800; }
    code { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; word-break: break-all; }
    table { width: 100%; border-collapse: collapse; }
    td { border-top: 1px solid #e3ebe6; padding: 10px 8px; vertical-align: top; }
    a { color: var(--blue); font-weight: 700; }
    @media (max-width: 860px) {
      main { width: min(100% - 28px, 1120px); padding-top: 24px; }
      header, .download-grid, .steps { grid-template-columns: 1fr; }
      h1 { font-size: 28px; }
    }
  </style>
</head>
<body>
  <main>
    <header>
      <div>
        <h1>物件候補リスト作成システム</h1>
        <p class="lead">リアプロの検索結果から、いい生活へ登録・確認する候補リストを作るための導入ページです。</p>
      </div>
      <p class="status">${summary.readyToPublish ? "配布中" : "準備中"} / ${escapeHtml(summary.version)}</p>
    </header>

    <section>
      <h2>Windowsで使い始める</h2>
      <div class="download-grid">
        <div class="download-panel primary-panel">
          <h3>1. インストーラーをダウンロード</h3>
          <p>新しくWindowsへ入れる場合は、まずこのファイルをダウンロードして実行します。Node.jsとPythonは同梱済みなので、別にインストールする必要はありません。</p>
          <div class="button-row">
            ${windowsHref
              ? `<a class="button primary" href="${windowsHref}">Windows版をダウンロード</a>`
              : `<span class="button primary" aria-disabled="true">Windows版は準備中</span>`}
            ${windowsPortableHref
              ? `<a class="button secondary" href="${windowsPortableHref}">開かない場合はZIP版</a>`
              : ""}
          </div>
          <p class="small">Windows版: ${escapeHtml(windowsInstaller || "未配置")}</p>
          ${windowsPortable ? `<p class="small">ZIP版: ${escapeHtml(windowsPortable)} を展開して START_WINDOWS.bat を開きます。</p>` : ""}
        </div>
        <div class="download-panel">
          <h3>Macで更新する場合</h3>
          <p>Macは通常、システム起動時のアップデート通知から更新します。手動で確認する場合だけZIPを使います。</p>
          <div class="button-row">
            ${macHref
              ? `<a class="button secondary" href="${macHref}">Mac更新ZIPをダウンロード</a>`
              : `<span class="button secondary" aria-disabled="true">Mac ZIPは準備中</span>`}
          </div>
          <p class="small">Mac版: ${escapeHtml(macZip || "未配置")}</p>
        </div>
      </div>
    </section>

    <section>
      <h2>インストール後の流れ</h2>
      <ol class="steps">
        <li><span class="step-no">1</span><h3>実行</h3><p>ダウンロードしたexeを開き、案内に沿ってインストールします。必要なのはGoogle Chromeだけです。</p></li>
        <li><span class="step-no">2</span><h3>起動</h3><p>デスクトップの「物件候補リスト作成システム」を開きます。</p></li>
        <li><span class="step-no">3</span><h3>ログイン</h3><p>Chromeでリアプロといい生活にログインします。</p></li>
        <li><span class="step-no">4</span><h3>取得</h3><p>システム画面の案内に沿って、検索結果を取得します。</p></li>
      </ol>
      <div class="note-box">Windowsで警告が出た場合は、発行元未確認のためです。Windows実機テスト後に、実際の表示に合わせてこの案内を更新します。</div>
      <div class="note-box">インストーラーが開かない場合は、Windows欄の「開かない場合はZIP版」を使います。ZIPを右クリックしてプロパティを開き、「許可する」または「ブロックの解除」があればチェックしてから展開してください。</div>
    </section>

    <section>
      <h2>困った時に見るところ</h2>
      <details open>
        <summary>古い制作中ファイルがWindowsに残っている場合</summary>
        <p>先に「物件候補リスト作成システム」をアンインストールし、必要に応じて <code>AppData\\Local\\PropertyListAutomation</code> を削除してから入れ直します。CSVが必要な場合は先に退避してください。</p>
      </details>
      <details>
        <summary>更新通知用URL</summary>
        <p><code>${escapeHtml(manifestUrl)}</code></p>
      </details>
      <details>
        <summary>管理用ファイル</summary>
        <ul>${technicalItems}</ul>
      </details>
      <details>
        <summary>チェックサム</summary>
        <table>${checksumItems}</table>
      </details>
    </section>
  </main>
</body>
</html>
`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#39;",
  }[char]));
}

async function sha256File(filePath) {
  const hash = createHash("sha256");
  await new Promise((resolve, reject) => {
    const stream = createReadStream(filePath);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.on("error", reject);
    stream.on("end", resolve);
  });
  return hash.digest("hex");
}

async function readJson(filePath) {
  return JSON.parse(await fs.readFile(filePath, "utf8"));
}

function readArgumentValue(name) {
  const prefix = `${name}=`;
  const found = process.argv.find((arg) => arg.startsWith(prefix));
  return found ? found.slice(prefix.length).trim() : "";
}

function normalizeSiteUrl(value) {
  return String(value || "").trim().replace(/\/+$/, "");
}

function inferHumanPageUrl(value) {
  const normalized = normalizeSiteUrl(value);
  const rawMatch = normalized.match(/^https:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)(?:\/.*)?$/);
  if (rawMatch) {
    const [, owner, repo] = rawMatch;
    return `https://${owner}.github.io/${repo}/`;
  }
  return `${normalized}/index.html`;
}

async function pathExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
