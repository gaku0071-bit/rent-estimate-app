import fs from "node:fs/promises";
import path from "node:path";
import { spawnSync } from "node:child_process";

const ROOT = path.resolve(import.meta.dirname, "..");
const REQUIRED_FILES = [
  "src/index.html",
  "src/app.js",
  "src/styles.css",
  "automation/server.mjs",
  "automation/chrome_bridge.mjs",
  "automation/test_chrome_bridge.mjs",
  "automation/env_check.mjs",
  "automation/node_runner.command",
  "automation/verify_sample.mjs",
  "automation/verify_windows.ps1",
  "data/verification_sample.json",
  "data/verification_rules.json",
  "README.md",
  "docs/setup.md",
  "docs/spec.md",
  "docs/automation.md",
  "docs/verification.md",
  "物件候補リスト作成.command",
  "物件候補リスト作成.bat",
  "環境確認.command",
  "環境確認.bat",
  "本番前確認.command",
  "本番前確認.bat",
  "総合確認.command",
  "総合確認.bat",
  "CSV生成確認.command",
  "CSV生成確認.bat",
  "Windows接続確認.bat",
  "CODEX_WINDOWS引き継ぎ.md",
];

const checks = [];

await checkNodeVersion();
await checkRequiredFiles();
await checkCsvSchema();
await checkChrome();
await checkPython();
await checkChromeBridge();
await checkLocalServer();

const failed = checks.filter((check) => check.status === "NG");
const warned = checks.filter((check) => check.status === "注意");

checks.forEach((check) => {
  console.log(`${check.status}: ${check.label}${check.detail ? ` / ${check.detail}` : ""}`);
});

console.log("");
console.log(`環境確認: ${failed.length ? "NG" : warned.length ? "注意あり" : "OK"} / OK ${checks.filter((check) => check.status === "OK").length}件 / 注意 ${warned.length}件 / NG ${failed.length}件`);

if (failed.length) {
  process.exitCode = 1;
}

async function checkNodeVersion() {
  const major = Number(process.versions.node.split(".")[0]);
  addCheck(Number.isFinite(major) && major >= 18 ? "OK" : "NG", "Node.js", `v${process.versions.node}`);
}

async function checkRequiredFiles() {
  const missing = [];
  for (const file of REQUIRED_FILES) {
    try {
      await fs.access(path.join(ROOT, file));
    } catch {
      missing.push(file);
    }
  }
  addCheck(missing.length ? "NG" : "OK", "必要ファイル", missing.length ? `不足: ${missing.join(", ")}` : `${REQUIRED_FILES.length}件`);
}

async function checkCsvSchema() {
  const appJs = await fs.readFile(path.join(ROOT, "src", "app.js"), "utf8");
  const version = appJs.match(/CSV_SCHEMA_VERSION\s*=\s*"([^"]+)"/)?.[1] || "";
  addCheck(version ? "OK" : "NG", "CSV形式", version || "読み取り不可");
}

async function checkChrome() {
  if (process.platform === "darwin") {
    const exists = await pathExists("/Applications/Google Chrome.app");
    addCheck(exists ? "OK" : "注意", "Google Chrome", exists ? "インストール済み" : "見つかりません");
    return;
  }

  if (process.platform === "win32") {
    const candidates = [
      process.env.PROGRAMFILES ? path.join(process.env.PROGRAMFILES, "Google", "Chrome", "Application", "chrome.exe") : "",
      process.env["PROGRAMFILES(X86)"] ? path.join(process.env["PROGRAMFILES(X86)"], "Google", "Chrome", "Application", "chrome.exe") : "",
      process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, "Google", "Chrome", "Application", "chrome.exe") : "",
    ].filter(Boolean);
    const found = await somePathExists(candidates);
    addCheck(found ? "OK" : "注意", "Google Chrome", found ? "インストール済み" : "見つかりません");
    return;
  }

  addCheck("注意", "Google Chrome", "このOSでは自動確認していません");
}

async function checkPython() {
  const envPython = process.env.PYTHON ? [{ command: process.env.PYTHON, args: ["--version"] }] : [];
  const candidates = process.platform === "win32"
    ? [
        ...envPython,
        { command: "py", args: ["-3", "--version"] },
        { command: "python", args: ["--version"] },
        { command: "python3", args: ["--version"] },
      ]
    : [
        ...envPython,
        { command: "python3", args: ["--version"] },
        { command: "python", args: ["--version"] },
      ];
  for (const candidate of candidates) {
    const result = spawnSync(candidate.command, candidate.args, { encoding: "utf8", windowsHide: true });
    if (result.status === 0) {
      const version = (result.stdout || result.stderr || "").trim();
      addCheck("OK", "Python3", version);
      return;
    }
  }
  addCheck("注意", "Python3", "Chrome取得ランナーで必要です");
}

async function checkChromeBridge() {
  if (process.platform !== "win32") return;
  try {
    const response = await fetch("http://127.0.0.1:9223/status", { signal: AbortSignal.timeout(1500) });
    const status = response.ok ? await response.json() : {};
    addCheck(status.ok ? "OK" : "注意", "Chrome接続", status.ok ? `タブ${status.tabCount || 0}件` : "未接続");
  } catch {
    addCheck("注意", "Chrome接続", "未起動。物件候補リスト作成.batから起動してください");
  }
}

async function checkLocalServer() {
  const foundServer = await findRunningServer();
  if (foundServer?.ok) {
    addCheck("OK", "ローカルサーバー", `起動中 ${foundServer.url} / CSV形式 ${foundServer.status.csvSchemaVersion || "不明"}`);
    return;
  }
  if (foundServer?.occupied) {
    addCheck("注意", "ローカルサーバー", `${foundServer.port}番は応答していますが、このシステムではない可能性があります / HTTP ${foundServer.statusCode}`);
    return;
  }
  addCheck("注意", "ローカルサーバー", "未起動。物件候補リスト作成を開くと起動します");
}

async function findRunningServer() {
  let occupied = null;
  for (let port = 8765; port <= 8775; port += 1) {
    const result = await checkServerPort(port);
    if (result.ok) return result;
    if (result.occupied && !occupied) occupied = result;
  }
  return occupied;
}

async function checkServerPort(port) {
  const url = `http://127.0.0.1:${port}`;
  try {
    const response = await fetch(`${url}/api/status`, { signal: AbortSignal.timeout(700) });
    if (!response.ok) {
      return { occupied: true, port, statusCode: response.status };
    }
    const status = await response.json();
    return { ok: true, port, url: `${url}/index.html`, status };
  } catch {
    return { empty: true, port };
  }
}

function addCheck(status, label, detail = "") {
  checks.push({ status, label, detail });
}

async function pathExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function somePathExists(filePaths) {
  for (const filePath of filePaths) {
    if (await pathExists(filePath)) return true;
  }
  return false;
}
