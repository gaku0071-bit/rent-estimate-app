@echo off
setlocal

cd /d "%~dp0"

echo このPCで物件候補リスト作成システムを使う準備ができているか確認します。
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode env
echo.
pause
