@echo off
setlocal
chcp 65001 >nul 2>nul
title 物件候補リスト作成システム 起動診断

set "PROJECT_ROOT=%~dp0"
set "LOG_FILE=%PROJECT_ROOT%startup-debug.log"

echo ==== Property List Automation startup debug ==== > "%LOG_FILE%"
echo Date: %DATE% %TIME% >> "%LOG_FILE%"
echo Project root: %PROJECT_ROOT% >> "%LOG_FILE%"
echo User: %USERNAME% >> "%LOG_FILE%"
echo Computer: %COMPUTERNAME% >> "%LOG_FILE%"
echo. >> "%LOG_FILE%"

echo [Files] >> "%LOG_FILE%"
dir "%PROJECT_ROOT%START_WINDOWS.bat" >> "%LOG_FILE%" 2>&1
dir "%PROJECT_ROOT%automation\run_windows.ps1" >> "%LOG_FILE%" 2>&1
dir "%PROJECT_ROOT%runtime\node\node.exe" >> "%LOG_FILE%" 2>&1
dir "%PROJECT_ROOT%runtime\node\npm.cmd" >> "%LOG_FILE%" 2>&1
dir "%PROJECT_ROOT%runtime\python\python.exe" >> "%LOG_FILE%" 2>&1
dir "%PROJECT_ROOT%node_modules\playwright\package.json" >> "%LOG_FILE%" 2>&1
echo. >> "%LOG_FILE%"

echo [PowerShell] >> "%LOG_FILE%"
where powershell >> "%LOG_FILE%" 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$PSVersionTable.PSVersion; 'PowerShell OK'" >> "%LOG_FILE%" 2>&1
echo. >> "%LOG_FILE%"

echo [Unblock files] >> "%LOG_FILE%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%PROJECT_ROOT%' -Recurse -Force | Unblock-File -ErrorAction SilentlyContinue; 'Unblock done'" >> "%LOG_FILE%" 2>&1
echo. >> "%LOG_FILE%"

echo [Runtime versions] >> "%LOG_FILE%"
"%PROJECT_ROOT%runtime\node\node.exe" --version >> "%LOG_FILE%" 2>&1
"%PROJECT_ROOT%runtime\node\npm.cmd" --version >> "%LOG_FILE%" 2>&1
"%PROJECT_ROOT%runtime\python\python.exe" --version >> "%LOG_FILE%" 2>&1
echo. >> "%LOG_FILE%"

echo [Run app] >> "%LOG_FILE%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%PROJECT_ROOT%automation\run_windows.ps1" >> "%LOG_FILE%" 2>&1
set "EXIT_CODE=%ERRORLEVEL%"
echo. >> "%LOG_FILE%"
echo Exit code: %EXIT_CODE% >> "%LOG_FILE%"

echo.
echo 起動診断が終わりました。
echo ログ:
echo %LOG_FILE%
echo.
type "%LOG_FILE%"
echo.
pause
exit /b %EXIT_CODE%
