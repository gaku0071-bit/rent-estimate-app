@echo off
setlocal

cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js が見つかりません。
  echo Node.js LTS をインストールしてから再実行してください。
  echo https://nodejs.org/
  pause
  exit /b 1
)

echo サーバー掲載用リリース配布物を作成します。
node automation\build_release_package.mjs
if errorlevel 1 goto failed

echo.
echo 完了しました。
echo dist\releases フォルダを確認してください。
pause
exit /b 0

:failed
echo.
echo リリース配布物の作成に失敗しました。上のメッセージを確認してください。
pause
exit /b 1
