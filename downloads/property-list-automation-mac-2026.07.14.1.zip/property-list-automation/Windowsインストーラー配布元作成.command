#!/bin/zsh
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

NODE_BIN="$("$PROJECT_ROOT/automation/node_runner.command")" || {
  read -r "?Enterで閉じます..." || true
  exit 1
}

echo "Windowsインストーラー用の配布元を作成します。"
echo ""
"$NODE_BIN" automation/build_windows_installer_source.mjs
echo ""
echo "作成先を開きます。"
open "$PROJECT_ROOT/dist/windows-installer-source" >/dev/null 2>&1 || true
echo ""
read -r "?完了しました。Enterで閉じます..." || true
