@echo off
setlocal

cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js が見つかりません。
  echo Node.js LTS をインストールしてから再実行してください。
  echo https://nodejs.org/
  pause
  exit /b 1
)

echo サーバー公開用フォルダを作成します。
node automation\build_update_server_public.mjs
if errorlevel 1 goto failed

echo.
echo 完了しました。
echo dist\update-server-public フォルダを確認してください。
pause
exit /b 0

:failed
echo.
echo サーバー公開用フォルダの作成に失敗しました。上のメッセージを確認してください。
pause
exit /b 1
