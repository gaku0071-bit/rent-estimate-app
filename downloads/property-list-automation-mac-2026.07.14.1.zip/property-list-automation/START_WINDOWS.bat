@echo off
setlocal
chcp 65001 >nul 2>nul
title 物件候補リスト作成システム 起動

set "PROJECT_ROOT=%~dp0"
set "POWERSHELL_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%POWERSHELL_EXE%" (
  echo Windows PowerShellが見つかりません。
  echo Windowsの標準機能が使えない状態です。
  pause
  exit /b 1
)

"%POWERSHELL_EXE%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PROJECT_ROOT%automation\run_windows.ps1"
set "EXIT_CODE=%ERRORLEVEL%"

if not "%EXIT_CODE%"=="0" (
  echo.
  echo 物件候補リスト作成システムを起動できませんでした。
  echo.
  echo よくある原因:
  echo - インストール先の同梱Node.js / Pythonが壊れている
  echo - Google Chrome が入っていない
  echo - Chromeが起動中で接続できない
  echo - セキュリティソフトが起動ファイルを止めている
  echo.
  echo ログ:
  echo %PROJECT_ROOT%data\chrome-bridge-windows-error.log
  echo.
  echo 表示されているエラー内容を確認してください。
  pause
  exit /b %EXIT_CODE%
)
