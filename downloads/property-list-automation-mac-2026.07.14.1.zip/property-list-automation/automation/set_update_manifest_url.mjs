import fs from "node:fs/promises";
import path from "node:path";
import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const settingsPath = path.join(projectRoot, "updates", "update-settings.json");

const urlArg = readArgumentValue("--url");
const clear = process.argv.includes("--clear");

async function main() {
  let manifestUrl = clear ? "" : String(urlArg || "").trim();

  if (!clear && !manifestUrl) {
    const rl = readline.createInterface({ input, output });
    try {
      manifestUrl = String(await rl.question("更新サーバーの update-manifest.json URLを入力してください。空Enterでローカル確認に戻します: ")).trim();
    } finally {
      rl.close();
    }
  }

  if (manifestUrl && !/^https?:\/\//.test(manifestUrl)) {
    throw new Error("URLは http:// または https:// から始めてください。");
  }

  const settings = {
    schemaVersion: 1,
    manifestUrl,
    updatedAt: new Date().toISOString(),
    notes: manifestUrl
      ? "このPCは起動時に指定URLの update-manifest.json を確認します。"
      : "manifestUrl が空のため、ローカルの updates/update-manifest.json を確認します。",
  };

  await fs.mkdir(path.dirname(settingsPath), { recursive: true });
  await fs.writeFile(settingsPath, `${JSON.stringify(settings, null, 2)}\n`, "utf8");

  console.log(manifestUrl ? "更新サーバーURLを設定しました。" : "更新サーバーURLを空にしました。ローカル確認に戻ります。");
  console.log(JSON.stringify({
    settings: path.relative(projectRoot, settingsPath),
    manifestUrl,
  }, null, 2));
}

function readArgumentValue(name) {
  const prefix = `${name}=`;
  const found = process.argv.find((arg) => arg.startsWith(prefix));
  return found ? found.slice(prefix.length).trim() : "";
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
