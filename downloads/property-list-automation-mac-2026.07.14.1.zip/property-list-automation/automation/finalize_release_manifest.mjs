import fs from "node:fs/promises";
import path from "node:path";
import { createReadStream } from "node:fs";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const distRoot = path.join(projectRoot, "dist");
const versionPath = path.join(projectRoot, "app-version.json");

const versionArg = readArgumentValue("--version");
const baseUrl = readArgumentValue("--base-url") || "https://example.com/downloads";
const releaseDirArg = readArgumentValue("--release-dir");
const windowsExeArg = readArgumentValue("--windows-exe");
const allowMissingWindows = process.argv.includes("--allow-missing-windows");

async function main() {
  const appVersion = await readJson(versionPath);
  const versionName = String(versionArg || appVersion.version || "").trim();
  if (!versionName) throw new Error("バージョンを特定できません。app-version.json または --version を確認してください。");

  const releaseRoot = releaseDirArg
    ? path.resolve(releaseDirArg)
    : path.join(distRoot, "releases", versionName);
  const downloadsDir = path.join(releaseRoot, "downloads");

  const macZipName = `property-list-automation-mac-${versionName}.zip`;
  const macZipPath = path.join(downloadsDir, macZipName);
  const windowsExeName = `property-list-automation-windows-${versionName}.exe`;
  const windowsExePath = await ensureWindowsExe(downloadsDir, windowsExeName);

  if (!await pathExists(macZipPath)) {
    throw new Error(`Mac更新ZIPが見つかりません: ${macZipPath}`);
  }

  const macSha256 = await sha256File(macZipPath);
  const windowsReady = Boolean(windowsExePath);
  const windowsSha256 = windowsReady ? await sha256File(windowsExePath) : "WINDOWS_EXE_SHA256_AFTER_BUILD";

  const manifest = {
    schemaVersion: 1,
    publishedAt: new Date().toISOString(),
    windows: {
      version: versionName,
      url: joinUrl(baseUrl, windowsExeName),
      sha256: windowsSha256,
      packageType: "exe",
      fileName: windowsExeName,
      required: false,
      notes: windowsReady
        ? ["Windows版インストーラー更新"]
        : ["Windowsでインストーラーexeを作成後、このURLとSHA-256を確定してください。"],
    },
    mac: {
      version: versionName,
      url: joinUrl(baseUrl, macZipName),
      sha256: macSha256,
      packageType: "zip",
      fileName: macZipName,
      required: false,
      notes: ["Mac版更新ZIP"],
    },
  };

  const outputName = windowsReady ? "update-manifest.json" : "update-manifest.template.json";
  const outputPath = path.join(releaseRoot, outputName);
  await fs.writeFile(outputPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
  await writeFinalizeGuide(releaseRoot, {
    versionName,
    baseUrl,
    macZipName,
    macSha256,
    windowsExeName,
    windowsReady,
    windowsSha256,
    outputName,
  });

  console.log(windowsReady ? "リリースmanifestを確定しました。" : "リリースmanifestテンプレートを更新しました。");
  console.log(JSON.stringify({
    version: versionName,
    output: outputPath,
    baseUrl,
    mac: {
      file: path.relative(releaseRoot, macZipPath),
      sha256: macSha256,
    },
    windows: windowsReady
      ? {
          file: path.relative(releaseRoot, windowsExePath),
          sha256: windowsSha256,
        }
      : {
          file: "",
          sha256: "",
          missing: true,
          nextStep: "WindowsでBUILD_WINDOWS_INSTALLER.batを実行し、exeをdownloadsへ置いてから再実行してください。",
        },
  }, null, 2));
}

async function ensureWindowsExe(downloadsDir, windowsExeName) {
  const targetPath = path.join(downloadsDir, windowsExeName);
  if (await pathExists(targetPath)) return targetPath;

  const candidates = [
    windowsExeArg ? path.resolve(windowsExeArg) : "",
    path.join(distRoot, windowsExeName),
  ].filter(Boolean);

  for (const candidate of candidates) {
    if (!await pathExists(candidate)) continue;
    await fs.mkdir(downloadsDir, { recursive: true });
    await fs.copyFile(candidate, targetPath);
    return targetPath;
  }

  if (allowMissingWindows) return "";

  throw new Error([
    `Windowsインストーラーexeが見つかりません: ${windowsExeName}`,
    "Windowsで BUILD_WINDOWS_INSTALLER.bat を実行してexeを作成してください。",
    `作成後、${path.relative(projectRoot, targetPath)} へ置くか、--windows-exe=ファイルパス を指定して再実行してください。`,
  ].join("\n"));
}

async function writeFinalizeGuide(releaseRoot, summary) {
  const manifestLine = summary.windowsReady
    ? `- 確定manifest: ${summary.outputName}`
    : `- 未確定manifest: ${summary.outputName}`;
  const windowsLine = summary.windowsReady
    ? `- Windows exe: downloads/${summary.windowsExeName}
  SHA-256: ${summary.windowsSha256}`
    : `- Windows exe: 未作成
  Windowsで BUILD_WINDOWS_INSTALLER.bat を実行し、downloads/${summary.windowsExeName} を配置してから再実行してください。`;

  const guide = `リリースmanifest確定結果

バージョン: ${summary.versionName}
作成日: ${new Date().toISOString()}
ベースURL: ${summary.baseUrl}

${manifestLine}

- Mac ZIP: downloads/${summary.macZipName}
  SHA-256: ${summary.macSha256}

${windowsLine}

次にやること:

1. downloads 内のファイルをサーバーへアップロードします。
2. ${summary.outputName} を確認します。
3. Windows exeが未作成の場合は、Windowsでexeを作ってからこのコマンドを再実行します。
4. Windows exeまで揃ったら、update-manifest.json をサーバーへ配置します。
5. 各PCを起動して「新しいアップデートがあります」の通知を確認します。
`;
  await fs.writeFile(path.join(releaseRoot, "FINALIZE_MANIFEST_RESULT.txt"), guide, "utf8");
}

async function sha256File(filePath) {
  const hash = createHash("sha256");
  await new Promise((resolve, reject) => {
    const stream = createReadStream(filePath);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.on("error", reject);
    stream.on("end", resolve);
  });
  return hash.digest("hex");
}

async function readJson(filePath) {
  return JSON.parse(await fs.readFile(filePath, "utf8"));
}

function readArgumentValue(name) {
  const prefix = `${name}=`;
  const found = process.argv.find((arg) => arg.startsWith(prefix));
  return found ? found.slice(prefix.length).trim() : "";
}

function joinUrl(root, fileName) {
  return `${String(root || "").replace(/\/+$/, "")}/${encodeURIComponent(fileName)}`;
}

async function pathExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
