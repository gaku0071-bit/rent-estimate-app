#!/bin/zsh
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"

NODE_BIN="$("$PROJECT_ROOT/automation/node_runner.command")" || {
  read -r "?Enterで閉じます..." || true
  exit 1
}

echo "物件候補リスト作成システムを起動します。"
echo "Chromeで画面を開きます。8765番が使用中の場合は別ポートを自動で試します。"
echo ""

for PORT in $(seq 8765 8775); do
  if curl -fs "http://127.0.0.1:${PORT}/api/status" >/dev/null 2>&1; then
    echo "既に起動しています。ブラウザで画面を開きます。"
    open "http://127.0.0.1:${PORT}/index.html" >/dev/null 2>&1 || true
    exit 0
  fi
done

OPEN_BROWSER=1 "$NODE_BIN" automation/server.mjs
