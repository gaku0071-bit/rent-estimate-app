import json
import argparse
import base64
import atexit
import os
import platform
import re
import subprocess
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "data"
OUTPUT_FILE = OUTPUT_DIR / "chrome_capture.json"
ESEIKATSU_CACHE_FILE = OUTPUT_DIR / "eseikatsu_full_cache.json"
CHROME_TRANSPORT = os.environ.get("CHROME_TRANSPORT", "").strip().lower()
IS_MAC = platform.system() == "Darwin" and CHROME_TRANSPORT != "bridge"
CHROME_BRIDGE_URL = os.environ.get("CHROME_BRIDGE_URL", "http://127.0.0.1:9223").rstrip("/")
APPLE_TAB_DELIMITER = "<<<CODEX_TAB_DELIMITER_20260701>>>"
CHROME_EXECUTION_TAB_INDEX: Optional[int] = None
APPLE_EVENT_SCRIPT_CHUNK_THRESHOLD = 12000
APPLE_EVENT_SCRIPT_CHUNK_SIZE = 9000


def run_osascript(script: str) -> str:
    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            check=True,
            capture_output=True,
            text=True,
            timeout=120,
        )
    except subprocess.TimeoutExpired as error:
        raise subprocess.CalledProcessError(124, ["osascript", "-e", script], output=error.stdout, stderr="AppleScript timed out") from error
    except subprocess.CalledProcessError as error:
        detail = (error.stderr or error.output or "").strip()
        if detail:
            raise subprocess.CalledProcessError(error.returncode, error.cmd, output=error.output, stderr=detail) from error
        raise
    return result.stdout.strip()


def bridge_request(path: str, payload: Optional[dict] = None) -> dict:
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
    request = urllib.request.Request(
        f"{CHROME_BRIDGE_URL}{path}",
        data=data,
        headers=headers,
        method="POST" if payload is not None else "GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError) as error:
        raise subprocess.CalledProcessError(
            1,
            ["chrome-bridge", path],
            stderr=f"Windows Chrome接続に失敗しました: {error}",
        ) from error


def bridge_tabs() -> dict:
    return bridge_request("/tabs")


def chrome_tab_property_values(property_name: str) -> list[str]:
    delimiter = APPLE_TAB_DELIMITER
    script = f"""
    set oldDelimiters to AppleScript's text item delimiters
    set AppleScript's text item delimiters to {json.dumps(delimiter)}
    tell application "Google Chrome"
      set tabValues to {{}}
      repeat with chromeTab in tabs of front window
        try
          set end of tabValues to ({property_name} of chromeTab as text)
        on error
          set end of tabValues to ""
        end try
      end repeat
    end tell
    set joinedValues to tabValues as text
    set AppleScript's text item delimiters to oldDelimiters
    return joinedValues
    """
    output = run_osascript(script)
    if output == "":
        return [""]
    return output.split(delimiter)


def chrome_titles() -> list[str]:
    if not IS_MAC:
        return [str(tab.get("title") or "") for tab in bridge_tabs().get("tabs", [])]
    return chrome_tab_property_values("title")


def chrome_urls() -> list[str]:
    if not IS_MAC:
        return [str(tab.get("url") or "") for tab in bridge_tabs().get("tabs", [])]
    return chrome_tab_property_values("URL")


def chrome_active_tab_index() -> Optional[int]:
    if not IS_MAC:
        try:
            value = bridge_tabs().get("activeIndex")
            return int(value) if value else None
        except (subprocess.CalledProcessError, TypeError, ValueError):
            return None
    try:
        output = run_osascript('tell application "Google Chrome" to get active tab index of front window')
        return int(output.strip())
    except (subprocess.CalledProcessError, ValueError):
        return None


def set_active_tab(index: int) -> None:
    global CHROME_EXECUTION_TAB_INDEX
    CHROME_EXECUTION_TAB_INDEX = int(index)
    if not IS_MAC:
        bridge_request("/activate", {"index": index})
        return
    run_osascript(f'tell application "Google Chrome" to set active tab index of front window to {index}')


def restore_active_tab(index: Optional[int]) -> None:
    if not index:
        return
    try:
        if IS_MAC:
            run_osascript(f'tell application "Google Chrome" to set active tab index of front window to {int(index)}')
        else:
            bridge_request("/activate", {"index": int(index)})
    except (subprocess.CalledProcessError, TypeError, ValueError):
        pass


def ensure_execution_tab_active() -> None:
    if not IS_MAC or not CHROME_EXECUTION_TAB_INDEX:
        return
    try:
        active_index = chrome_active_tab_index()
        if active_index != CHROME_EXECUTION_TAB_INDEX:
            run_osascript(
                f'tell application "Google Chrome" to set active tab index of front window to {int(CHROME_EXECUTION_TAB_INDEX)}'
            )
            time.sleep(0.15)
    except (subprocess.CalledProcessError, TypeError, ValueError):
        pass


def move_realpro_to_page(page_number: int) -> None:
    page_index = max(int(page_number or 1) - 1, 0)
    run_chrome_javascript(
        f"""
        (() => {{
          const url = new URL(location.href);
          url.pathname = '/main.php';
          url.searchParams.set('method', 'estate');
          url.searchParams.set('display', 'building');
          if ({page_index} > 0) {{
            url.searchParams.set('page', String({page_index}));
          }} else {{
            url.searchParams.delete('page');
          }}
          location.href = url.href;
        }})()
        """
    )
    time.sleep(1.8)


def run_chrome_javascript(script: str) -> str:
    if not IS_MAC:
        return str(bridge_request("/eval", {"script": script}).get("result") or "")
    ensure_execution_tab_active()
    encoded_script = base64.b64encode(script.encode("utf-8")).decode("ascii")
    wrapped_script = (
        "eval(decodeURIComponent(Array.prototype.map.call("
        f'atob("{encoded_script}"), '
        "function(c) { return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2); }"
        ").join('')))"
    )
    # Chrome's Apple Events bridge rejects large JavaScript arguments. Send the
    # base64 payload in small pieces, then evaluate it once in the target tab.
    if len(wrapped_script) > APPLE_EVENT_SCRIPT_CHUNK_THRESHOLD:
        chunks = [
            encoded_script[index:index + APPLE_EVENT_SCRIPT_CHUNK_SIZE]
            for index in range(0, len(encoded_script), APPLE_EVENT_SCRIPT_CHUNK_SIZE)
        ]
        run_osascript(
            'tell application "Google Chrome" to execute active tab of front window javascript '
            + json.dumps("window.__codexAppleEventChunks = []; true")
        )
        for chunk in chunks:
            run_osascript(
                'tell application "Google Chrome" to execute active tab of front window javascript '
                + json.dumps(f"window.__codexAppleEventChunks.push({json.dumps(chunk)}); true")
            )
        chunked_script = (
            "(() => {"
            "try {"
            "return eval(decodeURIComponent(Array.prototype.map.call("
            "atob(window.__codexAppleEventChunks.join('')), "
            "function(c) { return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2); }"
            ").join('')));"
            "} finally { window.__codexAppleEventChunks = null; }"
            "})()"
        )
        return run_osascript(
            'tell application "Google Chrome" to execute active tab of front window javascript '
            + json.dumps(chunked_script)
        )
    return run_osascript(f'tell application "Google Chrome" to execute active tab of front window javascript {json.dumps(wrapped_script)}')


def read_current_tab_info() -> dict:
    try:
        return json.loads(run_chrome_javascript(
            """
            JSON.stringify({
              title: document.title || '',
              url: location.href || ''
            })
            """
        ))
    except (subprocess.CalledProcessError, json.JSONDecodeError):
        return {"title": "", "url": ""}


def is_realpro_list_url(url: str) -> bool:
    value = str(url or "")
    return "realnetpro.com" in value and "room_detail.php" not in value and "method=estate" in value


def realpro_candidate_indexes(preferred_index: int) -> list[int]:
    titles = chrome_titles()
    urls = chrome_urls()
    active_index = chrome_active_tab_index()
    candidates = []
    for candidate in [
        preferred_index,
        suggest_realpro_index(urls, titles, active_index),
        active_index,
    ]:
        if candidate:
            candidates.append(int(candidate))
    candidates.extend(
        index
        for index, url in enumerate(urls, start=1)
        if is_realpro_list_url(url)
    )
    valid_max = max(len(urls), len(titles))
    unique = []
    for candidate in candidates:
        if 1 <= candidate <= valid_max and candidate not in unique:
            unique.append(candidate)
    return unique


def activate_realpro_result_tab(preferred_index: int, start_page: int = 1) -> tuple[int, str, str]:
    checked = []
    for candidate in realpro_candidate_indexes(preferred_index):
        set_active_tab(candidate)
        time.sleep(0.35)
        info = read_current_tab_info()
        current_url = str(info.get("url") or "")
        checked.append(f"{candidate}: {current_url}")
        if "realnetpro.com" not in current_url or "room_detail.php" in current_url:
            continue
        if "method=estate" not in current_url or "main.php" not in current_url or start_page > 1:
            move_realpro_to_page(start_page)
        wait_for_page_text_ready()
        status = realpro_page_status()
        if status.get("loginDetected"):
            raise SystemExit("リアプロがログイン画面です。Chromeでリアプロにログインし、リスト検索結果一覧を開いてから再取得してください。")
        if status.get("isResultPage"):
            return candidate, str(status.get("title") or info.get("title") or ""), str(status.get("url") or current_url)

    checked_text = " / ".join(checked) if checked else "候補タブなし"
    raise SystemExit(f"リアプロのリスト検索結果画面を確認できませんでした。リアプロのリスト検索結果一覧を開いてから再取得してください。確認したタブ: {checked_text}")


def capture_scrolled_text() -> str:
    snapshots = []
    try:
        reset_scroll_positions()
        snapshots.append(run_chrome_javascript("document.body.innerText"))
        metrics = json.loads(run_chrome_javascript(
            "JSON.stringify({height: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight), viewport: window.innerHeight})"
        ))
        height = int(metrics.get("height") or 0)
        viewport = max(int(metrics.get("viewport") or 800), 400)
        positions = list(range(0, height + viewport, max(viewport - 120, 300))) or [0]

        for position in positions:
            run_chrome_javascript(f"window.scrollTo(0, {position});")
            time.sleep(0.18)
            snapshots.append(run_chrome_javascript("document.body.innerText"))

        run_chrome_javascript("window.scrollTo(0, 0);")
        snapshots.extend(capture_scrollable_elements_text())
    except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError):
        snapshots.append(run_chrome_javascript("document.body.innerText"))

    return merge_text_snapshots(snapshots)


def capture_scrollable_elements_text() -> list[str]:
    snapshots = []
    elements = json.loads(run_chrome_javascript(
        """
        JSON.stringify(Array.from(document.querySelectorAll('body *'))
          .map((el, index) => ({ index, height: el.scrollHeight, viewport: el.clientHeight, textLength: (el.innerText || '').length }))
          .filter((item) => item.height > item.viewport + 200 && item.viewport > 120 && item.textLength > 200)
          .sort((a, b) => (b.height - b.viewport) - (a.height - a.viewport))
          .slice(0, 6))
        """
    ))

    for element in elements:
        step = max(int(element.get("viewport") or 500) - 80, 240)
        height = int(element.get("height") or 0)
        for position in range(0, height + step, step):
            run_chrome_javascript(
                f"""
                (function() {{
                  const el = Array.from(document.querySelectorAll('body *'))[{int(element["index"])}];
                  if (el) {{
                    el.scrollTop = {position};
                    el.dispatchEvent(new Event('scroll', {{ bubbles: true }}));
                  }}
                }})();
                """
            )
            time.sleep(0.35)
            snapshots.append(run_chrome_javascript("document.body.innerText"))
            snapshots.append(run_chrome_javascript(
                f"""
                (function() {{
                  const el = Array.from(document.querySelectorAll('body *'))[{int(element["index"])}];
                  return el ? el.innerText : '';
                }})();
                """
            ))
        run_chrome_javascript(
            f"""
            (function() {{
              const el = Array.from(document.querySelectorAll('body *'))[{int(element["index"])}];
              if (el) {{
                el.scrollTop = 0;
                el.dispatchEvent(new Event('scroll', {{ bubbles: true }}));
              }}
            }})();
            """
        )

    return snapshots


def reset_scroll_positions() -> None:
    run_chrome_javascript(
        """
        (function() {
          window.scrollTo(0, 0);
          Array.from(document.querySelectorAll('body *')).forEach((el) => {
            if (el.scrollHeight > el.clientHeight + 100) {
              el.scrollTop = 0;
              el.dispatchEvent(new Event('scroll', { bubbles: true }));
            }
          });
        })();
        """
    )
    time.sleep(0.35)


def merge_text_snapshots(snapshots: list[str]) -> str:
    seen = set()
    chunks = []
    for snapshot in snapshots:
        normalized = snapshot.strip()
        if normalized and normalized not in seen:
            seen.add(normalized)
            chunks.append(normalized)
    return "\n\n".join(chunks)


def capture_current_tab(
    index: int,
    title: str,
    url: str,
    prompt: str = "このタブを取得対象として表示できていれば Enter を押してください...",
    auto: bool = False,
    pages: int = 1,
    start_page: int = 1,
    capture_realpro_details: bool = True,
    source_hint: str = "",
) -> dict:
    if source_hint == "realpro" or ("realnetpro.com" in url and "room_detail.php" not in url):
        index, title, url = activate_realpro_result_tab(index, start_page)
    else:
        set_active_tab(index)
    print(f"\n[{index}] {title}")
    print(url)
    if auto:
        print("自動取得します。")
    else:
        input(prompt)

    # Chrome's JavaScript execution through Apple Events may be disabled.
    # We still capture title/url and leave rawText empty when unavailable.
    raw_text = ""
    js_error = ""
    page_captures = []
    api_rooms = []
    api_page_captures = []
    api_error = ""
    if "e-bukken.app" in url:
        try:
            api_result = capture_eseikatsu_api_rooms(pages)
            api_rooms = api_result.get("rooms", [])
            api_page_captures = api_result.get("pageCaptures", [])
            api_error = api_result.get("error", "")
            raw_text = "\n".join(filter(None, [
                f"いい生活API取得 {len(api_rooms)}件",
                api_page_captures and f"APIページ {len(api_page_captures)}ページ",
            ]))
            page_captures = [{
                "pageNumber": 1,
                "url": run_chrome_javascript("location.href"),
                "lineCount": max(1, len([line for line in raw_text.splitlines() if line.strip()])),
                "textLength": max(len(raw_text), 1),
                "stopReason": "api-capture-used",
            }]
        except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError) as error:
            api_error = str(error)
    elif "realnetpro.com" in url and "room_detail.php" not in url:
        try:
            api_rooms, page_captures, raw_text = capture_realpro_dom_rooms(
                pages,
                capture_details=capture_realpro_details,
            )
            if start_page > 1:
                for offset, page_capture in enumerate(page_captures):
                    page_capture["pageNumber"] = start_page + offset
        except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError) as error:
            api_error = str(error)
            if "ログイン画面" in api_error or "リスト検索結果画面ではありません" in api_error:
                raise SystemExit(api_error)

    structured_source = ("realnetpro.com" in url and "room_detail.php" not in url) or "e-bukken.app" in url
    if structured_source and not raw_text:
        raw_text = api_error or "構造化取得に失敗しました。"
        page_captures = [{
            "pageNumber": 1,
            "url": run_chrome_javascript("location.href"),
            "lineCount": 1,
            "textLength": len(raw_text),
            "stopReason": "structured-capture-failed",
        }]

    if not structured_source:
        try:
            raw_text, page_captures = capture_paginated_text(pages)
        except subprocess.CalledProcessError as error:
            js_error = error.stderr.strip() or error.stdout.strip()
        finally:
            try:
                restore_current_url(url)
            except subprocess.CalledProcessError:
                pass

    return {
        "index": index,
        "title": title,
        "url": url,
        "rawText": raw_text,
        "rooms": api_rooms,
        "pageCaptures": page_captures,
        "apiPageCaptures": api_page_captures,
        "apiError": api_error,
        "jsError": js_error,
        "startPage": start_page,
    }


def capture_paginated_text(pages: int) -> tuple[str, list[dict]]:
    snapshots = []
    page_captures = []
    for page_number in range(max(pages, 1)):
        wait_for_page_text_ready()
        page_text = capture_scrolled_text()
        snapshots.append(page_text)
        page_captures.append({
            "pageNumber": page_number + 1,
            "url": run_chrome_javascript("location.href"),
            "lineCount": len([line for line in page_text.splitlines() if line.strip()]),
            "textLength": len(page_text),
        })
        if page_number >= pages - 1:
            page_captures[-1]["stopReason"] = "requested-pages-reached"
            break
        try:
            next_info = click_next_page_info()
            clicked = bool(next_info.get("clicked"))
        except subprocess.CalledProcessError:
            next_info = {"clicked": False, "reason": "click-error"}
            clicked = False
        page_captures[-1]["next"] = next_info
        if not clicked:
            page_captures[-1]["stopReason"] = next_info.get("reason") or "next-not-clicked"
            break
        time.sleep(1.2)
    return merge_text_snapshots(snapshots), page_captures


def capture_realpro_parallel_pages(pages: int) -> tuple[list[dict], list[dict], str]:
    status_key = "__codexRealproParallelCapture"
    script = r"""
    window.__STATUS_KEY__ = { status: 'running', completedPages: 0 };
    void (async () => {
      const requestedPages = __PAGES__;
      const baseUrl = new URL(location.href);
      const firstPage = Number(baseUrl.searchParams.get('page') || '0') || 0;
      const pagerPages = Array.from(document.querySelectorAll('td.pager'))
        .map((el) => (el.getAttribute('onclick') || '').match(/pager\('([^']+)','([^']+)'\)/))
        .filter(Boolean)
        .map((match) => Number(match[2]))
        .filter(Number.isFinite);
      const maxPage = Math.max(firstPage, ...pagerPages);
      const lastPage = Math.min(firstPage + requestedPages - 1, maxPage);
      const pageIndexes = Array.from(
        { length: Math.max(0, lastPage - firstPage + 1) },
        (_, index) => firstPage + index
      );
      const pageResults = [];

      const normalize = (value) => String(value || '').normalize('NFKC').replace(/\s+/g, ' ').trim();
      const cleanRoom = (value) => String(value || '').normalize('NFKC').match(/^[A-Za-z0-9-]+/)?.[0] || normalize(value);
      const yen = (value) => Number(String(value || '').normalize('NFKC').replace(/[^0-9]/g, '')) || 0;
      const parseAccess = (value) => {
        const match = String(value || '').match(/^沿線：(.+?)「(.+?)」(徒歩|バス|自動車|車|自転車)([0-9０-９]+)分/);
        if (!match) return { line: '', station: '', accessMethod: '徒歩', walkMinutes: 0 };
        return {
          line: normalize(match[1]),
          station: normalize(match[2]),
          accessMethod: match[3] === '自動車' ? '車' : match[3],
          walkMinutes: Number(String(match[4]).normalize('NFKC')),
        };
      };
      const textOf = (element) => String(element?.textContent || '');
      const splitCell = (td) => textOf(td).split(/\n+/).map((line) => line.trim()).filter(Boolean);
      const equipmentMarkers = ['家電', '家具', '駐車場有り', '駐車場あり', '駐車場空有', '駐車場空きあり', '駐車可', 'ペット', 'ネット無料', 'エアコン', 'オートロック', '宅配BOX'];

      const parseDocument = (doc, pageUrl) => {
        const rooms = [];
        let building = { building: '', address: '', line: '', station: '', accessMethod: '徒歩', walkMinutes: 0 };
        for (const tr of Array.from(doc.querySelectorAll('tr'))) {
          const text = textOf(tr).trim();
          const lines = text.split(/\n+/).map((line) => line.trim()).filter(Boolean);
          const addressIndex = lines.findIndex((line) => line.startsWith('住所：'));
          const accessIndex = lines.findIndex((line) => line.startsWith('沿線：'));
          if (!tr.classList.contains('room_info_tr') && addressIndex > 0 && accessIndex > addressIndex) {
            building = {
              building: normalize(lines[addressIndex - 1]),
              address: normalize(lines[addressIndex].replace(/^住所：/, '')),
              ...parseAccess(lines[accessIndex]),
            };
            continue;
          }
          if (!tr.classList.contains('room_info_tr') || !building.building) continue;
          const cells = Array.from(tr.querySelectorAll('td'));
          const roomAnchor = tr.querySelector('a.room_number');
          const onclick = roomAnchor?.getAttribute('onclick') || '';
          const id = onclick.match(/go_detail\(event,'([^']+)'/)?.[1] || '';
          const roomLabel = normalize(textOf(roomAnchor) || textOf(cells[0]) || '');
          const status = Array.from(tr.querySelectorAll('.st')).map((el) => normalize(textOf(el))).filter(Boolean).join(' ');
          const dateLines = splitCell(cells[5]);
          const layoutLines = splitCell(cells[6]);
          const rentLines = splitCell(cells[7]);
          const equipmentText = normalize(textOf(cells[1]) || '');
          rooms.push({
            ...building,
            room: cleanRoom(roomLabel),
            roomLabel,
            realproRoomId: id,
            layout: normalize(layoutLines[0]),
            area: normalize(layoutLines[1]).replace('m2', '㎡'),
            rent: yen(rentLines[0]),
            fee: yen(rentLines[1]),
            status,
            availableDate: normalize(dateLines[0]),
            adFee: '',
            equipment: equipmentMarkers.filter((marker) => equipmentText.includes(marker)),
            webAd: '判定不可',
            imageReuse: '判定不可',
            floorPlanReuse: '判定不可',
            priorContact: '判定不可',
            applicationCount: 0,
            detailCaptureStatus: id ? '未取得' : '詳細IDなし',
            detailCaptureReason: id ? '詳細取得前' : '一覧から詳細IDを取得できませんでした',
            detailHttpStatus: '',
            detailTextLength: 0,
            url: id ? `${location.origin}/room_detail.php?id=${encodeURIComponent(id)}&type=room` : '',
          });
        }
        const text = doc.body?.innerText || '';
        return {
          pageUrl,
          rooms,
          textLength: text.length,
          summary: (text.match(/[0-9,]+\s*棟\s*[0-9,]+\s*戸/) || [''])[0],
          loginDetected: /ログインID|パスワード/.test(text) && !/検索結果|部屋番号|空室|退去予定/.test(text),
        };
      };

      for (let offset = 0; offset < pageIndexes.length; offset += 5) {
        const batch = pageIndexes.slice(offset, offset + 5);
        const results = await Promise.all(batch.map(async (pageIndex) => {
          const pageUrl = new URL(baseUrl.href);
          pageUrl.searchParams.set('method', 'estate');
          pageUrl.searchParams.set('display', 'building');
          pageUrl.searchParams.set('page', String(pageIndex));
          const response = await fetch(pageUrl.href, { credentials: 'include' });
          if (!response.ok) throw new Error(`HTTP ${response.status}: page ${pageIndex + 1}`);
          const html = await response.text();
          const doc = new DOMParser().parseFromString(html, 'text/html');
          return { pageIndex, ...parseDocument(doc, pageUrl.href) };
        }));
        pageResults.push(...results);
        window.__STATUS_KEY__ = {
          status: 'running',
          completedPages: pageResults.length,
          totalPages: pageIndexes.length,
          roomCount: pageResults.reduce((sum, page) => sum + page.rooms.length, 0),
        };
      }
      window.__STATUS_KEY__ = {
        status: 'done',
        firstPage,
        maxPage,
        pageResults: pageResults.sort((a, b) => a.pageIndex - b.pageIndex),
      };
    })().catch((error) => {
      window.__STATUS_KEY__ = { status: 'error', error: String(error), stack: error?.stack || '' };
    });
    """.replace("__STATUS_KEY__", status_key).replace("__PAGES__", str(max(pages, 1)))
    run_chrome_javascript(script)

    deadline = time.time() + max(90, pages * 4)
    payload = {}
    last_completed_pages = 0
    while time.time() < deadline:
        payload = json.loads(run_chrome_javascript(
            f"JSON.stringify(window.{status_key} || {{ status: 'missing' }})"
        ))
        completed_pages = int(payload.get("completedPages") or 0)
        if payload.get("status") == "running" and completed_pages > 0 and completed_pages != last_completed_pages:
            print(
                f"リアプロ一覧取得: {completed_pages}/{int(payload.get('totalPages') or pages)}ページ / "
                f"{int(payload.get('roomCount') or 0)}戸",
                flush=True,
            )
            last_completed_pages = completed_pages
        if payload.get("status") == "done":
            break
        if payload.get("status") == "error":
            raise ValueError(payload.get("error") or "リアプロ並列取得に失敗しました。")
        time.sleep(0.5)
    if payload.get("status") != "done":
        raise ValueError("リアプロ並列取得がタイムアウトしました。")

    rooms = []
    page_captures = []
    raw_text_parts = []
    seen_ids = set()
    seen_keys = set()
    for result in payload.get("pageResults") or []:
        if result.get("loginDetected"):
            raise ValueError("リアプロがログイン画面です。")
        page_rooms = result.get("rooms") or []
        for room in page_rooms:
            room_id = str(room.get("realproRoomId") or "")
            key = "::".join(str(room.get(part) or "") for part in ["building", "room", "layout", "rent"])
            if room_id and room_id in seen_ids:
                continue
            if not room_id and key in seen_keys:
                continue
            rooms.append(room)
            if room_id:
                seen_ids.add(room_id)
            seen_keys.add(key)
        summary = result.get("summary") or ""
        raw_text_parts.append("\n".join(filter(None, [summary, f"DOM取得戸数 {len(page_rooms)}件"])))
        page_captures.append({
            "pageNumber": int(result.get("pageIndex") or 0) + 1,
            "url": result.get("pageUrl") or "",
            "lineCount": 2,
            "textLength": max(int(result.get("textLength") or 0), 1),
            "expandedRoomButtons": 0,
            "roomCount": len(page_rooms),
            "roomRowCount": len(page_rooms),
            "roomAnchorCount": sum(1 for room in page_rooms if room.get("realproRoomId")),
            "loginDetected": False,
            "captureMode": "parallel-fetch",
        })
    if page_captures:
        final_page = page_captures[-1]["pageNumber"] - 1
        max_page = int(payload.get("maxPage") or 0)
        page_captures[-1]["stopReason"] = (
            "last-page-reached" if final_page >= max_page else "requested-pages-reached"
        )
    if not rooms:
        raise ValueError("リアプロ並列取得で号室を取得できませんでした。")
    return rooms, page_captures, merge_text_snapshots(raw_text_parts)


def capture_realpro_dom_rooms(pages: int, capture_details: bool = True) -> tuple[list[dict], list[dict], str]:
    initial_url = run_chrome_javascript("location.href")
    try:
        print(f"リアプロ一覧並列取得: 最大{max(pages, 1)}ページ", flush=True)
        rooms, page_captures, raw_text = capture_realpro_parallel_pages(pages)
        raw_text_parts = [raw_text]
    except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError) as parallel_error:
        print(f"リアプロ並列取得を従来方式へ切替: {parallel_error}", flush=True)
        rooms = []
        page_captures = []
        raw_text_parts = []
        try:
            for page_number in range(max(pages, 1)):
                print(f"リアプロ一覧取得: {page_number + 1}/{max(pages, 1)}ページ", flush=True)
                wait_for_page_text_ready()
                page_status = realpro_page_status()
                if page_status.get("loginDetected"):
                    raise ValueError("リアプロがログイン画面です。Chromeでリアプロにログインし、リスト検索結果一覧を開いてから再取得してください。")
                if not page_status.get("isResultPage"):
                    raise ValueError(f"リアプロのリスト検索結果画面ではありません: {page_status.get('url') or ''}")
                expanded_count = expand_realpro_all_rooms()
                page_rooms = json.loads(run_chrome_javascript(REALPRO_DOM_ROOMS_JS))
                summary = json.loads(run_chrome_javascript(
                    """
                    JSON.stringify((() => {
                      const text = document.body && document.body.textContent || '';
                      return {
                        summary: (text.match(/[0-9,]+\\s*棟\\s*[0-9,]+\\s*戸/) || [''])[0],
                        textLength: text.length,
                        url: location.href,
                      };
                    })())
                    """
                ))
                raw_text = "\n".join(filter(None, [
                    summary.get("summary", ""),
                    f"DOM取得戸数 {len(page_rooms)}件",
                ]))
                raw_text_parts.append(raw_text)
                page_capture = {
                    "pageNumber": page_number + 1,
                    "url": summary.get("url") or run_chrome_javascript("location.href"),
                    "lineCount": max(1, len([line for line in raw_text.splitlines() if line.strip()])),
                    "textLength": max(len(raw_text), int(summary.get("textLength") or 0), 1),
                    "expandedRoomButtons": expanded_count,
                    "roomCount": len(page_rooms),
                    "roomRowCount": page_status.get("roomRowCount", 0),
                    "roomAnchorCount": page_status.get("roomAnchorCount", 0),
                    "loginDetected": False,
                    "captureMode": "sequential-fallback",
                }
                existing_ids = {str(room.get("realproRoomId") or "") for room in rooms if room.get("realproRoomId")}
                existing_keys = {
                    "::".join(str(room.get(part) or "") for part in ["building", "room", "layout", "rent"])
                    for room in rooms
                }
                for room in page_rooms:
                    room_id = str(room.get("realproRoomId") or "")
                    key = "::".join(str(room.get(part) or "") for part in ["building", "room", "layout", "rent"])
                    if room_id and room_id in existing_ids:
                        continue
                    if not room_id and key in existing_keys:
                        continue
                    rooms.append(room)
                    if room_id:
                        existing_ids.add(room_id)
                    existing_keys.add(key)
                if page_number >= pages - 1:
                    page_capture["stopReason"] = "requested-pages-reached"
                    page_captures.append(page_capture)
                    break
                try:
                    next_info = click_next_page_info()
                    clicked = bool(next_info.get("clicked"))
                except subprocess.CalledProcessError:
                    next_info = {"clicked": False, "reason": "click-error"}
                    clicked = False
                page_capture["next"] = next_info
                if not clicked:
                    page_capture["stopReason"] = next_info.get("reason") or "next-not-clicked"
                    page_captures.append(page_capture)
                    break
                page_captures.append(page_capture)
                time.sleep(1.2)
        finally:
            restore_current_url(initial_url)
            time.sleep(1.0)
            wait_for_page_text_ready()

    if not capture_details:
        return rooms, page_captures, merge_text_snapshots(raw_text_parts)

    detail_summaries = []
    detail_targets = [room for room in rooms if room.get("realproRoomId")]
    for index in range(0, len(detail_targets), 10):
        chunk = detail_targets[index:index + 10]
        print(f"リアプロ詳細確認: {min(index + 10, len(detail_targets))}/{len(detail_targets)}件", flush=True)
        try:
            detail_summaries.extend(capture_realpro_detail_summaries(chunk))
        except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError) as error:
            reason = str(error)
            detail_summaries.extend({
                "realproRoomId": str(room.get("realproRoomId") or ""),
                "webAd": "判定不可",
                "equipment": [],
                "applicationCount": 0,
                "title": "",
                "url": room.get("url", ""),
                "detailCaptureStatus": "詳細確認失敗",
                "detailCaptureReason": reason,
                "status": "",
                "detailTextLength": 0,
            } for room in chunk if room.get("realproRoomId"))
        detail_rooms_by_id = {str(room.get("realproRoomId") or ""): room for room in detail_targets}
        confirmed_candidates = sum(
            1 for detail in detail_summaries
            if detail.get("webAd") in {"可", "管理会社に確認"}
            and int(detail.get("applicationCount") or 0) == 0
            and not re.search(
                r"商談中|審査中|申込あり",
                str(detail_rooms_by_id.get(str(detail.get("realproRoomId") or ""), {}).get("status") or ""),
            )
        )
        print(
            f"候補判定: {min(index + 10, len(detail_targets))}/{len(detail_targets)}件 / 候補{confirmed_candidates}件",
            flush=True,
        )
        time.sleep(0.4)
    details_by_id = {str(detail.get("realproRoomId")): detail for detail in detail_summaries}
    for room in rooms:
        detail = details_by_id.get(str(room.get("realproRoomId") or ""))
        if detail:
            room.update({
                "webAd": detail.get("webAd", room.get("webAd", "判定不可")),
                "equipment": sorted(set((room.get("equipment") or []) + (detail.get("equipment") or []))),
                "applicationCount": int(detail.get("applicationCount") or 0),
                "detailTitle": detail.get("title", ""),
                "url": detail.get("url", room.get("url", "")),
                "detailCaptureStatus": detail.get("detailCaptureStatus") or ("詳細確認不完全" if detail.get("webAd") == "判定不可" else "取得OK"),
                "detailCaptureReason": detail.get("detailCaptureReason", ""),
                "detailHttpStatus": detail.get("status", ""),
                "detailTextLength": detail.get("detailTextLength", 0),
            })

    return rooms, page_captures, merge_text_snapshots(raw_text_parts)


def realpro_page_status() -> dict:
    try:
        return json.loads(run_chrome_javascript(
            """
            JSON.stringify((() => {
              const text = document.body && document.body.innerText || '';
              const normalized = text.normalize('NFKC');
              const url = location.href;
              const loginDetected = /ログインID|パスワード|ログイン/.test(normalized)
                && !/検索結果|部屋番号|空室|退去予定/.test(normalized);
              return {
                url,
                title: document.title || '',
                textLength: text.length,
                isResultPage: location.hostname.includes('realnetpro.com')
                  && location.pathname.includes('main.php')
                  && location.search.includes('method=estate'),
                loginDetected,
                roomRowCount: document.querySelectorAll('tr.room_info_tr').length,
                roomAnchorCount: document.querySelectorAll('a.room_number').length,
                expandButtonCount: document.querySelectorAll('.all_room_open, .hide_room_open').length,
                summary: (normalized.match(/[0-9,]+\\s*棟\\s*[0-9,]+\\s*戸/) || [''])[0],
              };
            })())
            """
        ))
    except (subprocess.CalledProcessError, json.JSONDecodeError):
        return {"isResultPage": False, "loginDetected": False, "url": ""}


def expand_realpro_all_rooms() -> int:
    total_clicked = 0
    for _ in range(3):
        try:
            clicked = int(run_chrome_javascript(
                """
                (() => {
                  const isVisible = (el) => {
                    const style = window.getComputedStyle(el);
                    const rect = el.getBoundingClientRect();
                    return style.display !== 'none' && style.visibility !== 'hidden' && rect.width >= 0 && rect.height >= 0;
                  };
                  const targets = Array.from(document.querySelectorAll('.all_room_open, .hide_room_open'))
                    .filter((el) => {
                      const text = String(el.textContent || el.value || '').replace(/\\s+/g, '');
                      return isVisible(el) && (text.includes('全部屋を表示') || text.includes('表示する'));
                    });
                  targets.forEach((el) => el.click());
                  return targets.length;
                })()
                """
            ) or "0")
        except (subprocess.CalledProcessError, ValueError):
            clicked = 0
        total_clicked += clicked
        if not clicked:
            break
        time.sleep(0.8)
        wait_for_page_text_ready()
    return total_clicked


def capture_realpro_detail_summaries(rooms: list[dict]) -> list[dict]:
    ids = []
    seen = set()
    for room in rooms:
        room_id = str(room.get("realproRoomId") or "")
        if room_id and room_id not in seen:
            ids.append(room_id)
            seen.add(room_id)

    if not ids:
        return []

    status_key = "__codexRealproDetailCapture"
    run_chrome_javascript(
        f"""
        window.{status_key} = {{ status: 'running' }};
        void (async () => {{
          const ids = {json.dumps(ids, ensure_ascii=False)};
          const details = [];
          const captureOne = async (id) => {{
            try {{
              const url = `${{location.origin}}/room_detail.php?id=${{encodeURIComponent(id)}}&type=room`;
              const {{ response, text: html }} = await fetchTextWithTimeout(url, {{ credentials: 'include' }}, 30000);
              const doc = new DOMParser().parseFromString(html, 'text/html');
              const text = (doc.body && doc.body.innerText || '').normalize('NFKC');
              const adSection = (text.match(/広告掲載[\\s\\S]{{0,260}}/) || [''])[0];
              const webAd = extractWebAd(adSection || text);
              const applicationCount = await fetchApplicationCount(doc);
              return {{
                realproRoomId: id,
                title: (doc.querySelector('title') && doc.querySelector('title').innerText || '').trim(),
                url,
                status: response.status,
                webAd,
                equipment: extractEquipment(text),
                applicationCount,
                detailCaptureStatus: response.ok && webAd !== '判定不可' ? '取得OK' : '詳細確認不完全',
                detailCaptureReason: detailCaptureReason({{ response, text, adSection, webAd }}),
                detailTextLength: text.length,
              }};
            }} catch (error) {{
              return {{
                realproRoomId: id,
                title: '',
                url: `${{location.origin}}/room_detail.php?id=${{encodeURIComponent(id)}}&type=room`,
                status: 0,
                webAd: '判定不可',
                equipment: [],
                applicationCount: 0,
                detailCaptureStatus: '取得エラー',
                detailCaptureReason: String(error),
                detailTextLength: 0,
                error: String(error),
              }};
            }}
          }};
          for (let index = 0; index < ids.length; index += 2) {{
            const chunk = ids.slice(index, index + 2);
            details.push(...await Promise.all(chunk.map(captureOne)));
            window.{status_key} = {{ status: 'running', details }};
          }}
          window.{status_key} = {{ status: 'done', details }};

          async function fetchWithTimeout(url, options = {{}}, timeoutMs = 10000) {{
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), timeoutMs);
            try {{
              return await fetch(url, {{ ...options, signal: controller.signal }});
            }} finally {{
              clearTimeout(timer);
            }}
          }}

          async function fetchTextWithTimeout(url, options = {{}}, timeoutMs = 10000) {{
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), timeoutMs);
            try {{
              const response = await fetch(url, {{ ...options, signal: controller.signal }});
              const text = await response.text();
              return {{ response, text }};
            }} finally {{
              clearTimeout(timer);
            }}
          }}

          function extractWebAd(text) {{
            const webSection = (String(text || '').match(/webサービスにこの物件の広告を掲載[\\s\\S]{{0,80}}/) || [String(text || '')])[0];
            if (/許可されていません|不可/.test(webSection)) return '許可されていません';
            if (/管理会社に確認|要確認|管理会社へご確認|掲載希望の場合は管理会社/.test(webSection)) return '管理会社に確認';
            if (/[［\\[]?\\s*可\\s*[］\\]]?|許可されています/.test(webSection)) return '可';
            return '判定不可';
          }}

          function detailCaptureReason({{ response, text, adSection, webAd }}) {{
            if (!response.ok) return `HTTP ${{response.status}}`;
            if (!text) return '詳細本文が空です';
            if (!adSection) return '広告掲載欄を検出できませんでした';
            if (webAd === '判定不可') return 'WEB広告掲載可否の文言を検出できませんでした';
            return '';
          }}

          function extractApplicationCount(text) {{
            const match = String(text || '').match(/(?:申込|申し込み)\\s*([0-9]+)\\s*件/);
            return Number(match && match[1] || 0);
          }}

          function extractEquipment(text) {{
            const value = String(text || '').normalize('NFKC');
            const rules = [
              ['バス・トイレ別', /バス・トイレ別|BT別|セパレート/],
              ['独立洗面台', /独立洗面|洗面化粧台|シャンプードレッサー/],
              ['エアコン', /エアコン/],
              ['暖房', /暖房/],
              ['オートロック', /オートロック/],
              ['宅配ボックス', /宅配ボックス|宅配BOX/],
              ['インターネット無料', /インターネット無料|ネット無料/],
              ['Wi-Fi無料', /Wi-?Fi無料|Wifi無料|ワイファイ無料/i],
              ['駐輪場あり', /駐輪場(?:有り|あり|可)/],
              ['ペット相談', /ペット相談|ペット可|ペット飼育/],
              ['灯油暖房', /灯油暖房|灯油FF/],
              ['都市ガス', /都市ガス/],
              ['プロパンガス', /プロパンガス|LPガス/],
              ['エレベーター', /エレベーター/],
              ['防犯カメラ', /防犯カメラ/],
            ];
            const equipment = rules.filter(([, pattern]) => pattern.test(value)).map(([label]) => label);
            const parkingText = (value.match(/駐車場[\\s\\S]{{0,180}}/) || [''])[0];
            if (parkingText && !/空きなし|空なし|無し|なし|無|不可|要確認|満車/.test(parkingText) && /空きあり|空有|空車|有り|あり|可/.test(parkingText)) {{
              equipment.push('駐車場空きあり');
            }}
            return equipment;
          }}

          async function fetchApplicationCount(doc) {{
            try {{
              const value = (selector) => doc.querySelector(selector) && doc.querySelector(selector).value || '';
              const displayFlag = value('#njc_apply_display_flag') || 'N';
              if (displayFlag !== 'Y') return extractApplicationCount(doc.body && doc.body.innerText || '');
              const body = new URLSearchParams();
              body.set('bk_type', '1');
              body.set('rnp_bk_id', value('#building_id'));
              body.set('rnp_hy_id', value('#room_id'));
              body.set('residence_type', value('#residence_type') || 'room');
              body.set('company_id', value('#company_id'));
              body.set('user_id', value('#user_id'));
              body.set('func', 'request');
              body.set('option_break_flag', value('#mylist_njc_apply_option_break_flag') || '0');
              const {{ text: raw }} = await fetchTextWithTimeout('./ajax/starfruit_auth_tyukai.php', {{
                method: 'POST',
                credentials: 'include',
                headers: {{ 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }},
                body: body.toString(),
              }}, 10000);
              const result = JSON.parse(raw);
              return Number(result && result.count || 0);
            }} catch (error) {{
              return extractApplicationCount(doc.body && doc.body.innerText || '');
            }}
          }}
        }})().catch((error) => {{
          window.{status_key} = {{ status: 'error', error: String(error), stack: error && error.stack }};
        }});
        true;
        """
    )

    deadline = time.time() + max(90, len(ids) * 20)
    last_payload = {}
    while time.time() < deadline:
        payload = json.loads(run_chrome_javascript(f"JSON.stringify(window.{status_key} || {{ status: 'missing' }})"))
        last_payload = payload
        if payload.get("status") == "done":
            return payload.get("details", [])
        if payload.get("status") == "error":
            return payload.get("details", [])
        time.sleep(0.5)

    return last_payload.get("details", [])


def restore_current_url(url: str) -> None:
    run_chrome_javascript(
        f"""
        if (location.href !== {json.dumps(url, ensure_ascii=False)}) {{
          location.href = {json.dumps(url, ensure_ascii=False)};
        }}
        """
    )


REALPRO_DOM_ROOMS_JS = r"""
JSON.stringify((() => {
  const normalize = (value) => String(value || '').normalize('NFKC').replace(/\s+/g, ' ').trim();
  const cleanRoom = (value) => String(value || '').normalize('NFKC').match(/^[A-Za-z0-9-]+/)?.[0] || normalize(value);
  const yen = (value) => Number(String(value || '').normalize('NFKC').replace(/[^0-9]/g, '')) || 0;
  const parseAccess = (value) => {
    const match = String(value || '').match(/^沿線：(.+?)「(.+?)」(徒歩|バス|自動車|車|自転車)([0-9０-９]+)分/);
    if (!match) return { line: '', station: '', accessMethod: '徒歩', walkMinutes: 0 };
    return {
      line: normalize(match[1]),
      station: normalize(match[2]),
      accessMethod: match[3] === '自動車' ? '車' : match[3],
      walkMinutes: Number(String(match[4]).normalize('NFKC')),
    };
  };
  const textOf = (element) => String(element?.textContent || '');
  const splitCell = (td) => textOf(td).split(/\n+/).map((line) => line.trim()).filter(Boolean);
  const equipmentMarkers = ['家電', '家具', '駐車場有り', '駐車場あり', '駐車場空有', '駐車場空きあり', '駐車可', 'ペット', 'ネット無料', 'エアコン', 'オートロック', '宅配BOX'];
  const rooms = [];
  let building = { building: '', address: '', line: '', station: '', accessMethod: '徒歩', walkMinutes: 0 };

  for (const tr of Array.from(document.querySelectorAll('tr'))) {
    const text = textOf(tr).trim();
    const lines = text.split(/\n+/).map((line) => line.trim()).filter(Boolean);
    const addressIndex = lines.findIndex((line) => line.startsWith('住所：'));
    const accessIndex = lines.findIndex((line) => line.startsWith('沿線：'));
    if (!tr.classList.contains('room_info_tr') && addressIndex > 0 && accessIndex > addressIndex) {
      building = {
        building: normalize(lines[addressIndex - 1]),
        address: normalize(lines[addressIndex].replace(/^住所：/, '')),
        ...parseAccess(lines[accessIndex]),
      };
      continue;
    }

    if (!tr.classList.contains('room_info_tr') || !building.building) continue;

    const cells = Array.from(tr.querySelectorAll('td'));
    const roomAnchor = tr.querySelector('a.room_number');
    const onclick = roomAnchor?.getAttribute('onclick') || '';
    const id = onclick.match(/go_detail\(event,'([^']+)'/)?.[1] || '';
    const roomLabel = normalize(textOf(roomAnchor) || textOf(cells[0]) || '');
    const status = Array.from(tr.querySelectorAll('.st')).map((el) => normalize(textOf(el))).filter(Boolean).join(' ');
    const dateLines = splitCell(cells[5]);
    const layoutLines = splitCell(cells[6]);
    const rentLines = splitCell(cells[7]);
    const equipmentText = normalize(textOf(cells[1]) || '');

    rooms.push({
      ...building,
      room: cleanRoom(roomLabel),
      roomLabel,
      realproRoomId: id,
      layout: normalize(layoutLines[0]),
      area: normalize(layoutLines[1]).replace('m2', '㎡'),
      rent: yen(rentLines[0]),
      fee: yen(rentLines[1]),
      status,
      availableDate: normalize(dateLines[0]),
      adFee: '',
      equipment: equipmentMarkers.filter((marker) => equipmentText.includes(marker)),
      webAd: '判定不可',
      imageReuse: '判定不可',
      floorPlanReuse: '判定不可',
      priorContact: '判定不可',
      applicationCount: 0,
      detailCaptureStatus: id ? '未取得' : '詳細IDなし',
      detailCaptureReason: id ? '詳細取得前' : '一覧から詳細IDを取得できませんでした',
      detailHttpStatus: '',
      detailTextLength: 0,
      url: id ? `${location.origin}/room_detail.php?id=${encodeURIComponent(id)}&type=room` : '',
    });
  }
  return rooms;
})())
"""


def wait_for_page_text_ready(timeout_seconds: float = 12.0) -> None:
    started_at = time.time()
    last_length = 0
    stable_count = 0
    while time.time() - started_at < timeout_seconds:
        try:
            metrics = json.loads(run_chrome_javascript(
                """
                JSON.stringify({
                  url: location.href,
                  readyState: document.readyState,
                  textLength: (document.body && document.body.textContent || '').length
                })
                """
            ))
        except (subprocess.CalledProcessError, json.JSONDecodeError):
            time.sleep(0.5)
            continue

        text_length = int(metrics.get("textLength") or 0)
        url = str(metrics.get("url") or "")
        required_length = 900 if "e-bukken.app" in url else 1200
        if metrics.get("readyState") == "complete" and text_length >= required_length:
            return
        if text_length == last_length and text_length > 300:
            stable_count += 1
            if stable_count >= 4 and "e-bukken.app" not in url:
                return
        else:
            stable_count = 0
        last_length = text_length
        time.sleep(0.5)


def click_next_page_info() -> dict:
    result = run_chrome_javascript(
        """
        JSON.stringify((function() {
          const normalize = (value) => String(value || '').replace(/\\s+/g, '').trim();
          const isDisabled = (el) => {
            const className = String(el.className || '');
            return Boolean(el.disabled) || el.getAttribute('aria-disabled') === 'true' || /disabled|disable|Mui-disabled/.test(className);
          };
          const candidates = Array.from(document.querySelectorAll('a, button, [role="button"], input[type="button"], input[type="submit"], td, span, li'));
          const realproNext = Array.from(document.querySelectorAll('td.pager'))
            .find((el) => !isDisabled(el) && String(el.textContent || '').includes('次'));
          if (location.hostname.includes('realnetpro.com') && location.pathname.includes('main.php')) {
            const url = new URL(location.href);
            const currentPage = Number(url.searchParams.get('page') || '0') || 0;
            const pagerPages = Array.from(document.querySelectorAll('td.pager'))
              .map((el) => (el.getAttribute('onclick') || '').match(/pager\\('([^']+)','([^']+)'\\)/))
              .filter(Boolean)
              .map((match) => Number(match[2]))
              .filter(Number.isFinite);
            const maxPage = Math.max(-1, ...pagerPages);
            if (maxPage >= 0) {
              if (currentPage >= maxPage && !realproNext) {
                return { clicked: false, reason: 'last-page-reached', url: location.href, currentPage, maxPage };
              }
              const nextPage = currentPage + 1;
              url.searchParams.set('method', 'estate');
              url.searchParams.set('display', 'building');
              url.searchParams.set('page', String(nextPage));
              const nextUrl = url.href;
              location.href = nextUrl;
              return { clicked: true, reason: 'realpro-direct-page', url: location.href, nextUrl, currentPage, nextPage, maxPage };
            }
          }
          const next = realproNext || candidates.find((el) => {
            const text = normalize(el.textContent || el.value);
            const aria = (el.getAttribute('aria-label') || '').trim();
            const onclick = (el.getAttribute('onclick') || '').trim();
            const className = String(el.className || '');
            const isRealproPager = text === '次' && (onclick.includes('pager(') || className.includes('pager'));
            const isESeikatsuPager = aria === 'Go to next page';
            const isPlainPager = ['次', '次へ', 'Next', '›', '>'].includes(text) && text.length <= 4;
            return !isDisabled(el) && (isRealproPager || isESeikatsuPager || isPlainPager);
          });
          if (!next) return { clicked: false, reason: 'next-not-found', url: location.href };
          const before = location.href;
          const text = normalize(next.textContent || next.value);
          const onclick = next.getAttribute('onclick') || '';
          const className = String(next.className || '');
          if (onclick && onclick.includes('pager(')) {
            const match = onclick.match(/pager\\('([^']+)','([^']+)'\\)/);
            if (match) {
              const nextUrl = `${location.origin}${location.pathname}?${match[1]}&page=${match[2]}`;
              if (nextUrl === before) return { clicked: false, reason: 'next-url-same', url: before, nextUrl, text, onclick, className };
              location.href = nextUrl;
              return { clicked: true, reason: 'pager-url', url: before, nextUrl, text, onclick, className };
            }
            setTimeout(() => Function(onclick).call(next), 0);
            return { clicked: true, reason: 'pager-scheduled', url: before, text, onclick, className };
          }
          setTimeout(() => next.click(), 0);
          return { clicked: true, reason: 'click-scheduled', url: before, text, onclick, className };
        })())
        """
    )
    try:
        return json.loads(result)
    except json.JSONDecodeError:
        normalized = result.strip().lower()
        return {"clicked": normalized in {"true", "missing value", ""}, "reason": "legacy-result", "raw": result}


def click_next_page() -> bool:
    return bool(click_next_page_info().get("clicked"))


def capture_eseikatsu_api_rooms(pages: int, page_size: int = 100, concurrency: int = 5) -> dict:
    status_key = "__codexESeikatsuApiCapture"
    safe_page_size = max(20, min(int(page_size or 100), 200))
    safe_concurrency = max(1, min(int(concurrency or 5), 10))
    run_chrome_javascript(
        f"""
        window.{status_key} = {{ status: 'running' }};
        (async () => {{
          const apiUrl = buildESeikatsuApiUrl();
          const pageCount = {max(pages, 1)};
          const requestedItemsPerPage = {safe_page_size};
          const concurrency = {safe_concurrency};
          const baseUrl = new URL(apiUrl);
          baseUrl.searchParams.set('items_per_page', String(requestedItemsPerPage));
          const itemsPerPage = Number(baseUrl.searchParams.get('items_per_page') || String(requestedItemsPerPage));
          const baseStartIndex = 1;
          const rooms = [];
          const pageCaptures = [];
          let token = await getESeikatsuAccessToken();

          const fetchOnePage = async (pageIndex) => {{
            window.{status_key} = {{
              status: 'running',
              currentPage: pageIndex + 1,
              pageCount,
              fetchedCount: rooms.length,
              pageCaptures,
              requestedItemsPerPage,
              concurrency,
            }};
            const pageUrl = new URL(baseUrl.href);
            const startIndex = baseStartIndex + (pageIndex * itemsPerPage);
            pageUrl.searchParams.set('start_index', String(startIndex));
            let response = await fetchESeikatsuPage(pageUrl.href, token);
            if (response.status === 401) {{
              window.__codexESeikatsuAccessToken = '';
              token = await getESeikatsuAccessToken();
              response = await fetchESeikatsuPage(pageUrl.href, token);
            }}
            const data = await response.json();
            const items = Array.isArray(data.items) ? data.items : [];
            return {{
              pageIndex,
              rooms: items.map(normalizeESeikatsuApiRoom),
              pageCapture: {{
              pageNumber: pageIndex + 1,
              url: pageUrl.href,
              status: response.status,
              totalCount: data.total_counts ?? null,
              itemCount: items.length,
                requestedItemsPerPage,
                itemsPerPage,
              startIndex,
              }},
            }};
          }};

          for (let start = 0; start < pageCount; start += concurrency) {{
            const indexes = [];
            for (let pageIndex = start; pageIndex < Math.min(start + concurrency, pageCount); pageIndex += 1) {{
              indexes.push(pageIndex);
            }}
            const results = await Promise.all(indexes.map(fetchOnePage));
            results
              .sort((a, b) => a.pageIndex - b.pageIndex)
              .forEach((result) => {{
                pageCaptures.push(result.pageCapture);
                rooms.push(...result.rooms);
              }});
            window.{status_key} = {{
              status: 'running',
              currentPage: Math.min(start + concurrency, pageCount),
              pageCount,
              fetchedCount: rooms.length,
              pageCaptures,
              requestedItemsPerPage,
              concurrency,
            }};
          }}

          window.{status_key} = {{ status: 'done', rooms, pageCaptures, requestedItemsPerPage, concurrency }};
        }})().catch((error) => {{
          window.{status_key} = {{ status: 'error', error: String(error), stack: error && error.stack }};
        }});

        function buildESeikatsuApiUrl() {{
          const currentUrl = new URL(location.href);
          const parts = currentUrl.pathname.split('/').filter(Boolean);
          const organizationGuid = currentUrl.searchParams.get('organization_guid') || parts[0] || '';
          if (!organizationGuid) {{
            const stored = sessionStorage.getItem('IiseikatsuApiRequestKey');
            if (stored) return stored;
          }}
          const params = new URLSearchParams();
          params.set('organization_guid', organizationGuid);
          params.set('order_organization_guid', organizationGuid);
          params.set('order', currentUrl.searchParams.get('order') || 'saishu_koshin_time.desc,tatemono_name.asc,sort_heya_kukaku_number.asc');
          params.set('items_per_page', currentUrl.searchParams.get('items_per_page') || '20');
          const page = Number(currentUrl.searchParams.get('p') || '1');
          params.set('start_index', String(((page || 1) - 1) * Number(params.get('items_per_page')) + 1));
          for (const value of currentUrl.searchParams.getAll('bukken_status_code')) {{
            if (value && value !== '0') params.append('bukken_status_code', value);
          }}
          if (!params.has('bukken_status_code')) {{
            params.append('bukken_status_code', '2');
            params.append('bukken_status_code', '1');
          }}
          params.set('type', 'chinshaku');
          params.set('suppress_null', 'true');
          return `https://api.e-bukken-1.com/bukken/1.0/search/?${{params.toString()}}`;
        }}

        async function fetchESeikatsuPage(url, token) {{
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 20000);
          try {{
            return await fetch(url, {{
            headers: {{
              Authorization: `Bearer ${{token}}`,
              Accept: 'application/json',
              'X-Es-Consumer-Key': 'eb_chintai',
            }},
            credentials: 'omit',
            signal: controller.signal,
          }});
          }} finally {{
            clearTimeout(timer);
          }}
        }}

        function normalizeESeikatsuApiRoom(item) {{
          const bukken = item.chinshaku_bukken_view || {{}};
          const condition = item.chinshaku_boshu_joken_view || {{}};
          const advertisements = Array.isArray(bukken.chinshaku_kokoku) ? bukken.chinshaku_kokoku : [];
          const isListed = advertisements.some((ad) =>
            ad.baitai_keisai_flag === true ||
            (Array.isArray(ad.chinshaku_keisai) && ad.chinshaku_keisai.some((entry) => entry.keisai_flag === true))
          );
          const organizationGuid = new URL(location.href).pathname.split('/').filter(Boolean)[0] || item.domain_guid || '';
          const guid = bukken.chinshaku_bukken_guid || bukken.chinshaku_view_guid || item.spec_bukken_view_guid || '';

          return {{
            building: item.tatemono_name || item.tatemono_to_name || '',
            room: item.heya_kukaku_number || '',
            layout: item.madori_name || item.madori || '',
            status: bukken.bukken_status || (condition.boshu_chu_flag ? '募集中' : '不明'),
            listing: isListed ? '掲載中' : '未掲載',
            url: guid ? `${{location.origin}}/${{organizationGuid}}/bukken/${{guid}}` : '',
          }};
        }}

        async function getESeikatsuAccessToken() {{
          if (window.__codexESeikatsuAccessToken) return window.__codexESeikatsuAccessToken;

          const state = Math.random().toString(36).slice(2);
          const nonce = Math.random().toString(36).slice(2);
          const params = new URLSearchParams({{
            client_id: 'Pek8UZpyPfkN5v9gQc4YY6CyRHGCZvwl',
            redirect_uri: 'https://rent.e-bukken.app',
            audience: 'https://api.es-account.com/',
            scope: 'openid profile email',
            response_type: 'token id_token',
            response_mode: 'web_message',
            prompt: 'none',
            state,
            nonce,
          }});
          const authUrl = `https://auth.es-account.com/authorize?${{params.toString()}}`;
          const response = await new Promise((resolve, reject) => {{
            const iframe = document.createElement('iframe');
            iframe.style.display = 'none';
            // Auth0のサイレント認証は初回だけ遅れることがあるため、通常の通信より長く待つ。
            const timer = setTimeout(() => {{
              cleanup();
              reject(new Error('Auth0 silent token timeout'));
            }}, 30000);
            const cleanup = () => {{
              clearTimeout(timer);
              window.removeEventListener('message', onMessage);
              iframe.remove();
            }};
            const onMessage = (event) => {{
              if (event.origin !== 'https://auth.es-account.com') return;
              cleanup();
              resolve(event.data && event.data.response ? event.data.response : event.data);
            }};
            window.addEventListener('message', onMessage);
            iframe.src = authUrl;
            document.body.appendChild(iframe);
          }});

          if (!response || !response.access_token) {{
            throw new Error(response && response.error ? `${{response.error}}: ${{response.error_description || ''}}` : 'Auth0 silent token missing');
          }}
          window.__codexESeikatsuAccessToken = response.access_token;
          return response.access_token;
        }}
        """
    )

    deadline = time.time() + max(60, min(1200, max(pages, 1) * 8))
    last_reported_page = -1
    while time.time() < deadline:
        payload = json.loads(run_chrome_javascript(f"JSON.stringify(window.{status_key} || {{ status: 'missing' }})"))
        if payload.get("status") == "running":
            current_page = int(payload.get("currentPage") or 0)
            if current_page and current_page != last_reported_page:
                print(
                    f"いい生活全件取得: {current_page}/{int(payload.get('pageCount') or pages)}ページ / "
                    f"{int(payload.get('fetchedCount') or 0)}件 / "
                    f"{int(payload.get('requestedItemsPerPage') or safe_page_size)}件ずつ / "
                    f"同時{int(payload.get('concurrency') or safe_concurrency)}",
                    flush=True,
                )
                last_reported_page = current_page
        if payload.get("status") == "done":
            return payload
        if payload.get("status") == "error":
            return {"rooms": [], "pageCaptures": [], "error": payload.get("error", "unknown error")}
        time.sleep(0.5)

    return {"rooms": [], "pageCaptures": [], "error": "いい生活API取得がタイムアウトしました。"}


def parse_tab_indexes(raw_value: str) -> list[int]:
    if not raw_value.strip():
        return []

    indexes = []
    for item in raw_value.replace("、", ",").split(","):
        item = item.strip()
        if item:
            indexes.append(int(item))
    return indexes


def suggest_realpro_index(urls: list[str], titles: Optional[list[str]] = None, active_index: Optional[int] = None) -> Optional[int]:
    candidates = []
    for index, url in enumerate(urls, start=1):
        if "realnetpro.com" not in url or "room_detail.php" in url:
            continue
        if "method=estate" not in url:
            continue
        title = (titles[index - 1] if titles and index - 1 < len(titles) else "").lower()
        score = 1
        if "リアルネットプロ" in title or "リアプロ" in title:
            score += 8
        if "gmail" in title or "mail" in title:
            score -= 5
        if "main.php" in url or "method=estate" in url or "display=building" in url:
            score += 4
        if active_index == index:
            score += 20
        candidates.append((score, index))
    if not candidates:
        return None
    return sorted(candidates, reverse=True)[0][1]


def suggest_realpro_open_index(urls: list[str], titles: Optional[list[str]] = None, active_index: Optional[int] = None) -> Optional[int]:
    candidates = []
    for index, url in enumerate(urls, start=1):
        if "realnetpro.com" not in url or "room_detail.php" in url:
            continue
        title = (titles[index - 1] if titles and index - 1 < len(titles) else "").lower()
        score = 1
        if "リアルネットプロ" in title or "リアプロ" in title:
            score += 8
        if "login" in url or "index.php" in url:
            score += 2
        if active_index == index:
            score += 10
        candidates.append((score, index))
    if not candidates:
        return None
    return sorted(candidates, reverse=True)[0][1]


def suggest_eseikatsu_index(urls: list[str], titles: Optional[list[str]] = None) -> Optional[int]:
    candidates = []
    for index, url in enumerate(urls, start=1):
        if "rent.e-bukken.app" not in url:
            continue
        title = titles[index - 1] if titles and index - 1 < len(titles) else ""
        score = 1
        if "物件広告" in title or "いい生活賃貸クラウド" in title:
            score += 8
        if "login" in url:
            score -= 4
        if "realnetpro" in title.lower() or "リアルネットプロ" in title:
            score -= 5
        candidates.append((score, index))
    if not candidates:
        return None
    return sorted(candidates, reverse=True)[0][1]


def suggest_detail_indexes(urls: list[str]) -> list[int]:
    return [
        index
        for index, url in enumerate(urls, start=1)
        if "realnetpro.com" in url and "room_detail.php" in url
    ]


def chrome_tab_status(titles: list[str], urls: list[str]) -> dict:
    active_index = chrome_active_tab_index()
    return {
        "tabs": [
            {
                "index": index,
                "title": title,
                "url": url,
            }
            for index, (title, url) in enumerate(zip(titles, urls), start=1)
        ],
        "activeIndex": active_index,
        "suggestedRealpro": suggest_realpro_index(urls, titles, active_index),
        "suggestedESeikatsu": suggest_eseikatsu_index(urls, titles),
        "suggestedDetails": suggest_detail_indexes(urls),
    }


def eseikatsu_total_status(titles: list[str], urls: list[str], page_size: int = 100, concurrency: int = 5) -> dict:
    suggested_eseikatsu = suggest_eseikatsu_index(urls, titles)
    if not suggested_eseikatsu:
        raise SystemExit("いい生活は rent.e-bukken.app の物件一覧/広告画面を開いてください。")

    title = titles[suggested_eseikatsu - 1]
    url = urls[suggested_eseikatsu - 1]
    set_active_tab(suggested_eseikatsu)
    requested_page_size = max(20, min(int(page_size or 100), 200))
    safe_concurrency = max(1, min(int(concurrency or 5), 10))
    api_result = capture_eseikatsu_api_rooms(1, page_size=requested_page_size, concurrency=safe_concurrency)
    page_captures = api_result.get("pageCaptures", [])
    first_page = page_captures[0] if page_captures else {}
    item_count = int(first_page.get("itemCount") or len(api_result.get("rooms", [])) or 20)
    total_count = int(first_page.get("totalCount") or 0)
    page_size = requested_page_size
    required_pages = (total_count + page_size - 1) // page_size if total_count else 0

    return {
        "index": suggested_eseikatsu,
        "title": title,
        "url": url,
        "host": "rent.e-bukken.app",
        "totalCount": total_count,
        "itemCount": item_count,
        "pageSize": page_size,
        "requestedPageSize": requested_page_size,
        "concurrency": safe_concurrency,
        "requiredPages": required_pages,
        "apiError": api_result.get("error", ""),
    }


def capture_eseikatsu_cache(
    titles: list[str],
    urls: list[str],
    pages: int,
    page_size: int = 100,
    concurrency: int = 5,
) -> dict:
    suggested_eseikatsu = suggest_eseikatsu_index(urls, titles)
    if not suggested_eseikatsu:
        raise SystemExit("いい生活は rent.e-bukken.app の物件一覧/広告画面を開いてください。")

    title = titles[suggested_eseikatsu - 1]
    url = urls[suggested_eseikatsu - 1]
    set_active_tab(suggested_eseikatsu)
    requested_page_size = max(20, min(int(page_size or 100), 200))
    safe_concurrency = max(1, min(int(concurrency or 5), 10))
    started_at = time.time()
    api_result = capture_eseikatsu_api_rooms(pages, page_size=requested_page_size, concurrency=safe_concurrency)
    page_captures = api_result.get("pageCaptures", [])
    rooms = api_result.get("rooms", [])
    total_count = int((page_captures[0] if page_captures else {}).get("totalCount") or len(rooms) or 0)
    item_count = max([int(page.get("itemCount") or 0) for page in page_captures] or [20], default=20)
    page_size = requested_page_size
    required_pages = (total_count + page_size - 1) // page_size if total_count else 0
    raw_fetched_count = sum(int(page.get("itemCount") or 0) for page in page_captures)
    has_all_pages = bool(required_pages and len(page_captures) >= required_pages)
    # APIの総件数に重複号室が含まれる場合、重複整理後のrooms件数は総件数を下回る。
    # 取得中に掲載件数が増減するため、必要ページをエラーなく走査できたことも完了条件にする。
    is_full = bool(total_count and (
        len(rooms) >= total_count or
        (has_all_pages and not api_result.get("error"))
    ))
    payload = {
        "capturedAt": datetime.now(timezone.utc).isoformat(),
        "eSeikatsu": {
            "index": suggested_eseikatsu,
            "title": title,
            "url": url,
            "rooms": rooms,
            "apiPageCaptures": page_captures,
            "apiError": api_result.get("error", ""),
        },
        "meta": {
            "totalCount": total_count,
            "fetchedCount": len(rooms),
            "rawFetchedCount": raw_fetched_count,
            "pageSize": page_size,
            "requestedPageSize": requested_page_size,
            "concurrency": safe_concurrency,
            "requestedPages": pages,
            "requiredPages": required_pages,
            "isFull": is_full,
            "elapsedSeconds": round(time.time() - started_at, 2),
        },
    }
    preserved_existing_full_cache = False
    if not is_full and ESEIKATSU_CACHE_FILE.exists():
        try:
            existing = json.loads(ESEIKATSU_CACHE_FILE.read_text(encoding="utf-8"))
            preserved_existing_full_cache = bool((existing.get("meta") or {}).get("isFull"))
        except (json.JSONDecodeError, OSError):
            preserved_existing_full_cache = False
    if not preserved_existing_full_cache:
        ESEIKATSU_CACHE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {
        "filename": str(ESEIKATSU_CACHE_FILE.relative_to(ROOT)),
        "capturedAt": payload["capturedAt"],
        "totalCount": total_count,
        "fetchedCount": len(rooms),
        "rawFetchedCount": raw_fetched_count,
        "requestedPages": pages,
        "requiredPages": required_pages,
        "isFull": is_full,
        "preservedExistingFullCache": preserved_existing_full_cache,
        "apiError": api_result.get("error", ""),
        "pageSize": page_size,
        "requestedPageSize": requested_page_size,
        "concurrency": safe_concurrency,
        "elapsedSeconds": round(time.time() - started_at, 2),
    }


def retry_realpro_details_from_capture(
    titles: list[str],
    urls: list[str],
    target_ids: Optional[list[str]] = None,
) -> dict:
    if not OUTPUT_FILE.exists():
        raise SystemExit("data/chrome_capture.json が見つかりません。先にリアプロを取得してください。")
    data = json.loads(OUTPUT_FILE.read_text(encoding="utf-8"))
    rooms = ((data.get("realpro") or {}).get("rooms") or [])
    requested_ids = {str(value) for value in (target_ids or []) if str(value)}
    targets = [
        room for room in rooms
        if room.get("realproRoomId") and (
            str(room.get("realproRoomId")) in requested_ids
            if requested_ids
            else (
                room.get("webAd") == "判定不可" or
                room.get("detailCaptureStatus") in {"未取得", "詳細確認失敗", "詳細確認不完全"}
            )
        )
    ]
    suggested_realpro = suggest_realpro_index(urls, titles, chrome_active_tab_index())
    if targets and not suggested_realpro:
        raise SystemExit("リアプロ一覧タブを確認できません。")
    if targets:
        set_active_tab(suggested_realpro)

    details = []
    errors = []
    for index in range(0, len(targets), 10):
        chunk = targets[index:index + 10]
        print(f"リアプロ詳細再確認: {min(index + 10, len(targets))}/{len(targets)}件", flush=True)
        try:
            details.extend(capture_realpro_detail_summaries(chunk))
        except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError) as error:
            errors.append(str(error))
        target_rooms_by_id = {str(room.get("realproRoomId") or ""): room for room in targets}
        confirmed_candidates = sum(
            1 for detail in details
            if detail.get("webAd") in {"可", "管理会社に確認"}
            and int(detail.get("applicationCount") or 0) == 0
            and not re.search(
                r"商談中|審査中|申込あり",
                str(target_rooms_by_id.get(str(detail.get("realproRoomId") or ""), {}).get("status") or ""),
            )
        )
        print(
            f"候補判定: {min(index + 10, len(targets))}/{len(targets)}件 / 候補{confirmed_candidates}件",
            flush=True,
        )

    details_by_id = {str(detail.get("realproRoomId")): detail for detail in details}
    updated = 0
    for room in rooms:
        detail = details_by_id.get(str(room.get("realproRoomId") or ""))
        if not detail:
            continue
        room.update({
            "webAd": detail.get("webAd", room.get("webAd", "判定不可")),
            "equipment": sorted(set((room.get("equipment") or []) + (detail.get("equipment") or []))),
            "applicationCount": int(detail.get("applicationCount") or 0),
            "detailTitle": detail.get("title", ""),
            "url": detail.get("url", room.get("url", "")),
            "detailCaptureStatus": detail.get("detailCaptureStatus") or ("詳細確認不完全" if detail.get("webAd") == "判定不可" else "取得OK"),
            "detailCaptureReason": detail.get("detailCaptureReason", ""),
            "detailHttpStatus": detail.get("status", ""),
            "detailTextLength": detail.get("detailTextLength", 0),
        })
        updated += 1

    OUTPUT_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    remaining = sum(1 for room in rooms if room.get("webAd") == "判定不可")
    return {
        "filename": str(OUTPUT_FILE.relative_to(ROOT)),
        "requestedTargetCount": len(requested_ids),
        "targetCount": len(targets),
        "updatedCount": updated,
        "remainingUnknownWebAd": remaining,
        "errors": errors[:3],
    }


def apply_realpro_conditions(titles: list[str], urls: list[str], encoded_conditions: str) -> dict:
    suggested_realpro = suggest_realpro_index(urls, titles, chrome_active_tab_index())
    if not suggested_realpro:
        suggested_realpro = suggest_realpro_open_index(urls, titles, chrome_active_tab_index())
    if not suggested_realpro:
        raise SystemExit("リアプロをChromeで開いてください。ログイン後、もう一度「反映してリアプロ検索」を押してください。")

    raw_json = base64.b64decode(encoded_conditions.encode("ascii")).decode("utf-8")
    conditions = json.loads(raw_json)
    title = titles[suggested_realpro - 1]
    url = urls[suggested_realpro - 1]
    set_active_tab(suggested_realpro)
    if "method=estate" not in url or "main.php" not in url:
        move_realpro_to_page(1)
        wait_for_page_text_ready()
        page_status = realpro_page_status()
        if page_status.get("loginDetected"):
            raise SystemExit("リアプロがログイン画面です。Chromeでリアプロにログインしてから、もう一度「反映してリアプロ検索」を押してください。")
        if not page_status.get("isResultPage"):
            raise SystemExit(f"リアプロの検索画面を確認できませんでした: {page_status.get('url') or ''}")
        title = run_chrome_javascript("document.title")
        url = run_chrome_javascript("location.href")

    result = json.loads(run_chrome_javascript(
        f"""
        JSON.stringify((() => {{
          const conditions = {json.dumps(conditions, ensure_ascii=False)};
          const applied = [];
          const skipped = [];
          const layoutMap = {{
            'ワンルーム': ['1'],
            '1K': ['3'],
            '1DK': ['4'],
            '1LDK': ['6'],
            '2K': ['7'],
            '2DK': ['8'],
            '2LDK': ['9'],
            '3K': ['10'],
            '3DK': ['11'],
            '3LDK': ['12'],
            '3LDK〜': ['12', '13', '14', '15', '16', '17', '18'],
            '4LDK': ['15'],
          }};
          const routeMap = {{
            '南北線': '1082',
            '地下南北線': '1082',
            '札幌市南北線': '1082',
            '東西線': '1083',
            '地下東西線': '1083',
            '札幌市東西線': '1083',
            '札幌市電': '1084',
            '札幌市軌道線': '1084',
            '東豊線': '1085',
            '地下東豊線': '1085',
            '札幌市東豊線': '1085',
            'JR函館本線': '1051',
            '函館本線': '1051',
            'JR千歳線': '1056',
            '千歳線': '1056',
            'JR学園都市線': '1055',
            'JR札沼線': '1055',
            '札沼線': '1055',
          }};
          const transportationMap = {{ '徒歩': '1', 'バス': '2', '車': '3', '自動車': '3' }};
          const updatedMap = {{ '当日': '1', '3日以内': '3', '7日以内': '7', '14日以内': '14' }};
          const normalizeStationName = (value) => String(value || '')
            .normalize('NFKC')
            .replace(/\\s+/g, '')
            .replace(/駅$/g, '');

          const byName = (name) => document.querySelector(`[name="${{CSS.escape(name)}}"]`);
          const setSelect = (name, value, label) => {{
            const select = byName(name);
            if (!select || !value) return false;
            const stringValue = String(value);
            const option = Array.from(select.options).find((item) => item.value === stringValue);
            if (!option) {{
              skipped.push(`${{label}}=${{stringValue}}`);
              return false;
            }}
            select.value = stringValue;
            select.dispatchEvent(new Event('change', {{ bubbles: true }}));
            applied.push(label);
            return true;
          }};
          const setInput = (name, value, label) => {{
            const input = byName(name);
            if (!input) return false;
            input.value = value ? String(value) : '';
            input.dispatchEvent(new Event('input', {{ bubbles: true }}));
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
            applied.push(label);
            return true;
          }};
          const setCheckbox = (name, checked, label) => {{
            const input = byName(name);
            if (!input) return false;
            input.checked = Boolean(checked);
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
            if (checked) applied.push(label);
            return true;
          }};

          setInput('keyword', '', 'フリーワードクリア');
          setSelect('rental_cost1', conditions.rentMin || '-1', '賃料下限');
          setSelect('rental_cost2', conditions.rentMax || '-1', '賃料上限');
          setSelect('update_date', updatedMap[conditions.updated] || '-1', '更新日');
          setSelect('transportation_id', transportationMap[conditions.accessMethod] || '-1', '駅までの移動手段');
          setInput('required_time', conditions.walkMinutes || '', '駅までの分数');
          setCheckbox('include_common_fee', conditions.includeManagementFee, '管理費・共益費含む');
          setCheckbox('enable_enter_flag', conditions.immediate, '即入物件');
          setCheckbox('diversion', false, 'WEB広告掲載条件クリア');

          const sapporoCityCodes = new Set([
            '01101', '01102', '01103', '01104', '01105',
            '01106', '01107', '01108', '01109', '01110',
          ]);
          document.querySelectorAll('input[name="city_code[]"]').forEach((input) => {{
            input.checked = Boolean(conditions.sapporoOnly && sapporoCityCodes.has(input.value));
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
          }});
          if (conditions.sapporoOnly) applied.push('札幌市10区');

          const requestedLayouts = Array.isArray(conditions.layouts) ? conditions.layouts : [];
          const layoutValues = new Set(requestedLayouts.flatMap((layout) => layoutMap[layout] || []).filter(Boolean));
          document.querySelectorAll('input[name="room_layout_id[]"]').forEach((input) => {{
            input.checked = layoutValues.has(input.value);
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
          }});
          if (requestedLayouts.length) {{
            applied.push(`間取${{layoutValues.size}}件`);
            requestedLayouts.filter((layout) => !layoutMap[layout]).forEach((layout) => skipped.push(`間取:${{layout}}`));
          }}

          const requestedLineNames = new Set(Array.isArray(conditions.lines) ? conditions.lines : []);
          (Array.isArray(conditions.stations) ? conditions.stations : []).forEach((stationKey) => {{
            const [lineName] = String(stationKey).split(':');
            if (lineName) requestedLineNames.add(lineName);
          }});
          const routeValues = new Set([...requestedLineNames].map((lineName) => routeMap[lineName]).filter(Boolean));
          document.querySelectorAll('input[name="route_id[]"]').forEach((input) => {{
            const nextChecked = routeValues.has(input.value);
            input.checked = nextChecked;
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
          }});
          if (requestedLineNames.size) {{
            applied.push(`路線${{routeValues.size}}件`);
            [...requestedLineNames].filter((lineName) => !routeMap[lineName]).forEach((lineName) => skipped.push(`路線:${{lineName}}`));
          }}

          const requestedStationNames = new Set((Array.isArray(conditions.stations) ? conditions.stations : [])
            .map((stationKey) => normalizeStationName(String(stationKey).split(':').slice(1).join(':')))
            .filter(Boolean));
          const matchedStationNames = new Set();
          const stationCodesByName = loadStationCodes(routeValues);
          document.querySelectorAll('.codex-condition-hidden').forEach((input) => input.remove());
          document.querySelectorAll('input[name="station_id[]"]').forEach((input) => {{
            const label = input.closest('label')?.innerText || input.parentElement?.innerText || '';
            const stationName = normalizeStationName(label);
            const nextChecked = requestedStationNames.has(stationName);
            input.checked = nextChecked;
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
            if (nextChecked) matchedStationNames.add(stationName);
          }});
          const hiddenStationCodes = [];
          requestedStationNames.forEach((stationName) => {{
            const code = stationCodesByName.get(stationName);
            if (code && !matchedStationNames.has(stationName)) {{
              hiddenStationCodes.push(code);
              matchedStationNames.add(stationName);
            }}
          }});
          if (hiddenStationCodes.length) {{
            appendHiddenArray('station_id[]', hiddenStationCodes);
          }}
          const setAlong = document.querySelector('#set_along');
          if (setAlong && routeValues.size) setAlong.value = [...routeValues].join(',');
          const setStation = document.querySelector('#set_station');
          if (setStation && hiddenStationCodes.length) setStation.value = hiddenStationCodes.join(',');
          if (requestedStationNames.size) {{
            applied.push(`駅${{matchedStationNames.size}}件`);
            [...requestedStationNames]
              .filter((stationName) => !matchedStationNames.has(stationName))
              .forEach((stationName) => skipped.push(`駅:${{stationName}}`));
          }}

          const equipment = Array.isArray(conditions.equipment) ? conditions.equipment : [];
          const wantsParking = equipment.includes('駐車場空きあり');
          setCheckbox('parking_flag', wantsParking, '駐車場有り');
          setCheckbox('available_parking_flag', wantsParking, '駐車場空きあり');
          const equipmentMap = {{
            'バス・トイレ別': 'input[name="eq_rm[]"][value="151"]',
            'BT別': 'input[name="eq_rm[]"][value="151"]',
            'セパレート': 'input[name="eq_rm[]"][value="151"]',
            'オートロック': 'input[name="eq_bld[]"][value="1"]',
          }};
          const equipmentLabelMap = {{
            'エアコン': ['エアコン'],
            'インターネット無料': ['インターネット無料', 'ネット無料', '無料インターネット'],
          }};
          const handledEquipment = new Set(['駐車場空きあり']);
          equipment.forEach((item) => {{
            if (handledEquipment.has(item)) return;
            const selector = equipmentMap[item];
            const input = selector ? document.querySelector(selector) : findCheckboxByLabel(equipmentLabelMap[item] || [item]);
            if (!input) {{
              skipped.push(`設備:${{item}}`);
              return;
            }}
            input.checked = true;
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
            handledEquipment.add(item);
            applied.push(`設備:${{item}}`);
          }});
          equipment
            .filter((item) => !handledEquipment.has(item))
            .forEach((item) => skipped.push(`設備:${{item}}`));
          if (conditions.webAllowed) skipped.push('WEB広告掲載可否は取得後判定（管理会社確認を残す）');
          if (conditions.excludeNegotiating) skipped.push('商談中・審査中は取得後判定');

          function appendHiddenArray(name, values) {{
            const form = document.getElementById('main_form') || document.forms[0] || document.body;
            values.forEach((value) => {{
              const input = document.createElement('input');
              input.type = 'hidden';
              input.name = name;
              input.value = value;
              input.className = 'codex-condition-hidden';
              form.appendChild(input);
            }});
          }}

          function findCheckboxByLabel(keywords) {{
            const normalizedKeywords = keywords.map((keyword) => normalizeStationName(keyword));
            const inputs = [...document.querySelectorAll('input[type="checkbox"]')];
            return inputs.find((input) => {{
              const label = input.closest('label')?.innerText || input.parentElement?.innerText || '';
              const text = normalizeStationName(label);
              return normalizedKeywords.some((keyword) => text.includes(keyword));
            }});
          }}

          function loadStationCodes(routeValues) {{
            const map = new Map();
            if (!routeValues.size) return map;
            try {{
              const body = [...routeValues]
                .map((value) => `along_code%5B%5D=${{encodeURIComponent(value)}}`)
                .join('&');
              const request = new XMLHttpRequest();
              request.open('POST', 'ajax/get_station_code.php', false);
              request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
              request.send(body);
              if (request.status < 200 || request.status >= 300 || !request.responseText || request.responseText === 'false') return map;
              const payload = JSON.parse(request.responseText);
              Object.values(payload || {{}}).forEach((route) => {{
                (route.station || []).forEach((station) => {{
                  const name = normalizeStationName(station.StationName);
                  if (name && station.StationCode7) map.set(name, String(station.StationCode7));
                }});
              }});
            }} catch (error) {{
              skipped.push(`駅コード取得失敗:${{String(error)}}`);
            }}
            return map;
          }}

          const searchButton = document.querySelector('.go_search_submit') || document.querySelector('.go_search');
          const form = document.getElementById('main_form') || document.forms[0];
          const submitted = Boolean(conditions.submitSearch && (searchButton || form));
          if (submitted) {{
            setTimeout(() => {{
              if (searchButton) {{
                searchButton.click();
              }} else {{
                form.submit();
              }}
            }}, 100);
          }}

          return {{
            href: location.href,
            title: document.title,
            applied,
            skipped,
            submitted,
            searchSummary: (document.body && document.body.innerText || '').match(/[0-9,]+\\s*棟\\s*[0-9,]+\\s*戸/)?.[0] || '',
          }};
        }})())
        """
    ))
    if result.get("submitted"):
        time.sleep(2.2)
        try:
            wait_for_page_text_ready()
            result["href"] = run_chrome_javascript("location.href")
            result["url"] = result["href"]
            result["title"] = run_chrome_javascript("document.title")
            result["searchSummary"] = run_chrome_javascript(
                "(document.body && document.body.innerText || '').match(/[0-9,]+\\s*棟\\s*[0-9,]+\\s*戸/)?.[0] || ''"
            )
        except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError):
            pass

    return {
        "index": suggested_realpro,
        "title": title,
        "url": url,
        **result,
    }


def prompt_index(label: str, default_index: Optional[int], required: bool = True) -> Optional[int]:
    default_label = f" [{default_index}]" if default_index else ""
    while True:
        raw_value = input(f"{label}{default_label}: ").strip()
        if raw_value:
            return int(raw_value)
        if default_index:
            return default_index
        if not required:
            return None
        print("タブ番号を入力してください。")


def prompt_detail_indexes(default_indexes: list[int]) -> list[int]:
    default_label = ",".join(str(index) for index in default_indexes)
    raw_value = input(f"リアプロ詳細タブ番号をカンマ区切りで入力してください（なければEnter） [{default_label}]: ").strip()
    if raw_value:
        return parse_tab_indexes(raw_value)
    return default_indexes


def main() -> None:
    parser = argparse.ArgumentParser(description="Chromeで開いているリアプロ・いい生活画面から本文テキストを取得します。")
    parser.add_argument("--auto", action="store_true", help="推定したタブを確認なしで取得します。")
    parser.add_argument("--tabs-json", action="store_true", help="Chromeタブのタイトル・URLと自動判定結果だけをJSON出力します。")
    parser.add_argument("--eseikatsu-total-json", action="store_true", help="いい生活の全件数と必要ページ数だけをJSON出力します。")
    parser.add_argument("--eseikatsu-cache-json", action="store_true", help="いい生活APIだけを取得してキャッシュJSONに保存します。")
    parser.add_argument("--retry-realpro-details-json", action="store_true", help="保存済み取得JSONのリアプロ詳細未確認だけを再取得します。")
    parser.add_argument("--retry-realpro-detail-ids-json", help="base64 JSONの部屋ID配列に一致するリアプロ詳細だけを再取得します。")
    parser.add_argument("--skip-realpro-details", action="store_true", help="リアプロ一覧だけを取得し、詳細確認を後回しにします。")
    parser.add_argument("--apply-realpro-conditions-json", help="base64 JSONの検索条件をリアプロ画面へ反映します。")
    parser.add_argument("--realpro-pages", type=int, default=1, help="リアプロ一覧で取得するページ数。初期値は1。")
    parser.add_argument("--realpro-start-page", type=int, default=1, help="リアプロ一覧で取得を開始するページ番号。初期値は1。")
    parser.add_argument("--eseikatsu-pages", type=int, default=1, help="いい生活一覧で取得するページ数。初期値は1。")
    parser.add_argument("--eseikatsu-page-size", type=int, default=100, help="いい生活APIの1ページ取得件数。初期値は100。旧方式比較は20。")
    parser.add_argument("--eseikatsu-concurrency", type=int, default=5, help="いい生活APIの同時取得数。初期値は5。旧方式比較は1。")
    args = parser.parse_args()

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    original_active_index = chrome_active_tab_index()
    if not args.tabs_json:
        atexit.register(lambda: restore_active_tab(original_active_index))

    titles = chrome_titles()
    urls = chrome_urls()
    active_index = chrome_active_tab_index()
    suggested_realpro = suggest_realpro_index(urls, titles, active_index)
    suggested_eseikatsu = suggest_eseikatsu_index(urls, titles)
    suggested_details = suggest_detail_indexes(urls)

    if args.tabs_json:
        print(json.dumps(chrome_tab_status(titles, urls), ensure_ascii=False))
        return

    if args.eseikatsu_total_json:
        print(json.dumps(
            eseikatsu_total_status(
                titles,
                urls,
                page_size=args.eseikatsu_page_size,
                concurrency=args.eseikatsu_concurrency,
            ),
            ensure_ascii=False,
        ))
        return

    if args.eseikatsu_cache_json:
        print(json.dumps(
            capture_eseikatsu_cache(
                titles,
                urls,
                max(args.eseikatsu_pages, 1),
                page_size=args.eseikatsu_page_size,
                concurrency=args.eseikatsu_concurrency,
            ),
            ensure_ascii=False,
        ))
        return

    if args.retry_realpro_details_json:
        print(json.dumps(retry_realpro_details_from_capture(titles, urls), ensure_ascii=False))
        return

    if args.retry_realpro_detail_ids_json:
        try:
            decoded = base64.b64decode(args.retry_realpro_detail_ids_json).decode("utf-8")
            target_ids = json.loads(decoded)
            if not isinstance(target_ids, list):
                raise ValueError("部屋IDは配列で指定してください。")
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError) as error:
            raise SystemExit(f"部屋ID指定を読み取れませんでした: {error}")
        print(json.dumps(retry_realpro_details_from_capture(titles, urls, target_ids), ensure_ascii=False))
        return

    if args.apply_realpro_conditions_json:
        print(json.dumps(apply_realpro_conditions(titles, urls, args.apply_realpro_conditions_json), ensure_ascii=False))
        return

    print("Chromeで開いているタブ:")
    for index, (title, url) in enumerate(zip(titles, urls), start=1):
        print(f"{index}: {title} - {url}")

    if args.auto:
        if not suggested_realpro or not suggested_eseikatsu:
            raise SystemExit(
                "--auto ではリアプロ一覧タブといい生活タブを自動判定できませんでした。"
                "いい生活は rent.e-bukken.app の物件一覧/広告画面を開いてください。"
                "sfa.e-bukken.app の営業支援/追客画面は取得対象外です。"
            )
        realpro_index = suggested_realpro
        eseikatsu_index = suggested_eseikatsu
        detail_indexes = []
        print(
            f"\n自動判定: リアプロ一覧={realpro_index}, いい生活={eseikatsu_index}, "
            f"リアプロ詳細={suggested_details or 'なし'}（自動取得では追加詳細タブを省略）"
        )
    else:
        realpro_index = prompt_index("\nリアプロのタブ番号を入力してください", suggested_realpro)
        eseikatsu_index = prompt_index("いい生活のタブ番号を入力してください", suggested_eseikatsu)
        detail_indexes = prompt_detail_indexes(suggested_details)

    print("処理段階: リアプロ一覧と詳細を取得中", flush=True)
    realpro_capture = capture_current_tab(
        realpro_index,
        titles[realpro_index - 1],
        urls[realpro_index - 1],
        auto=args.auto,
        pages=args.realpro_pages,
        start_page=args.realpro_start_page,
        capture_realpro_details=not args.skip_realpro_details,
        source_hint="realpro",
    )

    print("処理段階: 開いているリアプロ詳細タブを確認中", flush=True)
    realpro_detail_captures = [
        capture_current_tab(
            index,
            titles[index - 1],
            urls[index - 1],
            "このリアプロ詳細画面で広告掲載条件と電子入居申込件数が見えていれば Enter を押してください...",
            auto=args.auto,
        )
        for index in detail_indexes
    ]

    print("処理段階: いい生活の掲載情報を確認中", flush=True)
    e_seikatsu_capture = capture_current_tab(
        eseikatsu_index,
        titles[eseikatsu_index - 1],
        urls[eseikatsu_index - 1],
        auto=args.auto,
        pages=args.eseikatsu_pages,
    )

    captures = {
        "capturedAt": datetime.now(timezone.utc).isoformat(),
        "realpro": realpro_capture,
        "realproDetails": realpro_detail_captures,
        "eSeikatsu": e_seikatsu_capture,
    }

    print("処理段階: 取得結果を保存中", flush=True)
    OUTPUT_FILE.write_text(json.dumps(captures, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"\n取得結果を書き出しました: {OUTPUT_FILE}")
    if IS_MAC and (captures["realpro"]["jsError"] or captures["eSeikatsu"]["jsError"]):
        print("ChromeのApple Events JavaScript実行がオフのため、本文取得できないタブがありました。")
        print("Chromeの 表示 > デベロッパー > Apple Events からのJavaScriptを許可 をオンにすると本文取得できます。")


if __name__ == "__main__":
    main()
