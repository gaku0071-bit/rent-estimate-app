﻿param(
  [string]$Mode = "all-basic"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ProjectRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location $ProjectRoot

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  throw "Node.js が見つかりません。先に Node.js LTS をインストールしてください。 https://nodejs.org/"
}

$modeArgs = @{
  "sample" = ""
  "all-basic" = "--all-basic"
  "json" = "--json-only"
  "rules" = "--rules-only"
  "docs" = "--docs-only"
  "server" = "--server-only"
  "update-flow" = "update-flow"
  "env" = "env"
  "chrome-bridge" = "chrome-bridge"
}

if (-not $modeArgs.ContainsKey($Mode)) {
  throw "不明な確認モードです: $Mode"
}

if ($Mode -eq "env") {
  node automation/env_check.mjs
} elseif ($Mode -eq "chrome-bridge") {
  node automation/test_chrome_bridge.mjs
} elseif ($Mode -eq "update-flow") {
  node automation/verify_update_flow.mjs
} elseif ($modeArgs[$Mode]) {
  node automation/verify_sample.mjs $modeArgs[$Mode]
} else {
  node automation/verify_sample.mjs
}
