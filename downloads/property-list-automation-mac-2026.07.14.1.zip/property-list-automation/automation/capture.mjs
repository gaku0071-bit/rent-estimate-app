import fs from "node:fs/promises";
import path from "node:path";

const ROOT = path.resolve(import.meta.dirname, "..");
const OUTPUT_DIR = path.join(ROOT, "data");
const OUTPUT_FILE = path.join(OUTPUT_DIR, "capture.json");
const PROFILE_DIR = path.join(ROOT, ".browser-profile");

async function main() {
  const args = parseArgs();
  const { chromium } = await loadPlaywright();
  await fs.mkdir(OUTPUT_DIR, { recursive: true });

  const context = await chromium.launchPersistentContext(PROFILE_DIR, {
    channel: "chrome",
    headless: false,
    viewport: { width: 1366, height: 900 },
  });

  const realproPage = await openOrReusePage(context, "https://www.realnetpro.com/");
  console.log("リアプロを開きました。ログインして、リスト検索結果を表示してください。");
  await waitForEnter("表示できたら Enter を押してください...");

  const realproRooms = await extractRealproRooms(realproPage, args.realproPages);
  console.log("必要なリアプロ詳細画面を別タブで開いてください。ない場合はそのまま進めます。");
  await waitForEnter("詳細タブを開けたら Enter を押してください...");
  const realproDetails = await extractRealproDetailPages(context, realproPage);

  const eSeikatsuPage = await openOrReusePage(context, "https://rent.e-bukken.app/login");
  console.log("いい生活を開きました。ログインして、物件一覧または対象一覧を表示してください。");
  await waitForEnter("表示できたら Enter を押してください...");

  const eSeikatsuRooms = await extractESeikatsuRooms(eSeikatsuPage, args.eSeikatsuPages);

  const payload = {
    capturedAt: new Date().toISOString(),
    realproRooms,
    realproDetails,
    eSeikatsuRooms,
  };

  await fs.writeFile(OUTPUT_FILE, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
  console.log(`取得結果を書き出しました: ${OUTPUT_FILE}`);

  await context.close();
}

function parseArgs() {
  const args = { realproPages: 1, eSeikatsuPages: 1 };
  for (let index = 2; index < process.argv.length; index += 1) {
    const item = process.argv[index];
    if (item === "--realpro-pages") args.realproPages = Number(process.argv[index += 1] ?? 1);
    if (item === "--eseikatsu-pages") args.eSeikatsuPages = Number(process.argv[index += 1] ?? 1);
  }
  return args;
}

async function loadPlaywright() {
  try {
    return await import("playwright");
  } catch {
    console.error("Playwright が未インストールです。先に `npm install` を実行してください。");
    process.exitCode = 1;
    throw new Error("missing playwright");
  }
}

async function openOrReusePage(context, url) {
  const pages = context.pages();
  const existing = pages.find((page) => page.url().startsWith(new URL(url).origin));
  const page = existing ?? await context.newPage();
  await page.goto(url, { waitUntil: "domcontentloaded" });
  return page;
}

async function waitForEnter(message) {
  process.stdout.write(`${message}\n`);
  process.stdin.resume();
  await new Promise((resolve) => process.stdin.once("data", resolve));
  process.stdin.pause();
}

async function extractRealproRooms(page, pages = 1) {
  const rooms = await captureRealproDomRooms(page, pages);
  const paginated = await collectPaginatedText(page, pages);
  return page.evaluate(({ rawText, pageCaptures, rooms }) => {
    const text = rawText;
    const lines = text.split(/\n+/).map((line) => line.trim()).filter(Boolean);

    return {
      mode: "raw-text-v1",
      url: location.href,
      title: document.title,
      lineCount: lines.length,
      rawText: text,
      rooms,
      pageCaptures,
      note: rooms.length ? "リアプロDOMから号室単位で取得" : "リアプロDOM取得に失敗したため本文テキストを使用",
    };
  }, { ...paginated, rooms });
}

async function extractESeikatsuRooms(page, pages = 1) {
  const apiResult = await captureESeikatsuApiRooms(page, pages);
  const paginated = await collectPaginatedText(page, pages);
  return page.evaluate(({ rawText, pageCaptures, apiResult }) => {
    const text = rawText;
    const lines = text.split(/\n+/).map((line) => line.trim()).filter(Boolean);

    return {
      mode: "raw-text-v1",
      url: location.href,
      title: document.title,
      lineCount: lines.length,
      rawText: text,
      rooms: apiResult.rooms,
      pageCaptures,
      apiPageCaptures: apiResult.pageCaptures,
      apiError: apiResult.error,
      note: apiResult.rooms.length ? "いい生活APIから号室単位で取得" : "いい生活API取得に失敗したため本文テキストを使用",
    };
  }, { ...paginated, apiResult });
}

async function captureESeikatsuApiRooms(page, pages = 1) {
  return page.evaluate(async (pageCount) => {
    try {
      const token = await getESeikatsuAccessToken();
      const apiUrl = buildESeikatsuApiUrl();
      const baseUrl = new URL(apiUrl);
      const itemsPerPage = Number(baseUrl.searchParams.get("items_per_page") || "20");
      const baseStartIndex = Number(baseUrl.searchParams.get("start_index") || "1");
      const rooms = [];
      const pageCaptures = [];

      for (let pageIndex = 0; pageIndex < Math.max(pageCount, 1); pageIndex += 1) {
        const pageUrl = new URL(baseUrl.href);
        const startIndex = baseStartIndex + (pageIndex * itemsPerPage);
        pageUrl.searchParams.set("start_index", String(startIndex));
        const response = await fetch(pageUrl.href, {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
            "X-Es-Consumer-Key": "eb_chintai",
          },
          credentials: "omit",
        });
        const data = await response.json();
        const items = Array.isArray(data.items) ? data.items : [];
        pageCaptures.push({
          pageNumber: pageIndex + 1,
          url: pageUrl.href,
          status: response.status,
          totalCount: data.total_counts ?? null,
          itemCount: items.length,
          startIndex,
        });
        rooms.push(...items.map(normalizeESeikatsuApiRoom));
      }

      return { rooms, pageCaptures, error: "" };
    } catch (error) {
      return { rooms: [], pageCaptures: [], error: String(error) };
    }

    function buildESeikatsuApiUrl() {
      const currentUrl = new URL(location.href);
      const parts = currentUrl.pathname.split("/").filter(Boolean);
      const organizationGuid = currentUrl.searchParams.get("organization_guid") || parts[0] || "";
      if (!organizationGuid) {
        const stored = sessionStorage.getItem("IiseikatsuApiRequestKey");
        if (stored) return stored;
      }
      const params = new URLSearchParams();
      params.set("organization_guid", organizationGuid);
      params.set("order_organization_guid", organizationGuid);
      params.set("order", currentUrl.searchParams.get("order") || "saishu_koshin_time.desc,tatemono_name.asc,sort_heya_kukaku_number.asc");
      params.set("items_per_page", currentUrl.searchParams.get("items_per_page") || "20");
      const page = Number(currentUrl.searchParams.get("p") || "1");
      params.set("start_index", String(((page || 1) - 1) * Number(params.get("items_per_page")) + 1));
      for (const value of currentUrl.searchParams.getAll("bukken_status_code")) params.append("bukken_status_code", value);
      if (!params.has("bukken_status_code")) {
        params.append("bukken_status_code", "2");
        params.append("bukken_status_code", "1");
      }
      params.set("type", "chinshaku");
      params.set("suppress_null", "true");
      return `https://api.e-bukken-1.com/bukken/1.0/search/?${params.toString()}`;
    }

    function normalizeESeikatsuApiRoom(item) {
      const bukken = item.chinshaku_bukken_view || {};
      const condition = item.chinshaku_boshu_joken_view || {};
      const advertisements = Array.isArray(bukken.chinshaku_kokoku) ? bukken.chinshaku_kokoku : [];
      const isListed = advertisements.some((ad) =>
        ad.baitai_keisai_flag === true ||
        (Array.isArray(ad.chinshaku_keisai) && ad.chinshaku_keisai.some((entry) => entry.keisai_flag === true))
      );
      const organizationGuid = new URL(location.href).pathname.split("/").filter(Boolean)[0] || item.domain_guid || "";
      const guid = bukken.chinshaku_bukken_guid || bukken.chinshaku_view_guid || item.spec_bukken_view_guid || "";

      return {
        building: item.tatemono_name || item.tatemono_to_name || "",
        room: item.heya_kukaku_number || "",
        layout: item.madori_name || item.madori || "",
        status: bukken.bukken_status || (condition.boshu_chu_flag ? "募集中" : "不明"),
        listing: isListed ? "掲載中" : "未掲載",
        url: guid ? `${location.origin}/${organizationGuid}/bukken/${guid}` : "",
      };
    }

    async function getESeikatsuAccessToken() {
      if (window.__codexESeikatsuAccessToken) return window.__codexESeikatsuAccessToken;

      const state = Math.random().toString(36).slice(2);
      const nonce = Math.random().toString(36).slice(2);
      const params = new URLSearchParams({
        client_id: "Pek8UZpyPfkN5v9gQc4YY6CyRHGCZvwl",
        redirect_uri: "https://rent.e-bukken.app",
        audience: "https://api.es-account.com/",
        scope: "openid profile email",
        response_type: "token id_token",
        response_mode: "web_message",
        prompt: "none",
        state,
        nonce,
      });
      const authUrl = `https://auth.es-account.com/authorize?${params.toString()}`;
      const response = await new Promise((resolve, reject) => {
        const iframe = document.createElement("iframe");
        iframe.style.display = "none";
        const timer = setTimeout(() => {
          cleanup();
          reject(new Error("Auth0 silent token timeout"));
        }, 10000);
        const cleanup = () => {
          clearTimeout(timer);
          window.removeEventListener("message", onMessage);
          iframe.remove();
        };
        const onMessage = (event) => {
          if (event.origin !== "https://auth.es-account.com") return;
          cleanup();
          resolve(event.data?.response || event.data);
        };
        window.addEventListener("message", onMessage);
        iframe.src = authUrl;
        document.body.appendChild(iframe);
      });

      if (!response?.access_token) {
        throw new Error(response?.error ? `${response.error}: ${response.error_description || ""}` : "Auth0 silent token missing");
      }
      window.__codexESeikatsuAccessToken = response.access_token;
      return response.access_token;
    }
  }, pages);
}

async function captureRealproDomRooms(page, pages = 1) {
  const initialUrl = page.url();
  const rooms = [];
  try {
    for (let pageNumber = 0; pageNumber < Math.max(pages, 1); pageNumber += 1) {
      await waitForPageTextReady(page);
      rooms.push(...await page.evaluate(() => {
        const normalize = (value) => String(value || "").normalize("NFKC").replace(/\s+/g, " ").trim();
        const cleanRoom = (value) => String(value || "").normalize("NFKC").match(/^[A-Za-z0-9-]+/)?.[0] || normalize(value);
        const yen = (value) => Number(String(value || "").normalize("NFKC").replace(/[^0-9]/g, "")) || 0;
        const parseAccess = (value) => {
          const match = String(value || "").match(/^沿線：(.+?)「(.+?)」(徒歩|バス|自動車|車|自転車)([0-9０-９]+)分/);
          if (!match) return { line: "", station: "", accessMethod: "徒歩", walkMinutes: 0 };
          return {
            line: normalize(match[1]),
            station: normalize(match[2]),
            accessMethod: match[3] === "自動車" ? "車" : match[3],
            walkMinutes: Number(String(match[4]).normalize("NFKC")),
          };
        };
        const splitCell = (td) => String(td?.innerText || "").split(/\n+/).map((line) => line.trim()).filter(Boolean);
        const equipmentMarkers = ["家電", "家具", "駐車場有り", "ペット", "ネット無料", "エアコン", "オートロック", "宅配BOX"];
        const capturedRooms = [];
        let building = { building: "", address: "", line: "", station: "", accessMethod: "徒歩", walkMinutes: 0 };

        for (const tr of Array.from(document.querySelectorAll("tr"))) {
          const text = String(tr.innerText || "").trim();
          const lines = text.split(/\n+/).map((line) => line.trim()).filter(Boolean);
          const addressIndex = lines.findIndex((line) => line.startsWith("住所："));
          const accessIndex = lines.findIndex((line) => line.startsWith("沿線："));
          if (!tr.classList.contains("room_info_tr") && addressIndex > 0 && accessIndex > addressIndex) {
            building = {
              building: normalize(lines[addressIndex - 1]),
              address: normalize(lines[addressIndex].replace(/^住所：/, "")),
              ...parseAccess(lines[accessIndex]),
            };
            continue;
          }

          if (!tr.classList.contains("room_info_tr") || !building.building) continue;

          const cells = Array.from(tr.querySelectorAll("td"));
          const roomAnchor = tr.querySelector("a.room_number");
          const onclick = roomAnchor?.getAttribute("onclick") || "";
          const id = onclick.match(/go_detail\(event,'([^']+)'/)?.[1] || "";
          const roomLabel = normalize(roomAnchor?.innerText || cells[0]?.innerText || "");
          const status = Array.from(tr.querySelectorAll(".st")).map((el) => normalize(el.innerText)).filter(Boolean).join(" ");
          const dateLines = splitCell(cells[5]);
          const layoutLines = splitCell(cells[6]);
          const rentLines = splitCell(cells[7]);
          const equipmentText = normalize(cells[1]?.innerText || "");

          capturedRooms.push({
            ...building,
            room: cleanRoom(roomLabel),
            roomLabel,
            realproRoomId: id,
            layout: normalize(layoutLines[0]),
            area: normalize(layoutLines[1]).replace("m2", "㎡"),
            rent: yen(rentLines[0]),
            fee: yen(rentLines[1]),
            status,
            availableDate: normalize(dateLines[0]),
            adFee: "",
            equipment: equipmentMarkers.filter((marker) => equipmentText.includes(marker)),
            webAd: "判定不可",
            imageReuse: "判定不可",
            floorPlanReuse: "判定不可",
            priorContact: "判定不可",
            applicationCount: 0,
            detailCaptureStatus: id ? "未取得" : "詳細IDなし",
            detailCaptureReason: id ? "詳細取得前" : "一覧から詳細IDを取得できませんでした",
            detailHttpStatus: "",
            detailTextLength: 0,
            url: id ? `${location.origin}/room_detail.php?id=${encodeURIComponent(id)}&type=room` : "",
          });
        }
        return capturedRooms;
      }));
      if (pageNumber >= pages - 1) break;
      let clicked = false;
      try {
        clicked = await clickNextPage(page);
      } catch {
        clicked = false;
      }
      if (!clicked) break;
      await page.waitForTimeout(1200);
    }
  } finally {
    if (page.url() !== initialUrl) {
      await page.goto(initialUrl, { waitUntil: "domcontentloaded" });
    }
  }
  const detailSummaries = [];
  for (let index = 0; index < rooms.length; index += 10) {
    detailSummaries.push(...await captureRealproDetailSummaries(page, rooms.slice(index, index + 10)));
    await page.waitForTimeout(400);
  }
  const detailsById = new Map(detailSummaries.map((detail) => [String(detail.realproRoomId), detail]));
  rooms.forEach((room) => {
    const detail = detailsById.get(String(room.realproRoomId || ""));
    if (!detail) return;
    room.webAd = detail.webAd || room.webAd;
    room.equipment = [...new Set([...(room.equipment || []), ...(detail.equipment || [])])].sort();
    room.applicationCount = Number(detail.applicationCount || 0);
    room.detailTitle = detail.title || "";
    room.url = detail.url || room.url;
    room.detailCaptureStatus = detail.detailCaptureStatus || (detail.webAd === "判定不可" ? "詳細確認不完全" : "取得OK");
    room.detailCaptureReason = detail.detailCaptureReason || "";
    room.detailHttpStatus = detail.status || "";
    room.detailTextLength = detail.detailTextLength || 0;
  });
  return rooms;
}

async function captureRealproDetailSummaries(page, rooms) {
  const ids = [...new Set(rooms.map((room) => String(room.realproRoomId || "")).filter(Boolean))];
  if (!ids.length) return [];

  return page.evaluate(async (roomIds) => {
    const details = [];
    for (const id of roomIds) {
      try {
        const url = `${location.origin}/room_detail.php?id=${encodeURIComponent(id)}&type=room`;
        const response = await fetch(url, { credentials: "include" });
        const html = await response.text();
        const doc = new DOMParser().parseFromString(html, "text/html");
        const text = (doc.body?.innerText || "").normalize("NFKC");
        const adSection = text.match(/広告掲載[\s\S]{0,260}/)?.[0] || "";
        const webAd = extractWebAd(adSection || text);
        const applicationCount = await fetchApplicationCount(doc);
        details.push({
          realproRoomId: id,
          title: doc.querySelector("title")?.innerText.trim() || "",
          url,
          status: response.status,
          webAd,
          equipment: extractEquipment(text),
          applicationCount,
          detailCaptureStatus: response.ok && webAd !== "判定不可" ? "取得OK" : "詳細確認不完全",
          detailCaptureReason: detailCaptureReason({ response, text, adSection, webAd }),
          detailTextLength: text.length,
        });
      } catch (error) {
        details.push({
          realproRoomId: id,
          title: "",
          url: `${location.origin}/room_detail.php?id=${encodeURIComponent(id)}&type=room`,
          status: 0,
          webAd: "判定不可",
          equipment: [],
          applicationCount: 0,
          detailCaptureStatus: "取得エラー",
          detailCaptureReason: String(error),
          detailTextLength: 0,
          error: String(error),
        });
      }
    }
    return details;

    function extractWebAd(text) {
      const webSection = String(text || "").match(/webサービスにこの物件の広告を掲載[\s\S]{0,80}/)?.[0] || String(text || "");
      if (/許可されていません|不可/.test(webSection)) return "許可されていません";
      if (/管理会社に確認|要確認|管理会社へご確認|掲載希望の場合は管理会社/.test(webSection)) return "管理会社に確認";
      if (/[［\[]?\s*可\s*[］\]]?|許可されています/.test(webSection)) return "可";
      return "判定不可";
    }

    function detailCaptureReason({ response, text, adSection, webAd }) {
      if (!response.ok) return `HTTP ${response.status}`;
      if (!text) return "詳細本文が空です";
      if (!adSection) return "広告掲載欄を検出できませんでした";
      if (webAd === "判定不可") return "WEB広告掲載可否の文言を検出できませんでした";
      return "";
    }

    function extractApplicationCount(text) {
      const match = String(text || "").match(/(?:申込|申し込み)\s*([0-9]+)\s*件/);
      return Number(match?.[1] || 0);
    }

    function extractEquipment(text) {
      const value = String(text || "").normalize("NFKC");
      const rules = [
        ["バス・トイレ別", /バス・トイレ別|BT別|セパレート/],
        ["独立洗面台", /独立洗面|洗面化粧台|シャンプードレッサー/],
        ["エアコン", /エアコン/],
        ["暖房", /暖房/],
        ["オートロック", /オートロック/],
        ["宅配ボックス", /宅配ボックス|宅配BOX/],
        ["インターネット無料", /インターネット無料|ネット無料/],
        ["Wi-Fi無料", /Wi-?Fi無料|Wifi無料|ワイファイ無料/i],
        ["駐輪場あり", /駐輪場(?:有り|あり|可)/],
        ["ペット相談", /ペット相談|ペット可|ペット飼育/],
        ["灯油暖房", /灯油暖房|灯油FF/],
        ["都市ガス", /都市ガス/],
        ["プロパンガス", /プロパンガス|LPガス/],
        ["エレベーター", /エレベーター/],
        ["防犯カメラ", /防犯カメラ/],
      ];
      const equipment = rules.filter(([, pattern]) => pattern.test(value)).map(([label]) => label);
      const parkingText = value.match(/駐車場[\s\S]{0,80}/)?.[0] || "";
      if (parkingText && !/空きなし|無し|なし|無|不可|要確認/.test(parkingText) && /空きあり|空有|有り|あり|可/.test(parkingText)) {
        equipment.push("駐車場空きあり");
      }
      return equipment;
    }

    async function fetchApplicationCount(doc) {
      try {
        const value = (selector) => doc.querySelector(selector)?.value || "";
        const displayFlag = value("#njc_apply_display_flag") || "N";
        if (displayFlag !== "Y") return extractApplicationCount(doc.body?.innerText || "");
        const body = new URLSearchParams();
        body.set("bk_type", "1");
        body.set("rnp_bk_id", value("#building_id"));
        body.set("rnp_hy_id", value("#room_id"));
        body.set("residence_type", value("#residence_type") || "room");
        body.set("company_id", value("#company_id"));
        body.set("user_id", value("#user_id"));
        body.set("func", "request");
        body.set("option_break_flag", value("#mylist_njc_apply_option_break_flag") || "0");
        const response = await fetch("./ajax/starfruit_auth_tyukai.php", {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
          body: body.toString(),
        });
        const result = JSON.parse(await response.text());
        return Number(result?.count || 0);
      } catch {
        return extractApplicationCount(doc.body?.innerText || "");
      }
    }
  }, ids);
}

async function collectPaginatedText(page, pages = 1) {
  const initialUrl = page.url();
  const snapshots = [];
  const pageCaptures = [];
  for (let pageNumber = 0; pageNumber < Math.max(pages, 1); pageNumber += 1) {
    await waitForPageTextReady(page);
    const pageText = await collectScrolledText(page);
    snapshots.push(pageText);
    pageCaptures.push({
      pageNumber: pageNumber + 1,
      url: page.url(),
      lineCount: pageText.split(/\n+/).filter((line) => line.trim()).length,
      textLength: pageText.length,
    });
    if (pageNumber >= pages - 1) break;
    let clicked = false;
    try {
      clicked = await clickNextPage(page);
    } catch {
      clicked = false;
    }
    if (!clicked) break;
    await page.waitForTimeout(1200);
  }
  if (page.url() !== initialUrl) {
    await page.goto(initialUrl, { waitUntil: "domcontentloaded" });
  }
  return { rawText: mergeTextSnapshots(snapshots), pageCaptures };
}

async function waitForPageTextReady(page, timeout = 12000) {
  const startedAt = Date.now();
  let lastLength = 0;
  let stableCount = 0;
  while (Date.now() - startedAt < timeout) {
    const metrics = await page.evaluate(() => ({
      url: location.href,
      readyState: document.readyState,
      textLength: (document.body?.innerText || "").length,
    }));
    const requiredLength = metrics.url.includes("e-bukken.app") ? 900 : 1200;
    if (metrics.readyState === "complete" && metrics.textLength >= requiredLength) return;
    if (metrics.textLength === lastLength && metrics.textLength > 300) {
      stableCount += 1;
      if (stableCount >= 4 && !metrics.url.includes("e-bukken.app")) return;
    } else {
      stableCount = 0;
    }
    lastLength = metrics.textLength;
    await page.waitForTimeout(500);
  }
}

async function clickNextPage(page) {
  return page.evaluate(() => {
    const normalize = (value) => String(value || "").replace(/\s+/g, "").trim();
    const isDisabled = (el) => {
      const className = String(el.className || "");
      return Boolean(el.disabled) || el.getAttribute("aria-disabled") === "true" || /disabled|Mui-disabled/.test(className);
    };
    const candidates = Array.from(document.querySelectorAll('a, button, [role="button"], input[type="button"], input[type="submit"], td, span, li'));
    const realproNext = Array.from(document.querySelectorAll("td.pager"))
      .find((el) => !isDisabled(el) && String(el.innerText || el.textContent || "").includes("次"));
    const next = realproNext || candidates.find((el) => {
      const text = normalize(el.innerText || el.textContent || el.value);
      const aria = (el.getAttribute("aria-label") || "").trim();
      const onclick = (el.getAttribute("onclick") || "").trim();
      const className = String(el.className || "");
      const isRealproPager = text === "次" && (onclick.includes("pager(") || className.includes("pager"));
      const isESeikatsuPager = aria === "Go to next page";
      const isPlainPager = ["次", "次へ", "Next", "›", ">"].includes(text) && text.length <= 4;
      return !isDisabled(el) && (isRealproPager || isESeikatsuPager || isPlainPager);
    });
    if (!next) return false;
    const before = location.href;
    next.scrollIntoView({ block: "center", inline: "center" });
    next.click();
    if (location.href === before) {
      const onclick = next.getAttribute("onclick");
      if (onclick && onclick.includes("pager(")) {
        Function(onclick).call(next);
      }
    }
    return true;
  });
}

async function collectScrolledText(page) {
  await resetScrollPositions(page);
  const metrics = await page.evaluate(() => ({
    height: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight),
    viewport: window.innerHeight,
  }));
  const step = Math.max((metrics.viewport || 800) - 120, 300);
  const positions = [];
  for (let position = 0; position <= metrics.height + step; position += step) {
    positions.push(position);
  }

  const snapshots = [await page.evaluate(() => document.body.innerText)];
  for (const position of positions.length ? positions : [0]) {
    await page.evaluate((y) => window.scrollTo(0, y), position);
    await page.waitForTimeout(180);
    snapshots.push(await page.evaluate(() => document.body.innerText));
  }
  await page.evaluate(() => window.scrollTo(0, 0));
  snapshots.push(...await collectScrollableElementText(page));
  return mergeTextSnapshots(snapshots);
}

async function collectScrollableElementText(page) {
  const elements = await page.evaluate(() => Array.from(document.querySelectorAll("body *"))
    .map((el, index) => ({ index, height: el.scrollHeight, viewport: el.clientHeight, textLength: (el.innerText || "").length }))
    .filter((item) => item.height > item.viewport + 200 && item.viewport > 120 && item.textLength > 200)
    .sort((a, b) => (b.height - b.viewport) - (a.height - a.viewport))
    .slice(0, 6));

  const snapshots = [];
  for (const element of elements) {
    const step = Math.max((element.viewport || 500) - 80, 240);
    for (let position = 0; position <= element.height + step; position += step) {
      await page.evaluate(({ index, y }) => {
        const el = Array.from(document.querySelectorAll("body *"))[index];
        if (el) {
          el.scrollTop = y;
          el.dispatchEvent(new Event("scroll", { bubbles: true }));
        }
      }, { index: element.index, y: position });
      await page.waitForTimeout(350);
      snapshots.push(await page.evaluate(() => document.body.innerText));
      snapshots.push(await page.evaluate((index) => {
        const el = Array.from(document.querySelectorAll("body *"))[index];
        return el ? el.innerText : "";
      }, element.index));
    }
    await page.evaluate((index) => {
      const el = Array.from(document.querySelectorAll("body *"))[index];
      if (el) {
        el.scrollTop = 0;
        el.dispatchEvent(new Event("scroll", { bubbles: true }));
      }
    }, element.index);
  }
  return snapshots;
}

async function resetScrollPositions(page) {
  await page.evaluate(() => {
    window.scrollTo(0, 0);
    Array.from(document.querySelectorAll("body *")).forEach((el) => {
      if (el.scrollHeight > el.clientHeight + 100) {
        el.scrollTop = 0;
        el.dispatchEvent(new Event("scroll", { bubbles: true }));
      }
    });
  });
  await page.waitForTimeout(350);
}

function mergeTextSnapshots(snapshots) {
  const seen = new Set();
  const chunks = [];
  for (const snapshot of snapshots) {
    const normalized = snapshot.trim();
    if (normalized && !seen.has(normalized)) {
      seen.add(normalized);
      chunks.push(normalized);
    }
  }
  return chunks.join("\n\n");
}

async function extractRealproDetailPages(context, listPage) {
  const pages = context.pages().filter((page) => {
    const url = page.url();
    return url.startsWith("https://www.realnetpro.com/") && page !== listPage;
  });

  const details = [];
  for (const page of pages) {
    details.push(await page.evaluate(() => ({
      mode: "realpro-detail-raw-text-v1",
      url: location.href,
      title: document.title,
      rawText: document.body.innerText,
      note: "画面側で広告掲載条件と電子入居申込件数を推定パースする",
    })));
  }

  return details;
}

main().catch((error) => {
  if (error.message !== "missing playwright") {
    console.error(error);
    process.exitCode = 1;
  }
});
