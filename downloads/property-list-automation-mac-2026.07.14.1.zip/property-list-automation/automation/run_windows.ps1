﻿Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ProjectRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location $ProjectRoot

function Resolve-NodeRuntime {
  $BundledNode = Join-Path $ProjectRoot "runtime\node\node.exe"
  if (Test-Path $BundledNode) {
    return $BundledNode
  }
  $PathNode = Get-Command node -ErrorAction SilentlyContinue
  if ($PathNode) {
    return $PathNode.Source
  }
  throw "Node.js が見つかりません。同梱Node.jsが壊れている可能性があります。インストーラーを再ダウンロードして入れ直してください。"
}

function Resolve-NpmRuntime {
  $BundledNpmCmd = Join-Path $ProjectRoot "runtime\node\npm.cmd"
  if (Test-Path $BundledNpmCmd) {
    return @{ Command = $BundledNpmCmd; Prefix = @() }
  }

  $BundledNpmCli = Join-Path $ProjectRoot "runtime\node\node_modules\npm\bin\npm-cli.js"
  if (Test-Path $BundledNpmCli) {
    return @{ Command = $script:NodeExe; Prefix = @($BundledNpmCli) }
  }

  $PathNpm = Get-Command npm -ErrorAction SilentlyContinue
  if ($PathNpm) {
    return @{ Command = $PathNpm.Source; Prefix = @() }
  }

  throw "npm が見つかりません。同梱Node.jsが壊れている可能性があります。インストーラーを再ダウンロードして入れ直してください。"
}

function Resolve-PythonRuntime {
  $BundledPython = Join-Path $ProjectRoot "runtime\python\python.exe"
  if (Test-Path $BundledPython) {
    return @{ Command = $BundledPython; Prefix = @() }
  }

  if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 --version *> $null
    if ($LASTEXITCODE -eq 0) {
      return @{ Command = "py"; Prefix = @("-3") }
    }
  }

  $PathPython = Get-Command python -ErrorAction SilentlyContinue
  if ($PathPython) {
    & $PathPython.Source --version *> $null
    if ($LASTEXITCODE -eq 0) {
      return @{ Command = $PathPython.Source; Prefix = @() }
    }
  }

  throw "Python 3 が見つかりません。同梱Pythonが壊れている可能性があります。インストーラーを再ダウンロードして入れ直してください。"
}

$script:NodeExe = Resolve-NodeRuntime
$NpmRuntime = Resolve-NpmRuntime
$PythonRuntime = Resolve-PythonRuntime
$NpmCommand = $NpmRuntime["Command"]
$PythonCommand = $PythonRuntime["Command"]

$NodeDir = Split-Path $script:NodeExe -Parent
$PythonDir = Split-Path $PythonCommand -Parent
$env:PATH = "$NodeDir;$PythonDir;$env:PATH"
if (@($PythonRuntime["Prefix"]).Count -eq 0) {
  $env:PYTHON = $PythonCommand
} else {
  Remove-Item Env:PYTHON -ErrorAction SilentlyContinue
}

Write-Host "使用するNode.js: $script:NodeExe"
Write-Host "使用するPython: $PythonCommand"

if (-not (Test-Path (Join-Path $ProjectRoot "node_modules\playwright\package.json"))) {
  Write-Host "初回準備として必要な部品をインストールします..."
  $NpmArgs = @($NpmRuntime["Prefix"]) + @("install", "--omit=dev", "--no-audit", "--no-fund")
  & $NpmCommand @NpmArgs
  if ($LASTEXITCODE -ne 0) {
    throw "npm install に失敗しました。"
  }
}

$ChromeCandidates = @(@(
  $(if ($env:PROGRAMFILES) { Join-Path $env:PROGRAMFILES "Google\Chrome\Application\chrome.exe" }),
  $(if (${env:PROGRAMFILES(X86)}) { Join-Path ${env:PROGRAMFILES(X86)} "Google\Chrome\Application\chrome.exe" }),
  $(if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Google\Chrome\Application\chrome.exe" })
) | Where-Object { $_ -and (Test-Path $_) })

if (-not $ChromeCandidates.Count) {
  throw "Google Chrome が見つかりません。Chromeをインストールしてください。"
}

$ChromePath = $ChromeCandidates[0]
$ChromeProfile = Join-Path $ProjectRoot "data\chrome-profile-windows"
$ExtensionPath = Join-Path $ProjectRoot "extension"
New-Item -ItemType Directory -Force -Path $ChromeProfile | Out-Null

$CdpReady = $false
try {
  Invoke-WebRequest -Uri "http://127.0.0.1:9222/json/version" -UseBasicParsing -TimeoutSec 2 | Out-Null
  $CdpReady = $true
} catch {
  Write-Host "Windows取得用Chromeを起動します。初回はリアプロといい生活へログインしてください。"
  $ChromeArgs = @(
    "--remote-debugging-address=127.0.0.1",
    "--remote-debugging-port=9222",
    "--user-data-dir=`"$ChromeProfile`"",
    "--no-first-run",
    "--new-window"
  )
  if (Test-Path (Join-Path $ExtensionPath "manifest.json")) {
    $ChromeArgs += "--disable-extensions-except=`"$ExtensionPath`""
    $ChromeArgs += "--load-extension=`"$ExtensionPath`""
  }
  Start-Process -FilePath $ChromePath -ArgumentList $ChromeArgs
  foreach ($Attempt in 1..15) {
    Start-Sleep -Seconds 1
    try {
      Invoke-WebRequest -Uri "http://127.0.0.1:9222/json/version" -UseBasicParsing -TimeoutSec 2 | Out-Null
      $CdpReady = $true
      break
    } catch {
      # Chromeの起動完了を待つ。
    }
  }
}

if (-not $CdpReady) {
  throw "Windows取得用Chromeへ接続できませんでした。Chromeを閉じてから、もう一度このファイルを開いてください。"
}

$BridgeReady = $false
try {
  Invoke-WebRequest -Uri "http://127.0.0.1:9223/status" -UseBasicParsing -TimeoutSec 2 | Out-Null
  $BridgeReady = $true
} catch {
  Write-Host "Chrome接続ブリッジを起動します..."
  $BridgeLog = Join-Path $ProjectRoot "data\chrome-bridge-windows.log"
  $BridgeErrorLog = Join-Path $ProjectRoot "data\chrome-bridge-windows-error.log"
  Start-Process -FilePath $script:NodeExe `
    -ArgumentList @("automation/chrome_bridge.mjs") `
    -WorkingDirectory $ProjectRoot `
    -WindowStyle Hidden `
    -RedirectStandardOutput $BridgeLog `
    -RedirectStandardError $BridgeErrorLog
  foreach ($Attempt in 1..10) {
    Start-Sleep -Seconds 1
    try {
      Invoke-WebRequest -Uri "http://127.0.0.1:9223/status" -UseBasicParsing -TimeoutSec 2 | Out-Null
      $BridgeReady = $true
      break
    } catch {
      # 接続ブリッジの起動完了を待つ。
    }
  }
}

if (-not $BridgeReady) {
  throw "Chrome接続ブリッジを起動できませんでした。data\chrome-bridge-windows-error.log を確認してください。"
}

Write-Host "画面を起動します。8765番が使用中の場合は別ポートを自動で試します。"
foreach ($Port in 8765..8775) {
  try {
    $response = Invoke-WebRequest -Uri "http://127.0.0.1:$Port/api/status" -UseBasicParsing -TimeoutSec 2
    if ($response.StatusCode -eq 200) {
      Write-Host "既に起動しています。ブラウザで画面を開きます。"
      Start-Process "http://127.0.0.1:$Port/index.html"
      exit 0
    }
  } catch {
    # このポートで起動していない場合は次のポートを確認する。
  }
}

$env:OPEN_BROWSER = "1"
& $script:NodeExe automation/server.mjs
