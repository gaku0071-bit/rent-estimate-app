#!/bin/zsh

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CODEX_NODE="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"

if [ -x "$CODEX_NODE" ]; then
  echo "$CODEX_NODE"
  exit 0
fi

if command -v node >/dev/null 2>&1; then
  command -v node
  exit 0
fi

echo "Node.js が見つかりません。先に Node.js LTS をインストールしてください。" >&2
echo "https://nodejs.org/" >&2
exit 1
