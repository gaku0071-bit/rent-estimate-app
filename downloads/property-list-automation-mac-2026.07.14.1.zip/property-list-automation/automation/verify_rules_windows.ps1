﻿& (Join-Path $PSScriptRoot "verify_windows.ps1") -Mode rules
