import fs from "node:fs/promises";
import { createWriteStream } from "node:fs";
import https from "node:https";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const distRoot = path.join(projectRoot, "dist");
const stagingRoot = path.join(distRoot, "windows-installer-source");
const appStagingRoot = path.join(stagingRoot, "property-list-automation");
const versionPath = path.join(projectRoot, "app-version.json");
const runtimeCacheRoot = path.join(distRoot, "runtime-cache");

const bundledRuntime = {
  node: {
    version: "v24.18.0",
    url: "https://nodejs.org/dist/v24.18.0/node-v24.18.0-win-x64.zip",
    target: path.join(appStagingRoot, "runtime", "node")
  },
  python: {
    version: "3.14.6",
    url: "https://www.python.org/ftp/python/3.14.6/python-3.14.6-embed-amd64.zip",
    target: path.join(appStagingRoot, "runtime", "python")
  }
};

const skipDirectoryNames = new Set([
  ".git",
  ".idea",
  ".vscode",
  "__pycache__",
  "backups",
  "downloads",
  "node_modules",
  "dist",
  "exports",
  "outputs",
  "staged"
]);

const skipRootDirectories = new Set([
  "installer"
]);

const skipFileNames = new Set([
  ".DS_Store",
  "Thumbs.db",
  "desktop.ini",
  "server.log",
  "chrome-bridge-windows.log",
  "chrome-bridge-windows-error.log"
]);

const skipRootFiles = new Set([
  "BUILD_WINDOWS_INSTALLER.bat",
  "Windowsインストーラー配布元作成.command"
]);

const dataFilesToKeep = new Set([
  "performance_baseline.json",
  "performance_latest.json",
  "sample_capture.json",
  "sample_structured_capture.json",
  "verification_rules.json",
  "verification_sample.json"
]);

const generatedDataNames = [
  "chrome_capture",
  "realpro_chunk_cache",
  "eseikatsu_full_cache",
  "extension_capture"
];

function isGeneratedDataFile(name) {
  if (!name.endsWith(".json") && !name.endsWith(".csv") && !name.endsWith(".log")) {
    return false;
  }
  return generatedDataNames.some((prefix) => name.startsWith(prefix));
}

async function readJson(filePath) {
  return JSON.parse(await fs.readFile(filePath, "utf8"));
}

async function copyFileSafe(source, destination) {
  await fs.mkdir(path.dirname(destination), { recursive: true });
  await fs.copyFile(source, destination);
}

function shouldSkipEntry(relativePath, entry) {
  const parts = relativePath.split(path.sep).filter(Boolean);
  const rootName = parts[0] || entry.name;

  if (entry.isDirectory()) {
    if (parts.length === 1 && skipRootDirectories.has(rootName)) return true;
    if (skipDirectoryNames.has(entry.name)) return true;
    if (rootName === "data") return true;
  }

  if (entry.isFile()) {
    if (parts.length === 1 && skipRootFiles.has(entry.name)) return true;
    if (skipFileNames.has(entry.name)) return true;
    if (rootName === "data") return true;
  }

  return false;
}

async function copyDirectory(sourceDir, destinationDir, relativeBase = "") {
  const entries = await fs.readdir(sourceDir, { withFileTypes: true });

  for (const entry of entries) {
    const sourcePath = path.join(sourceDir, entry.name);
    const relativePath = path.join(relativeBase, entry.name);
    const destinationPath = path.join(destinationDir, entry.name);

    if (shouldSkipEntry(relativePath, entry)) {
      continue;
    }

    if (entry.isDirectory()) {
      await fs.mkdir(destinationPath, { recursive: true });
      await copyDirectory(sourcePath, destinationPath, relativePath);
    } else if (entry.isFile()) {
      await copyFileSafe(sourcePath, destinationPath);
    }
  }
}

async function copyDirectoryRaw(sourceDir, destinationDir) {
  const entries = await fs.readdir(sourceDir, { withFileTypes: true });
  await fs.mkdir(destinationDir, { recursive: true });

  for (const entry of entries) {
    const sourcePath = path.join(sourceDir, entry.name);
    const destinationPath = path.join(destinationDir, entry.name);
    if (entry.isDirectory()) {
      await copyDirectoryRaw(sourcePath, destinationPath);
    } else if (entry.isFile()) {
      await copyFileSafe(sourcePath, destinationPath);
    }
  }
}

function runCommand(command, args, options = {}) {
  const result = spawnSync(command, args, {
    stdio: "inherit",
    shell: false,
    ...options
  });
  if (result.status !== 0) {
    throw new Error(`${command} ${args.join(" ")} に失敗しました。`);
  }
}

async function downloadFile(url, destination) {
  await fs.mkdir(path.dirname(destination), { recursive: true });
  return new Promise((resolve, reject) => {
    const request = https.get(url, (response) => {
      if ([301, 302, 303, 307, 308].includes(response.statusCode) && response.headers.location) {
        response.resume();
        downloadFile(new URL(response.headers.location, url).toString(), destination).then(resolve, reject);
        return;
      }
      if (response.statusCode !== 200) {
        response.resume();
        reject(new Error(`${url} のダウンロードに失敗しました: HTTP ${response.statusCode}`));
        return;
      }
      const file = createWriteStream(destination);
      response.pipe(file);
      file.on("finish", () => file.close(resolve));
      file.on("error", reject);
    });
    request.on("error", reject);
  });
}

async function ensureDownloaded(url, destination) {
  try {
    const stat = await fs.stat(destination);
    if (stat.size > 0) return;
  } catch {
    // まだキャッシュがない場合はダウンロードする。
  }
  console.log(`ダウンロード: ${url}`);
  await downloadFile(url, destination);
}

function extractZip(zipPath, destination) {
  awaitableRm(destination);
  const unzipResult = spawnSync("unzip", ["-q", zipPath, "-d", destination], { stdio: "inherit" });
  if (unzipResult.status === 0) return;

  const tarResult = spawnSync("tar", ["-xf", zipPath, "-C", destination], { stdio: "inherit" });
  if (tarResult.status === 0) return;

  throw new Error(`${zipPath} を展開できませんでした。unzip または tar が必要です。`);
}

function awaitableRm(target) {
  const result = spawnSync(process.execPath, [
    "-e",
    "const fs=require('fs');fs.rmSync(process.argv[1],{recursive:true,force:true});fs.mkdirSync(process.argv[1],{recursive:true});",
    target
  ], { stdio: "inherit" });
  if (result.status !== 0) throw new Error(`${target} の初期化に失敗しました。`);
}

async function extractZipToTarget(zipPath, target, options = {}) {
  const tempDir = `${target}-extract`;
  await fs.rm(target, { recursive: true, force: true });
  await fs.rm(tempDir, { recursive: true, force: true });
  await fs.mkdir(tempDir, { recursive: true });

  extractZip(zipPath, tempDir);

  const entries = await fs.readdir(tempDir, { withFileTypes: true });
  const sourceRoot = options.stripSingleRoot && entries.length === 1 && entries[0].isDirectory()
    ? path.join(tempDir, entries[0].name)
    : tempDir;
  await copyDirectoryRaw(sourceRoot, target);
  await fs.rm(tempDir, { recursive: true, force: true });
}

async function prepareBundledRuntime() {
  const nodeZip = path.join(runtimeCacheRoot, `node-${bundledRuntime.node.version}-win-x64.zip`);
  const pythonZip = path.join(runtimeCacheRoot, `python-${bundledRuntime.python.version}-embed-amd64.zip`);

  await ensureDownloaded(bundledRuntime.node.url, nodeZip);
  await ensureDownloaded(bundledRuntime.python.url, pythonZip);

  await extractZipToTarget(nodeZip, bundledRuntime.node.target, { stripSingleRoot: true });
  await extractZipToTarget(pythonZip, bundledRuntime.python.target);

  const runtimeInfo = {
    node: {
      version: bundledRuntime.node.version,
      url: bundledRuntime.node.url,
      executable: "runtime/node/node.exe"
    },
    python: {
      version: bundledRuntime.python.version,
      url: bundledRuntime.python.url,
      executable: "runtime/python/python.exe"
    },
    bundledAt: new Date().toISOString()
  };
  await fs.writeFile(
    path.join(appStagingRoot, "runtime", "RUNTIME_INFO.json"),
    JSON.stringify(runtimeInfo, null, 2),
    "utf8"
  );

  await installProductionDependencies();
  return runtimeInfo;
}

async function installProductionDependencies() {
  const npmCli = path.join(bundledRuntime.node.target, "node_modules", "npm", "bin", "npm-cli.js");
  try {
    await fs.access(npmCli);
  } catch {
    throw new Error("同梱Node.js内にnpm-cli.jsが見つかりません。");
  }

  console.log("Windows配布元へ必要なNode部品を同梱します...");
  runCommand(process.execPath, [
    npmCli,
    "install",
    "--omit=dev",
    "--ignore-scripts",
    "--no-audit",
    "--no-fund",
    "--package-lock=false"
  ], { cwd: appStagingRoot });
}

async function copyAllowedDataFiles() {
  const sourceDataDir = path.join(projectRoot, "data");
  const targetDataDir = path.join(appStagingRoot, "data");
  await fs.mkdir(targetDataDir, { recursive: true });

  let entries = [];
  try {
    entries = await fs.readdir(sourceDataDir, { withFileTypes: true });
  } catch {
    return;
  }

  for (const entry of entries) {
    if (!entry.isFile()) continue;
    if (!dataFilesToKeep.has(entry.name)) continue;
    if (isGeneratedDataFile(entry.name) && !dataFilesToKeep.has(entry.name)) continue;
    await copyFileSafe(path.join(sourceDataDir, entry.name), path.join(targetDataDir, entry.name));
  }
}

async function writeBuildGuide(version) {
  const guide = `Windowsインストーラー作成メモ

バージョン: ${version.version}
作成日: ${new Date().toISOString()}

このフォルダは、インストーラーに入れる配布元です。
実務データ、取得済みJSON、CSV、Chromeプロファイルは含めていません。

Windowsでexeを作る手順:
1. Windowsに Inno Setup をインストールします。
   https://jrsoftware.org/isinfo.php
2. このプロジェクト全体をWindowsへ置きます。
3. Inno Setup Compilerで次のファイルを開きます。
   installer\\windows\\property-list-automation.iss
4. Compile を実行します。
5. dist フォルダに property-list-automation-windows-${version.version}.exe が作成されます。

同梱される実行環境:
- Node.js ${bundledRuntime.node.version} Windows x64
- Python ${bundledRuntime.python.version} Windows embeddable x64
- npm install済みのNode部品

確認すること:
- インストール後、デスクトップアイコンから起動できる
- 専用Chromeが開く
- Chrome拡張機能が読み込まれる
- リアプロといい生活へログインできる
- システム画面の診断が通る
`;
  await fs.writeFile(path.join(stagingRoot, "BUILD_WINDOWS_INSTALLER.txt"), guide, "utf8");
}

async function ensureEmptyRuntimeFolders() {
  for (const name of ["data", "exports", "outputs"]) {
    await fs.mkdir(path.join(appStagingRoot, name), { recursive: true });
  }
}

async function main() {
  const version = await readJson(versionPath);

  await fs.rm(stagingRoot, { recursive: true, force: true });
  await fs.mkdir(appStagingRoot, { recursive: true });

  await copyDirectory(projectRoot, appStagingRoot);
  await ensureEmptyRuntimeFolders();
  await copyAllowedDataFiles();
  const runtimeInfo = await prepareBundledRuntime();
  await writeBuildGuide(version);

  const packageInfo = await readJson(path.join(projectRoot, "package.json"));
  const summary = {
    app: packageInfo.name,
    version: version.version,
    source: appStagingRoot,
    runtime: {
      node: runtimeInfo.node.version,
      python: runtimeInfo.python.version,
      nodeModulesBundled: true
    },
    innoScript: path.join(projectRoot, "installer", "windows", "property-list-automation.iss")
  };

  console.log("Windowsインストーラー配布元を作成しました。");
  console.log(JSON.stringify(summary, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
