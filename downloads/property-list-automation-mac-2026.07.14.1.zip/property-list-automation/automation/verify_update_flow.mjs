import fs from "node:fs/promises";
import { createReadStream } from "node:fs";
import http from "node:http";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { createHash } from "node:crypto";
import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const keepTemp = process.argv.includes("--keep-temp");
const skipApply = process.argv.includes("--dry-run-only");

const skipDirectoryNames = new Set([
  ".git",
  ".idea",
  ".vscode",
  "__pycache__",
  "backups",
  "downloads",
  "node_modules",
  "dist",
  "exports",
  "outputs",
  "staged",
]);

const skipRootDirectories = new Set(["installer"]);

const skipFileNames = new Set([
  ".DS_Store",
  "Thumbs.db",
  "desktop.ini",
  "server.log",
  "chrome-bridge-windows.log",
  "chrome-bridge-windows-error.log",
]);

const dataFilesToKeep = new Set([
  "performance_baseline.json",
  "performance_latest.json",
  "sample_capture.json",
  "sample_structured_capture.json",
  "verification_rules.json",
  "verification_sample.json",
]);

async function main() {
  const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), "property-list-update-verify-"));
  const tempProjectRoot = path.join(tempRoot, "property-list-automation");
  let appServer;
  let updateFileServer;

  try {
    await copyProjectForVerification(projectRoot, tempProjectRoot);

    const appPort = await findOpenPort(8890);
    appServer = startAppServer(tempProjectRoot, appPort);
    await waitForStatus(appPort, appServer);

    const updatePackageParent = path.join(tempRoot, "update-package");
    const updatePackageRoot = path.join(updatePackageParent, "property-list-automation");
    await copyProjectForVerification(tempProjectRoot, updatePackageRoot);

    const zipPath = path.join(tempRoot, "property-list-automation-update-test.zip");
    await createZipArchive(updatePackageParent, "property-list-automation", zipPath);
    const sha256 = await sha256File(zipPath);

    updateFileServer = await startStaticFileServer(zipPath);
    const downloadUrl = `http://127.0.0.1:${updateFileServer.port}/${path.basename(zipPath)}`;
    const updateInfo = {
      latestVersion: "2099.01.01.1",
      downloadUrl,
      sha256,
      notes: ["更新フロー自動検証用のテストファイル"],
    };

    const status = await getJson(appPort, "/api/status");
    assert(status.requiredFilesAvailable === true, "必須ファイル確認がOKではありません。");

    const backup = await postJson(appPort, "/api/update-backup", updateInfo);
    assert(backup.ok === true && backup.backupName, "更新前バックアップを作成できません。");

    const backups = await getJson(appPort, "/api/update-backups");
    assert(
      Array.isArray(backups.backups) && backups.backups.some((item) => item.backupName === backup.backupName),
      "作成したバックアップを一覧で確認できません。",
    );

    const prepared = await postJson(appPort, "/api/update-prepare", updateInfo);
    assert(prepared.readyToApply === true, "更新ファイルを適用可能な状態にできません。");
    assert(prepared.sha256 === sha256, "SHA-256の検証結果が一致しません。");

    const dryRunApply = await postJson(appPort, "/api/update-apply", { dryRun: true });
    assert(dryRunApply.ok === true && dryRunApply.dryRun === true, "更新適用の事前確認に失敗しました。");

    let actualApply = null;
    if (!skipApply) {
      actualApply = await postJson(appPort, "/api/update-apply", {});
      assert(actualApply.ok === true && actualApply.dryRun === false, "更新適用に失敗しました。");
    }

    const restoreDryRun = await postJson(appPort, "/api/update-restore", {
      backupName: backup.backupName,
      dryRun: true,
    });
    assert(restoreDryRun.ok === true && restoreDryRun.dryRun === true, "バックアップ復元の事前確認に失敗しました。");

    console.log([
      "更新フロー確認: OK",
      `バックアップ ${backup.backupName}`,
      `ZIP確認 ${prepared.packageType}`,
      `適用確認 ${dryRunApply.copiedFiles}ファイル`,
      skipApply ? "実適用スキップ" : `実適用 ${actualApply.copiedFiles}ファイル`,
      `復元確認 ${restoreDryRun.copiedFiles}ファイル`,
    ].join(" / "));

    if (keepTemp) {
      console.log(`検証用フォルダ: ${tempRoot}`);
    }
  } finally {
    if (updateFileServer) {
      await closeServer(updateFileServer.server);
    }
    if (appServer) {
      await stopChildProcess(appServer);
    }
    if (!keepTemp) {
      await fs.rm(tempRoot, { recursive: true, force: true });
    }
  }
}

async function copyProjectForVerification(sourceRoot, destinationRoot) {
  await fs.rm(destinationRoot, { recursive: true, force: true });
  await fs.mkdir(destinationRoot, { recursive: true });
  await copyDirectory(sourceRoot, destinationRoot);
  await ensureRuntimeFolders(destinationRoot);
  await copyAllowedDataFiles(sourceRoot, destinationRoot);
}

async function copyDirectory(sourceDir, destinationDir, relativeBase = "") {
  const entries = await fs.readdir(sourceDir, { withFileTypes: true });
  for (const entry of entries) {
    const sourcePath = path.join(sourceDir, entry.name);
    const relativePath = path.join(relativeBase, entry.name);
    const destinationPath = path.join(destinationDir, entry.name);

    if (shouldSkipEntry(relativePath, entry)) {
      continue;
    }

    if (entry.isDirectory()) {
      await fs.mkdir(destinationPath, { recursive: true });
      await copyDirectory(sourcePath, destinationPath, relativePath);
      continue;
    }

    if (entry.isFile()) {
      await fs.mkdir(path.dirname(destinationPath), { recursive: true });
      await fs.copyFile(sourcePath, destinationPath);
    }
  }
}

function shouldSkipEntry(relativePath, entry) {
  const parts = relativePath.split(path.sep).filter(Boolean);
  const rootName = parts[0] || entry.name;

  if (entry.isDirectory()) {
    if (parts.length === 1 && skipRootDirectories.has(rootName)) return true;
    if (skipDirectoryNames.has(entry.name)) return true;
    if (rootName === "data") return true;
  }

  if (entry.isFile()) {
    if (skipFileNames.has(entry.name)) return true;
    if (rootName === "data") return true;
  }

  return false;
}

async function ensureRuntimeFolders(root) {
  for (const name of ["data", "exports", "outputs", path.join("updates", "downloads"), path.join("updates", "staged")]) {
    await fs.mkdir(path.join(root, name), { recursive: true });
  }
}

async function copyAllowedDataFiles(sourceRoot, destinationRoot) {
  const sourceDataDir = path.join(sourceRoot, "data");
  const destinationDataDir = path.join(destinationRoot, "data");
  await fs.mkdir(destinationDataDir, { recursive: true });

  let entries = [];
  try {
    entries = await fs.readdir(sourceDataDir, { withFileTypes: true });
  } catch {
    return;
  }

  for (const entry of entries) {
    if (!entry.isFile() || !dataFilesToKeep.has(entry.name)) continue;
    await fs.copyFile(path.join(sourceDataDir, entry.name), path.join(destinationDataDir, entry.name));
  }
}

function startAppServer(root, port) {
  const child = spawn(process.execPath, ["automation/server.mjs"], {
    cwd: root,
    env: {
      ...process.env,
      PORT: String(port),
      UPDATE_MANIFEST_URL: "",
      BROWSER: "none",
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  child.stdoutText = "";
  child.stderrText = "";
  child.stdout.on("data", (chunk) => {
    child.stdoutText += chunk.toString();
  });
  child.stderr.on("data", (chunk) => {
    child.stderrText += chunk.toString();
  });
  return child;
}

async function waitForStatus(port, child) {
  const deadline = Date.now() + 15000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) break;
    try {
      const status = await getJson(port, "/api/status");
      if (status && status.nodeVersion) return;
    } catch {
      await sleep(200);
    }
  }
  const log = [child.stdoutText?.trim(), child.stderrText?.trim()].filter(Boolean).join(" / ");
  throw new Error(`検証用サーバーの起動を確認できません。${log ? ` ${log}` : ""}`);
}

async function findOpenPort(startPort) {
  for (let port = startPort; port < startPort + 100; port += 1) {
    if (await isPortOpen(port)) return port;
  }
  throw new Error("検証用ポートを確保できません。");
}

function isPortOpen(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.once("error", () => resolve(false));
    server.once("listening", () => {
      server.close(() => resolve(true));
    });
    server.listen(port, "127.0.0.1");
  });
}

async function createZipArchive(parentDir, packageDirName, zipPath) {
  await fs.rm(zipPath, { force: true });

  if (process.platform === "win32") {
    const powershell = findPowerShellCommand();
    if (!powershell) {
      throw new Error("PowerShellが見つからないため、更新検証用ZIPを作成できません。");
    }
    const result = spawnSync(powershell, [
      "-NoProfile",
      "-ExecutionPolicy",
      "Bypass",
      "-Command",
      "Compress-Archive -LiteralPath $args[0] -DestinationPath $args[1] -Force",
      path.join(parentDir, packageDirName),
      zipPath,
    ], {
      encoding: "utf8",
      windowsHide: true,
    });
    if (result.status !== 0) {
      throw new Error((result.stderr || result.stdout || "ZIP作成に失敗しました。").trim());
    }
    return;
  }

  const result = spawnSync("zip", ["-qr", zipPath, packageDirName], {
    cwd: parentDir,
    encoding: "utf8",
  });
  if (result.status !== 0) {
    throw new Error((result.stderr || result.stdout || "ZIP作成に失敗しました。").trim());
  }
}

function findPowerShellCommand() {
  for (const command of ["powershell", "pwsh"]) {
    const result = spawnSync(command, ["-NoProfile", "-Command", "$PSVersionTable.PSVersion.ToString()"], {
      encoding: "utf8",
      windowsHide: true,
    });
    if (result.status === 0) return command;
  }
  return "";
}

async function sha256File(filePath) {
  const hash = createHash("sha256");
  await new Promise((resolve, reject) => {
    const stream = createReadStream(filePath);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.on("error", reject);
    stream.on("end", resolve);
  });
  return hash.digest("hex");
}

async function startStaticFileServer(filePath) {
  const fileName = path.basename(filePath);
  const stat = await fs.stat(filePath);
  const server = http.createServer((request, response) => {
    const url = new URL(request.url || "/", "http://127.0.0.1");
    if (url.pathname !== `/${fileName}`) {
      response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      response.end("not found");
      return;
    }

    response.writeHead(200, {
      "Content-Type": "application/zip",
      "Content-Length": String(stat.size),
    });
    createReadStream(filePath).pipe(response);
  });

  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });

  return {
    server,
    port: server.address().port,
  };
}

async function getJson(port, pathname) {
  const response = await fetch(`http://127.0.0.1:${port}${pathname}`, {
    signal: AbortSignal.timeout(10000),
  });
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${await response.text()}`);
  }
  return response.json();
}

async function postJson(port, pathname, body) {
  const response = await fetch(`http://127.0.0.1:${port}${pathname}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(30000),
  });
  const text = await response.text();
  let payload = {};
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = { raw: text };
  }
  if (!response.ok) {
    throw new Error(payload.detail || payload.error || `HTTP ${response.status}: ${text}`);
  }
  return payload;
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function stopChildProcess(child) {
  if (child.exitCode !== null) return;
  child.kill();
  await new Promise((resolve) => {
    const timer = setTimeout(resolve, 3000);
    child.once("exit", () => {
      clearTimeout(timer);
      resolve();
    });
  });
  if (child.exitCode === null) {
    child.kill("SIGKILL");
  }
}

function closeServer(server) {
  return new Promise((resolve) => {
    server.close(() => resolve());
  });
}

main().catch((error) => {
  console.error(`更新フロー確認: NG / ${error.message}`);
  process.exitCode = 1;
});
