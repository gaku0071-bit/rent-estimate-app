import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";

const ROOT = path.resolve(import.meta.dirname, "..");
const CDP_PORT = Number(process.env.TEST_CDP_PORT || 9322);
const BRIDGE_PORT = Number(process.env.TEST_BRIDGE_PORT || 9323);
const profileDir = await fs.mkdtemp(path.join(os.tmpdir(), "property-list-chrome-"));
const chromePath = resolveChromePath();
const python = resolvePython();
const children = [];

try {
  const chrome = spawn(chromePath, [
    "--headless=new",
    `--remote-debugging-port=${CDP_PORT}`,
    "--remote-debugging-address=127.0.0.1",
    `--user-data-dir=${profileDir}`,
    "--no-first-run",
    "--disable-gpu",
    "about:blank",
  ], { stdio: "ignore" });
  children.push(chrome);
  await waitFor(`http://127.0.0.1:${CDP_PORT}/json/version`, 20_000);

  const bridge = spawn(process.execPath, ["automation/chrome_bridge.mjs"], {
    cwd: ROOT,
    env: {
      ...process.env,
      CHROME_CDP_URL: `http://127.0.0.1:${CDP_PORT}`,
      CHROME_BRIDGE_PORT: String(BRIDGE_PORT),
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  children.push(bridge);
  let bridgeError = "";
  bridge.stderr.on("data", (chunk) => {
    bridgeError += chunk;
  });
  await waitFor(`http://127.0.0.1:${BRIDGE_PORT}/status`, 20_000, () => bridgeError);

  const tabs = await getJson(`http://127.0.0.1:${BRIDGE_PORT}/tabs`);
  assert(Array.isArray(tabs.tabs) && tabs.tabs.length >= 1, "Chromeタブを取得できません。");

  const activated = await postJson(`http://127.0.0.1:${BRIDGE_PORT}/activate`, { index: 1 });
  assert(activated.activeIndex === 1, "Chromeタブを選択できません。");

  const evaluated = await postJson(`http://127.0.0.1:${BRIDGE_PORT}/eval`, {
    script: "JSON.stringify({ok: true, value: 21 * 2})",
  });
  const evaluation = JSON.parse(evaluated.result);
  assert(evaluation.ok === true && evaluation.value === 42, "Chrome JavaScript実行結果が不正です。");

  const pythonResult = await run(python.command, [
    ...python.prefix,
    "automation/capture_chrome_mac.py",
    "--tabs-json",
  ], {
    cwd: ROOT,
    env: {
      ...process.env,
      CHROME_TRANSPORT: "bridge",
      CHROME_BRIDGE_URL: `http://127.0.0.1:${BRIDGE_PORT}`,
    },
  });
  const pythonTabs = JSON.parse(pythonResult.stdout);
  assert(Array.isArray(pythonTabs.tabs) && pythonTabs.tabs.length >= 1, "Python取得処理からChromeタブを取得できません。");

  console.log(`Chrome接続統合確認: OK / タブ${pythonTabs.tabs.length}件 / JavaScript実行42 / Python連携OK`);
} finally {
  children.reverse().forEach((child) => {
    if (!child.killed) child.kill("SIGTERM");
  });
  await fs.rm(profileDir, { recursive: true, force: true }).catch(() => {});
}

function resolveChromePath() {
  const candidates = process.platform === "darwin"
    ? ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    : process.platform === "win32"
      ? [
          process.env.PROGRAMFILES && path.join(process.env.PROGRAMFILES, "Google", "Chrome", "Application", "chrome.exe"),
          process.env["PROGRAMFILES(X86)"] && path.join(process.env["PROGRAMFILES(X86)"], "Google", "Chrome", "Application", "chrome.exe"),
          process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, "Google", "Chrome", "Application", "chrome.exe"),
        ].filter(Boolean)
      : ["google-chrome", "chromium"];
  return process.env.CHROME_PATH || candidates[0];
}

function resolvePython() {
  const envPython = process.env.PYTHON ? [{ command: process.env.PYTHON, prefix: [] }] : [];
  const candidates = process.platform === "win32"
    ? [
        ...envPython,
        { command: "py", prefix: ["-3"] },
        { command: "python", prefix: [] },
        { command: "python3", prefix: [] },
      ]
    : [
        ...envPython,
        { command: "python3", prefix: [] },
        { command: "python", prefix: [] },
      ];
  for (const candidate of candidates) {
    const result = spawnSync(candidate.command, [...candidate.prefix, "--version"], {
      encoding: "utf8",
      windowsHide: true,
    });
    if (result.status === 0) return candidate;
  }
  throw new Error("Python 3が見つかりません。");
}

async function waitFor(url, timeoutMs, errorDetail = () => "") {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(1000) });
      if (response.ok) return;
    } catch {
      // 起動完了まで待つ。
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw new Error(`起動待ちがタイムアウトしました: ${url} ${errorDetail()}`.trim());
}

async function getJson(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`${url} HTTP ${response.status}`);
  return response.json();
}

async function postJson(url, body) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!response.ok) throw new Error(`${url} HTTP ${response.status}: ${await response.text()}`);
  return response.json();
}

function run(command, args, options) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { ...options, windowsHide: true });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => {
      stdout += chunk;
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) resolve({ stdout, stderr });
      else reject(new Error((stderr || stdout || `${command} exited ${code}`).trim()));
    });
  });
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}
