#!/usr/bin/env python3
"""Validate latest exported CSVs against the latest captured source data."""

from __future__ import annotations

import csv
import json
import re
import sys
import unicodedata
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parents[1]
CAPTURE_FILE = ROOT / "data" / "chrome_capture.json"
EXPORTS_DIR = ROOT / "exports"
LOCAL_TZ = ZoneInfo("Asia/Tokyo")


def normalize(value: object) -> str:
    text = unicodedata.normalize("NFKC", str(value or ""))
    text = re.sub(r"\s+", "", text)
    return text.lower()


def normalize_building(value: object) -> str:
    text = normalize(value)
    text = re.sub(r"\(.+?\)", "", text)
    text = re.sub(r"\[.+?\]", "", text)
    text = re.sub(r"【.+?】", "", text)
    return text


def normalize_room(value: object) -> str:
    text = normalize(value)
    text = re.sub(r"\(.+?\)", "", text)
    text = re.sub(r"号室$", "", text)
    text = re.sub(r"部屋$", "", text)
    return str(int(text)) if re.fullmatch(r"[0-9]+", text) else text


def room_key(row: dict[str, object]) -> str:
    return f"{normalize_building(row.get('building') or row.get('建物名'))}::{normalize_room(row.get('room') or row.get('号室'))}"


def read_csv(filename: str) -> list[dict[str, str]]:
    path = EXPORTS_DIR / filename
    if not path.exists():
      raise AssertionError(f"{filename} がありません。CSV保存を実行してください。")
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def load_capture() -> dict:
    if not CAPTURE_FILE.exists():
        raise AssertionError("data/chrome_capture.json がありません。")
    return json.loads(CAPTURE_FILE.read_text(encoding="utf-8"))


def load_active_eseikatsu_keys(data: dict) -> set[str]:
    rooms = data.get("eSeikatsu", {}).get("rooms") or data.get("eSeikatsuRooms") or []
    active = set()
    for room in rooms:
        status = normalize(room.get("status"))
        listing = normalize(room.get("listing"))
        if status == normalize("募集中") and listing == normalize("掲載中"):
            active.add(room_key(room))
    if not active:
        raise AssertionError("いい生活の募集中・掲載中データを確認できません。")
    return active


def parse_capture_datetime(value: object) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).astimezone(LOCAL_TZ)
    except ValueError:
        return None


def capture_freshness_warning(data: dict) -> str:
    captured_at = parse_capture_datetime(data.get("capturedAt") or data.get("meta", {}).get("capturedAt"))
    if not captured_at:
        return "注意: 取得日時を確認できません。実務CSVを使う前にリアプロを再取得してください。"
    today = datetime.now(LOCAL_TZ).date()
    if captured_at.date() == today:
        return ""
    return f"注意: 取得日は{captured_at.date().isoformat()}です。実務で使う前にリアプロを当日再取得してください。"


def verify_candidate_csvs(active_keys: set[str]) -> list[str]:
    errors: list[str] = []
    candidate_files = ["latest-practical.csv", "latest-work.csv", "latest-candidates.csv"]
    for filename in candidate_files:
        rows = read_csv(filename)
        for row in rows:
            if room_key(row) in active_keys:
                errors.append(
                    f"{filename}: いい生活で募集中・掲載中の同一号室が候補に含まれています "
                    f"{row.get('建物名', '')} {row.get('号室', '')}"
                )
    return errors


def verify_all_csv(active_keys: set[str]) -> list[str]:
    errors: list[str] = []
    for row in read_csv("latest-all.csv"):
        if room_key(row) not in active_keys:
            continue
        if row.get("作業対象") != "対象外":
            errors.append(
                "latest-all.csv: いい生活で募集中・掲載中の同一号室が候補扱いになっています "
                f"{row.get('建物名', '')} {row.get('号室', '')} / "
                f"{row.get('作業対象', '')} / {row.get('確認理由', '')}"
            )
    return errors


def verify_counts() -> list[str]:
    errors: list[str] = []
    practical = read_csv("latest-practical.csv")
    work = read_csv("latest-work.csv")
    review = read_csv("latest-review.csv")
    candidates = read_csv("latest-candidates.csv")
    if len(practical) != len(candidates):
        errors.append(f"現場用CSVと候補CSVの件数が一致しません: {len(practical)} / {len(candidates)}")
    if len(work) + len(review) != len(practical):
        errors.append(f"作業対象CSV + 確認用CSV と現場用CSVの件数が一致しません: {len(work)} + {len(review)} / {len(practical)}")
    return errors


def main() -> int:
    data = load_capture()
    active_keys = load_active_eseikatsu_keys(data)
    errors = []
    errors.extend(verify_candidate_csvs(active_keys))
    errors.extend(verify_all_csv(active_keys))
    errors.extend(verify_counts())
    if errors:
        print("\n".join(errors))
        return 1
    practical_count = len(read_csv("latest-practical.csv"))
    work_count = len(read_csv("latest-work.csv"))
    review_count = len(read_csv("latest-review.csv"))
    all_count = len(read_csv("latest-all.csv"))
    warning = capture_freshness_warning(data)
    suffix = f" / {warning}" if warning else ""
    print(f"最新CSV確認: OK / 現場用{practical_count}件 / 作業対象{work_count}件 / 確認{review_count}件 / 全件{all_count}件{suffix}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
