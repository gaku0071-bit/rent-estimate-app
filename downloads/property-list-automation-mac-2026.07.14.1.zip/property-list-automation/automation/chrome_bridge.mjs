import http from "node:http";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const { chromium } = require("playwright");

const HOST = process.env.CHROME_BRIDGE_HOST || "127.0.0.1";
const PORT = Number(process.env.CHROME_BRIDGE_PORT || 9223);
const CDP_URL = process.env.CHROME_CDP_URL || "http://127.0.0.1:9222";

let browser = null;
let selectedPage = null;

async function connectedBrowser() {
  if (browser?.isConnected()) return browser;
  browser = await chromium.connectOverCDP(CDP_URL);
  browser.on("disconnected", () => {
    browser = null;
    selectedPage = null;
  });
  return browser;
}

async function pages() {
  const connected = await connectedBrowser();
  return connected.contexts().flatMap((context) => context.pages());
}

async function tabsPayload() {
  const openPages = await pages();
  if (!selectedPage || !openPages.includes(selectedPage)) {
    selectedPage = openPages[0] || null;
  }
  const tabs = await Promise.all(openPages.map(async (page, offset) => ({
    index: offset + 1,
    title: await page.title().catch(() => ""),
    url: page.url(),
  })));
  return {
    tabs,
    activeIndex: selectedPage ? openPages.indexOf(selectedPage) + 1 : null,
  };
}

async function activate(index) {
  const openPages = await pages();
  const page = openPages[Number(index) - 1];
  if (!page) throw new Error(`Chromeタブ ${index} が見つかりません。`);
  selectedPage = page;
  await page.bringToFront();
  return { activeIndex: Number(index), url: page.url() };
}

async function evaluate(script) {
  const openPages = await pages();
  if (!selectedPage || !openPages.includes(selectedPage)) {
    selectedPage = openPages[0] || null;
  }
  if (!selectedPage) throw new Error("Chromeに開いているタブがありません。");
  const value = await selectedPage.evaluate((source) => window.eval(source), String(script || ""));
  if (value === undefined || value === null) return "";
  return typeof value === "string" ? value : JSON.stringify(value);
}

function sendJson(response, status, payload) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  response.end(JSON.stringify(payload));
}

async function readJson(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 5_000_000) throw new Error("リクエストが大きすぎます。");
    chunks.push(chunk);
  }
  return chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {};
}

const server = http.createServer(async (request, response) => {
  try {
    const url = new URL(request.url || "/", `http://${request.headers.host}`);
    if (request.method === "GET" && url.pathname === "/status") {
      const payload = await tabsPayload();
      sendJson(response, 200, {
        ok: true,
        cdpUrl: CDP_URL,
        tabCount: payload.tabs.length,
        activeIndex: payload.activeIndex,
      });
      return;
    }
    if (request.method === "GET" && url.pathname === "/tabs") {
      sendJson(response, 200, await tabsPayload());
      return;
    }
    if (request.method === "POST" && url.pathname === "/activate") {
      const body = await readJson(request);
      sendJson(response, 200, await activate(body.index));
      return;
    }
    if (request.method === "POST" && url.pathname === "/eval") {
      const body = await readJson(request);
      sendJson(response, 200, { result: await evaluate(body.script) });
      return;
    }
    sendJson(response, 404, { error: "Not found" });
  } catch (error) {
    sendJson(response, 500, {
      error: "Chrome接続ブリッジでエラーが発生しました。",
      detail: error.message,
    });
  }
});

server.on("error", (error) => {
  console.error(error.message);
  process.exitCode = 1;
});

server.listen(PORT, HOST, () => {
  console.log(`Chrome接続ブリッジ: http://${HOST}:${PORT} -> ${CDP_URL}`);
});
