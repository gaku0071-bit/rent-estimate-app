#!/bin/zsh
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

NODE_BIN="$("$PROJECT_ROOT/automation/node_runner.command")" || {
  read -r "?Enterで閉じます..."
  exit 1
}

echo "サンプルJSON・検証ルール・ドキュメントをまとめて確認します。"
"$NODE_BIN" automation/verify_sample.mjs --all-basic
echo ""
read -r "?Enterで閉じます..." || true
