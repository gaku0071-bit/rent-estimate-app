@echo off
setlocal

cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js が見つかりません。
  echo Node.js LTS をインストールしてから再実行してください。
  echo https://nodejs.org/
  pause
  exit /b 1
)

echo リリースmanifestを確定します。
node automation\finalize_release_manifest.mjs
if errorlevel 1 goto failed

echo.
echo 完了しました。
echo dist\releases フォルダを確認してください。
pause
exit /b 0

:failed
echo.
echo リリースmanifestの確定に失敗しました。上のメッセージを確認してください。
pause
exit /b 1
