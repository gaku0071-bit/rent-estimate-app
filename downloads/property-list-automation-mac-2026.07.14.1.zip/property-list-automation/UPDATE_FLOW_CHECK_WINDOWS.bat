@echo off
setlocal

cd /d "%~dp0"

echo Starting update flow check.
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode update-flow
if errorlevel 1 goto failed

echo.
echo Update flow check OK.
pause
exit /b 0

:failed
echo.
echo Update flow check failed. Check the message above.
pause
exit /b 1
