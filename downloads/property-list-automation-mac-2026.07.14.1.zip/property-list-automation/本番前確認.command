#!/bin/zsh
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

NODE_BIN="$("$PROJECT_ROOT/automation/node_runner.command")" || {
  read -r "?Enterで閉じます..." || true
  exit 1
}

CODEX_NODE_MODULES="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules"
if [ -d "$CODEX_NODE_MODULES" ]; then
  export NODE_PATH="$CODEX_NODE_MODULES${NODE_PATH:+:$NODE_PATH}"
fi

echo "本番前確認を開始します。"
echo "1. 環境確認"
"$NODE_BIN" automation/env_check.mjs
echo ""

echo "2. 総合確認"
"$NODE_BIN" automation/verify_sample.mjs --all-basic
echo ""

echo "3. CSV生成確認"
"$NODE_BIN" automation/verify_sample.mjs
echo ""

echo "4. 更新フロー確認"
"$NODE_BIN" automation/verify_update_flow.mjs
echo ""

echo "本番前確認OKです。"
read -r "?Enterで閉じます..." || true
