@echo off
setlocal

cd /d "%~dp0"

echo Starting pre-release check.
echo 1. Environment check
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode env
if errorlevel 1 goto failed
echo.

echo 2. Full sample check
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode all-basic
if errorlevel 1 goto failed
echo.

echo 3. CSV check
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode sample
if errorlevel 1 goto failed
echo.

echo 4. Update flow check
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode update-flow
if errorlevel 1 goto failed
echo.

echo Pre-release check OK.
pause
exit /b 0

:failed
echo.
echo Pre-release check failed. Check the message above.
pause
exit /b 1
