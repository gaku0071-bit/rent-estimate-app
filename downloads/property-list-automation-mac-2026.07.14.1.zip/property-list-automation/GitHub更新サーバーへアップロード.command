#!/bin/zsh
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
PUBLIC_DIR="$ROOT_DIR/dist/update-server-public"
WORK_DIR="$ROOT_DIR/dist/update-server-publish-work"
REMOTE_URL="https://github.com/gaku0071-bit/rent-estimate-app.git"
BRANCH_NAME="property-list-updates"
MANIFEST_URL="https://raw.githubusercontent.com/gaku0071-bit/rent-estimate-app/property-list-updates/update-manifest.json"
INSTALL_PAGE_URL="https://gaku0071-bit.github.io/rent-estimate-app/"
PUBLIC_VERSION=""

echo "物件候補リスト 更新サーバーへアップロード"
echo

if ! command -v git >/dev/null 2>&1; then
  echo "git が見つかりません。先にgitを使える状態にしてください。"
  exit 1
fi

if [ ! -f "$PUBLIC_DIR/update-manifest.json" ]; then
  echo "update-manifest.json が見つかりません。先にサーバー公開フォルダを作成してください。"
  echo "$PUBLIC_DIR"
  exit 1
fi

if [ -f "$PUBLIC_DIR/SERVER_PUBLIC_STATUS.json" ]; then
  PUBLIC_VERSION="$(grep -E '"version"[[:space:]]*:' "$PUBLIC_DIR/SERVER_PUBLIC_STATUS.json" | head -1 | sed -E 's/.*"version"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/')"
fi
if [ -z "$PUBLIC_VERSION" ]; then
  PUBLIC_VERSION="unknown"
fi

rm -rf "$WORK_DIR"
mkdir -p "$WORK_DIR"
rsync -a --delete "$PUBLIC_DIR"/ "$WORK_DIR"/

cd "$WORK_DIR"
git init -q
git checkout -B "$BRANCH_NAME" >/dev/null
git config user.name "property-list-automation"
git config user.email "property-list-automation@local"
git add .
git commit -m "Publish property list automation updates $PUBLIC_VERSION" >/dev/null

if ! git remote get-url origin >/dev/null 2>&1; then
  git remote add origin "$REMOTE_URL"
fi

echo "GitHubへpushします。"
echo "GitHubのPersonal Access Tokenを貼り付けてください。入力内容は画面に表示されません。"
echo
read -r -s GITHUB_TOKEN"?Personal Access Token: "
echo

if [ -z "$GITHUB_TOKEN" ]; then
  echo "Personal Access Token が空です。もう一度実行してください。"
  exit 1
fi

ASKPASS_FILE="$(mktemp)"
cat > "$ASKPASS_FILE" <<'EOS'
#!/bin/sh
case "$1" in
  *Username*) printf '%s\n' 'gaku0071-bit' ;;
  *Password*) printf '%s\n' "$GITHUB_TOKEN" ;;
  *) printf '\n' ;;
esac
EOS
chmod 700 "$ASKPASS_FILE"
trap 'rm -f "$ASKPASS_FILE"; unset GITHUB_TOKEN' EXIT

printf "protocol=https\nhost=github.com\n\n" | git credential reject >/dev/null 2>&1 || true
GITHUB_TOKEN="$GITHUB_TOKEN" GIT_ASKPASS="$ASKPASS_FILE" GIT_TERMINAL_PROMPT=0 git push -u origin "$BRANCH_NAME" --force

NODE_BIN="$ROOT_DIR/.codex-node"
if [ ! -x "$NODE_BIN" ]; then
  NODE_BIN="/Users/abukawatakehito/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
fi
if [ ! -x "$NODE_BIN" ]; then
  NODE_BIN="$(command -v node || true)"
fi
if [ -n "$NODE_BIN" ]; then
  cd "$ROOT_DIR"
  "$NODE_BIN" automation/set_update_manifest_url.mjs --url="$MANIFEST_URL" >/dev/null || true
fi

echo
echo "アップロード完了です。"
echo "更新manifest URL:"
echo "$MANIFEST_URL"
echo
echo "導入ページ URL:"
echo "$INSTALL_PAGE_URL"
echo
echo "このURLを各PCの更新サーバーURLに設定します。"
