@echo off
setlocal

cd /d "%~dp0"

echo 画面操作とCSV生成まで確認します。
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode sample
echo.
pause
