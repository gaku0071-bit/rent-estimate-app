@echo off
setlocal

cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js が見つかりません。
  echo Node.js LTS をインストールしてから再実行してください。
  echo https://nodejs.org/
  pause
  exit /b 1
)

echo 更新サーバーURLを設定します。
node automation\set_update_manifest_url.mjs
if errorlevel 1 goto failed

echo.
echo 完了しました。
pause
exit /b 0

:failed
echo.
echo 更新サーバーURLの設定に失敗しました。上のメッセージを確認してください。
pause
exit /b 1
