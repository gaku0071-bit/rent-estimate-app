@echo off
setlocal

cd /d "%~dp0"

echo Checking this PC for the property list automation system.
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode env
echo.
pause
