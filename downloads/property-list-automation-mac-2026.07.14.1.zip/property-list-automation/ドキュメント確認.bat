@echo off
setlocal

cd /d "%~dp0"

echo ドキュメント整合性を確認します。
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode docs
echo.
pause
