@echo off
setlocal

cd /d "%~dp0"

echo 検証サンプルJSONを確認します。
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode json
echo.
pause
