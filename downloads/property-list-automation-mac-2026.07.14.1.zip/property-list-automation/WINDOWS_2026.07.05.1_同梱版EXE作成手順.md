# Windows同梱版インストーラー作成手順 2026.07.05.1

目的:
Windows利用者PCにNode.js / Pythonを別途インストールしなくても動くインストーラーを作成する。

今回の変更:
- Node.js LTS v24.18.0 Windows x64 を同梱
- Python 3.14.6 embeddable Windows x64 を同梱
- Playwrightなど必要なNode部品を `node_modules` に同梱
- WindowsのPATHに入っているNode/Pythonへ依存しない
- Google Chromeだけは利用者PCに必要

## 作成するファイル

`dist/property-list-automation-windows-2026.07.05.1.exe`

## Windows側でやること

1. このプロジェクトをWindowsで開く。
2. `BUILD_WINDOWS_INSTALLER.bat` を実行する。
3. Inno Setupが入っていない場合は案内に従って入れる。
4. 作成されたEXEを確認する。

## 作成後の確認

インストール後、次のファイルが存在することを確認する。

```text
%LOCALAPPDATA%\PropertyListAutomation\runtime\node\node.exe
%LOCALAPPDATA%\PropertyListAutomation\runtime\node\npm.cmd
%LOCALAPPDATA%\PropertyListAutomation\runtime\python\python.exe
%LOCALAPPDATA%\PropertyListAutomation\node_modules\playwright\package.json
```

デスクトップの「物件候補リスト作成システム」を開いて、次を確認する。

- 起動時にNode.js/Python不足のエラーが出ない
- 専用Chromeが開く
- システム画面が開く
- `Chromeタブ確認` が動く

## 注意

- Windows本体へNode.jsやPythonをインストールしない。
- 以前の制作中ファイルを消す場合も、実務CSVが残っていないか確認してから削除する。
- Google Chromeは別途必要。

## Mac側へ戻すもの

作成できたら、次のEXEをMac側へ戻す。

```text
property-list-automation-windows-2026.07.05.1.exe
```

Mac側ではこのEXEを `dist/releases/2026.07.05.1/downloads/` に入れて、manifest確定とサーバー公開を行う。
