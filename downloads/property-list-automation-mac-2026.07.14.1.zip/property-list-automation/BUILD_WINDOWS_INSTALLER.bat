@echo off
setlocal
cd /d "%~dp0"

set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"

if not defined ISCC (
  echo Inno Setup が見つかりません。
  echo 先に Inno Setup をインストールしてください。
  echo https://jrsoftware.org/isinfo.php
  pause
  exit /b 1
)

if not exist "dist\windows-installer-source\property-list-automation\START_WINDOWS.bat" (
  echo インストーラー配布元を作成します...
  where node >nul 2>nul
  if errorlevel 1 (
    echo Node.js が見つかりません。
    echo Macで npm run build:windows-installer-source を実行してから、このフォルダをWindowsへ置いてください。
    pause
    exit /b 1
  )
  node automation\build_windows_installer_source.mjs
  if errorlevel 1 (
    echo 配布元の作成に失敗しました。
    pause
    exit /b 1
  )
)

echo Windowsインストーラーを作成します...
"%ISCC%" "installer\windows\property-list-automation.iss"
if errorlevel 1 (
  echo インストーラー作成に失敗しました。
  pause
  exit /b 1
)

echo 完了しました。
echo dist フォルダの property-list-automation-windows-*.exe を確認してください。
pause
