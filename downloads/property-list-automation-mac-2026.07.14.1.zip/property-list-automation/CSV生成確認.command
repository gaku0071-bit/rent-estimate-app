#!/bin/zsh
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

NODE_BIN="$("$PROJECT_ROOT/automation/node_runner.command")" || {
  read -r "?Enterで閉じます..." || true
  exit 1
}

CODEX_NODE_MODULES="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules"
if [ -d "$CODEX_NODE_MODULES" ]; then
  export NODE_PATH="$CODEX_NODE_MODULES${NODE_PATH:+:$NODE_PATH}"
fi

echo "画面操作とCSV生成まで確認します。"
echo "ローカルサーバーを一時起動し、検証サンプルから作業対象CSVを出力できるか確認します。"
"$NODE_BIN" automation/verify_sample.mjs
echo ""
read -r "?Enterで閉じます..." || true
