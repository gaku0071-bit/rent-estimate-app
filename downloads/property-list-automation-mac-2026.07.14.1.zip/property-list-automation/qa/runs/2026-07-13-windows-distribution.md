# Windows配布物取り込み記録 2026-07-13

## Driveから取り込んだ配布物

- 版: `2026.07.13.2`
- EXE: `property-list-automation-windows-2026.07.13.2.exe`
- Driveサイズ: `40,143,687 bytes`
- Mac側取り込みサイズ: `40,143,687 bytes`
- SHA-256: `46ec33448c42b9fa0123b9e807f4fac602bbbf9bf40128f042e34ffb3383363b`
- 保存先: `dist/releases/2026.07.13.2/downloads/`

## 変更内容

- 建物名に「レオパレス」を含む物件を候補から除外
- 除外理由を「レオパレス物件は候補対象外」と表示
- 通常候補には表示せず、「除外も表示」で確認可能

## Drive上で確認した関連ファイル

- `property-list-automation-windows-portable-2026.07.13.2.zip`
- `property-list-automation-windows-installer-source-2026.07.13.2.zip`
- `WINDOWS_2026.07.13.2_distribution-handoff.md`

Portable ZIPとinstaller-source ZIPはDrive上の存在を確認済みだが、Mac側へはまだ取り込んでいない。

## 公開前の注意

- Drive上に `property-list-automation-mac-2026.07.13.2.zip` はまだ確認できていない。
- Windows版だけを先に公開する場合は、manifestのWindows欄だけを `2026.07.13.2` に更新し、Mac欄は現行版を維持する。
- Mac版とWindows版を同じ版番号で公開する場合は、Mac版ZIPも取得してからmanifestを確定する。

