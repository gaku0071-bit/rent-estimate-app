#include "version.iss.inc"

#define AppName "物件候補リスト作成システム"
#define AppId "{{B1B3B05E-6B0D-4C31-A93D-85E661949C4F}"
#define SourceRoot "..\..\dist\windows-installer-source\property-list-automation"

[Setup]
AppId={#AppId}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={localappdata}\PropertyListAutomation
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=..\..\dist
OutputBaseFilename=property-list-automation-windows-{#AppVersion}
Compression=lzma
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName={#AppName}

[Languages]
Name: "japanese"; MessagesFile: "compiler:Languages\Japanese.isl"

[Tasks]
Name: "desktopicon"; Description: "デスクトップにアイコンを作成する"; GroupDescription: "追加アイコン:"; Flags: checkedonce

[Files]
Source: "{#SourceRoot}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Dirs]
Name: "{app}\data"
Name: "{app}\exports"
Name: "{app}\outputs"

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\START_WINDOWS.bat"; WorkingDir: "{app}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\START_WINDOWS.bat"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\START_WINDOWS.bat"; WorkingDir: "{app}"; Description: "{#AppName} を起動する"; Flags: postinstall nowait skipifsilent

[UninstallDelete]
Type: files; Name: "{app}\data\chrome-bridge-windows.log"
Type: files; Name: "{app}\data\chrome-bridge-windows-error.log"
