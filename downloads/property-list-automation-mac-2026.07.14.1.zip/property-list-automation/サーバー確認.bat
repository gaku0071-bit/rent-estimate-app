@echo off
setlocal

cd /d "%~dp0"

echo 動いているローカルサーバーを確認します。
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode server
echo.
pause
