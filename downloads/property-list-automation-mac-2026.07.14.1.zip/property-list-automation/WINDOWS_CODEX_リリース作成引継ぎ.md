# Windows Codex リリース作成引継ぎ

このファイルは、Windows側のCodexに渡して、Windowsインストーラーexe作成からアップデート配布用フォルダ作成まで進めてもらうための作業指示書です。

## 目的

Windows実機でしか作れない Windowsインストーラーexe を作成し、サーバー公開用の最終配布物を完成させる。

完成させるもの:

- `dist/property-list-automation-windows-<version>.exe`
- `dist/releases/<version>/downloads/property-list-automation-windows-<version>.exe`
- `dist/releases/<version>/update-manifest.json`
- `dist/update-server-public`

## 最初に読むファイル

Windows側のCodexは、作業前に次を読むこと。

1. `README.md`
2. `CODEX_WINDOWS引き継ぎ.md`
3. `docs/windows_installer.md`
4. `docs/update_distribution_spec.md`
5. `app-version.json`

## 前提

Windows PCには次が必要。

- Node.js LTS
- Python 3
- Google Chrome
- Inno Setup 6
- このプロジェクト一式

Inno Setupがない場合は、先にインストールする。

公式:

`https://jrsoftware.org/isinfo.php`

## 注意

次のフォルダやファイルは実務データなので、削除・上書きしない。

- `data`
- `exports`
- `outputs`
- `backups`
- `updates/downloads`
- `updates/staged`
- Chromeプロファイル
- リアプロ、いい生活のログイン状態

`dist` は配布物生成用なので作り直してよい。

## 作業手順

### 1. プロジェクトルートへ移動

PowerShell または コマンドプロンプトで、プロジェクトルートへ移動する。

例:

```powershell
cd "C:\path\to\property-list-automation"
```

### 2. 環境確認

```powershell
npm run verify:env
```

期待結果:

- Node.js が使える
- Python 3 が使える
- Chrome が見つかる

### 3. 基本確認

```powershell
npm run verify:basic
```

期待結果:

```text
総合確認: OK
```

### 4. 更新フロー確認

```powershell
npm run verify:update-flow
```

期待結果:

```text
更新フロー確認: OK
```

### 5. Windowsインストーラー配布元を作成

```powershell
npm run build:windows-installer-source
```

期待結果:

- `dist/windows-installer-source/property-list-automation` が作成される
- 実務データ、CSV、バックアップが含まれていない

### 6. Windowsインストーラーexeを作成

簡単な方法:

```powershell
.\BUILD_WINDOWS_INSTALLER.bat
```

または Inno Setup Compiler で次を開いて Compile する。

```text
installer\windows\property-list-automation.iss
```

期待される出力:

```text
dist\property-list-automation-windows-<version>.exe
```

`<version>` は `app-version.json` の `version`。

例:

```text
dist\property-list-automation-windows-2026.07.04.1.exe
```

### 7. リリース配布物を作成

```powershell
npm run build:release-package
```

期待結果:

- `dist/releases/<version>` が作成される
- Mac ZIP が `downloads` に入る
- Windowsインストーラー配布元ZIP が `downloads` に入る
- Windows exe が存在する場合は `downloads` に取り込まれる

### 8. manifestを確定

Windows exeを作った後に実行する。

```powershell
npm run release:finalize-manifest
```

期待結果:

```text
リリースmanifestを確定しました。
```

作成されるもの:

```text
dist/releases/<version>/update-manifest.json
```

もし Windows exe が別フォルダにある場合:

```powershell
node automation/finalize_release_manifest.mjs --windows-exe="C:\path\to\property-list-automation-windows-<version>.exe"
```

### 9. サーバー公開用フォルダを作成

```powershell
npm run build:update-server-public
```

期待結果:

```text
サーバー公開用フォルダを作成しました。
```

作成されるもの:

```text
dist/update-server-public
```

この中身をサーバーへアップロードする。

### 10. 公開用フォルダの確認

次のファイルがあること。

```text
dist/update-server-public/index.html
dist/update-server-public/update-manifest.json
dist/update-server-public/checksums.txt
dist/update-server-public/downloads/property-list-automation-mac-<version>.zip
dist/update-server-public/downloads/property-list-automation-windows-<version>.exe
```

`SERVER_PUBLIC_STATUS.json` の `readyToPublish` が `true` であること。

```powershell
type dist\update-server-public\SERVER_PUBLIC_STATUS.json
```

期待:

```json
"readyToPublish": true
```

## 本番サーバーURLが決まっている場合

本番サーバーURLが決まっている場合は、release package作成時にURLを入れる。

例:

```powershell
node automation/build_release_package.mjs --base-url=https://サーバーURL/downloads --manifest-url=https://サーバーURL/update-manifest.json
```

その後:

```powershell
npm run release:finalize-manifest
npm run build:update-server-public
```

## アップロード後の確認

サーバーへ `dist/update-server-public` の中身をアップロードしたら、ブラウザで確認する。

```text
https://サーバーURL/index.html
https://サーバーURL/update-manifest.json
```

各PCの更新サーバーURLを設定する場合:

```powershell
npm run update:set-url -- --url=https://サーバーURL/update-manifest.json
```

または:

```powershell
.\SET_UPDATE_SERVER_URL.bat
```

## 最終確認

次を実行する。

```powershell
npm run verify:basic
npm run verify:update-flow
```

公開用フォルダに実務データが混ざっていないか確認する。

確認対象:

- `backups`
- `exports`
- `outputs`
- `node_modules`
- 取得済みの `chrome_capture`
- 取得済みの `extension_capture`
- 取得済みの `realpro_chunk_cache`
- 取得済みの `eseikatsu_full_cache`

これらが `dist/update-server-public` に入っていたらNG。

## Windows側Codexへの依頼文

Windows側のCodexには、次のように依頼する。

```text
WINDOWS_CODEX_リリース作成引継ぎ.md を読んで、書かれている順番で Windowsインストーラーexe作成、manifest確定、サーバー公開用フォルダ作成、検証まで進めてください。

実務データ、CSV、バックアップ、Chromeログイン状態は削除・上書きしないでください。

作業後に、作成された exe、update-manifest.json、dist/update-server-public の場所、検証結果、残っている作業を報告してください。
```

## 作業完了時に報告する内容

Windows側Codexは、最後に次を報告する。

- 作成した Windows exe のパス
- `update-manifest.json` のパス
- `dist/update-server-public` のパス
- `SERVER_PUBLIC_STATUS.json` の `readyToPublish`
- `npm run verify:basic` の結果
- `npm run verify:update-flow` の結果
- サーバーへアップロードする必要があるファイル一覧
- エラーや未完了作業
