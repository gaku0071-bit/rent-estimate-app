const EXTENSION_VERSION = "0.2.3";
const serverUrlInput = document.querySelector("#serverUrl");
const realproPagesInput = document.querySelector("#realproPages");
const withDetailsInput = document.querySelector("#withDetails");
const checkServerButton = document.querySelector("#checkServer");
const captureRealproButton = document.querySelector("#captureRealpro");
const statusText = document.querySelector("#statusText");
const barFill = document.querySelector("#barFill");
const tabKind = document.querySelector("#tabKind");
const tabUrl = document.querySelector("#tabUrl");

initPopup();

async function initPopup() {
  const stored = await chrome.storage.local.get(["serverUrl", "realproPages", "withDetails"]);
  if (stored.serverUrl) serverUrlInput.value = stored.serverUrl;
  if (stored.realproPages) realproPagesInput.value = stored.realproPages;
  if (stored.withDetails != null) withDetailsInput.checked = Boolean(stored.withDetails);
  await refreshTabInfo();
}

checkServerButton.addEventListener("click", async () => {
  await saveSettings();
  try {
    setStatus("サーバーを確認しています...", 10);
    const result = await fetchJson(`${serverBaseUrl()}/api/extension/status`);
    const latest = result.latestCapture
      ? `最新: リアプロ${result.latestCapture.realproRooms}戸 / いい生活${result.latestCapture.eSeikatsuRooms}件`
      : "最新取得なし";
    setStatus(`サーバーOK。${latest}`, 100);
  } catch (error) {
    setStatus(`サーバー確認に失敗しました: ${error.message}`, 0);
  }
});

captureRealproButton.addEventListener("click", async () => {
  await saveSettings();
  const target = await targetRealproTab();
  const tab = target?.tab;
  if (!tab?.id) {
    setStatus("同じChrome内でリアプロのリスト検索結果画面を開いてから実行してください。", 0);
    return;
  }

  setBusy(true);
  try {
    const pages = clamp(Number(realproPagesInput.value || 10), 1, 200);
    const sourceText = target.source === "active" ? "" : "（開いているリアプロ一覧タブから）";
    setStatus(`リアプロ${pages}ページを取得します...${sourceText}`, 5);
    const capture = await sendTabMessage(tab.id, {
      type: "REALPRO_CAPTURE",
      pages,
      withDetails: withDetailsInput.checked,
    });
    if (!capture?.ok) throw new Error(capture?.error || "リアプロ取得に失敗しました。");

    setStatus("ローカルシステムへ保存しています...", 92);
    const saved = await fetchJson(`${serverBaseUrl()}/api/extension/realpro-capture`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        extensionVersion: EXTENSION_VERSION,
        capturedAt: new Date().toISOString(),
        realpro: capture.realpro,
      }),
    });
    setStatus(`保存OK。リアプロ${saved.realproRooms}戸 / いい生活${saved.eSeikatsuRooms}件。システム画面で結果を確認してください。`, 100);
  } catch (error) {
    setStatus(`取得に失敗しました: ${error.message}`, 0);
  } finally {
    setBusy(false);
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "REALPRO_EXTENSION_PROGRESS") return;
  const current = Number(message.current || 0);
  const total = Math.max(Number(message.total || 0), 1);
  const base = message.phase === "details" ? 50 : 8;
  const span = message.phase === "details" ? 40 : 42;
  const percent = Math.min(90, Math.round(base + (current / total) * span));
  setStatus(message.text || "取得中...", percent);
});

serverUrlInput.addEventListener("change", saveSettings);
realproPagesInput.addEventListener("change", saveSettings);
withDetailsInput.addEventListener("change", saveSettings);

async function refreshTabInfo() {
  const activeTab = await currentTab();
  const target = await targetRealproTab(activeTab);
  const tab = target?.tab || activeTab;
  const url = String(tab?.url || "");
  tabUrl.textContent = url || "タブを確認できません。";
  if (target?.source === "other" && isRealproListTab(tab)) {
    tabKind.textContent = "リアプロ一覧（別タブ）";
    return;
  }
  if (isRealproListTab(tab)) {
    tabKind.textContent = "リアプロ一覧";
    return;
  }
  if (url.includes("realnetpro.com")) {
    tabKind.textContent = "リアプロ";
    return;
  }
  if (url.includes("rent.e-bukken.app")) {
    tabKind.textContent = "いい生活";
    return;
  }
  tabKind.textContent = "対象外";
}

async function targetRealproTab(activeTab = null) {
  const active = activeTab || await currentTab();
  if (isRealproListTab(active)) return { tab: active, source: "active" };

  const realproTabs = await realproTabsInCurrentWindow();
  const listTab = realproTabs.find(isRealproListTab);
  if (listTab) return { tab: listTab, source: "other" };

  const anyRealproTab = realproTabs.find((tab) => String(tab?.url || "").includes("realnetpro.com"));
  if (anyRealproTab) return { tab: anyRealproTab, source: "other" };

  return { tab: active, source: "active" };
}

async function realproTabsInCurrentWindow() {
  try {
    return await chrome.tabs.query({
      currentWindow: true,
      url: "https://www.realnetpro.com/*",
    });
  } catch {
    return [];
  }
}

function isRealproListTab(tab) {
  const url = String(tab?.url || "");
  return url.includes("realnetpro.com") &&
    url.includes("method=estate") &&
    url.includes("display=building");
}

async function saveSettings() {
  await chrome.storage.local.set({
    serverUrl: serverUrlInput.value,
    realproPages: realproPagesInput.value,
    withDetails: withDetailsInput.checked,
  });
}

async function currentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function sendTabMessage(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(`${error.message}。対象ページを再読み込みしてからもう一度試してください。`));
        return;
      }
      resolve(response);
    });
  });
}

async function fetchJson(url, options) {
  const response = await fetch(url, options);
  const text = await response.text();
  const payload = text ? JSON.parse(text) : {};
  if (!response.ok) throw new Error(payload.detail || payload.error || `HTTP ${response.status}`);
  return payload;
}

function serverBaseUrl() {
  return String(serverUrlInput.value || "http://127.0.0.1:8765").replace(/\/+$/, "");
}

function setBusy(busy) {
  captureRealproButton.disabled = busy;
  checkServerButton.disabled = busy;
}

function setStatus(text, percent) {
  statusText.textContent = text;
  barFill.style.width = `${clamp(Number(percent || 0), 0, 100)}%`;
}

function clamp(value, min, max) {
  if (!Number.isFinite(value)) return min;
  return Math.min(Math.max(Math.trunc(value), min), max);
}
