(() => {
  const REQUEST_TYPE = "PROPERTY_LIST_EXTENSION_CAPTURE";
  const CONDITIONS_TYPE = "PROPERTY_LIST_EXTENSION_APPLY_CONDITIONS";
  const PING_TYPE = "PROPERTY_LIST_EXTENSION_PING";
  const STATUS_TYPE = "PROPERTY_LIST_EXTENSION_STATUS";
  const EVENT_TYPE = "PROPERTY_LIST_EXTENSION_CAPTURE_EVENT";

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const message = event.data || {};
    if (message.type === PING_TYPE) {
      chrome.runtime.sendMessage({
        type: "SYSTEM_EXTENSION_PING",
        requestId: message.requestId,
      }, (response) => {
        const error = chrome.runtime.lastError;
        if (error) {
          postEvent(message.requestId, "error", { error: error.message });
          return;
        }
        postEvent(message.requestId, "pong", response || {});
      });
      return;
    }

    if (message.type === STATUS_TYPE) {
      chrome.runtime.sendMessage({
        type: "SYSTEM_EXTENSION_STATUS",
        requestId: message.requestId,
      }, (response) => {
        const error = chrome.runtime.lastError;
        if (error) {
          postEvent(message.requestId, "error", { error: error.message });
          return;
        }
        postEvent(message.requestId, "status", response || {});
      });
      return;
    }

    if (message.type === CONDITIONS_TYPE) {
      chrome.runtime.sendMessage({
        type: "SYSTEM_APPLY_REALPRO_CONDITIONS",
        requestId: message.requestId,
        payload: message.payload || {},
      }, (response) => {
        const error = chrome.runtime.lastError;
        if (error) {
          postEvent(message.requestId, "error", { error: error.message });
          return;
        }
        postEvent(message.requestId, "accepted", response || {});
      });
      return;
    }

    if (message.type !== REQUEST_TYPE) return;

    chrome.runtime.sendMessage({
      type: "SYSTEM_CAPTURE_REALPRO",
      requestId: message.requestId,
      payload: message.payload || {},
    }, (response) => {
      const error = chrome.runtime.lastError;
      if (error) {
        postEvent(message.requestId, "error", { error: error.message });
        return;
      }
      postEvent(message.requestId, "accepted", response || {});
    });
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type !== "SYSTEM_CAPTURE_EVENT") return;
    postEvent(message.requestId, message.event, message.payload || {});
  });

  function postEvent(requestId, event, payload = {}) {
    window.postMessage({
      type: EVENT_TYPE,
      requestId,
      event,
      payload,
    }, window.location.origin);
  }
})();
