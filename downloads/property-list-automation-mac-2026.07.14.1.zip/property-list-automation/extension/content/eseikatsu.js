chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "ESEIKATSU_STATUS") return false;
  sendResponse({
    ok: true,
    kind: "eSeikatsu",
    title: document.title || "",
    url: location.href,
  });
  return false;
});
