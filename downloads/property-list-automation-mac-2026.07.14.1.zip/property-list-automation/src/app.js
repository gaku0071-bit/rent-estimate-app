const CSV_SCHEMA_VERSION = "2026-06-22.1";
const MAX_PREVIEW_ROWS = 250;

const railwayStations = {
  "地下南北線": [
    "麻生",
    "北34条",
    "北24条",
    "北18条",
    "北12条",
    "さっぽろ",
    "大通",
    "すすきの",
    "中島公園",
    "幌平橋",
    "中の島",
    "平岸",
    "南平岸",
    "澄川",
    "自衛隊前",
    "真駒内",
  ],
  "地下東西線": [
    "宮の沢",
    "発寒南",
    "琴似",
    "二十四軒",
    "西28丁目",
    "円山公園",
    "西18丁目",
    "西11丁目",
    "大通",
    "バスセンター前",
    "菊水",
    "東札幌",
    "白石",
    "南郷7丁目",
    "南郷13丁目",
    "南郷18丁目",
    "大谷地",
    "ひばりが丘",
    "新さっぽろ",
  ],
  "地下東豊線": [
    "栄町",
    "新道東",
    "元町",
    "環状通東",
    "東区役所前",
    "北13条東",
    "さっぽろ",
    "大通",
    "豊水すすきの",
    "学園前",
    "豊平公園",
    "美園",
    "月寒中央",
    "福住",
  ],
  "札幌市電": [
    "西4丁目",
    "西8丁目",
    "中央区役所前",
    "西15丁目",
    "西線6条",
    "西線9条旭山公園通",
    "西線11条",
    "西線14条",
    "西線16条",
    "ロープウェイ入口",
    "電車事業所前",
    "中央図書館前",
    "石山通",
    "東屯田通",
    "幌南小学校前",
    "山鼻19条",
    "静修学園前",
    "行啓通",
    "中島公園通",
    "山鼻9条",
    "東本願寺前",
    "資生館小学校前",
    "すすきの",
    "狸小路",
  ],
  "JR函館本線": [
    "ほしみ",
    "星置",
    "稲穂",
    "手稲",
    "稲積公園",
    "発寒",
    "発寒中央",
    "琴似",
    "桑園",
    "札幌",
    "苗穂",
    "白石",
    "厚別",
    "森林公園",
  ],
  "JR千歳線": ["札幌", "苗穂", "白石", "平和", "新札幌", "上野幌"],
  "JR札沼線": [
    "札幌",
    "桑園",
    "八軒",
    "新川",
    "新琴似",
    "太平",
    "百合が原",
    "篠路",
    "拓北",
    "あいの里教育大",
    "あいの里公園",
  ],
};

const realproRooms = [
  {
    building: "センテベーネ",
    room: "201",
    address: "札幌市西区二十四軒四条4丁目",
    line: "地下東西線",
    station: "琴似",
    accessMethod: "徒歩",
    walkMinutes: 2,
    layout: "2LDK",
    area: "51.03㎡",
    rent: 81000,
    fee: 3000,
    status: "商談中",
    availableDate: "2026年07月01日",
    adFee: "1ヶ月",
    equipment: ["バス・トイレ別", "独立洗面台", "オートロック", "駐車場空きあり"],
    webAd: "可",
    imageReuse: "可能",
    floorPlanReuse: "可能",
    priorContact: "不要",
    applicationCount: 0,
    url: "https://www.realnetpro.com/main.php?method=estate&display=building",
  },
  {
    building: "センテベーネ",
    address: "札幌市西区二十四軒四条4丁目",
    room: "302",
    line: "地下東西線",
    station: "琴似",
    accessMethod: "徒歩",
    walkMinutes: 2,
    layout: "2LDK",
    area: "51.03㎡",
    rent: 82000,
    fee: 3000,
    status: "空室",
    availableDate: "2026年07月01日",
    adFee: "1ヶ月",
    equipment: ["バス・トイレ別", "独立洗面台", "オートロック", "駐車場空きあり"],
    webAd: "可",
    imageReuse: "可能",
    floorPlanReuse: "可能",
    priorContact: "不要",
    applicationCount: 0,
    url: "https://www.realnetpro.com/main.php?method=estate&display=building",
  },
  {
    building: "RioVista",
    room: "501",
    address: "札幌市豊平区水車町7丁目",
    line: "地下南北線",
    station: "中の島",
    accessMethod: "徒歩",
    walkMinutes: 10,
    layout: "ワンルーム",
    area: "29.17㎡",
    rent: 44000,
    fee: 6000,
    status: "空室",
    availableDate: "即入",
    adFee: "2ヶ月",
    equipment: ["バス・トイレ別", "エアコン", "宅配ボックス"],
    webAd: "可",
    imageReuse: "可能",
    floorPlanReuse: "可能",
    priorContact: "不要",
    applicationCount: 0,
    url: "https://www.realnetpro.com/main.php?method=estate&display=building",
  },
  {
    building: "RioVista",
    room: "601",
    address: "札幌市豊平区水車町7丁目",
    line: "地下南北線",
    station: "中の島",
    accessMethod: "徒歩",
    walkMinutes: 10,
    layout: "ワンルーム",
    area: "29.17㎡",
    rent: 45000,
    fee: 6000,
    status: "空室",
    availableDate: "即入",
    adFee: "2ヶ月",
    equipment: ["バス・トイレ別", "エアコン", "宅配ボックス"],
    webAd: "可",
    imageReuse: "可能",
    floorPlanReuse: "可能",
    priorContact: "不要",
    applicationCount: 0,
    url: "https://www.realnetpro.com/main.php?method=estate&display=building",
  },
  {
    building: "RioVista",
    room: "203",
    address: "札幌市豊平区水車町7丁目",
    line: "地下南北線",
    station: "中の島",
    accessMethod: "徒歩",
    walkMinutes: 10,
    layout: "2LDK",
    area: "54.65㎡",
    rent: 72000,
    fee: 9000,
    status: "空室",
    availableDate: "即入",
    adFee: "2ヶ月",
    equipment: ["バス・トイレ別", "独立洗面台", "エアコン"],
    webAd: "可",
    imageReuse: "可能",
    floorPlanReuse: "可能",
    priorContact: "不要",
    applicationCount: 0,
    url: "https://www.realnetpro.com/main.php?method=estate&display=building",
  },
  {
    building: "Roi Chic",
    room: "301",
    address: "札幌市中央区南十五条西12丁目",
    line: "札幌市電",
    station: "西線14条",
    accessMethod: "徒歩",
    walkMinutes: 5,
    layout: "2LDK",
    area: "60.92㎡",
    rent: 95000,
    fee: 3500,
    status: "退去予定",
    availableDate: "2026年06月下旬",
    adFee: "2ヶ月",
    equipment: ["バス・トイレ別", "独立洗面台", "エアコン", "防犯カメラ"],
    webAd: "管理会社に確認",
    imageReuse: "可能",
    floorPlanReuse: "可能",
    priorContact: "必要",
    applicationCount: 0,
    url: "https://www.realnetpro.com/main.php?method=estate&display=building",
  },
  {
    building: "NIPPO Core 月寒中央",
    room: "102",
    address: "札幌市豊平区月寒東二条7丁目",
    line: "地下東豊線",
    station: "月寒中央",
    accessMethod: "徒歩",
    walkMinutes: 7,
    layout: "1DK",
    area: "32.4㎡",
    rent: 38000,
    fee: 2000,
    status: "空室",
    availableDate: "即入",
    adFee: "2ヶ月",
    equipment: ["バス・トイレ別", "暖房"],
    webAd: "許可されていません",
    imageReuse: "可能",
    floorPlanReuse: "可能",
    priorContact: "不要",
    applicationCount: 0,
    url: "https://www.realnetpro.com/main.php?method=estate&display=building",
  },
  {
    building: "effort N11",
    room: "402",
    address: "札幌市東区北十一条東6丁目",
    line: "地下東豊線",
    station: "東区役所前",
    accessMethod: "徒歩",
    walkMinutes: 4,
    layout: "1LDK",
    area: "41.18㎡",
    rent: 63000,
    fee: 3000,
    status: "退去予定",
    availableDate: "2026年06月中旬",
    adFee: "1.5ヶ月",
    equipment: ["バス・トイレ別", "独立洗面台", "オートロック", "インターネット無料"],
    webAd: "可",
    imageReuse: "可能",
    floorPlanReuse: "可能",
    priorContact: "不要",
    applicationCount: 1,
    url: "https://www.realnetpro.com/main.php?method=estate&display=building",
  },
];

const eSeikatsuRooms = [
  {
    building: "RioVista",
    room: "501",
    layout: "ワンルーム",
    status: "募集止",
    listing: "未掲載",
    url: "https://rent.e-bukken.app/",
  },
  {
    building: "センテベーネ",
    room: "201",
    layout: "2LDK",
    status: "募集中",
    listing: "掲載中",
    url: "https://rent.e-bukken.app/",
  },
  {
    building: "NIPPO Core 月寒中央",
    room: "102",
    layout: "1DK",
    status: "募集中",
    listing: "掲載中",
    url: "https://rent.e-bukken.app/",
  },
];

const previewRows = document.querySelector("#previewRows");
const searchForm = document.querySelector("#searchForm");
const downloadSample = document.querySelector("#downloadSample");
const downloadAllRows = document.querySelector("#downloadAllRows");
const downloadPracticalRows = document.querySelector("#downloadPracticalRows");
const downloadWorkRows = document.querySelector("#downloadWorkRows");
const downloadReviewRows = document.querySelector("#downloadReviewRows");
const saveCsvFiles = document.querySelector("#saveCsvFiles");
const downloadDetailUnconfirmedRows = document.querySelector("#downloadDetailUnconfirmedRows");
const resetSearchConditions = document.querySelector("#resetSearchConditions");
const showExcludedToggle = document.querySelector("#showExcluded");
const resultTypeFilter = document.querySelector("#resultTypeFilter");
const resultTextFilter = document.querySelector("#resultTextFilter");
const clearResultFilters = document.querySelector("#clearResultFilters");
const candidateCoverageNote = document.querySelector("#candidateCoverageNote");
const loadLatestCapture = document.querySelector("#loadLatestCapture");
const loadVerificationSample = document.querySelector("#loadVerificationSample");
const loadVerificationSampleDefault = document.querySelector("#loadVerificationSampleDefault");
const runChromeCaptureButton = document.querySelector("#runChromeCapture");
const runFastCaptureButton = document.querySelector("#runFastCapture");
const resumeFastDetailsButton = document.querySelector("#resumeFastDetails");
const runRealproChunkCaptureButton = document.querySelector("#runRealproChunkCapture");
const runPreflightCheck = document.querySelector("#runPreflightCheck");
const checkVerificationBasic = document.querySelector("#checkVerificationBasic");
const checkVerificationJson = document.querySelector("#checkVerificationJson");
const checkVerificationRules = document.querySelector("#checkVerificationRules");
const checkChromeTabs = document.querySelector("#checkChromeTabs");
const checkServerStatus = document.querySelector("#checkServerStatus");
const clearCurrentCapture = document.querySelector("#clearCurrentCapture");
const chromeTabStatus = document.querySelector("#chromeTabStatus");
const chromeTabHistory = document.querySelector("#chromeTabHistory");
const opsCheckTabs = document.querySelector("#opsCheckTabs");
const opsRealproTabTarget = document.querySelector("#opsRealproTabTarget");
const opsESeikatsuTabTarget = document.querySelector("#opsESeikatsuTabTarget");
const opsRealproCapturePages = document.querySelector("#opsRealproCapturePages");
const realproLoggedIn = document.querySelector("#realproLoggedIn");
const eSeikatsuLoggedIn = document.querySelector("#eSeikatsuLoggedIn");
const eSeikatsuListingOpen = document.querySelector("#eSeikatsuListingOpen");
const readinessStatus = document.querySelector("#readinessStatus");
const connectionBand = document.querySelector("#connectionBand");
const conditionBuilder = document.querySelector("#conditionBuilder");
const workflowSurface = document.querySelector("#workflowSurface");
const realproServiceState = document.querySelector("#realproServiceState");
const eSeikatsuServiceState = document.querySelector("#eSeikatsuServiceState");
const workflowReady = document.querySelector("#workflowReady");
const workflowRunning = document.querySelector("#workflowRunning");
const workflowComplete = document.querySelector("#workflowComplete");
const workflowMonitor = document.querySelector("#workflowMonitor");
const workflowCurrentTitle = document.querySelector("#workflowCurrentTitle");
const workflowCurrentText = document.querySelector("#workflowCurrentText");
const workflowNextAction = document.querySelector("#workflowNextAction");
const workflowStages = {
  prepare: document.querySelector("#workflowStagePrepare"),
  list: document.querySelector("#workflowStageList"),
  details: document.querySelector("#workflowStageDetails"),
  compare: document.querySelector("#workflowStageCompare"),
  candidates: document.querySelector("#workflowStageCandidates"),
  done: document.querySelector("#workflowStageDone"),
};
const workflowRunningTitle = document.querySelector("#workflowRunningTitle");
const workflowRunningMessage = document.querySelector("#workflowRunningMessage");
const workflowElapsedTime = document.querySelector("#workflowElapsedTime");
const workflowProgressBar = document.querySelector("#workflowProgressBar");
const workflowPageProgress = document.querySelector("#workflowPageProgress");
const workflowRoomProgress = document.querySelector("#workflowRoomProgress");
const workflowJudgedProgress = document.querySelector("#workflowJudgedProgress");
const workflowCandidateProgress = document.querySelector("#workflowCandidateProgress");
const workflowRemainingTime = document.querySelector("#workflowRemainingTime");
const workflowCompleteTitle = document.querySelector("#workflowCompleteTitle");
const workflowCompleteText = document.querySelector("#workflowCompleteText");
const workflowWorkCount = document.querySelector("#workflowWorkCount");
const workflowReviewCount = document.querySelector("#workflowReviewCount");
const workflowExcludedCount = document.querySelector("#workflowExcludedCount");
const workflowUnknownCount = document.querySelector("#workflowUnknownCount");
const workflowSaveCsv = document.querySelector("#workflowSaveCsv");
const realproCapturePages = document.querySelector("#realproCapturePages");
const realproStartPage = document.querySelector("#realproStartPage");
const eSeikatsuCapturePages = document.querySelector("#eSeikatsuCapturePages");
const capturePlan = document.querySelector("#capturePlan");
const setESeikatsuFullPages = document.querySelector("#setESeikatsuFullPages");
const buildESeikatsuCache = document.querySelector("#buildESeikatsuCache");
const retryRealproDetails = document.querySelector("#retryRealproDetails");
const retryZeroRoomPages = document.querySelector("#retryZeroRoomPages");
const applyRealproConditions = document.querySelector("#applyRealproConditions");
const applyRealproConditionsAndSearch = document.querySelector("#applyRealproConditionsAndSearch");
const applyRealproConditionsMain = document.querySelector("#applyRealproConditionsMain");
const applyRealproConditionsAndSearchMain = document.querySelector("#applyRealproConditionsAndSearchMain");
const selectedConditions = document.querySelector("#selectedConditions");
const conditionStatus = document.querySelector("#conditionStatus");
const conditionJsonInput = document.querySelector("#conditionJsonInput");
const applyConditionJson = document.querySelector("#applyConditionJson");
const clearConditionJson = document.querySelector("#clearConditionJson");
const conditionRestoreHistory = document.querySelector("#conditionRestoreHistory");
const lineChoices = document.querySelector("#lineChoices");
const stationChoices = document.querySelector("#stationChoices");
const emptyStations = document.querySelector("#emptyStations");
const searchPresetSelect = document.querySelector("#searchPresetSelect");
const searchPresetName = document.querySelector("#searchPresetName");
const loadSearchPreset = document.querySelector("#loadSearchPreset");
const saveSearchPreset = document.querySelector("#saveSearchPreset");
const deleteSearchPreset = document.querySelector("#deleteSearchPreset");
const searchPresetStatus = document.querySelector("#searchPresetStatus");
const runtimeNotice = document.querySelector("#runtimeNotice");
const currentServerUrl = document.querySelector("#currentServerUrl");
const serverUrlState = document.querySelector("#serverUrlState");
const copyCurrentServerUrl = document.querySelector("#copyCurrentServerUrl");
const reloadCurrentPage = document.querySelector("#reloadCurrentPage");
const checkExtensionStatus = document.querySelector("#checkExtensionStatus");
const loadExtensionCapture = document.querySelector("#loadExtensionCapture");
const extensionCaptureState = document.querySelector("#extensionCaptureState");
const extensionLatestState = document.querySelector("#extensionLatestState");
const extensionStatusText = document.querySelector("#extensionStatusText");
const resultSummary = document.querySelector("#resultSummary");
const csvSummary = document.querySelector("#csvSummary");
const savedCsvLinks = document.querySelector("#savedCsvLinks");
const csvHistory = document.querySelector("#csvHistory");
const csvSchemaVersion = document.querySelector("#csvSchemaVersion");
const exclusionSummary = document.querySelector("#exclusionSummary");
const resultViewSummary = document.querySelector("#resultViewSummary");
const actionSummary = document.querySelector("#actionSummary");
const resultTypeSummary = document.querySelector("#resultTypeSummary");
const verificationStatus = document.querySelector("#verificationStatus");
const captureFile = document.querySelector("#captureFile");
const downloadVisibleRows = document.querySelector("#downloadVisibleRows");
const importStatus = document.querySelector("#importStatus");
const completionToast = document.querySelector("#completionToast");
const completionToastAction = document.querySelector("#completionToastAction");
const completionToastClose = document.querySelector("#completionToastClose");
const completionToastTitle = document.querySelector("#completionToastTitle");
const completionToastMessage = document.querySelector("#completionToastMessage");
const completionToastMeta = document.querySelector("#completionToastMeta");
const updateStatusButton = document.querySelector("#updateStatusButton");
const updateToast = document.querySelector("#updateToast");
const updateToastTitle = document.querySelector("#updateToastTitle");
const updateToastMessage = document.querySelector("#updateToastMessage");
const updateToastNotes = document.querySelector("#updateToastNotes");
const updateNowButton = document.querySelector("#updateNowButton");
const updateLaterButton = document.querySelector("#updateLaterButton");
const captureSummary = document.querySelector("#captureSummary");
const importHistory = document.querySelector("#importHistory");
const preflightHistory = document.querySelector("#preflightHistory");
const productionChecklistSummary = document.querySelector("#productionChecklistSummary");
const completeProductionChecklist = document.querySelector("#completeProductionChecklist");
const resetProductionChecklist = document.querySelector("#resetProductionChecklist");
const productionMemo = document.querySelector("#productionMemo");
const clearProductionMemo = document.querySelector("#clearProductionMemo");
const freshnessReviewHistory = document.querySelector("#freshnessReviewHistory");
const captureQualityReviewHistory = document.querySelector("#captureQualityReviewHistory");
const detailUnconfirmedReviewHistory = document.querySelector("#detailUnconfirmedReviewHistory");
let latestRows = [];
let latestStats = { total: 0, shown: 0, excluded: 0, duplicated: 0 };
let importedRealproRooms = [];
let importedESeikatsuRooms = [];
let hasLoadedCaptureData = false;
let captureIsRunning = false;
let captureProgressTimer = 0;
let captureProgressSource = "";
let captureLastError = "";
let currentWorkflowStage = "prepare";
let currentImportMeta = null;
let currentSearchPresetName = "";
let lastRealproSearchResult = null;
let lastChromeTabStatus = null;
let lastLiveCaptureProgress = null;
let latestServerCsvForOps = null;
let activeExtensionCaptureRequestId = "";
let eSeikatsuReviewRunning = false;
let eSeikatsuReviewPromise = null;
let eSeikatsuReviewPollTimer = 0;
let eSeikatsuReviewGeneration = 0;
let eSeikatsuReviewAbortController = null;

function setCurrentSearchPresetName(name) {
  currentSearchPresetName = name || "";
  if (currentSearchPresetName) {
    localStorage.setItem("currentSearchPresetName", currentSearchPresetName);
  } else {
    localStorage.removeItem("currentSearchPresetName");
  }
}

function restoreCurrentSearchPresetName() {
  currentSearchPresetName = localStorage.getItem("currentSearchPresetName") || "";
}

function restoreLastRealproSearchResult() {
  try {
    lastRealproSearchResult = JSON.parse(localStorage.getItem("lastRealproSearchResult") || "null");
  } catch {
    localStorage.removeItem("lastRealproSearchResult");
    lastRealproSearchResult = null;
  }
}

function saveLastRealproSearchResult(result = {}) {
  lastRealproSearchResult = {
    criteriaJson: selectedConditionJson(),
    searchSummary: String(result.searchSummary || "").trim(),
    submitted: Boolean(result.submitted),
    appliedCount: Array.isArray(result.applied) ? result.applied.length : 0,
    skipped: Array.isArray(result.skipped) ? result.skipped : [],
    updatedAt: new Date().toISOString(),
  };
  localStorage.setItem("lastRealproSearchResult", JSON.stringify(lastRealproSearchResult));
}

function currentRealproSearchResult() {
  if (!lastRealproSearchResult?.submitted) return null;
  if (!lastRealproSearchResult.searchSummary) return null;
  return normalizeCriteriaJson(lastRealproSearchResult.criteriaJson) === selectedConditionJson()
    ? lastRealproSearchResult
    : null;
}

function renderRailwayChoices() {
  lineChoices.innerHTML = Object.keys(railwayStations)
    .map((line) => `<label><input type="checkbox" name="line" value="${line}" /> ${line}</label>`)
    .join("");

  stationChoices.innerHTML = Object.entries(railwayStations)
    .map(([line, stations]) => `
      <div class="station-group" data-line-group="${line}" hidden>
        <div class="station-group-heading">
          <div class="station-group-title">${line}</div>
          <label class="select-all-stations">
            <input type="checkbox" name="selectAllStations" value="${line}" />
            この路線の駅をすべて選択
          </label>
        </div>
        <div class="station-row">
          ${stations.map((station) => `<label><input type="checkbox" name="station" value="${line}:${station}" data-station-name="${station}" /> ${station}</label>`).join("")}
        </div>
      </div>
    `)
    .join("");
}

function applyUiModeFromUrl() {
  const params = new URLSearchParams(location.search);
  const mode = params.get("mode") || "";
  const maintenance = mode === "maintenance" || params.get("maintenance") === "1" || params.get("admin") === "1";
  document.body.classList.toggle("maintenance-mode", maintenance);
  document.body.classList.toggle("practical-mode", !maintenance);
}

function renderRuntimeNotice() {
  if (!runtimeNotice) return;
  if (location.protocol === "file:") {
    runtimeNotice.hidden = false;
    runtimeNotice.innerHTML = `
      <div>
        現在 file:// で開いています。画面確認はできますが、Chrome取得・最新JSON読み込み・検証サンプル読み込みはサーバー版で使ってください。
        <div class="runtime-hint">普段は Mac: 物件候補リスト作成.command / Windows: 物件候補リスト作成.bat から起動できます。</div>
      </div>
      <a class="notice-action" href="${serverIndexUrl()}">サーバー版を開く</a>
    `;
    setServerOnlyControls(true);
    return;
  }

  runtimeNotice.hidden = true;
  runtimeNotice.innerHTML = "";
  setServerOnlyControls(false);
}

function renderCurrentServerUrl() {
  if (!currentServerUrl) return;
  currentServerUrl.textContent = location.protocol === "file:"
    ? "file:// 表示中。サーバー版ではありません"
    : serverIndexUrl();
  updateServerUrlStripStatus(location.protocol === "file:" ? "warn" : "", location.protocol === "file:" ? "サーバー版ではありません" : "未確認");
}

function updateServerUrlStripStatus(status = "", label = "") {
  const strip = currentServerUrl?.closest(".server-url-strip");
  if (!strip) return;
  strip.classList.toggle("server-url-strip-ok", status === "ok");
  strip.classList.toggle("server-url-strip-warn", status === "warn");
  if (serverUrlState && label) serverUrlState.textContent = label;
}

function setServerOnlyControls(isFileMode) {
  [runChromeCaptureButton, runFastCaptureButton, runRealproChunkCaptureButton, retryZeroRoomPages, loadLatestCapture, loadVerificationSample, loadVerificationSampleDefault, checkVerificationBasic, checkVerificationJson, checkVerificationRules, checkServerStatus].forEach((button) => {
    if (!button) return;
    button.title = isFileMode
      ? `この機能は ${serverIndexUrl()} で開くと使えます。`
      : "";
  });
}

function serverIndexUrl() {
  if (location.protocol === "http:" || location.protocol === "https:") {
    return `${location.origin}/index.html`;
  }
  return "http://127.0.0.1:8765/index.html";
}

function serverModeLinkText(label = "こちらを開いてください") {
  return `<a href="${serverIndexUrl()}">${escapeHtml(label)}</a>`;
}

async function refreshServerUrlStatus() {
  if (location.protocol === "file:") {
    updateServerUrlStripStatus("warn", "サーバー版ではありません");
    return { ok: false, reason: "file" };
  }

  try {
    const response = await fetch(`/api/status?ts=${Date.now()}`);
    if (!response.ok) {
      updateServerUrlStripStatus("warn", `HTTP ${response.status}`);
      return { ok: false, httpStatus: response.status };
    }
    const status = await response.json();
    if (status.csvSchemaVersion !== CSV_SCHEMA_VERSION) {
      updateServerUrlStripStatus("warn", "CSV形式違い");
      return { ...status, ok: false, reason: "schema" };
    }
    updateServerUrlStripStatus(status.docsAvailable ? "ok" : "warn", status.docsAvailable ? "OK" : "注意");
    return status;
  } catch {
    updateServerUrlStripStatus("warn", "確認失敗");
    return { ok: false, reason: "fetch" };
  }
}

function setCsvControls() {
  [downloadVisibleRows, downloadWorkRows, downloadReviewRows, downloadSample, downloadAllRows, downloadDetailUnconfirmedRows].forEach((button) => {
    if (!button) return;
    button.disabled = !hasLoadedCaptureData;
    button.title = hasLoadedCaptureData ? "" : "先にChrome取得、最新取得JSON、または検証サンプルを読み込んでください。";
  });
  renderCsvSummary();
}

function renderCsvSchemaVersion() {
  if (!csvSchemaVersion) return;
  csvSchemaVersion.textContent = CSV_SCHEMA_VERSION;
}

function restoreProductionChecklist() {
  const saved = productionChecklistState();
  const selected = new Set(saved.checked);
  document.querySelectorAll('input[name="productionChecklist"]').forEach((input) => {
    input.checked = selected.has(input.value);
  });
  renderProductionChecklistSummary();
}

function productionChecklistState() {
  const saved = JSON.parse(localStorage.getItem("productionChecklist") || "[]");
  if (Array.isArray(saved)) return { checked: saved, checkedAt: {} };
  return {
    checked: Array.isArray(saved.checked) ? saved.checked : [],
    checkedAt: saved.checkedAt && typeof saved.checkedAt === "object" ? saved.checkedAt : {},
  };
}

function productionChecklistLabel(value) {
  const labels = {
    source: "取得元",
    realproDetail: "リアプロ詳細",
    excluded: "除外判定",
    detailUnconfirmedReview: "詳細未確認検証",
    replacement: "差替候補",
    csv: "CSV確認",
  };
  return labels[value] ?? value;
}

function productionChecklistCsvText() {
  const inputs = [...document.querySelectorAll('input[name="productionChecklist"]')];
  const state = productionChecklistState();
  const checked = new Set(state.checked);
  return inputs
    .map((input) => {
      const status = checked.has(input.value) ? "済" : "未";
      const checkedAt = state.checkedAt[input.value] ? ` ${formatDateTime(state.checkedAt[input.value])}` : "";
      return `${productionChecklistLabel(input.value)}:${status}${checkedAt}`;
    })
    .join(" / ");
}

function productionChecklistProgressText() {
  const inputs = [...document.querySelectorAll('input[name="productionChecklist"]')];
  const checkedCount = inputs.filter((input) => input.checked).length;
  const state = productionChecklistState();
  const latestCheckedAt = Object.values(state.checkedAt).sort().at(-1);
  const latestLabel = latestCheckedAt ? ` / 最終チェック:${formatDateTime(latestCheckedAt)}` : "";
  return `${checkedCount}/${inputs.length}${latestLabel}`;
}

function productionChecklistIncompleteText() {
  const inputs = [...document.querySelectorAll('input[name="productionChecklist"]')];
  const missing = inputs
    .filter((input) => !input.checked)
    .map((input) => productionChecklistLabel(input.value));
  return missing.length ? `本番検証未完了: ${missing.join("、")}` : "";
}

function saveProductionChecklist(event) {
  const current = productionChecklistState();
  const checkedAt = { ...current.checkedAt };
  if (event?.target?.name === "productionChecklist") {
    if (event.target.checked) {
      checkedAt[event.target.value] = new Date().toISOString();
    } else {
      delete checkedAt[event.target.value];
    }
  }
  const checked = [...document.querySelectorAll('input[name="productionChecklist"]:checked')].map((input) => input.value);
  localStorage.setItem("productionChecklist", JSON.stringify({ checked, checkedAt }));
  renderProductionChecklistSummary();
}

function renderProductionChecklistSummary() {
  if (!productionChecklistSummary) return;
  const inputs = [...document.querySelectorAll('input[name="productionChecklist"]')];
  const checkedCount = inputs.filter((input) => input.checked).length;
  const state = productionChecklistState();
  const latestCheckedAt = Object.values(state.checkedAt).sort().at(-1);
  const latestLabel = latestCheckedAt ? ` / 最終チェック: ${formatDateTime(latestCheckedAt)}` : "";
  productionChecklistSummary.textContent = `本番検証: ${checkedCount}/${inputs.length} 完了${latestLabel}`;
  productionChecklistSummary.className = `note checklist-summary ${checkedCount === inputs.length && inputs.length ? "status-ok" : ""}`;
  document.querySelectorAll("[data-check-time]").forEach((item) => {
    const checkedAt = state.checkedAt[item.dataset.checkTime];
    item.textContent = checkedAt ? `確認日時: ${formatDateTime(checkedAt)}` : "";
  });
}

function resetProductionChecklistItems() {
  document.querySelectorAll('input[name="productionChecklist"]').forEach((input) => {
    input.checked = false;
  });
  localStorage.removeItem("productionChecklist");
  renderProductionChecklistSummary();
}

function completeProductionChecklistItems() {
  const now = new Date().toISOString();
  const checkedAt = {};
  const checked = [...document.querySelectorAll('input[name="productionChecklist"]')].map((input) => {
    input.checked = true;
    checkedAt[input.value] = now;
    return input.value;
  });
  localStorage.setItem("productionChecklist", JSON.stringify({ checked, checkedAt }));
  renderProductionChecklistSummary();
  renderCsvSummary();
}

function autoCheckProductionItems(values) {
  const current = productionChecklistState();
  const checked = new Set(current.checked);
  const checkedAt = { ...current.checkedAt };
  const now = new Date().toISOString();

  values.forEach((value) => {
    checked.add(value);
    if (!checkedAt[value]) checkedAt[value] = now;
  });

  document.querySelectorAll('input[name="productionChecklist"]').forEach((input) => {
    input.checked = checked.has(input.value);
  });
  localStorage.setItem("productionChecklist", JSON.stringify({ checked: [...checked], checkedAt }));
  renderProductionChecklistSummary();
  renderCsvSummary();
}

function restoreProductionMemo() {
  if (!productionMemo) return;
  productionMemo.value = localStorage.getItem("productionMemo") ?? "";
}

function saveProductionMemo() {
  if (!productionMemo) return;
  localStorage.setItem("productionMemo", productionMemo.value.trim());
}

function productionMemoText() {
  return productionMemo?.value?.trim() ?? "";
}

function clearProductionMemoText() {
  if (!productionMemo) return;
  productionMemo.value = "";
  localStorage.removeItem("productionMemo");
}

function appendProductionMemoTemplate(text) {
  if (!productionMemo || !text) return;
  const current = productionMemo.value.trim();
  productionMemo.value = current ? `${current}\n${text}` : text;
  saveProductionMemo();
}

function restoreLoginChecks() {
  realproLoggedIn.checked = localStorage.getItem("realproLoggedIn") === "true";
  eSeikatsuLoggedIn.checked = localStorage.getItem("eSeikatsuLoggedIn") === "true";
  if (eSeikatsuListingOpen) {
    eSeikatsuListingOpen.checked = localStorage.getItem("eSeikatsuListingOpen") === "true";
  }
  renderReadinessStatus();
}

function saveLoginCheck(event) {
  localStorage.setItem(event.target.id, String(event.target.checked));
  renderReadinessStatus();
}

function placeConditionBuilderAtTop() {
  if (!conditionBuilder || !connectionBand) return;
  if (conditionBuilder.previousElementSibling === connectionBand) return;
  connectionBand.after(conditionBuilder);
  conditionBuilder.classList.add("top-condition-builder");
  workflowSurface?.classList.add("workflow-after-conditions");
}

function placeCandidateResultsNearTop() {
  const resultPanel = document.getElementById("opsResultPanel");
  const results = document.getElementById("candidateResults");
  if (!resultPanel || !results) return;
  if (resultPanel.nextElementSibling !== results) resultPanel.after(results);
  results.classList.add("priority-results-panel");
}

function captureReadinessMessage() {
  const missing = [];
  if (!realproLoggedIn?.checked) missing.push("リアプロにログイン済み");
  if (!eSeikatsuLoggedIn?.checked) missing.push("いい生活にログイン済み");
  if (!eSeikatsuListingOpen?.checked) missing.push("いい生活の物件一覧/広告画面を開いている");
  if (location.protocol === "file:") missing.push(`${serverIndexUrl()}で開く`);
  return missing.length ? `取得前チェック: ${missing.join("、")} を確認してください。` : "";
}

function renderReadinessStatus() {
  if (!readinessStatus) return;
  const message = captureReadinessMessage();
  readinessStatus.textContent = message || "取得前チェックOKです。Chrome取得を開始できます。";
  readinessStatus.className = `readiness-status ${message ? "status-warn-inline" : "status-ok-inline"}`;
  if (!captureIsRunning && !hasLoadedCaptureData && !captureLastError) {
    updateWorkflowMonitor({
      state: message ? "ready" : "ready-ok",
      stage: "prepare",
      title: message ? "検索条件を決める" : "件数確認後に取得できます",
      text: message
        ? "条件を選んでリアプロへ反映し、件数を確認してからChrome準備を確認してください。"
        : "リアプロといい生活の準備が確認できています。リアプロ側の件数を確認したら取得を開始できます。",
      nextAction: message ? "条件入力・準備確認" : "リアプロを取得",
    });
  }
  const realproReady = Boolean(realproLoggedIn?.checked);
  const eSeikatsuReady = Boolean(eSeikatsuLoggedIn?.checked && eSeikatsuListingOpen?.checked);
  if (realproServiceState) realproServiceState.textContent = realproReady ? "接続済み" : "未確認";
  if (eSeikatsuServiceState) eSeikatsuServiceState.textContent = eSeikatsuReady ? "接続済み" : "未確認";
  connectionBand?.classList.toggle("connected", realproReady && eSeikatsuReady);
  renderOpsDashboard();
}

function renderCapturePlan() {
  if (!capturePlan) return;
  const realproPages = clampCapturePages(realproCapturePages?.value, 2, 200);
  const startPage = clampCapturePages(realproStartPage?.value, 1, 10000);
  const eSeikatsuPages = clampCapturePages(eSeikatsuCapturePages?.value, 2, 200);
  const realproRows = realproPages * 20;
  const totalPages = realproPages + eSeikatsuPages;
  const warnings = [];
  const zeroRoomPages = realproZeroRoomPages(currentImportMeta?.realproPages ?? []);

  if (totalPages > 5) warnings.push("まず少ないページ数で取得品質を確認してから増やしてください");
  if (totalPages > 15) warnings.push("時間がかかるため分割取得を推奨します");
  if (realproPages > 10) warnings.push("リアプロ詳細取得が多くなり、待ち時間が長くなります");
  if (eSeikatsuPages > 50) warnings.push("いい生活は大量API取得になります");
  if (zeroRoomPages.length) warnings.push(`0件ページ: ${formatNumberList(zeroRoomPages)}ページ`);

  capturePlan.className = `capture-plan ${warnings.length ? "status-warn-inline" : "status-ok-inline"}`;
  capturePlan.innerHTML = `
    <strong>取得目安</strong>
    リアプロ ${startPage}ページ目から約${realproRows}戸 / いい生活は全件キャッシュ使用
    ${warnings.length ? `<div>${escapeHtml(warnings.join(" / "))}</div>` : `<div>段階検証向きのページ数です。</div>`}
  `;
}

function applyCaptureStep(step) {
  const pages = Math.min(Math.max(Number(step) || 1, 1), 10);
  if (realproCapturePages) realproCapturePages.value = String(pages);
  if (realproStartPage) realproStartPage.value = "1";
  if (eSeikatsuCapturePages) eSeikatsuCapturePages.value = String(pages);
  clearCurrentSearchPresetName();
  saveSearchConditions();
  renderCapturePlan();
  if (conditionStatus) {
    conditionStatus.textContent = `段階取得を${pages}ページずつに設定しました。`;
    conditionStatus.className = "condition-status status-ok-inline";
  }
}

async function handleESeikatsuFullPagesSet() {
  if (!setESeikatsuFullPages) return;
  setESeikatsuFullPages.disabled = true;
  const previousText = setESeikatsuFullPages.textContent;
  setESeikatsuFullPages.textContent = "確認中...";

  try {
    const response = await fetch(`/api/eseikatsu-total?ts=${Date.now()}`);
    if (!response.ok) {
      const errorPayload = await readErrorResponse(response);
      throw new Error(errorPayload);
    }
    const status = await response.json();
    if (!status.requiredPages) {
      throw new Error(status.summary || "いい生活の必要ページ数を確認できませんでした。");
    }
    const pages = Math.min(Math.max(Number(status.requiredPages), 1), 200);
    if (eSeikatsuCapturePages) eSeikatsuCapturePages.value = String(pages);
    clearCurrentSearchPresetName();
    saveSearchConditions();
    renderCapturePlan();
    if (conditionStatus) {
      const clipped = Number(status.requiredPages) > 200 ? " / 上限200ページまで設定" : "";
      conditionStatus.textContent = `${status.summary}${clipped}`;
      conditionStatus.className = Number(status.requiredPages) > 50 ? "condition-status status-warn-inline" : "condition-status status-ok-inline";
    }
  } catch (error) {
    if (conditionStatus) {
      conditionStatus.textContent = `いい生活全体確認に失敗しました: ${error.message}`;
      conditionStatus.className = "condition-status status-warn-inline";
    }
  } finally {
    setESeikatsuFullPages.disabled = false;
    setESeikatsuFullPages.textContent = previousText;
  }
}

async function handleESeikatsuCacheBuild() {
  if (!buildESeikatsuCache) return;
  buildESeikatsuCache.disabled = true;
  const previousText = buildESeikatsuCache.textContent;
  buildESeikatsuCache.textContent = "確認中...";
  if (conditionStatus) {
    conditionStatus.textContent = "いい生活全体の必要ページ数を確認しています...";
    conditionStatus.className = "condition-status status-warn-inline";
  }

  try {
    const totalResponse = await fetch(`/api/eseikatsu-total?ts=${Date.now()}`);
    if (!totalResponse.ok) {
      const errorPayload = await readErrorResponse(totalResponse);
      throw new Error(errorPayload);
    }
    const totalStatus = await totalResponse.json();
    if (!totalStatus.requiredPages) {
      throw new Error(totalStatus.summary || "いい生活の必要ページ数を確認できませんでした。");
    }
    const pages = Math.min(Math.max(Number(totalStatus.requiredPages), 1), 200);
    if (eSeikatsuCapturePages) eSeikatsuCapturePages.value = String(pages);
    renderCapturePlan();
    buildESeikatsuCache.textContent = "作成中...";
    if (conditionStatus) {
      conditionStatus.textContent = `いい生活全件キャッシュを作成しています... ${pages}ページ`;
      conditionStatus.className = "condition-status status-warn-inline";
    }
    const response = await fetch(`/api/eseikatsu-cache?pages=${pages}&ts=${Date.now()}`);
    if (!response.ok) {
      const errorPayload = await readErrorResponse(response);
      throw new Error(errorPayload);
    }
    const result = await response.json();
    const status = result.cache || result;
    const total = Number(status.totalCount || 0);
    const fetched = Number(status.fetchedCount || 0);
    const isFull = Boolean(status.isFull);
    if (result.data) {
      importCaptureData(result.data, result.filename ?? "data/chrome_capture.json");
    }
    if (conditionStatus) {
      conditionStatus.textContent = isFull
        ? `いい生活全件キャッシュ作成済み: 全${total}件 / 取得${fetched}件`
        : `いい生活全件キャッシュ未完成: 全${total || "不明"}件 / 取得${fetched}件。必要ページ数 ${status.requiredPages || "不明"}ページ`;
      conditionStatus.className = isFull ? "condition-status status-ok-inline" : "condition-status status-warn-inline";
    }
  } catch (error) {
    if (conditionStatus) {
      conditionStatus.textContent = `いい生活全件キャッシュ作成に失敗しました: ${error.message}`;
      conditionStatus.className = "condition-status status-warn-inline";
    }
  } finally {
    buildESeikatsuCache.disabled = false;
    buildESeikatsuCache.textContent = previousText;
  }
}

async function handleRealproDetailsRetry() {
  if (!retryRealproDetails) return;
  retryRealproDetails.disabled = true;
  const previousText = retryRealproDetails.textContent;
  retryRealproDetails.textContent = "再取得中...";
  if (importStatus) importStatus.textContent = "リアプロ詳細未確認を再取得しています...";

  try {
    const response = await fetch(`/api/realpro-detail-retry?ts=${Date.now()}`);
    if (!response.ok) {
      const errorPayload = await readErrorResponse(response);
      throw new Error(errorPayload);
    }
    const result = await response.json();
    importCaptureData(result.data, result.filename ?? "data/chrome_capture.json");
    if (importStatus) {
      importStatus.textContent = `リアプロ詳細再取得OK: 対象${result.targetCount ?? 0}件 / 更新${result.updatedCount ?? 0}件 / 残り判定不可${result.remainingUnknownWebAd ?? 0}件。`;
    }
  } catch (error) {
    if (importStatus) importStatus.textContent = `リアプロ詳細再取得に失敗しました: ${error.message}`;
  } finally {
    retryRealproDetails.disabled = false;
    retryRealproDetails.textContent = previousText;
  }
}

async function handleApplyRealproConditions(options = {}) {
  const submitSearch = Boolean(options.submitSearch);
  const button = options.triggerButton || (submitSearch ? applyRealproConditionsAndSearch : applyRealproConditions);
  const previousText = button?.textContent;
  if (button) {
    button.disabled = true;
    button.textContent = submitSearch ? "検索中..." : "反映中...";
  }
  setOpsText("opsTopbarState", submitSearch ? "リアプロ検索中" : "条件反映中");
  setOpsText("opsProgressState", submitSearch ? "検索中" : "反映中");
  setOpsText("opsProgressTitle", submitSearch ? "リアプロへ条件を反映して検索しています" : "リアプロへ条件を反映しています");
  setOpsText("opsProgressMessage", "Chromeで開いているリアプロ画面へ、システムの検索条件を送っています。");
  setOpsText("opsCurrentOperation", "条件反映");
  setOpsText("opsCurrentPosition", "リアプロ検索画面");
  setOpsText("opsCurrentCheck", "Chrome連動を実行中");
  if (options.scrollToProgress) scrollToOpsProgress();
  if (conditionStatus) {
    conditionStatus.textContent = submitSearch
      ? "リアプロ画面へ検索条件を反映して検索しています..."
      : "リアプロ画面へ検索条件を反映しています...";
    conditionStatus.className = "condition-status status-warn-inline";
  }

  try {
    const conditions = collectSearchConditionData();
    if (submitSearch) conditions.submitSearch = true;
    const result = document.body.classList.contains("maintenance-mode")
      ? await (async () => {
        const response = await fetch(`/api/realpro-conditions?ts=${Date.now()}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(conditions),
        });
        if (!response.ok) {
          const errorPayload = await readErrorResponse(response);
          throw new Error(errorPayload);
        }
        return response.json();
      })()
      : await requestExtensionRealproConditions(conditions);
    const applied = Array.isArray(result.applied) ? result.applied : [];
    const skipped = Array.isArray(result.skipped) ? result.skipped : [];
    if (result.submitted && realproStartPage) {
      if (hasLoadedCaptureData) {
        clearLoadedCaptureData();
        if (importStatus) {
          importStatus.textContent = "リアプロ検索を実行したため、前回の取得結果を画面から外しました。CSV履歴と保存済みCSVは残っています。";
        }
        if (resultSummary) {
          resultSummary.textContent = "リアプロの件数確認後、上部の「リアプロを取得して候補作成」から今日の候補を作成します。";
        }
      }
      realproStartPage.value = "1";
      saveSearchConditions();
      saveLastRealproSearchResult(result);
      renderCapturePlan();
    }
    if (conditionStatus) {
      const searchCountConfirmed = Boolean(result.submitted && result.searchSummary);
      conditionStatus.textContent = [
        `リアプロへ反映しました: ${applied.length ? applied.join("、") : "反映項目なし"}`,
        skipped.length ? `未対応/取得後判定: ${skipped.join("、")}` : "",
        result.submitted
          ? (searchCountConfirmed ? "リアプロ検索を実行しました" : "リアプロ検索を実行しました。今回の件数をリアプロ画面で確認してください")
          : "",
        result.searchSummary ? `現在表示: ${result.searchSummary}` : "",
        result.submitted
          ? (searchCountConfirmed ? "上部の「リアプロを取得して候補作成」を押してください。" : "件数確認後に取得を開始できます。")
          : "リアプロ画面で条件を確認してから検索してください。",
      ].filter(Boolean).join(" / ");
      conditionStatus.className = skipped.length ? "condition-status status-warn-inline" : "condition-status status-ok-inline";
    }
    const searchCountConfirmed = Boolean(result.submitted && result.searchSummary);
    setOpsText("opsTopbarState", result.submitted && searchCountConfirmed ? "リアプロ検索済み" : result.submitted ? "件数確認待ち" : "条件反映済み");
    setOpsText("opsProgressState", result.submitted && searchCountConfirmed ? "件数確認済み" : result.submitted ? "件数確認待ち" : "反映完了");
    setOpsText("opsProgressTitle", result.submitted
      ? (searchCountConfirmed ? "リアプロ検索を実行しました" : "リアプロ検索を実行しました。件数確認待ち")
      : "リアプロへ条件を反映しました");
    setOpsText("opsProgressMessage", [
      applied.length ? `反映: ${applied.join("、")}` : "反映項目なし",
      skipped.length ? `未対応/取得後判定: ${skipped.join("、")}` : "",
      result.searchSummary ? `現在表示: ${result.searchSummary}` : "",
      result.submitted
        ? (searchCountConfirmed ? "次は「リアプロを取得して候補作成」を押してください。" : "リアプロ画面で今回の検索結果件数を確認してください。")
        : "リアプロ画面で条件を確認してから検索してください.",
    ].filter(Boolean).join(" / "));
    setOpsText("opsCurrentOperation", result.submitted ? (searchCountConfirmed ? "検索実行済み" : "件数確認待ち") : "条件反映済み");
    setOpsText("opsCurrentPosition", result.searchSummary || "リアプロ画面");
    setOpsText("opsCurrentCheck", result.submitted && !searchCountConfirmed ? "リアプロ画面で件数確認" : skipped.length ? "一部は取得後判定" : "反映OK");
    flashOpsPanel(".ops-progress-panel");
    renderOpsDashboard();
  } catch (error) {
    if (conditionStatus) {
      conditionStatus.textContent = `リアプロ検索条件の反映に失敗しました: ${error.message}`;
      conditionStatus.className = "condition-status status-warn-inline";
    }
    setOpsText("opsTopbarState", "連動エラー");
    setOpsText("opsProgressState", "反映失敗");
    setOpsText("opsProgressTitle", "リアプロへ条件を反映できませんでした");
    setOpsText("opsProgressMessage", error.message);
    setOpsText("opsCurrentOperation", "停止");
    setOpsText("opsCurrentPosition", "リアプロ画面未確認");
    setOpsText("opsCurrentCheck", "リアプロの検索画面が開いているか確認");
    scrollToOpsProgress();
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = previousText;
    }
  }
}

function collectSearchConditionData() {
  return {
    lines: checkedValues("line"),
    stations: checkedStationKeys(),
    layouts: checkedValues("layout"),
    equipment: checkedValues("equipment"),
    rentMin: searchForm.elements.rentMin.value,
    rentMax: searchForm.elements.rentMax.value,
    updated: searchForm.elements.updated.value,
    accessMethod: searchForm.elements.accessMethod.value,
    walkMinutes: searchForm.elements.walkMinutes.value,
    availability: searchForm.elements.availability.value,
    sapporoOnly: searchForm.elements.sapporoOnly.checked,
    includeManagementFee: searchForm.elements.includeManagementFee.checked,
    immediate: searchForm.elements.immediate.checked,
    webAllowed: searchForm.elements.webAllowed.checked,
    excludeNegotiating: searchForm.elements.excludeNegotiating.checked,
    realproPages: realproCapturePages?.value ?? "2",
    realproStartPage: realproStartPage?.value ?? "1",
    eSeikatsuPages: eSeikatsuCapturePages?.value ?? "2",
  };
}

function applySearchConditionData(data = {}) {
  const missing = [];
  setCheckedValues("line", data.lines);
  updateStationVisibility();
  setCheckedValues("station", data.stations);
  document.querySelectorAll(".station-group").forEach(updateStationSelectAllState);
  setCheckedValues("layout", data.layouts);
  setCheckedValues("equipment", data.equipment);
  setFieldValue("rentMin", data.rentMin);
  setFieldValue("rentMax", data.rentMax);
  setFieldValue("updated", data.updated);
  setFieldValue("accessMethod", data.accessMethod);
  setFieldValue("walkMinutes", data.walkMinutes);
  setFieldValue("availability", data.availability);
  setFieldChecked("sapporoOnly", data.sapporoOnly);
  setFieldChecked("includeManagementFee", data.includeManagementFee);
  setFieldChecked("immediate", data.immediate);
  setFieldChecked("webAllowed", data.webAllowed);
  setFieldChecked("excludeNegotiating", data.excludeNegotiating);
  if (realproCapturePages && data.realproPages) realproCapturePages.value = data.realproPages;
  if (realproStartPage && data.realproStartPage) realproStartPage.value = data.realproStartPage;
  if (eSeikatsuCapturePages && data.eSeikatsuPages) eSeikatsuCapturePages.value = data.eSeikatsuPages;
  renderCapturePlan();
  missing.push(...missingCheckedValues("line", data.lines, "沿線"));
  missing.push(...missingCheckedValues("station", data.stations, "駅"));
  missing.push(...missingCheckedValues("layout", data.layouts, "間取"));
  missing.push(...missingCheckedValues("equipment", data.equipment, "設備"));
  missing.push(...missingSelectValue("updated", data.updated, "更新日"));
  missing.push(...missingSelectValue("accessMethod", data.accessMethod, "駅までの移動手段"));
  missing.push(...missingSelectValue("availability", data.availability, "状態"));
  return { missing };
}

function missingCheckedValues(name, values = [], label) {
  if (!Array.isArray(values) || !values.length) return [];
  const existing = new Set([...document.querySelectorAll(`input[name="${name}"]`)].map((input) => input.value));
  return values.filter((value) => value && !existing.has(value)).map((value) => `${label}:${value}`);
}

function missingSelectValue(name, value, label) {
  if (!value || !searchForm.elements[name]) return [];
  const options = [...searchForm.elements[name].options].map((option) => option.value);
  return options.includes(value) ? [] : [`${label}:${value}`];
}

function parseSearchConditionJson(rawText) {
  const data = JSON.parse(String(rawText ?? "").trim());
  if (!data || typeof data !== "object" || Array.isArray(data)) {
    throw new Error("object-required");
  }
  const arrayFields = ["lines", "stations", "layouts", "equipment"];
  arrayFields.forEach((field) => {
    if (data[field] !== undefined && !Array.isArray(data[field])) {
      throw new Error(`${field}-array-required`);
    }
  });
  return data;
}

function applySearchConditionJson(rawText, sourceLabel = "検索条件JSON") {
  const data = parseSearchConditionJson(rawText);
  clearCurrentSearchPresetName();
  const result = applySearchConditionData(data);
  updateSelectedConditions();
  saveSearchConditions();
  const missingText = result.missing.length ? `未反映: ${result.missing.join(" / ")}` : "";
  saveConditionRestoreHistory({
    sourceLabel,
    restoredAt: new Date().toISOString(),
    criteriaText: selectedConditionText(),
    criteriaJson: JSON.stringify(data),
    missingText,
  });
  refreshCandidateRows(`${sourceLabel}を反映しました。`);
  conditionStatus.textContent = `${sourceLabel}を反映しました。${missingText ? ` ${missingText}` : ""}`;
  conditionStatus.className = `condition-status ${result.missing.length ? "status-warn-inline" : "status-ok-inline"}`;
}

function readConditionRestoreHistory() {
  try {
    const history = JSON.parse(localStorage.getItem("conditionRestoreHistory") || "[]");
    return Array.isArray(history) ? history : [];
  } catch {
    return [];
  }
}

function saveConditionRestoreHistory(entry) {
  const history = [
    entry,
    ...readConditionRestoreHistory().filter((item) => item.criteriaJson !== entry.criteriaJson),
  ].slice(0, 5);
  localStorage.setItem("conditionRestoreHistory", JSON.stringify(history));
  renderConditionRestoreHistory();
}

function renderConditionRestoreHistory() {
  if (!conditionRestoreHistory) return;
  const history = readConditionRestoreHistory();
  if (!history.length) {
    conditionRestoreHistory.hidden = true;
    conditionRestoreHistory.innerHTML = "";
    return;
  }

  conditionRestoreHistory.hidden = false;
  const warningCount = history.filter((item) => item.missingText).length;
  conditionRestoreHistory.innerHTML = `
    <div class="restore-history-title-row">
      <strong>復元履歴</strong>
      <span class="restore-history-count">${history.length}件${warningCount ? ` / 未反映あり${warningCount}件` : ""}</span>
      ${warningCount ? `<button class="text-button" type="button" data-clear-condition-restore-warnings>未反映履歴をクリア</button>` : ""}
      <button class="text-button" type="button" data-clear-condition-restore-history>履歴をクリア</button>
    </div>
    <ul>
      ${history.map((item, index) => `
        <li class="${item.missingText ? "restore-history-warning-row" : ""}">
          ${escapeHtml(formatDateTime(item.restoredAt))} /
          ${escapeHtml(item.sourceLabel ?? "検索条件JSON")} /
          ${escapeHtml(item.criteriaText ?? "指定なし")}
          ${item.missingText ? `<div class="restore-history-warning">${escapeHtml(item.missingText)}</div>` : ""}
          ${item.criteriaJson ? `
            <details class="restore-history-json">
              <summary>条件JSON</summary>
              <code>${escapeHtml(item.criteriaJson)}</code>
              <button class="text-button json-copy-button" type="button" data-copy-json>JSONをコピー</button>
            </details>
          ` : ""}
          <div class="restore-history-actions">
            <button class="text-button" type="button" data-restore-condition-index="${index}">この履歴を反映</button>
          </div>
        </li>
      `).join("")}
    </ul>
  `;
}

function clearConditionRestoreHistory() {
  const count = readConditionRestoreHistory().length;
  localStorage.removeItem("conditionRestoreHistory");
  renderConditionRestoreHistory();
  renderCsvSummary();
  return count;
}

function clearConditionRestoreWarnings() {
  const current = readConditionRestoreHistory();
  const history = current.filter((item) => !item.missingText);
  const removedCount = current.length - history.length;
  if (history.length) {
    localStorage.setItem("conditionRestoreHistory", JSON.stringify(history));
  } else {
    localStorage.removeItem("conditionRestoreHistory");
  }
  renderConditionRestoreHistory();
  renderCsvSummary();
  return removedCount;
}

function conditionRestoreHistorySummaryText() {
  const history = readConditionRestoreHistory();
  if (!history.length) return "";
  const latest = history[0];
  const warningCount = history.filter((item) => item.missingText).length;
  return [
    `復元履歴${history.length}件`,
    warningCount ? `未反映あり${warningCount}件` : "",
    `直近:${formatDateTime(latest.restoredAt)} ${latest.sourceLabel ?? "検索条件JSON"}`,
    latest.missingText || "",
  ].filter(Boolean).join(" / ");
}

function readFreshnessReviewHistory() {
  try {
    const history = JSON.parse(localStorage.getItem("freshnessReviewHistory") || "[]");
    return Array.isArray(history) ? history : [];
  } catch {
    return [];
  }
}

function saveFreshnessReviewHistory(entry) {
  const history = [entry, ...readFreshnessReviewHistory()].slice(0, 5);
  localStorage.setItem("freshnessReviewHistory", JSON.stringify(history));
  renderFreshnessReviewHistory();
}

function renderFreshnessReviewHistory() {
  if (!freshnessReviewHistory) return;
  const history = readFreshnessReviewHistory();
  if (!history.length) {
    freshnessReviewHistory.hidden = true;
    freshnessReviewHistory.innerHTML = "";
    return;
  }

  freshnessReviewHistory.hidden = false;
  const staleCount = history.filter((item) => item.requiresReacquire).length;
  freshnessReviewHistory.innerHTML = `
    <div class="restore-history-title-row">
      <strong>データ鮮度確認履歴</strong>
      <span class="restore-history-count">${history.length}件${staleCount ? ` / 再取得推奨${staleCount}件` : ""}</span>
      <button class="text-button" type="button" data-clear-freshness-review-history>履歴をクリア</button>
    </div>
    <ul>
      ${history.map((item) => `
        <li class="${item.requiresReacquire ? "restore-history-warning-row" : ""}">
          ${escapeHtml(formatDateTime(item.reviewedAt))} /
          ${escapeHtml(item.freshnessValue || "不明")}
          ${item.sourceLabel ? ` / ${escapeHtml(item.sourceLabel)}` : ""}
          <div class="${item.requiresReacquire ? "restore-history-warning" : "history-condition"}">${escapeHtml(item.summaryText ?? "")}</div>
          ${item.criteriaText ? `<div class="history-condition">検索条件: ${escapeHtml(item.criteriaText)}</div>` : ""}
        </li>
      `).join("")}
    </ul>
  `;
}

function clearFreshnessReviewHistory() {
  const count = readFreshnessReviewHistory().length;
  localStorage.removeItem("freshnessReviewHistory");
  renderFreshnessReviewHistory();
  return count;
}

function freshnessReviewHistorySummaryText() {
  const history = readFreshnessReviewHistory();
  if (!history.length) return "";
  const latest = history[0];
  const staleCount = history.filter((item) => item.requiresReacquire).length;
  return [
    `確認履歴${history.length}件`,
    staleCount ? `再取得推奨${staleCount}件` : "",
    `直近:${formatDateTime(latest.reviewedAt)} ${latest.freshnessValue || "不明"}`,
    latest.sourceLabel || "",
    latest.summaryText || "",
  ].filter(Boolean).join(" / ");
}

function currentFreshnessReviewMissingText() {
  const freshness = captureFreshnessSummary(currentImportMeta?.capturedAt);
  if (!freshness || freshness.value === "当日") return "";
  const history = readFreshnessReviewHistory();
  const reviewed = history.some((item) =>
    item.capturedAt === currentImportMeta?.capturedAt &&
    item.sourceLabel === (currentImportMeta?.filename || "現在の読み込みデータ")
  );
  return reviewed ? "" : "データ鮮度確認が未実施です。古い取得データのため、データ鮮度ボタンで再取得判断をメモしてください。";
}

function readCaptureQualityReviewHistory() {
  try {
    const history = JSON.parse(localStorage.getItem("captureQualityReviewHistory") || "[]");
    return Array.isArray(history) ? history : [];
  } catch {
    return [];
  }
}

function saveCaptureQualityReviewHistory(entry) {
  const history = [entry, ...readCaptureQualityReviewHistory()].slice(0, 5);
  localStorage.setItem("captureQualityReviewHistory", JSON.stringify(history));
  renderCaptureQualityReviewHistory();
}

function renderCaptureQualityReviewHistory() {
  if (!captureQualityReviewHistory) return;
  const history = readCaptureQualityReviewHistory();
  if (!history.length) {
    captureQualityReviewHistory.hidden = true;
    captureQualityReviewHistory.innerHTML = "";
    return;
  }

  captureQualityReviewHistory.hidden = false;
  const warningCount = history.filter((item) => item.warningCount).length;
  captureQualityReviewHistory.innerHTML = `
    <div class="restore-history-title-row">
      <strong>取得品質確認履歴</strong>
      <span class="restore-history-count">${history.length}件${warningCount ? ` / 注意あり${warningCount}件` : ""}</span>
      <button class="text-button" type="button" data-clear-capture-quality-review-history>履歴をクリア</button>
    </div>
    <ul>
      ${history.map((item) => `
        <li class="${item.warningCount ? "restore-history-warning-row" : ""}">
          ${escapeHtml(formatDateTime(item.reviewedAt))} /
          ${escapeHtml(item.warningCount ? `注意${item.warningCount}件` : "注意なし")}
          ${item.sourceLabel ? ` / ${escapeHtml(item.sourceLabel)}` : ""}
          <div class="${item.warningCount ? "restore-history-warning" : "history-condition"}">${escapeHtml(item.summaryText ?? "")}</div>
          ${item.criteriaText ? `<div class="history-condition">検索条件: ${escapeHtml(item.criteriaText)}</div>` : ""}
        </li>
      `).join("")}
    </ul>
  `;
}

function clearCaptureQualityReviewHistory() {
  const count = readCaptureQualityReviewHistory().length;
  localStorage.removeItem("captureQualityReviewHistory");
  renderCaptureQualityReviewHistory();
  return count;
}

function captureQualityReviewHistorySummaryText() {
  const history = readCaptureQualityReviewHistory();
  if (!history.length) return "";
  const latest = history[0];
  const warningCount = history.filter((item) => item.warningCount).length;
  return [
    `確認履歴${history.length}件`,
    warningCount ? `注意あり${warningCount}件` : "",
    `直近:${formatDateTime(latest.reviewedAt)} ${latest.warningCount ? `注意${latest.warningCount}件` : "注意なし"}`,
    latest.sourceLabel || "",
    latest.summaryText || "",
  ].filter(Boolean).join(" / ");
}

function readDetailUnconfirmedReviewHistory() {
  try {
    const history = JSON.parse(localStorage.getItem("detailUnconfirmedReviewHistory") || "[]");
    return Array.isArray(history) ? history : [];
  } catch {
    return [];
  }
}

function saveDetailUnconfirmedReviewHistory(entry) {
  const history = [entry, ...readDetailUnconfirmedReviewHistory()].slice(0, 5);
  localStorage.setItem("detailUnconfirmedReviewHistory", JSON.stringify(history));
  renderDetailUnconfirmedReviewHistory();
}

function renderDetailUnconfirmedReviewHistory() {
  if (!detailUnconfirmedReviewHistory) return;
  const history = readDetailUnconfirmedReviewHistory();
  if (!history.length) {
    detailUnconfirmedReviewHistory.hidden = true;
    detailUnconfirmedReviewHistory.innerHTML = "";
    return;
  }

  detailUnconfirmedReviewHistory.hidden = false;
  const unresolvedCount = history.filter((item) => item.hasUnconfirmed).length;
  detailUnconfirmedReviewHistory.innerHTML = `
    <div class="restore-history-title-row">
      <strong>詳細未確認検証履歴</strong>
      <span class="restore-history-count">${history.length}件${unresolvedCount ? ` / 未確認あり${unresolvedCount}件` : ""}</span>
      <button class="text-button" type="button" data-clear-detail-unconfirmed-review-history>履歴をクリア</button>
    </div>
    <ul>
      ${history.map((item) => `
        <li class="${item.hasUnconfirmed ? "restore-history-warning-row" : ""}">
          ${escapeHtml(formatDateTime(item.reviewedAt))} /
          ${escapeHtml(item.hasUnconfirmed ? "未確認あり" : "未確認なし")}
          ${item.sourceLabel ? ` / ${escapeHtml(item.sourceLabel)}` : ""}
          <div class="${item.hasUnconfirmed ? "restore-history-warning" : "history-condition"}">${escapeHtml(item.summaryText ?? "")}</div>
          ${item.criteriaText ? `<div class="history-condition">検索条件: ${escapeHtml(item.criteriaText)}</div>` : ""}
        </li>
      `).join("")}
    </ul>
  `;
}

function clearDetailUnconfirmedReviewHistory() {
  const count = readDetailUnconfirmedReviewHistory().length;
  localStorage.removeItem("detailUnconfirmedReviewHistory");
  renderDetailUnconfirmedReviewHistory();
  return count;
}

function detailUnconfirmedReviewHistorySummaryText() {
  const history = readDetailUnconfirmedReviewHistory();
  if (!history.length) return "";
  const latest = history[0];
  const unresolvedCount = history.filter((item) => item.hasUnconfirmed).length;
  return [
    `検証履歴${history.length}件`,
    unresolvedCount ? `未確認あり${unresolvedCount}件` : "",
    `直近:${formatDateTime(latest.reviewedAt)} ${latest.hasUnconfirmed ? "未確認あり" : "未確認なし"}`,
    latest.sourceLabel || "",
    latest.summaryText || "",
  ].filter(Boolean).join(" / ");
}

function currentDetailUnconfirmedReviewMissingText() {
  const detailText = detailUnconfirmedSummaryText();
  if (!detailText) return "";
  const history = readDetailUnconfirmedReviewHistory();
  const reviewed = history.some((item) =>
    item.capturedAt === currentImportMeta?.capturedAt &&
    item.sourceLabel === (currentImportMeta?.filename || "現在の読み込みデータ")
  );
  return reviewed ? "" : "詳細未確認検証が未実施です。詳細未確認があるため、詳細未確認検証ボタンで原因をメモしてください。";
}

function currentDetailUnconfirmedReviewStatusText() {
  const detailText = detailUnconfirmedSummaryText();
  if (!detailText) return "詳細未確認なし";
  return currentDetailUnconfirmedReviewMissingText() ? "未実施" : "検証済み";
}


function handleConditionJsonApply() {
  if (!conditionJsonInput) return;
  const rawText = conditionJsonInput.value.trim();
  if (!rawText) {
    conditionStatus.textContent = "検索条件JSONを貼り付けてください。";
    conditionStatus.className = "condition-status status-warn-inline";
    return;
  }

  try {
    applySearchConditionJson(rawText);
  } catch {
    conditionStatus.textContent = "検索条件JSONを読み込めませんでした。CSV履歴の条件JSONをそのまま貼り付けてください。";
    conditionStatus.className = "condition-status status-warn-inline";
  }
}

function saveSearchConditions() {
  const data = collectSearchConditionData();
  localStorage.setItem("propertySearchConditions", JSON.stringify(data));
}

function clearCurrentSearchPresetName() {
  setCurrentSearchPresetName("");
}

function restoreSearchConditions() {
  const raw = localStorage.getItem("propertySearchConditions");
  if (!raw) return;

  try {
    const data = JSON.parse(raw);
    applySearchConditionData(data);
  } catch {
    localStorage.removeItem("propertySearchConditions");
  }
}

function setCheckedValues(name, values = []) {
  const selected = new Set(Array.isArray(values) ? values : []);
  document.querySelectorAll(`input[name="${name}"]`).forEach((input) => {
    input.checked = selected.has(input.value);
  });
}

function setFieldValue(name, value) {
  if (value === undefined || !searchForm.elements[name]) return;
  searchForm.elements[name].value = value;
}

function setFieldChecked(name, checked) {
  if (checked === undefined || !searchForm.elements[name]) return;
  searchForm.elements[name].checked = Boolean(checked);
}

function readSearchPresets() {
  try {
    const presets = JSON.parse(localStorage.getItem("searchPresets") || "[]");
    return Array.isArray(presets) ? presets.map(normalizeSearchPreset).filter(Boolean) : [];
  } catch {
    return [];
  }
}

function normalizeSearchPreset(preset) {
  if (!preset || typeof preset !== "object" || !preset.conditions) return null;
  const id = String(preset.id || Date.now());
  return {
    id,
    name: String(preset.name || "検索条件"),
    savedAt: preset.savedAt || preset.updatedAt || new Date().toISOString(),
    updatedAt: preset.updatedAt || preset.savedAt || new Date().toISOString(),
    lastUsedAt: preset.lastUsedAt || "",
    usageCount: Number(preset.usageCount || 0),
    conditions: preset.conditions,
  };
}

function writeSearchPresets(presets) {
  localStorage.setItem("searchPresets", JSON.stringify(presets.map(normalizeSearchPreset).filter(Boolean).slice(0, 20)));
}

function presetTimeValue(value) {
  const time = Date.parse(value || "");
  return Number.isFinite(time) ? time : 0;
}

function sortedSearchPresets(presets = readSearchPresets()) {
  return [...presets].sort((a, b) => {
    const usedDiff = presetTimeValue(b.lastUsedAt) - presetTimeValue(a.lastUsedAt);
    if (usedDiff) return usedDiff;
    const countDiff = Number(b.usageCount || 0) - Number(a.usageCount || 0);
    if (countDiff) return countDiff;
    return presetTimeValue(b.updatedAt || b.savedAt) - presetTimeValue(a.updatedAt || a.savedAt);
  });
}

function presetOptionLabel(preset) {
  const details = [];
  if (preset.usageCount) details.push(`${preset.usageCount}回`);
  if (preset.lastUsedAt) details.push("前回使用");
  return details.length ? `${preset.name}（${details.join(" / ")}）` : preset.name;
}

function markSearchPresetUsed(presetId) {
  const presets = readSearchPresets();
  const index = presets.findIndex((item) => item.id === presetId);
  if (index < 0) return null;
  const usedPreset = {
    ...presets[index],
    lastUsedAt: new Date().toISOString(),
    usageCount: Number(presets[index].usageCount || 0) + 1,
  };
  presets[index] = usedPreset;
  writeSearchPresets(sortedSearchPresets(presets));
  return usedPreset;
}

function renderSearchPresets() {
  if (!searchPresetSelect) return;
  const selectedValue = searchPresetSelect.value;
  const presets = sortedSearchPresets();
  searchPresetSelect.innerHTML = presets.length
    ? ['<option value="">選択してください</option>', ...presets.map((preset) => `<option value="${escapeAttribute(preset.id)}">${escapeHtml(presetOptionLabel(preset))}</option>`)].join("")
    : '<option value="">保存済み条件なし</option>';
  if (selectedValue && presets.some((preset) => preset.id === selectedValue)) {
    searchPresetSelect.value = selectedValue;
  }
  if (deleteSearchPreset) deleteSearchPreset.disabled = !presets.length;
  if (loadSearchPreset) loadSearchPreset.disabled = !presets.length;
}

function defaultPresetName() {
  const condition = selectedConditionText();
  return condition === "指定なし" ? `検索条件 ${formatDateTime()}` : condition.slice(0, 40);
}

function saveCurrentSearchPreset() {
  const name = searchPresetName?.value.trim() || defaultPresetName();
  const presets = readSearchPresets();
  const existingIndex = presets.findIndex((preset) => preset.name === name);
  const now = new Date().toISOString();
  const preset = {
    id: existingIndex >= 0 ? presets[existingIndex].id : String(Date.now()),
    name,
    savedAt: existingIndex >= 0 ? presets[existingIndex].savedAt : now,
    updatedAt: now,
    lastUsedAt: now,
    usageCount: existingIndex >= 0 ? Number(presets[existingIndex].usageCount || 0) : 0,
    conditions: collectSearchConditionData(),
  };
  if (existingIndex >= 0) presets[existingIndex] = preset;
  else presets.unshift(preset);
  writeSearchPresets(sortedSearchPresets(presets));
  renderSearchPresets();
  setCurrentSearchPresetName(name);
  if (searchPresetSelect) searchPresetSelect.value = preset.id;
  if (searchPresetName) searchPresetName.value = name;
  if (searchPresetStatus) searchPresetStatus.textContent = `保存しました: ${name}`;
}

function loadSelectedSearchPreset() {
  const presetId = searchPresetSelect?.value;
  const preset = readSearchPresets().find((item) => item.id === presetId);
  if (!preset) {
    if (searchPresetStatus) searchPresetStatus.textContent = "呼び出すプリセットを選択してください。";
    return;
  }
  applySearchConditionData(preset.conditions);
  const usedPreset = markSearchPresetUsed(presetId) || preset;
  setCurrentSearchPresetName(usedPreset.name);
  updateSelectedConditions();
  saveSearchConditions();
  renderSearchPresets();
  if (searchPresetSelect) searchPresetSelect.value = usedPreset.id;
  refreshCandidateRows(`プリセットを呼び出しました: ${usedPreset.name}`);
  if (searchPresetName) searchPresetName.value = usedPreset.name;
  if (searchPresetStatus) searchPresetStatus.textContent = `呼び出しました: ${usedPreset.name}（使用${usedPreset.usageCount}回）`;
}

function deleteSelectedSearchPreset() {
  const presetId = searchPresetSelect?.value;
  const presets = readSearchPresets();
  const preset = presets.find((item) => item.id === presetId);
  if (!preset) {
    if (searchPresetStatus) searchPresetStatus.textContent = "削除するプリセットを選択してください。";
    return;
  }
  writeSearchPresets(presets.filter((item) => item.id !== presetId));
  renderSearchPresets();
  if (currentSearchPresetName === preset.name) clearCurrentSearchPresetName();
  if (searchPresetName) searchPresetName.value = "";
  if (searchPresetStatus) searchPresetStatus.textContent = `削除しました: ${preset.name}`;
}

function resetAllSearchConditions() {
  localStorage.removeItem("propertySearchConditions");
  clearCurrentSearchPresetName();
  searchForm.reset();
  document.querySelectorAll('input[name="station"], input[name="selectAllStations"]').forEach((input) => {
    input.checked = false;
    input.indeterminate = false;
  });
  updateStationVisibility();
  updateSelectedConditions();
  refreshCandidateRows("検索条件をリセットしました。");
  if (!hasLoadedCaptureData) resultSummary.textContent = "検索条件をリセットしました。データを読み込むと現在の条件で判定します。";
}

function updateStationVisibility() {
  const selectedLines = new Set(checkedValues("line"));

  document.querySelectorAll(".station-group").forEach((group) => {
    const line = group.dataset.lineGroup;
    const isVisible = selectedLines.has(line);
    group.hidden = !isVisible;

    if (!isVisible) {
      group.querySelectorAll('input[name="station"]').forEach((input) => {
        input.checked = false;
      });
      group.querySelector('input[name="selectAllStations"]').checked = false;
      group.querySelector('input[name="selectAllStations"]').indeterminate = false;
    }
  });

  emptyStations.hidden = selectedLines.size > 0;
}

function updateStationSelectAllState(group) {
  const stationInputs = [...group.querySelectorAll('input[name="station"]')];
  const selectedCount = stationInputs.filter((input) => input.checked).length;
  const selectAll = group.querySelector('input[name="selectAllStations"]');

  selectAll.checked = selectedCount === stationInputs.length && stationInputs.length > 0;
  selectAll.indeterminate = selectedCount > 0 && selectedCount < stationInputs.length;
}

function checkedValues(name) {
  return [...document.querySelectorAll(`input[name="${name}"]:checked`)].map((input) => input.value);
}

function checkedStationNames() {
  return [...document.querySelectorAll('input[name="station"]:checked')].map((input) => {
    const line = input.value.split(":")[0];
    return `${input.dataset.stationName}(${line})`;
  });
}

function checkedStationKeys() {
  return [...document.querySelectorAll('input[name="station"]:checked')].map((input) => input.value);
}

function getFieldLabel(name) {
  const field = searchForm.elements[name];
  if (!field || field instanceof RadioNodeList) return "";
  if (field.tagName === "SELECT") {
    return field.selectedOptions[0]?.textContent.trim() ?? "";
  }
  return field.value;
}

function yenLabel(value) {
  if (!value) return "";
  return `${Number(value).toLocaleString("ja-JP")}円`;
}

function formatDateTime(value = new Date()) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return [
    date.getFullYear(),
    "/",
    String(date.getMonth() + 1).padStart(2, "0"),
    "/",
    String(date.getDate()).padStart(2, "0"),
    " ",
    String(date.getHours()).padStart(2, "0"),
    ":",
    String(date.getMinutes()).padStart(2, "0"),
  ].join("");
}

function formatDateStamp(value = new Date()) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0"),
  ].join("");
}

function formatDateTimeStamp(value = new Date()) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0"),
    "-",
    String(date.getHours()).padStart(2, "0"),
    String(date.getMinutes()).padStart(2, "0"),
    String(date.getSeconds()).padStart(2, "0"),
  ].join("");
}

function captureFreshnessSummary(capturedAt, referenceDate = new Date()) {
  if (!capturedAt) return null;
  const capturedDate = new Date(capturedAt);
  const reference = referenceDate instanceof Date ? referenceDate : new Date(referenceDate);
  if (Number.isNaN(capturedDate.getTime()) || Number.isNaN(reference.getTime())) return null;

  const capturedDay = new Date(capturedDate.getFullYear(), capturedDate.getMonth(), capturedDate.getDate());
  const referenceDay = new Date(reference.getFullYear(), reference.getMonth(), reference.getDate());
  const ageDays = Math.max(0, Math.floor((referenceDay - capturedDay) / 86400000));
  if (ageDays === 0) {
    return {
      value: "当日",
      note: "最新取得",
      kind: "ok",
      message: "データ鮮度: 当日取得です。",
    };
  }
  if (ageDays === 1) {
    return {
      value: "1日前",
      note: "空室状況を確認",
      kind: "warn",
      message: "データ鮮度: 取得から1日経過しています。登録前にリアプロの最新状態を確認してください。",
    };
  }
  return {
    value: `${ageDays}日前`,
    note: "再取得推奨",
    kind: "warn",
    message: `データ鮮度: 取得から${ageDays}日経過しています。候補CSVを使う前に再取得を推奨します。`,
  };
}

function eSeikatsuCacheFreshnessWarning(cache, referenceDate = new Date()) {
  if (!cache?.used) return "";
  const freshness = captureFreshnessSummary(cache.capturedAt, referenceDate);
  if (!freshness || freshness.value === "当日") return "";
  return `いい生活全件キャッシュ鮮度: ${freshness.value}です。掲載件数は変動するため、実務CSVを使う前にいい生活全件キャッシュ作成をやり直してください。`;
}

function updateSelectedConditions() {
  const lines = [];
  const linesSelected = checkedValues("line");
  const stations = checkedStationNames();
  const layouts = checkedValues("layout");
  const equipment = checkedValues("equipment");
  const rentMin = searchForm.elements.rentMin.value;
  const rentMax = searchForm.elements.rentMax.value;
  const updated = getFieldLabel("updated");
  const accessMethod = getFieldLabel("accessMethod");
  const walkMinutes = searchForm.elements.walkMinutes.value;
  const availability = getFieldLabel("availability");

  if (linesSelected.length) lines.push(`沿線: ${linesSelected.join("、")}`);
  if (stations.length) lines.push(`駅: ${stations.join("、")}`);
  if (layouts.length) lines.push(`間取: ${layouts.join("、")}`);
  if (equipment.length) lines.push(`設備: ${equipment.join("、")}`);
  if (rentMin || rentMax) lines.push(`賃料: ${yenLabel(rentMin) || "下限なし"} 〜 ${yenLabel(rentMax) || "上限なし"}`);
  if (updated && updated !== "すべて表示") lines.push(`更新日: ${updated}`);
  if (accessMethod && accessMethod !== "指定なし") lines.push(`駅までの移動手段: ${accessMethod}`);
  if (walkMinutes) lines.push(`駅まで: ${walkMinutes}分以内`);
  if (availability && availability !== "指定なし") lines.push(`状態: ${availability}`);

  if (searchForm.elements.sapporoOnly.checked) lines.push("札幌市内のみ");
  if (searchForm.elements.includeManagementFee.checked) lines.push("管理費・共益費含む");
  if (searchForm.elements.immediate.checked) lines.push("即入物件で絞り込み");
  if (searchForm.elements.webAllowed.checked) lines.push("WEB掲載不可を除外（管理会社確認は残す）");
  if (searchForm.elements.excludeNegotiating.checked) lines.push("商談中・審査中を除外");

  const criteriaText = lines.length ? lines.join(" / ") : "条件は未選択です";
  selectedConditions.innerHTML = `
    <div data-selected-condition-text>${escapeHtml(criteriaText)}</div>
    <details class="condition-json">
      <summary>検索条件JSON</summary>
      <code>${escapeHtml(selectedConditionJson())}</code>
      <button class="text-button json-copy-button" type="button" data-copy-json>JSONをコピー</button>
    </details>
  `;
  renderConditionStatus();
  renderOpsDashboard();
}

function renderConditionStatus() {
  if (!conditionStatus) return;
  const isDefault = isDefaultSearchCriteria();
  conditionStatus.textContent = isDefault
    ? "検索条件は初期状態です。検証サンプルの期待件数チェックが使えます。"
    : "検索条件が変更されています。検証サンプルの期待件数チェックは省略されます。";
  conditionStatus.className = `condition-status ${isDefault ? "status-ok-inline" : "status-warn-inline"}`;
}

function setOpsText(id, text) {
  const node = document.getElementById(id);
  if (node) node.textContent = text;
}

function formatOpsRent(value) {
  const number = Number(value || 0);
  if (!number) return "";
  return `${number / 10000}万`;
}

function shortEquipmentLabel(item) {
  const labels = {
    "バス・トイレ別": "BT別",
    "駐車場空きあり": "空きあり",
    "インターネット無料": "ネット無料",
  };
  return labels[item] || item;
}

function opsStageName() {
  if (captureIsRunning) return "running";
  if (captureLastError) return "confirm";
  if (hasLoadedCaptureData) return "complete";
  if (currentRealproSearchResult()) return "confirm";
  if (!isDefaultSearchCriteria()) return "conditions";
  return "setup";
}

function renderOpsSteps(stageName = opsStageName()) {
  const order = ["setup", "conditions", "confirm", "running", "complete"];
  const ids = {
    setup: "opsStepSetup",
    conditions: "opsStepConditions",
    confirm: "opsStepConfirm",
    running: "opsStepRunning",
    complete: "opsStepComplete",
  };
  const activeIndex = Math.max(order.indexOf(stageName), 0);
  order.forEach((name, index) => {
    const node = document.getElementById(ids[name]);
    if (!node) return;
    node.classList.toggle("is-active", index === activeIndex);
    node.classList.toggle("is-done", index < activeIndex);
  });
  document.querySelectorAll(".ops-tabs span").forEach((item, index) => {
    item.classList.toggle("is-active", index === activeIndex);
  });
}

function renderOpsCheck(id, ok, okText, ngText) {
  const node = document.getElementById(id);
  if (!node) return;
  node.classList.toggle("is-ok", Boolean(ok));
  const small = node.querySelector("small");
  if (small) small.textContent = ok ? okText : ngText;
}

function renderOpsConditionSummary() {
  if (!searchForm) return;
  const criteria = collectCriteria();
  const stationNames = checkedStationNames().map((name) => name.replace(/\(.+\)$/, ""));
  const stationText = stationNames.length
    ? stationNames.slice(0, 5).join("、") + (stationNames.length > 5 ? ` ほか${stationNames.length - 5}駅` : "")
    : (criteria.lines.length ? criteria.lines.join("、") : "未指定");
  const rentText = criteria.rentMin || criteria.rentMax
    ? `${formatOpsRent(criteria.rentMin) || "下限なし"}〜${formatOpsRent(criteria.rentMax) || "上限なし"}`
    : "未指定";
  const accessText = criteria.walkMinutes
    ? `${criteria.accessMethod || "徒歩"}${criteria.walkMinutes}分以内`
    : "未指定";
  const equipment = criteria.equipment.filter((item) => item !== "駐車場空きあり");
  const parking = criteria.equipment.includes("駐車場空きあり") ? "空きあり" : "未指定";

  setOpsText("opsLineSummary", stationText);
  setOpsText("opsLayoutSummary", criteria.layouts.length ? criteria.layouts.join(" / ") : "未指定");
  setOpsText("opsRentSummary", rentText);
  setOpsText("opsAccessSummary", accessText);
  setOpsText("opsEquipmentSummary", equipment.length ? equipment.map(shortEquipmentLabel).join(" / ") : "未指定");
  setOpsText("opsParkingSummary", parking);
}

function renderOpsNotices(stageName, context = {}) {
  const node = document.getElementById("opsNoticeList");
  if (!node) return;
  const reviewCount = Number(context.reviewCount || 0);
  const excludedCount = Number(context.excludedCount || 0);
  const isPartial = Boolean(context.isPartial);
  const messages = [];

  if (captureLastError && !captureIsRunning) {
    messages.push(captureLastError);
    messages.push(...opsProblemAdviceLines(captureLastError).slice(0, 2));
    node.innerHTML = messages.map((message) => `<p>${escapeHtml(message)}</p>`).join("");
    return;
  }

  if (stageName === "complete") {
    if (isPartial) {
      messages.push("リアプロ検索結果の一部だけを取得しています。実務CSVは全体取得後に保存してください。");
    } else {
      messages.push("WEB広告掲載不可、電子入居申込あり、いい生活で募集中の同一号室は候補から外しています。");
    }
    if (reviewCount > 0) {
      messages.push(`管理会社確認が必要な候補が${reviewCount}件あります。WEB広告掲載可の確認後に登録作業へ進みます。`);
    }
    if (excludedCount > 0) {
      messages.push(`対象外${excludedCount}件はCSVで理由を確認できます。`);
    }
  } else if (stageName === "running") {
    messages.push("取得中は候補見込みが順番に増えます。完了後に同間取1部屋ルールといい生活照合で最終整理します。");
  } else if (stageName === "conditions") {
    messages.push("システムの条件をリアプロ検索へ反映して検索します。検索後、リアプロ画面で件数を確認してから取得します。");
  } else {
    messages.push("リアプロといい生活を開いて、ログイン済み・一覧表示済みを確認します。");
  }

  node.innerHTML = messages.map((message) => `<p>${escapeHtml(message)}</p>`).join("");
}

function opsProblemAdviceLines(message = "") {
  const text = String(message || "");
  const lines = [];
  if (/リアプロ一覧タブなし|リアプロ一覧|リスト検索/.test(text)) {
    lines.push("リアプロでリスト検索結果の一覧画面を開き、Chromeタブを確認してください。");
  }
  if (/いい生活|rent\.e-bukken|物件広告/.test(text)) {
    lines.push("いい生活は rent.e-bukken.app の物件広告一覧を開いてください。営業支援画面は対象外です。");
  }
  if (/file:|127\.0\.0\.1|ローカルサーバー/.test(text)) {
    lines.push("file:// ではなく、http://127.0.0.1:8765/index.html で開き直してください。");
  }
  if (/いい生活全体|全件|キャッシュ/.test(text)) {
    lines.push("いい生活全件キャッシュを更新してから、候補作成を再実行してください。");
  }
  if (/詳細未確認|判定不可/.test(text)) {
    lines.push("詳細未確認CSVで原因を確認し、必要なら詳細のみ再取得してください。未確認は候補には入れません。");
  }
  if (/候補.*0|0件/.test(text)) {
    lines.push("候補0件の場合は、条件、取得ページ数、除外理由、いい生活全件取得の順に確認してください。");
  }
  if (!lines.length) {
    lines.push("Chromeタブ確認、ログイン状態、取得ページ数を確認してから再実行してください。");
  }
  return [...new Set(lines)];
}

function renderOpsProblem(message = "", stage = currentWorkflowStage || "prepare") {
  const advice = opsProblemAdviceLines(message);
  setOpsText("opsTopbarState", "確認が必要");
  setOpsText("opsStageLabel", stage === "prepare" ? "ステップ1 / 準備" : "取得が停止しました");
  setOpsText("opsActionTitle", "処理を続ける前に確認してください");
  setOpsText("opsActionText", advice[0] || message);
  setOpsText("opsProgressState", "停止中");
  setOpsText("opsProgressTitle", "取得を開始できませんでした");
  setOpsText("opsCurrentOperation", "確認待ち");
  setOpsText("opsCurrentPosition", "-");
  setOpsText("opsCurrentCheck", advice[0] || "画面の状態を確認してください");
  setOpsText("opsTimeLabel", "完了状況");
  setOpsText("opsRemainingTime", "-");
  setOpsText("opsProgressMessage", [message, ...advice].filter(Boolean).join(" "));
  renderOpsNotices(opsStageName(), {});
}

function renderOpsLastRun(candidateCount) {
  const hasData = hasLoadedCaptureData && candidateCount >= 0;
  setOpsText("opsLastRunTitle", hasData ? `現在の候補 ${candidateCount}件` : "未取得");
  setOpsText("opsLastRunDate", hasData ? "候補一覧で確認" : "取得後に表示");
}

function opsCsvStatusText(candidateCount) {
  if (latestServerCsvForOps) {
    const savedTitle = latestServerCsvForOps.savedTitle || `保存済み ${latestServerCsvForOps.title}`;
    return hasLoadedCaptureData ? `現在の候補 ${candidateCount}件 / ${savedTitle}` : savedTitle;
  }
  return hasLoadedCaptureData ? `候補 ${candidateCount}件` : "候補完成後に表示します";
}

function renderOpsRunActions(stageName) {
  const runActions = document.querySelector(".ops-run-actions");
  const applyButton = document.querySelector("#opsApplyConditions");
  const runButton = document.querySelector("#opsRunCapture");
  if (!runActions || !applyButton || !runButton) return;

  const shouldShow = ["setup", "conditions", "confirm", "complete", "running"].includes(stageName);
  runActions.hidden = !shouldShow;
  if (!shouldShow) return;

  const realproSearchResult = currentRealproSearchResult();
  const sameCriteria = loadedCaptureMatchesCurrentCriteria();
  applyButton.textContent = realproSearchResult || hasLoadedCaptureData ? "条件を変更して再検索" : "反映してリアプロ検索";
  runButton.textContent = hasLoadedCaptureData
    ? (sameCriteria ? "拡張機能で追加取得" : "条件反映後に拡張取得")
    : (realproSearchResult ? "拡張機能で候補作成" : "件数確認後に取得");
  applyButton.disabled = captureIsRunning;
  runButton.disabled = captureIsRunning;
  if (opsRealproCapturePages) opsRealproCapturePages.disabled = captureIsRunning;
}

function latestPracticalCsvUrl() {
  const origin = location.protocol === "file:" ? serverIndexUrl().replace(/\/index\.html$/, "") : location.origin;
  return `${origin}/exports/latest-practical.csv`;
}

function formatOpsESeikatsuStatus() {
  const coverage = currentImportMeta?.eSeikatsuCoverage;
  if (coverage?.isFull) return `確認済み${coverage.total || coverage.fetched ? ` ${coverage.total || coverage.fetched}件` : ""}`;
  return "確認中";
}

function currentCoverageState() {
  const realproCoverage = currentImportMeta?.realproCoverage;
  const eSeikatsuCoverage = currentImportMeta?.eSeikatsuCoverage;
  const realproIncomplete = Boolean(hasLoadedCaptureData && realproCoverage?.hasTotal && !realproCoverage.isFull);
  const eSeikatsuIncomplete = Boolean(hasLoadedCaptureData && !eSeikatsuCoverage?.isFull);
  const hasIncompleteData = Boolean(realproIncomplete || eSeikatsuIncomplete);
  const shortLabel = eSeikatsuIncomplete
    ? "いい生活確認中"
    : realproIncomplete
    ? (captureIsRunning ? "リアプロ確認中" : "追加取得待ち")
    : "完了";
  return {
    realproCoverage,
    eSeikatsuCoverage,
    realproIncomplete,
    eSeikatsuIncomplete,
    hasIncompleteData,
    shortLabel,
    title: hasIncompleteData ? shortLabel : "候補リスト作成完了",
    reasonText: eSeikatsuIncomplete
      ? "いい生活を確認中です。確認が終わるまで建物名・号室の候補リストは表示しません。"
      : realproIncomplete
      ? (captureIsRunning
        ? "リアプロを確認中です。取得済み分の候補リストは表示し、追加取得が終わると候補が増える可能性があります。"
        : "リアプロの一部ページを取得済みです。残りのページは追加取得待ちで、候補が増える可能性があります。")
      : "リアプロ取得といい生活確認が完了しています。",
  };
}

function formatOpsRealproPageStatus() {
  const coverage = currentImportMeta?.realproCoverage;
  if (coverage?.capturedPages && coverage?.requiredPages) {
    return `${coverage.capturedPages}/${coverage.requiredPages}ページ`;
  }
  if (coverage?.capturedPages) return `${coverage.capturedPages}ページ`;
  return "未確認";
}

function realproRequiredPagesForOps() {
  const required = Number(currentImportMeta?.realproCoverage?.requiredPages || 0);
  if (Number.isFinite(required) && required > 0) return Math.min(Math.max(Math.ceil(required), 1), 200);
  return 0;
}

function loadedCaptureMatchesCurrentCriteria() {
  if (!hasLoadedCaptureData || !currentImportMeta?.criteriaJson) return true;
  return normalizeCriteriaJson(currentImportMeta.criteriaJson) === selectedConditionJson();
}

function opsCapturedRealproPageNumbers(options = {}) {
  const sameCriteriaOnly = options.sameCriteriaOnly ?? true;
  if (sameCriteriaOnly && !loadedCaptureMatchesCurrentCriteria()) return new Set();
  return new Set((currentImportMeta?.realproPages ?? [])
    .map((page) => Number(page?.pageNumber || 0))
    .filter((number) => Number.isFinite(number) && number > 0));
}

function opsFirstMissingRealproPage() {
  const required = realproRequiredPagesForOps();
  const captured = opsCapturedRealproPageNumbers();
  if (required) {
    for (let page = 1; page <= required; page += 1) {
      if (!captured.has(page)) return page;
    }
    return required + 1;
  }
  const maxCaptured = Math.max(0, ...captured);
  return Math.max(maxCaptured + 1, 1);
}

function opsCaptureRangeText(startPage, pages) {
  const start = Math.max(Number(startPage || 1), 1);
  const count = Math.max(Number(pages || 1), 1);
  const end = start + count - 1;
  const required = realproRequiredPagesForOps();
  const prefix = required ? `全${required}ページ中 ` : "";
  return start === end
    ? `${prefix}${start}ページ目を取得`
    : `${prefix}${start}〜${end}ページを取得`;
}

function updateOpsCaptureRangeSummary() {
  const summary = document.querySelector("#opsCaptureRangeSummary");
  if (!summary) return;
  const sameCriteria = loadedCaptureMatchesCurrentCriteria();
  const captured = opsCapturedRealproPageNumbers();
  const required = realproRequiredPagesForOps();
  if (hasLoadedCaptureData && sameCriteria && captured.size && realproStartPage) {
    const currentStart = clampCapturePages(realproStartPage.value, 1, 10000);
    const nextStart = opsFirstMissingRealproPage();
    if (captured.has(currentStart) && (!required || nextStart <= required)) {
      realproStartPage.value = String(nextStart);
    }
  }
  const startPage = clampCapturePages(realproStartPage?.value, 1, 10000);
  const pages = clampCapturePages(opsRealproCapturePages?.value || realproCapturePages?.value, 2, 200);
  const capturedPages = [...captured].sort((a, b) => a - b);
  const capturedText = captured.size
    ? ` / 取得済み ${formatNumberList(capturedPages)}ページ`
    : "";
  const remainingText = required ? ` / 未取得は${Math.max(required - captured.size, 0)}ページ` : "";
  const conditionText = hasLoadedCaptureData && !sameCriteria ? " / 条件変更: 新規取得" : "";
  summary.textContent = `${opsCaptureRangeText(startPage, pages)}${capturedText}${remainingText}${conditionText}`;
}

function setOpsCaptureRange(startPage, pages, label = "取得範囲を設定しました") {
  const safeStart = clampCapturePages(startPage, 1, 10000);
  const safePages = clampCapturePages(pages, 2, 200);
  if (realproStartPage) realproStartPage.value = String(safeStart);
  if (opsRealproCapturePages) opsRealproCapturePages.value = String(safePages);
  if (realproCapturePages) realproCapturePages.value = String(safePages);
  saveSearchConditions();
  renderCapturePlan();
  updateOpsCaptureRangeSummary();
  setOpsText("opsProgressState", "取得範囲設定済み");
  setOpsText("opsProgressTitle", label);
  setOpsText("opsProgressMessage", `取得範囲を「${opsCaptureRangeText(safeStart, safePages)}」にしました。このまま「候補を残して追加取得」を押してください。`);
  setOpsText("opsCurrentOperation", "取得設定");
  setOpsText("opsCurrentPosition", `${safeStart}〜${safeStart + safePages - 1}ページ`);
  setOpsText("opsCurrentCheck", "取得待ち");
  flashOpsPanel(".ops-command-panel");
}

function setOpsNextCapturePages(pageCount = 2) {
  const required = realproRequiredPagesForOps();
  const startPage = opsFirstMissingRealproPage();
  if (required && startPage > required) {
    setOpsText("opsProgressTitle", "全ページ取得済みです");
    setOpsText("opsProgressMessage", "追加で取得するページはありません。条件を変えるか、リセットしてから再取得してください。");
    flashOpsPanel(".ops-progress-panel");
    return;
  }
  const pages = required ? Math.min(pageCount, Math.max(required - startPage + 1, 1)) : pageCount;
  setOpsCaptureRange(startPage, pages, `次の${pages}ページを設定しました`);
}

function updateOpsFullPageButton() {
  const button = document.querySelector("#opsSetFullRealproPages");
  if (!button) return;
  const required = realproRequiredPagesForOps();
  const captured = opsCapturedRealproPageNumbers().size || Number(currentImportMeta?.realproCoverage?.capturedPages || 0);
  const remaining = Math.max(required - captured, 0);
  const shouldShow = Boolean(required && remaining > 0);
  button.hidden = !shouldShow;
  if (shouldShow) {
    button.textContent = captured ? `残り${remaining}ページ` : `全${required}ページ`;
    button.title = `今回のリアプロ検索結果は全${required}ページです`;
  }
  updateOpsCaptureRangeSummary();
}

function setOpsCapturePagesToFull() {
  const required = realproRequiredPagesForOps();
  if (!required) return;
  const startPage = opsFirstMissingRealproPage();
  const pages = Math.max(required - startPage + 1, 1);
  setOpsCaptureRange(startPage, pages, startPage > 1 ? "残り全部を設定しました" : `全${required}ページ取得に設定しました`);
}

function formatOpsRealproPosition(checkedRoomCount = 0) {
  const pageText = formatOpsRealproPageStatus();
  if (pageText !== "未確認" && checkedRoomCount) return `${pageText}・${checkedRoomCount}戸取得`;
  if (checkedRoomCount) return `${checkedRoomCount}戸取得`;
  return "-";
}

function handleOpsJump(target) {
  if (target === "conditions") {
    conditionBuilder?.scrollIntoView({ behavior: "smooth", block: "start" });
    return;
  }
  if (target === "complete") {
    if (hasLoadedCaptureData) {
      location.hash = "candidateResults";
      return;
    }
    document.getElementById("opsResultPanel")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    return;
  }
  if (target === "confirm" || target === "running") {
    document.querySelector(".ops-progress-panel")?.scrollIntoView({ behavior: "smooth", block: "center" });
    return;
  }
  document.getElementById("opsDashboard")?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function flashOpsPanel(selector) {
  const panel = document.querySelector(selector);
  if (!panel) return;
  panel.classList.remove("is-attention-flash");
  void panel.offsetWidth;
  panel.classList.add("is-attention-flash");
}

function scrollToOpsProgress() {
  document.querySelector(".ops-progress-panel")?.scrollIntoView({ behavior: "smooth", block: "start" });
  flashOpsPanel(".ops-progress-panel");
}

function openCandidateResultsPanel() {
  const target = hasLoadedCaptureData
    ? document.getElementById("candidateResults")
    : document.getElementById("opsResultPanel");
  if (!target) return;
  target.scrollIntoView({ behavior: "smooth", block: "start" });
  flashOpsPanel(hasLoadedCaptureData ? "#candidateResults" : "#opsResultPanel");
  if (hasLoadedCaptureData) location.hash = "candidateResults";
}

function scrollToCandidateSummaryPanel() {
  const target = document.getElementById("opsResultPanel") || document.getElementById("candidateResults");
  if (!target) return;
  target.scrollIntoView({ behavior: "smooth", block: "start" });
  flashOpsPanel("#opsResultPanel");
}

function hideCompletionToast() {
  if (completionToast) completionToast.hidden = true;
}

function candidateListWaitingForESeikatsu() {
  return Boolean(hasLoadedCaptureData && currentCoverageState().eSeikatsuIncomplete);
}

function candidateListReady() {
  return Boolean(hasLoadedCaptureData && !candidateListWaitingForESeikatsu());
}

function showCompletionToast(title = "取得が完了しました") {
  if (!completionToast || !completionToastTitle || !completionToastMessage || !completionToastMeta) return;
  if (!candidateListReady()) {
    hideCompletionToast();
    return;
  }
  const candidateRows = hasLoadedCaptureData ? buildRowsPreservingStats({ includeExcluded: false }) : [];
  const workCount = candidateRows.filter((row) => workTargetLabel(row) === "作業対象").length;
  const reviewCount = candidateRows.filter((row) => workTargetLabel(row) === "確認後判断").length;
  const pageText = hasLoadedCaptureData ? formatOpsRealproPageStatus() : "取得完了";
  const roomCount = importedRealproRooms.length || latestStats.total || 0;
  completionToastTitle.textContent = title;
  completionToastMessage.textContent = `候補${candidateRows.length}件（作業対象${workCount}件 / 確認${reviewCount}件）`;
  completionToastMeta.textContent = `${pageText}・${roomCount}戸確認。クリックで候補へ移動`;
  completionToast.hidden = false;
}

function handleOpsRunCaptureClick() {
  if (captureIsRunning) return;
  const sameCriteria = loadedCaptureMatchesCurrentCriteria();
  if (!currentRealproSearchResult() && (!hasLoadedCaptureData || !sameCriteria)) {
    setOpsText("opsTopbarState", "検索結果待ち");
    setOpsText("opsProgressState", "取得前");
    setOpsText("opsProgressTitle", "リアプロの検索結果をまだ確認できていません");
    setOpsText("opsProgressMessage", hasLoadedCaptureData && !sameCriteria
      ? "検索条件が変わっています。前回候補とは混ぜず、先に「条件をリアプロへ反映」を押してください。"
      : "これは候補0件という意味ではありません。1. Chromeタブ確認 → 2. 条件をリアプロへ反映、またはリアプロの検索結果一覧を開いてから、もう一度取得してください。");
    setOpsText("opsCurrentOperation", "取得前");
    setOpsText("opsCurrentPosition", "未確認");
    setOpsText("opsCurrentCheck", "リアプロ検索結果の総件数・総ページ数の確認待ち");
    scrollToOpsProgress();
    return;
  }
  setOpsText("opsTopbarState", "取得開始");
  setOpsText("opsProgressState", "起動中");
  setOpsText("opsProgressTitle", "Chrome拡張でリアプロ取得を開始します");
  setOpsText("opsProgressMessage", "Chromeは別作業に使えます。リアプロタブを閉じずに待ってください。");
  scrollToOpsProgress();
  handleExtensionPrimaryCaptureRun();
}

function renderOpsCandidatePreview(candidateRows = []) {
  const container = document.getElementById("opsCandidatePreview");
  if (!container) return;
  if (!hasLoadedCaptureData) {
    container.innerHTML = "候補作成後、ここに作業候補の建物・号室を表示します。";
    return;
  }
  if (!candidateRows.length) {
    const checkedRoomCount = importedRealproRooms.length || latestStats.total || 0;
    const excludedCount = Number(latestStats.excluded || 0);
    const judgedCount = Number(latestStats.total || 0);
    const zeroReason = checkedRoomCount && !judgedCount
      ? `リアプロから${checkedRoomCount}戸を取得しましたが、現在のシステム条件に合う判定対象は0件でした。`
      : `リアプロから${checkedRoomCount}戸を取得しましたが、今回の条件・除外ルールで作業対象に残りませんでした。`;
    const excludedText = excludedCount > 0 ? `対象外は${excludedCount}件です。` : "";
    container.innerHTML = `
      <div class="ops-preview-empty">
        <strong>作業候補は0件です</strong>
        <span>${zeroReason}${excludedText}下の候補作成結果で「除外も表示」を使うと理由を確認できます。</span>
      </div>
    `;
    return;
  }
  const workRows = candidateRows.filter((row) => workTargetLabel(row) === "作業対象");
  const reviewRows = candidateRows.filter((row) => workTargetLabel(row) === "確認後判断");
  const coverageState = currentCoverageState();
  const waitingForESeikatsu = candidateListWaitingForESeikatsu();
  if (waitingForESeikatsu) {
    container.innerHTML = `
      <div class="ops-preview-estimate">
        <span>候補見込み</span>
        <strong>${candidateRows.length}件</strong>
        <small>${escapeHtml(coverageState.reasonText)}</small>
      </div>
    `;
    return;
  }
  container.innerHTML = `
    <div class="ops-preview-heading">
      <strong>登録・確認する候補 ${candidateRows.length}件</strong>
      <span>作業対象 ${workRows.length}件 / 確認が必要 ${reviewRows.length}件</span>
    </div>
    ${coverageState.realproIncomplete ? `<p class="ops-preview-warning">${escapeHtml(coverageState.reasonText)}</p>` : ""}
    <div class="ops-preview-list">
      ${candidateRows.map((row) => `
        <a class="ops-preview-item" href="${escapeHtml(row.realproUrl || "#")}" target="_blank" rel="noopener noreferrer">
          <span>${escapeHtml(workTargetLabel(row))} / ${escapeHtml(row.action || row.type)}</span>
          <strong>${escapeHtml(row.building || "-")} ${escapeHtml(roomLabel(row.room))}</strong>
          <small>${escapeHtml([row.line, row.station, row.layout, yenLabel(row.rent), row.note].filter(Boolean).join(" / "))}</small>
        </a>
      `).join("")}
    </div>
  `;
}

function renderOpsDashboard() {
  const stageName = opsStageName();
  const opsDashboard = document.getElementById("opsDashboard");
  if (opsDashboard) opsDashboard.dataset.stage = stageName;
  const candidateRows = hasLoadedCaptureData ? buildRowsPreservingStats({ includeExcluded: false }) : [];
  const workCount = candidateRows.filter((row) => workTargetLabel(row) === "作業対象").length;
  const reviewCount = candidateRows.filter((row) => workTargetLabel(row) === "確認後判断").length;
  const excludedCount = Number(latestStats.excluded || 0);
  const realproReady = Boolean(realproLoggedIn?.checked);
  const eSeikatsuReady = Boolean(eSeikatsuLoggedIn?.checked && eSeikatsuListingOpen?.checked);
  const conditionReady = !isDefaultSearchCriteria();
  const realproSearchResult = currentRealproSearchResult();
  const countReady = hasLoadedCaptureData || Boolean(realproSearchResult);
  const checkedRoomCount = importedRealproRooms.length || latestStats.total || 0;
  const coverageState = currentCoverageState();
  const isPartial = coverageState.realproIncomplete;
  const hasIncompleteData = coverageState.hasIncompleteData;
  const waitingForESeikatsu = candidateListWaitingForESeikatsu();
  const candidateMetricText = hasLoadedCaptureData
    ? (waitingForESeikatsu ? `見込み ${candidateRows.length}件` : `${candidateRows.length}件`)
    : "0件";
  const incompleteReason = coverageState.shortLabel;
  const opsProgressPanel = document.querySelector(".ops-progress-panel");
  opsProgressPanel?.classList.toggle("is-running", captureIsRunning);
  opsProgressPanel?.classList.toggle("is-checking", Boolean(captureIsRunning));

  renderOpsSteps(stageName);
  renderOpsConditionSummary();
  renderOpsCandidatePreview(candidateRows);
  renderOpsTabTargets();
  updateOpsFullPageButton();
  renderOpsCheck("opsCheckRealpro", realproReady, "確認済み", "未確認");
  renderOpsCheck("opsCheckESeikatsu", eSeikatsuReady, "確認済み", "未確認");
  renderOpsCheck("opsCheckConditions", conditionReady, "反映準備OK", "未反映");
  renderOpsCheck(
    "opsCheckCount",
    countReady,
    hasLoadedCaptureData ? `${checkedRoomCount}戸` : (realproSearchResult?.searchSummary || "未確認"),
    "未確認",
  );

  if (captureLastError && !captureIsRunning) {
    renderOpsProblem(captureLastError, currentWorkflowStage || "prepare");
    setOpsText("opsMetricPages", hasLoadedCaptureData ? formatOpsRealproPageStatus() : "-");
    setOpsText("opsWorkCount", hasLoadedCaptureData ? String(workCount) : "-");
    setOpsText("opsReviewCount", hasLoadedCaptureData ? String(reviewCount) : "-");
    setOpsText("opsExcludedCount", hasLoadedCaptureData ? String(excludedCount) : "-");
    setOpsText("opsCsvState", latestServerCsvForOps || hasLoadedCaptureData ? "作成可能" : "未作成");
    setOpsText("opsCsvText", opsCsvStatusText(candidateRows.length));
    const openLatestPractical = document.querySelector("#opsOpenLatestPractical");
    if (openLatestPractical) openLatestPractical.disabled = !hasLoadedCaptureData && !latestServerCsvForOps;
    renderOpsLastRun(candidateRows.length);
    renderOpsRunActions(stageName);
    return;
  } else if (captureIsRunning) {
    setOpsText("opsTopbarState", "候補作成中");
    setOpsText("opsStageLabel", "ステップ4 / 取得・照合");
    setOpsText("opsActionTitle", "リアプロ詳細を確認しています");
    setOpsText("opsActionText", "WEB広告掲載、電子入居申込、いい生活掲載状況を号室単位で照合しています。");
    setOpsText("opsPrimaryAction", "進行状況を見る");
    setOpsText("opsSecondaryAction", "候補一覧を開く");
    setOpsText("opsProgressState", "取得中");
    setOpsText("opsProgressTitle", "候補リストを作成中");
  } else if (hasLoadedCaptureData) {
    setOpsText("opsTopbarState", waitingForESeikatsu ? "候補見込み" : (hasIncompleteData ? "候補表示中" : "候補抽出完了"));
    setOpsText("opsStageLabel", waitingForESeikatsu ? "ステップ4 / いい生活確認中" : "ステップ5 / 候補確認");
    setOpsText("opsActionTitle", "登録候補を確認します");
    setOpsText("opsActionText", waitingForESeikatsu
      ? `${coverageState.reasonText} 現時点では${checkedRoomCount}戸を判定し、候補見込みは${candidateRows.length}件です。`
      : hasIncompleteData
      ? `${coverageState.reasonText} 現時点では${checkedRoomCount}戸を判定し、候補リストは${candidateRows.length}件です。`
      : `${checkedRoomCount}戸を確認し、現在の条件で${candidateRows.length}件の候補を抽出しました。`);
    setOpsText("opsPrimaryAction", "候補一覧を開く");
    setOpsText("opsSecondaryAction", hasIncompleteData ? "未完了分を取得" : "条件を変える");
    setOpsText("opsProgressState", hasIncompleteData ? coverageState.shortLabel : "完了");
    setOpsText("opsProgressTitle", hasIncompleteData ? coverageState.title : `${checkedRoomCount}戸を取得・照合しました`);
  } else if (realproSearchResult) {
    setOpsText("opsTopbarState", "件数確認済み");
    setOpsText("opsStageLabel", "ステップ3 / リアプロ確認");
    setOpsText("opsActionTitle", "リアプロ検索結果を取得できます");
    setOpsText("opsActionText", `リアプロ側で ${realproSearchResult.searchSummary} を確認しました。次に号室詳細を取得して候補を作成します。`);
    setOpsText("opsPrimaryAction", "リアプロを取得して候補作成");
    setOpsText("opsSecondaryAction", "条件を編集");
    setOpsText("opsProgressState", "件数確認済み");
    setOpsText("opsProgressTitle", realproSearchResult.searchSummary);
  } else if (conditionReady) {
    setOpsText("opsTopbarState", "検索条件を準備中");
    setOpsText("opsStageLabel", "ステップ2 / 条件入力");
    setOpsText("opsActionTitle", "システムの条件でリアプロ検索します");
    setOpsText("opsActionText", "選んだ条件をリアプロ検索画面へ反映して検索します。検索後、リアプロ画面で件数を目視確認します。");
    setOpsText("opsPrimaryAction", "反映してリアプロ検索");
    setOpsText("opsSecondaryAction", "条件を編集");
    setOpsText("opsProgressState", "条件確認");
    setOpsText("opsProgressTitle", selectedConditionText());
  } else {
    setOpsText("opsTopbarState", "準備確認中");
    setOpsText("opsStageLabel", "ステップ1 / 準備");
    setOpsText("opsActionTitle", "リアプロといい生活を開きます");
    setOpsText("opsActionText", "ログイン済みのChromeで、リアプロのリスト検索といい生活の物件広告一覧を開きます。");
    setOpsText("opsPrimaryAction", "リアプロを開く");
    setOpsText("opsSecondaryAction", "いい生活を開く");
    setOpsText("opsProgressState", "待機中");
    setOpsText("opsProgressTitle", "取得開始前");
  }

  if (captureIsRunning) {
    if (lastLiveCaptureProgress) {
      renderLiveCaptureProgress(lastLiveCaptureProgress);
    } else {
      setOpsText("opsMetricPages", "確認中");
      setOpsText("opsMetricRealpro", "取得中");
      setOpsText("opsMetricJudged", "0 / 0");
      setOpsText("opsMetricCandidates", "0件");
      setOpsText("opsMetricESeikatsu", "確認中");
      setOpsText("opsTimeLabel", "残り目安");
      setOpsText("opsRemainingTime", "計算中");
      setOpsText("opsCurrentOperation", "Chromeタブ確認");
      setOpsText("opsCurrentPosition", "-");
      setOpsText("opsCurrentCheck", "リアプロ一覧といい生活一覧を確認中");
      setOpsText("opsProgressUpdatedAt", "-");
      setOpsText("opsProgressMessage", "Chromeタブを確認しています...");
    }
    setOpsText("opsWorkCount", "-");
    setOpsText("opsReviewCount", "-");
    setOpsText("opsExcludedCount", "-");
    setOpsText("opsCsvState", "作成中");
    setOpsText("opsCsvText", "取得完了後に保存できます");
      renderOpsNotices(stageName, { reviewCount, excludedCount, isPartial });
    renderOpsLastRun(candidateRows.length);
    renderOpsRunActions(stageName);
    return;
  }

  const judgedText = checkedRoomCount
    ? (hasLoadedCaptureData ? `${checkedRoomCount} / ${checkedRoomCount}` : `${Math.min(latestStats.total || checkedRoomCount, checkedRoomCount)} / ${checkedRoomCount}`)
    : "0 / 0";
  setOpsText("opsMetricPages", hasLoadedCaptureData ? formatOpsRealproPageStatus() : (realproSearchResult ? "取得前" : "未確認"));
  setOpsText("opsMetricRealpro", checkedRoomCount ? `${checkedRoomCount}戸` : "未確認");
  setOpsText("opsMetricJudged", judgedText);
  setOpsText("opsMetricCandidates", candidateMetricText);
  setOpsText("opsMetricESeikatsu", formatOpsESeikatsuStatus());
  setOpsText("opsTimeLabel", captureIsRunning ? "残り目安" : "完了状況");
  setOpsText("opsRemainingTime", captureIsRunning ? "計算中" : (hasLoadedCaptureData ? coverageState.shortLabel : "-"));
  setOpsText("opsProgressMessage", hasLoadedCaptureData
    ? (waitingForESeikatsu
      ? `${coverageState.reasonText} 候補見込みだけ表示しています。`
      : hasIncompleteData
      ? `${coverageState.reasonText} いい生活確認済みの候補リストは表示しています。`
      : "取得した号室数は登録可能件数ではありません。登録・差替に進める件数は作業候補です。")
    : realproSearchResult
      ? "件数確認済みです。次にリアプロを取得して候補作成へ進めます。"
      : "システムの条件でリアプロ検索後、リアプロ側の件数を確認してから取得します。");
  setOpsText("opsCurrentOperation", hasLoadedCaptureData ? (waitingForESeikatsu ? "候補見込みを表示中" : (hasIncompleteData ? "候補リストを表示中" : "候補判定完了")) : (realproSearchResult ? "取得待ち" : (conditionReady ? "検索条件確認" : "準備")));
  setOpsText("opsCurrentPosition", hasLoadedCaptureData ? formatOpsRealproPosition(checkedRoomCount) : (realproSearchResult?.searchSummary || "-"));
  setOpsText("opsCurrentCheck", hasLoadedCaptureData ? (hasIncompleteData ? coverageState.shortLabel : "作業対象・確認後判断・対象外を整理済み") : (realproSearchResult ? "取得開始できます" : "リアプロといい生活のタブを確認します"));
  setOpsText("opsProgressUpdatedAt", hasLoadedCaptureData ? formatDateTime(currentImportMeta?.importedAt || new Date()) : "-");
  setOpsText("opsWorkCount", hasLoadedCaptureData ? String(workCount) : "-");
  setOpsText("opsReviewCount", hasLoadedCaptureData ? String(reviewCount) : "-");
  setOpsText("opsExcludedCount", hasLoadedCaptureData ? String(excludedCount) : "-");
  setOpsText("opsCsvState", hasIncompleteData ? "未完成" : (latestServerCsvForOps || hasLoadedCaptureData ? "作成可能" : "未作成"));
  setOpsText("opsCsvText", hasIncompleteData ? "追加取得後に候補一覧で確認" : opsCsvStatusText(candidateRows.length));
  const openLatestPractical = document.querySelector("#opsOpenLatestPractical");
  if (openLatestPractical) openLatestPractical.disabled = !hasLoadedCaptureData && !latestServerCsvForOps;
  renderOpsNotices(stageName, { reviewCount, excludedCount, isPartial });
  renderOpsLastRun(candidateRows.length);
  renderOpsRunActions(stageName);
  const progressBar = document.getElementById("opsProgressBar");
  if (progressBar) progressBar.style.width = hasLoadedCaptureData ? "100%" : (realproSearchResult ? "34%" : (conditionReady ? "18%" : "0%"));
}

function renderPreview(rows) {
  updateResultTypeFilter(rows);
  const displayRows = filterResultRows(rows);
  renderCandidateCoverageNote(displayRows);
  renderResultViewSummary(rows, displayRows);
  const waitingForFinal = candidateListWaitingForESeikatsu();
  document.getElementById("candidateResults")?.classList.toggle("is-waiting-final", waitingForFinal);
  if (waitingForFinal) {
    previewRows.innerHTML = "";
    renderExclusionSummary();
    renderActionSummary(rows);
    renderResultTypeSummary(rows);
    renderVerificationStatus();
    return;
  }
  if (!displayRows.length) {
    const helpLines = emptyResultHelpLines(rows, displayRows);
    const helpHtml = helpLines.length
      ? `<div class="zero-result-help">${helpLines.map((line) => escapeHtml(line)).join("<br>")}</div>`
      : "";
    previewRows.innerHTML = `
      <tr>
        <td colspan="18" class="empty-result">
          <div>表示できる行がありません。</div>
          ${helpHtml}
        </td>
      </tr>
    `;
    renderExclusionSummary();
    renderActionSummary(rows);
    renderResultTypeSummary(rows);
    renderVerificationStatus();
    return;
  }

  const previewRowsForDom = displayRows.slice(0, MAX_PREVIEW_ROWS);
  const truncatedRow = displayRows.length > previewRowsForDom.length
    ? `
      <tr>
        <td colspan="18" class="empty-result">表示は先頭${MAX_PREVIEW_ROWS}件までです。CSVと集計は${displayRows.length}件全体を対象にしています。</td>
      </tr>
    `
    : "";

  previewRows.innerHTML = previewRowsForDom
    .map((row) => {
      const classNames = rowClassNames(row);
      const rowClass = classNames ? ` class="${classNames}"` : "";
      return `
        <tr${rowClass}>
          <td>${escapeHtml(row.action)}</td>
          <td>${escapeHtml(row.nextStep)}</td>
          <td>${escapeHtml(row.type)}</td>
          <td>${escapeHtml(row.priority)}</td>
          <td>${escapeHtml(row.priorityLabel)}</td>
          <td>${escapeHtml(workTargetLabel(row))}</td>
          <td>${escapeHtml(row.building)}</td>
          <td>${realproRoomLink(row)}</td>
          <td>${escapeHtml(locationAccessLabel(row))}</td>
          <td>${escapeHtml(row.layout)}</td>
          <td>${escapeHtml(yenLabel(row.rent))}</td>
          <td>${escapeHtml(realproStatusLabel(row))}</td>
          <td>${escapeHtml(row.equipment.join("、"))}</td>
          <td>${escapeHtml(row.ad)}</td>
          <td>${escapeHtml(row.status)}</td>
          <td>${escapeHtml(row.confirmationReason)}</td>
          <td>${escapeHtml(row.note)}</td>
          <td>${rowLinks(row)}</td>
        </tr>
      `;
    })
    .join("") + truncatedRow;
  renderExclusionSummary();
  renderActionSummary(rows);
  renderResultTypeSummary(rows);
  renderVerificationStatus();
}

function renderCandidateCoverageNote(displayRows = []) {
  if (!candidateCoverageNote) return;
  if (!hasLoadedCaptureData) {
    candidateCoverageNote.hidden = true;
    candidateCoverageNote.innerHTML = "";
    return;
  }
  const coverageState = currentCoverageState();
  const firstRealproUrl = displayRows.find((row) => row.realproUrl)?.realproUrl || "";
  const notes = [];
  if (candidateListWaitingForESeikatsu()) {
    notes.push(`
      <div class="candidate-estimate-card">
        <span>候補見込み</span>
        <strong>${displayRows.length}件</strong>
        <small>${escapeHtml(coverageState.reasonText)}</small>
      </div>
    `);
  } else if (firstRealproUrl) {
    notes.push(`
      <span>号室クリックでリアプロ詳細を開きます。初回だけログイン確認が出る場合は、ログイン後に同じ号室をもう一度開いてください。</span>
      <button class="text-button" type="button" data-open-realpro-detail-check="${escapeAttribute(firstRealproUrl)}">初回リンク確認</button>
    `);
    if (coverageState.realproIncomplete) {
      notes.push(`
        <span>リアプロ確認中です。取得済み分の候補リストは表示中で、追加取得が終わると候補が増える可能性があります。</span>
      `);
    }
  }
  if (!notes.length) {
    candidateCoverageNote.hidden = true;
    candidateCoverageNote.innerHTML = "";
    return;
  }
  candidateCoverageNote.hidden = false;
  candidateCoverageNote.innerHTML = notes.join("");
}

function emptyResultHelpLines(rows, displayRows) {
  if (!hasLoadedCaptureData) return [];
  if (rows.length && !displayRows.length) {
    return ["表示区分または結果検索の絞り込みで0件です。表示区分を「すべて」に戻すか、結果検索を消して確認してください。"];
  }
  if (latestStats.total > 0 && !rows.length && !showExcludedToggle?.checked) {
    return [
      `現在の検索条件に合うリアプロ号室は${latestStats.total}件ありますが、すべて候補外または除外です。`,
      "「除外も表示」をオンにすると、いい生活掲載中・商談中/審査中・申込あり・同間取募集中などの理由を確認できます。",
    ];
  }
  if (latestStats.total > 0 && !rows.length) {
    return [`現在の検索条件に合う${latestStats.total}件はありますが、表示できる候補がありません。条件と除外理由を確認してください。`];
  }
  return criteriaZeroDiagnosticLines();
}

function criteriaZeroDiagnosticLines(criteria = collectCriteria(), rooms = currentSourceRealproRooms()) {
  if (!rooms.length) return ["リアプロ取得データがありません。リアプロ一覧を取得してから再読み込みしてください。"];

  const lines = [];
  let remaining = [...rooms];
  const addStep = (active, label, predicate) => {
    if (!active) return;
    const before = remaining.length;
    remaining = remaining.filter(predicate);
    if (before !== remaining.length) lines.push(`${label}: ${before}件→${remaining.length}件`);
  };

  addStep(criteria.sapporoOnly, "札幌市内のみ", (room) => String(room.address || "").includes("札幌市"));
  addStep(criteria.lines.length > 0, `路線 ${criteria.lines.join("、")}`, (room) => criteria.lines.includes(room.line));
  addStep(criteria.stations.length > 0, `駅 ${criteria.stations.map((value) => value.split(":").slice(1).join(":") || value).join("、")}`, (room) => criteria.stations.includes(`${room.line}:${room.station}`));
  addStep(criteria.layouts.length > 0, `間取 ${criteria.layouts.join("、")}`, (room) => layoutMatchesSelected(room.layout, criteria.layouts));
  addStep(Boolean(criteria.rentMin), `賃料下限 ${yenLabel(criteria.rentMin)}`, (room) => criteriaRent(room, criteria) >= criteria.rentMin);
  addStep(Boolean(criteria.rentMax), `賃料上限 ${yenLabel(criteria.rentMax)}`, (room) => criteriaRent(room, criteria) <= criteria.rentMax);
  addStep(Boolean(criteria.accessMethod), `駅までの移動手段 ${criteria.accessMethod}`, (room) => (room.accessMethod ?? "徒歩") === criteria.accessMethod);
  addStep(Boolean(criteria.walkMinutes), `駅まで ${criteria.walkMinutes}分以内`, (room) => Number(room.walkMinutes || 0) <= criteria.walkMinutes);
  addStep(criteria.immediate, "即入物件", (room) => room.availableDate === "即入");
  addStep(criteria.availability === "空室", "状態 空室", (room) => String(room.status || "").includes("空室"));
  addStep(criteria.availability === "退去予定", "状態 退去予定", (room) => String(room.status || "").includes("退去予定"));
  addStep(criteria.availability === "空室・退去予定", "状態 空室・退去予定", (room) => ["空室", "退去予定"].some((status) => String(room.status || "").includes(status)));

  criteria.equipment.forEach((item) => {
    addStep(true, `設備 ${item}`, (room) => roomHasEquipment(room, item));
  });

  if (criteria.equipment.includes("駐車場空きあり") && !rooms.some((room) => roomHasEquipment(room, "駐車場空きあり"))) {
    lines.push("駐車場空きありは、現在の取得データ内では確認できていません。リアプロ検索側で駐車場条件を指定して取得済みなら、取得後の追加絞り込み側の駐車場チェックは外して確認してください。リアプロ側で指定していない場合は、リアプロ検索条件に駐車場空きありを反映して再取得してください。");
  }

  if (!lines.length) {
    return ["現在の検索条件では取得データに一致する号室がありません。リアプロ側の検索条件、取得ページ数、読み込んだ取得JSONを確認してください。"];
  }
  return [`条件別の減り方: ${lines.slice(0, 6).join(" / ")}`, ...lines.slice(6, 9)];
}

function currentSourceRealproRooms() {
  return importedRealproRooms.length ? importedRealproRooms : realproRooms;
}

function criteriaRent(room, criteria) {
  const rent = Number(room.rent || 0);
  const fee = Number(room.fee || 0);
  return criteria.includeManagementFee ? rent + fee : rent;
}

function roomHasEquipment(room, item) {
  return Array.isArray(room.equipment) && room.equipment.includes(item);
}

function isLeopalaceBuilding(room = {}) {
  const building = normalize(room.building);
  return building.includes("レオパレス") || building.includes("れおぱれす") || building.includes("leopalace");
}

function workTargetLabel(row) {
  if (row.priorityLabel === "高") return "作業対象";
  if (row.priorityLabel === "要確認") return "確認後判断";
  if (row.priorityLabel === "対象外") return "対象外";
  return "確認";
}

function rowClassNames(row) {
  const classNames = [];
  if (row.priorityLabel === "高") classNames.push("row-priority-high");
  if (row.priorityLabel === "要確認") classNames.push("row-priority-check");
  if (row.priorityLabel === "対象外" || row.type.includes("除外") || row.type.includes("候補外")) classNames.push("row-priority-out");
  return classNames.join(" ");
}

function renderResultViewSummary(rows, displayRows) {
  if (!resultViewSummary) return;
  const type = resultTypeFilter?.value || "すべて";
  const query = resultTextFilter?.value?.trim();
  const filterLabel = resultFilterSummaryText(type, query);
  const highCount = displayRows.filter((row) => row.priorityLabel === "高").length;
  const checkCount = displayRows.filter((row) => row.priorityLabel === "要確認").length;
  const outCount = displayRows.filter((row) => row.priorityLabel === "対象外").length;
  const candidateBreakdown = candidateBreakdownText(displayRows);
  const candidateBreakdownLabel = candidateBreakdown ? ` / 候補内訳: ${candidateBreakdown}` : "";
  resultViewSummary.textContent = `${filterLabel} / 表示中: ${displayRows.length}件 / 高優先度: ${highCount}件 / 要確認: ${checkCount}件 / 対象外: ${outCount}件${candidateBreakdownLabel} / 対象: ${rows.length}件`;
  renderCsvSummary(rows, displayRows);
}

function resultFilterSummaryText(type, query) {
  const labels = [];
  if (type && type !== "すべて") labels.push(`区分:${type}`);
  if (query) labels.push(`検索:${query}`);
  return labels.length ? `絞り込み中 (${labels.join(" / ")})` : "絞り込みなし";
}

function currentResultFilterSummaryText() {
  return resultFilterSummaryText(resultTypeFilter?.value || "すべて", resultTextFilter?.value?.trim() || "");
}

function csvExportScopeText(label) {
  const scopes = {
    表示中CSV: "現在の表示絞り込みを反映",
    現場用CSV: "候補全体から普段の登録作業で使う作業表を出力。画面の表示区分・結果検索は反映しない",
    作業対象CSV: "作業対象のみ。画面の表示区分・結果検索は反映しない",
    確認用CSV: "確認後判断のみ。画面の表示区分・結果検索は反映しない",
    候補CSV: "候補全体。画面の表示区分・結果検索は反映しない",
    全件CSV: "除外も含む全件。画面の表示区分・結果検索は反映しない",
    詳細未確認CSV: "詳細未確認のみ。画面の表示区分・結果検索は反映しない",
  };
  return scopes[label] ?? "指定CSV条件で出力";
}

function candidateBreakdownText(rows) {
  const labels = [
    ["管理会社確認", (row) => row.ad === "管理会社確認必要"],
    ["詳細未確認", (row) => row.type === "詳細未確認・除外"],
    ["掲載確認", (row) => row.type === "掲載確認候補"],
    ["差替", (row) => row.type === "掲載差替候補"],
    ["募集開始", (row) => row.type === "募集開始候補"],
  ];

  return labels
    .map(([label, predicate]) => {
      const count = rows.filter(predicate).length;
      return count ? `${label}${count}` : "";
    })
    .filter(Boolean)
    .join(" / ");
}

function confirmationReasonBreakdownText(rows) {
  const counts = rows.reduce((items, row) => {
    const reason = row.confirmationReason || "";
    if (reason) items.set(reason, (items.get(reason) ?? 0) + 1);
    return items;
  }, new Map());

  return [...counts.entries()]
    .map(([reason, count]) => `${reason}${count}`)
    .join(" / ");
}

function renderCsvSummary(rows = latestRows, displayRows = filterResultRows(rows)) {
  if (!csvSummary) return;
  if (!hasLoadedCaptureData) {
    csvSummary.textContent = "CSV出力はデータ読み込み後に使えます。";
    csvSummary.className = "note csv-summary";
    return;
  }

  const allRows = buildRowsPreservingStats({ includeExcluded: true });
  const candidateRows = buildRowsPreservingStats({ includeExcluded: false });
  const workRows = candidateRows.filter((row) => workTargetLabel(row) === "作業対象");
  const reviewRows = candidateRows.filter((row) => workTargetLabel(row) === "確認後判断");
  const detailUnconfirmedRows = buildDetailUnconfirmedCsvRows();
  updateCsvButtonAvailability({ displayRows, workRows, reviewRows, candidateRows, allRows, detailUnconfirmedRows });
  const visibleWorkCounts = workTargetSummaryText(displayRows);
  const workOnlyCounts = workTargetSummaryText(workRows);
  const reviewOnlyCounts = workTargetSummaryText(reviewRows);
  const candidateWorkCounts = workTargetSummaryText(candidateRows);
  const allWorkCounts = workTargetSummaryText(allRows);
  const candidateBreakdown = candidateBreakdownText(candidateRows);
  const allCandidateBreakdown = candidateBreakdownText(allRows);
  const reviewReasonBreakdown = confirmationReasonBreakdownText(reviewRows);
  const filtered = displayRows.length !== rows.length || Boolean(resultTypeFilter?.value || resultTextFilter?.value?.trim());
  const checklistWarning = productionChecklistIncompleteText();
  const freshness = captureFreshnessSummary(currentImportMeta?.capturedAt);
  const freshnessWarning = freshness && freshness.value !== "当日" ? freshness.message : "";
  const eSeikatsuCacheFreshnessText = eSeikatsuCacheFreshnessWarning(currentImportMeta?.eSeikatsuCache);
  const freshnessReviewMissingWarning = currentFreshnessReviewMissingText();
  const restoreHistoryText = conditionRestoreHistorySummaryText();
  const restoreHistoryWarning = restoreHistoryText.includes("未反映")
    ? `検索条件復元履歴に未反映があります: ${restoreHistoryText}`
    : "";
  const detailUnconfirmedText = detailUnconfirmedSummaryText();
  const detailUnconfirmedWarning = detailUnconfirmedText
    ? `詳細未確認は候補CSVに入れません: ${detailUnconfirmedText}`
    : "";
  const coverageWarning = dataCoverageBlockingText();
  const detailUnconfirmedReviewStatus = detailUnconfirmedText ? `詳細未確認検証状態: ${currentDetailUnconfirmedReviewStatusText()}` : "";
  const detailUnconfirmedReviewMissingWarning = currentDetailUnconfirmedReviewMissingText();
  const confirmNotice = candidateRows.some((row) => workTargetLabel(row) === "確認後判断")
    ? "候補CSVに確認後判断の行があります。登録前に注意欄を確認してください。"
    : "";
  csvSummary.textContent = [
    `表示中CSV: 現在表示中の${displayRows.length}件${visibleWorkCounts}`,
    `現場用CSV: 候補${candidateRows.length}件を作業表形式で出力`,
    `作業対象CSV: 登録作業に回す${workRows.length}件${workOnlyCounts}`,
    `確認用CSV: 確認後判断の${reviewRows.length}件${reviewOnlyCounts}${reviewReasonBreakdown ? ` / 確認理由: ${reviewReasonBreakdown}` : ""}`,
    `候補CSV: 除外を含まない候補${candidateRows.length}件${candidateWorkCounts}${candidateBreakdown ? ` / 候補内訳: ${candidateBreakdown}` : ""}`,
    `全件CSV: 除外・重複を含む${allRows.length}件${allWorkCounts}${allCandidateBreakdown ? ` / 全件内訳: ${allCandidateBreakdown}` : ""}`,
    `詳細未確認CSV: 改善用${detailUnconfirmedRows.length}件`,
    confirmNotice,
    freshnessWarning,
    eSeikatsuCacheFreshnessText,
    freshnessReviewMissingWarning,
    restoreHistoryWarning,
    coverageWarning,
    detailUnconfirmedWarning,
    detailUnconfirmedReviewStatus,
    detailUnconfirmedReviewMissingWarning,
    reviewRows.length ? "確認用CSVの行は確認理由チップで画面上でも絞り込めます。" : "",
    filtered ? "表示区分・結果検索の絞り込みは表示中CSVだけに反映されます。" : "",
    checklistWarning,
    `CSV形式: ${CSV_SCHEMA_VERSION}`,
  ].filter(Boolean).join(" / ");
  csvSummary.className = `note csv-summary ${confirmNotice || freshnessWarning || eSeikatsuCacheFreshnessText || freshnessReviewMissingWarning || restoreHistoryWarning || coverageWarning || detailUnconfirmedWarning || detailUnconfirmedReviewMissingWarning || checklistWarning ? "status-warn-inline" : ""}`.trim();
}

function updateCsvButtonAvailability({ displayRows, workRows, reviewRows, candidateRows, allRows, detailUnconfirmedRows }) {
  const coverageBlockedText = dataCoverageBlockingText();
  const coverageBlocked = Boolean(coverageBlockedText);
  setCsvButtonState(downloadVisibleRows, displayRows.length > 0 && !coverageBlocked, coverageBlocked ? coverageBlockedText : "表示中CSVに出力できる行がありません。");
  setCsvButtonState(downloadPracticalRows, candidateRows.length > 0 && !coverageBlocked, coverageBlocked ? coverageBlockedText : "現場用CSVに出力できる行がありません。");
  setCsvButtonState(downloadWorkRows, workRows.length > 0 && !coverageBlocked, coverageBlocked ? coverageBlockedText : "作業対象CSVに出力できる行がありません。");
  setCsvButtonState(downloadReviewRows, reviewRows.length > 0 && !coverageBlocked, coverageBlocked ? coverageBlockedText : "確認用CSVに出力できる行がありません。");
  setCsvButtonState(downloadSample, candidateRows.length > 0 && !coverageBlocked, coverageBlocked ? coverageBlockedText : "候補CSVに出力できる行がありません。");
  setCsvButtonState(downloadAllRows, allRows.length > 0, "全件CSVに出力できる行がありません。");
  setCsvButtonState(downloadDetailUnconfirmedRows, detailUnconfirmedRows.length > 0, "詳細未確認CSVに出力できる行がありません。");
  const canSaveCsvSet = !coverageBlocked && (workRows.length > 0 || reviewRows.length > 0 || candidateRows.length > 0 || allRows.length > 0);
  setCsvButtonState(saveCsvFiles, canSaveCsvSet, coverageBlocked ? coverageBlockedText : "保存できるCSVがありません。");
  setCsvButtonState(workflowSaveCsv, canSaveCsvSet, coverageBlocked ? coverageBlockedText : "保存できるCSVがありません。");
}

function setCsvButtonState(button, enabled, disabledTitle) {
  if (!button || !hasLoadedCaptureData) return;
  button.disabled = !enabled;
  button.title = enabled ? "" : disabledTitle;
}

function workTargetSummaryText(rows) {
  if (!rows.length) return "";
  const counts = rows.reduce((items, row) => {
    const label = workTargetLabel(row);
    items.set(label, (items.get(label) ?? 0) + 1);
    return items;
  }, new Map());
  const parts = ["作業対象", "確認後判断", "対象外"]
    .filter((label) => counts.has(label))
    .map((label) => `${label}${counts.get(label)}件`);
  return parts.length ? ` (${parts.join("・")})` : "";
}

function workTargetHistoryText(rows) {
  return workTargetSummaryText(rows).replace(/^\s*\(|\)\s*$/g, "");
}

function updateResultTypeFilter(rows) {
  if (!resultTypeFilter) return;
  const currentValue = resultTypeFilter.value;
  const types = [...new Set(rows.map((row) => row.type))];
  resultTypeFilter.innerHTML = [
    '<option value="">すべて</option>',
    ...types.map((type) => `<option value="${escapeAttribute(type)}">${escapeHtml(type)}</option>`),
  ].join("");
  resultTypeFilter.value = types.includes(currentValue) ? currentValue : "";
}

function filterResultRows(rows) {
  const type = resultTypeFilter?.value ?? "";
  const query = normalize(resultTextFilter?.value ?? "");
  return rows.filter((row) => {
    if (type && row.type !== type) return false;
    if (!query) return true;
    const haystack = normalize([
      row.type,
      row.action,
      row.nextStep,
      row.priorityLabel,
      workTargetLabel(row),
      row.building,
      row.room,
      row.address,
      row.line,
      row.station,
      row.layout,
      row.realproStatus,
      row.status,
      row.confirmationReason,
      row.note,
      row.detailUnconfirmedCause,
      row.equipment.join("、"),
    ].join(" "));
    return haystack.includes(query);
  });
}

function renderResultTypeSummary(rows) {
  if (!resultTypeSummary) return;
  const selectedType = resultTypeFilter?.value ?? "";
  const counts = rows.reduce((items, row) => {
    items.set(row.type, (items.get(row.type) ?? 0) + 1);
    return items;
  }, new Map());
  resultTypeSummary.innerHTML = [
    `<button class="type-pill${selectedType === "" ? " active" : ""}" type="button" data-result-type="">すべて: ${rows.length}</button>`,
    ...[...counts.entries()]
    .map(([type, count]) => `<button class="type-pill${selectedType === type ? " active" : ""}" type="button" data-result-type="${escapeAttribute(type)}">${escapeHtml(type)}: ${count}</button>`)
  ].join("");
}

function renderActionSummary(rows) {
  if (!actionSummary) return;
  if (!rows.length) {
    actionSummary.innerHTML = "";
    return;
  }
  const selectedActionQuery = resultTextFilter?.value?.trim() ?? "";
  const actionPillClass = (baseClass, query) => `${baseClass}${selectedActionQuery === query ? " active" : ""}`;

  const counts = rows.reduce((items, row) => {
    const action = row.action || "確認";
    items.set(action, (items.get(action) ?? 0) + 1);
    return items;
  }, new Map());
  const priorityCounts = rows.reduce((items, row) => {
    const label = row.priorityLabel || "確認";
    items.set(label, (items.get(label) ?? 0) + 1);
    return items;
  }, new Map());
  const workTargetCounts = rows.reduce((items, row) => {
    const label = workTargetLabel(row);
    items.set(label, (items.get(label) ?? 0) + 1);
    return items;
  }, new Map());
  const confirmationReasonCounts = rows.reduce((items, row) => {
    const label = row.confirmationReason || "";
    if (label) items.set(label, (items.get(label) ?? 0) + 1);
    return items;
  }, new Map());
  const detailCauseCounts = rows.reduce((items, row) => {
    const label = row.detailUnconfirmedCause || "";
    if (label) items.set(label, (items.get(label) ?? 0) + 1);
    return items;
  }, new Map());
  const priorityButtons = ["高", "要確認"]
    .filter((label) => priorityCounts.has(label))
    .map((label) => `<button class="${actionPillClass("action-pill priority-pill", label)}" type="button" data-action-query="${escapeAttribute(label)}">${escapeHtml(label)}: ${priorityCounts.get(label)}</button>`);
  const workTargetButtons = ["作業対象", "確認後判断", "対象外"]
    .filter((label) => workTargetCounts.has(label))
    .map((label) => `<button class="${actionPillClass("action-pill work-target-pill", label)}" type="button" data-action-query="${escapeAttribute(label)}">${escapeHtml(label)}: ${workTargetCounts.get(label)}</button>`);
  const confirmationReasonButtons = [...confirmationReasonCounts.entries()]
    .filter(([, count]) => count > 0)
    .slice(0, 8)
    .map(([reason, count]) => `<button class="${actionPillClass("action-pill reason-pill", reason)}" type="button" data-action-query="${escapeAttribute(reason)}">${escapeHtml(reason)}: ${count}</button>`);
  const detailCauseButtons = [...detailCauseCounts.entries()]
    .filter(([, count]) => count > 0)
    .slice(0, 6)
    .map(([cause, count]) => `<button class="${actionPillClass("action-pill detail-cause-pill", cause)}" type="button" data-action-query="${escapeAttribute(cause)}">未確認原因 ${escapeHtml(cause)}: ${count}</button>`);
  const actionButtons = [...counts.entries()]
    .map(([action, count]) => `<button class="${actionPillClass("action-pill", action)}" type="button" data-action-query="${escapeAttribute(action)}">${escapeHtml(action)}: ${count}</button>`)
  actionSummary.innerHTML = [...workTargetButtons, ...priorityButtons, ...confirmationReasonButtons, ...detailCauseButtons, ...actionButtons].join("");
}

function renderExclusionSummary() {
  if (!exclusionSummary) return;

  const breakdown = latestStats.excludedBreakdown ?? {};
  const lines = Object.entries(breakdown)
    .filter(([, count]) => count > 0)
    .map(([type, count]) => `${type}: ${count}件`);
  const duplicateLine = latestStats.duplicated > 0 ? `同一物件・同一間取の重複: ${latestStats.duplicated}件` : "";
  const detailCauseLine = detailUnconfirmedCauseBreakdownText(importedRealproRooms.filter((room) => matchesCriteria(room, collectCriteria())));
  const detailCauseSummary = detailCauseLine ? `詳細未確認原因: ${detailCauseLine}` : "";
  const summary = [...lines, duplicateLine, detailCauseSummary].filter(Boolean).join(" / ");
  exclusionSummary.textContent = summary ? `除外内訳: ${summary}` : "";
}

function rowLinks(row) {
  const links = [];
  if (row.realproUrl) links.push(`<a href="${escapeAttribute(row.realproUrl)}" target="_blank" rel="noreferrer">リアプロ</a>`);
  if (row.eSeikatsuUrl) links.push(`<a href="${escapeAttribute(row.eSeikatsuUrl)}" target="_blank" rel="noreferrer">いい生活</a>`);
  return links.length ? links.join(" / ") : "";
}

function realproRoomLink(row) {
  const room = escapeHtml(row.room);
  if (!row.realproUrl) return room;
  const label = `${row.building || "物件"} ${row.room || "号室"}をリアプロで開く`;
  return `<a class="room-detail-link" href="${escapeAttribute(row.realproUrl)}" target="_blank" rel="noreferrer" aria-label="${escapeAttribute(label)}" title="リアプロ物件詳細を別タブで開く">${room}<span aria-hidden="true">↗</span></a>`;
}

function locationAccessLabel(row) {
  const access = [row.line, row.station, row.accessMethod ? `${row.accessMethod}${row.walkMinutes ? `${row.walkMinutes}分` : ""}` : ""]
    .filter(Boolean)
    .join(" ");
  return [row.address, access].filter(Boolean).join(" / ");
}

function realproStatusLabel(row) {
  return [
    row.realproStatus,
    row.availableDate ? `入居:${row.availableDate}` : "",
    Number(row.applicationCount) > 0 ? `申込${row.applicationCount}件` : "",
  ].filter(Boolean).join(" / ");
}

function escapeAttribute(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("\"", "&quot;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll("'", "&#39;");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function renderVerificationStatus() {
  if (!verificationStatus) return;
  const expected = latestStats.expected;
  if (!expected) {
    verificationStatus.hidden = true;
    verificationStatus.textContent = "";
    return;
  }

  const checks = [
    ["判定総数", latestStats.total, expected.total],
    ["表示候補", latestStats.shown, expected.shown],
    ["除外", latestStats.excluded, expected.excluded],
    ["同間取重複", latestStats.duplicated, expected.duplicated],
    ["詳細未確認CSV", buildDetailUnconfirmedCsvRows().length, expected.detailUnconfirmedCsv],
    ...Object.entries(expected.excludedBreakdown ?? {}).map(([type, count]) => [
      type,
      latestStats.excludedBreakdown?.[type] ?? 0,
      count,
    ]),
  ];
  const failed = checks.filter(([, actual, expectedCount]) => actual !== expectedCount);
  const details = checks.map(([label, actual, expectedCount]) => `${label}: ${actual}/${expectedCount}`).join(" / ");
  verificationStatus.hidden = false;
  verificationStatus.className = `verification-status ${failed.length ? "status-error" : "status-ok"}`;
  verificationStatus.textContent = failed.length
    ? `検証サンプル確認: 要確認 (${details})`
    : `検証サンプル確認: OK (${details})`;
}

function renderCaptureSummary(items = []) {
  if (!captureSummary) return;
  const visibleItems = items.filter(Boolean);
  if (!visibleItems.length) {
    captureSummary.hidden = true;
    captureSummary.innerHTML = "";
    return;
  }

  captureSummary.hidden = false;
  captureSummary.innerHTML = visibleItems
    .map((item) => `
      <div class="summary-card ${summaryCardClass(item.kind)}">
        <span>${escapeHtml(item.label)}</span>
        <strong>${escapeHtml(item.value)}</strong>
        <small>${escapeHtml(item.note ?? "")}</small>
      </div>
    `)
    .join("");
}

function summaryCardClass(kind) {
  if (kind === "error") return "summary-card-error";
  if (kind === "warn") return "summary-card-warn";
  if (kind === "ok") return "summary-card-ok";
  return "";
}

function setImportStatusLines(lines) {
  importStatus.innerHTML = lines.filter(Boolean).map(escapeHtml).join("<br>");
}

function readImportHistory() {
  try {
    const history = JSON.parse(localStorage.getItem("importHistory") || "[]");
    return Array.isArray(history) ? history : [];
  } catch {
    return [];
  }
}

function saveImportHistory(entry) {
  const history = [entry, ...readImportHistory()].slice(0, 5);
  localStorage.setItem("importHistory", JSON.stringify(history));
  renderImportHistory();
}

function renderImportHistory() {
  if (!importHistory) return;
  const history = readImportHistory();
  if (!history.length) {
    importHistory.hidden = true;
    importHistory.innerHTML = "";
    return;
  }

  importHistory.hidden = false;
  importHistory.innerHTML = `
    <div class="history-title-row">
      <strong>読み込み履歴</strong>
      <button class="text-button" type="button" data-clear-import-history>履歴をクリア</button>
    </div>
    ${historyFreshnessLegend()}
    <ul>
      ${history.map((item) => `
        <li class="${historyFreshnessClass(item, item.importedAt)}">
          ${escapeHtml(formatDateTime(item.importedAt))} /
          ${escapeHtml(item.filename ?? "取得JSON")} /
          リアプロ${escapeHtml(item.realproCount ?? 0)}件 /
          いい生活${escapeHtml(item.eSeikatsuCount ?? 0)}件 /
          候補${escapeHtml(item.shownCount ?? 0)}件 /
          ${item.captureScaleValue ? `取得規模${escapeHtml(item.captureScaleValue)} /` : ""}
          取得品質${Number(item.qualityWarningCount) ? `注意${escapeHtml(item.qualityWarningCount)}件` : "OK"}
          ${item.captureScaleText ? `<div class="history-condition">取得規模詳細: ${escapeHtml(item.captureScaleText)}</div>` : ""}
          <div class="history-condition">データ鮮度: ${escapeHtml(historyFreshnessText(item))}</div>
          ${item.presetName ? `<div class="history-condition">プリセット: ${escapeHtml(item.presetName)}</div>` : ""}
          <div class="history-condition">条件: ${escapeHtml(item.criteriaText ?? "指定なし")}</div>
        </li>
      `).join("")}
    </ul>
  `;
}

function clearImportHistory() {
  localStorage.removeItem("importHistory");
  renderImportHistory();
}

function readPreflightHistory() {
  try {
    const history = JSON.parse(localStorage.getItem("preflightHistory") || "[]");
    return Array.isArray(history) ? history : [];
  } catch {
    return [];
  }
}

function savePreflightHistory(entry) {
  const history = [entry, ...readPreflightHistory()].slice(0, 5);
  localStorage.setItem("preflightHistory", JSON.stringify(history));
  renderPreflightHistory();
}

function renderPreflightHistory() {
  if (!preflightHistory) return;
  const history = readPreflightHistory();
  if (!history.length) {
    preflightHistory.hidden = true;
    preflightHistory.innerHTML = "";
    return;
  }

  preflightHistory.hidden = false;
  const latest = history[0];
  const failedCount = history.filter((item) => item.status !== "OK").length;
  const latestText = latest ? ` / 直近:${formatDateTime(latest.checkedAt)} ${latest.status}` : "";
  preflightHistory.innerHTML = `
    <div class="history-title-row">
      <strong>本番前確認履歴</strong>
      <span class="restore-history-count ${latest?.status === "OK" ? "preflight-latest-ok" : "preflight-latest-failed"}">${history.length}件${failedCount ? ` / 失敗${failedCount}件` : ""}${latestText}</span>
      <button class="text-button" type="button" data-clear-preflight-history>履歴をクリア</button>
    </div>
    <ul>
      ${history.map((item) => `
        <li class="${item.status === "OK" ? "preflight-ok" : "preflight-failed history-stale"}">
          ${escapeHtml(formatDateTime(item.checkedAt))} /
          <strong>${escapeHtml(item.status)}</strong> /
          ${escapeHtml(item.sourceLabel ?? "本番前確認")}
          <div class="history-condition">リアプロ: ${escapeHtml(item.realproCount ?? "-")}件 / いい生活: ${escapeHtml(item.eSeikatsuCount ?? "-")}件 / 詳細未確認: ${escapeHtml(item.detailUnconfirmedCount ?? "-")}件</div>
          <div class="history-condition">ドキュメント: ${escapeHtml(item.docsChecked ?? "-")}件 / CSV形式: ${escapeHtml(item.csvSchemaVersion ?? "不明")}</div>
          ${item.serverStatusText ? `<div class="history-condition">サーバー: ${escapeHtml(item.serverStatusText)}</div>` : ""}
          ${item.message ? `<div class="history-condition ${item.status === "OK" ? "" : "restore-history-snapshot-warn"}">${escapeHtml(item.message)}</div>` : ""}
        </li>
      `).join("")}
    </ul>
  `;
}

function clearPreflightHistory() {
  const count = readPreflightHistory().length;
  localStorage.removeItem("preflightHistory");
  renderPreflightHistory();
  return count;
}

function readChromeTabHistory() {
  try {
    const history = JSON.parse(localStorage.getItem("chromeTabHistory") || "[]");
    return Array.isArray(history) ? history : [];
  } catch {
    return [];
  }
}

function saveChromeTabHistory(entry) {
  const history = [entry, ...readChromeTabHistory()].slice(0, 8);
  localStorage.setItem("chromeTabHistory", JSON.stringify(history));
  renderChromeTabHistory();
}

function renderChromeTabHistory() {
  if (!chromeTabHistory) return;
  const history = readChromeTabHistory();
  if (!history.length) {
    chromeTabHistory.hidden = true;
    chromeTabHistory.innerHTML = "";
    return;
  }

  chromeTabHistory.hidden = false;
  const latest = history[0];
  const failedCount = history.filter((item) => item.status !== "OK").length;
  chromeTabHistory.innerHTML = `
    <div class="history-title-row">
      <strong>Chromeタブ確認履歴</strong>
      <span class="restore-history-count ${latest?.status === "OK" ? "preflight-latest-ok" : "preflight-latest-failed"}">${history.length}件${failedCount ? ` / 注意${failedCount}件` : ""} / 直近:${escapeHtml(formatDateTime(latest.checkedAt))} ${escapeHtml(latest.status)}</span>
      <button class="text-button" type="button" data-clear-chrome-tab-history>履歴をクリア</button>
    </div>
    <ul>
      ${history.map((item) => `
        <li class="${item.status === "OK" ? "preflight-ok" : "preflight-failed history-stale"}">
          ${escapeHtml(formatDateTime(item.checkedAt))} /
          <strong>${escapeHtml(item.status)}</strong> /
          ${escapeHtml(item.sourceLabel ?? "Chromeタブ確認")}
          <div class="history-condition">${escapeHtml(item.summary ?? "結果不明")}</div>
          <div class="history-condition">リアプロ一覧: ${escapeHtml(item.realproList ?? "-")} / いい生活: ${escapeHtml(item.eSeikatsuList ?? "-")} / リアプロ詳細: ${escapeHtml(item.realproDetails ?? "0")}件</div>
        </li>
      `).join("")}
    </ul>
  `;
}

function clearChromeTabHistory() {
  const count = readChromeTabHistory().length;
  localStorage.removeItem("chromeTabHistory");
  renderChromeTabHistory();
  return count;
}

function historyFreshnessText(item) {
  if (item.freshnessText) return item.freshnessText;
  const freshness = captureFreshnessSummary(item.capturedAt, item.importedAt);
  return freshness ? `${freshness.value} / ${freshness.note}` : "不明";
}

function historyFreshnessClass(item, referenceDate) {
  const freshnessText = item.freshnessText || "";
  const freshness = freshnessText ? { value: freshnessText.split("/")[0].trim() } : captureFreshnessSummary(item.capturedAt, referenceDate);
  if (!freshness || freshness.value === "当日") return "";
  const ageDays = Number(freshness.value.match(/^(\d+)日前$/)?.[1] ?? 0);
  if (ageDays >= 2) return "history-stale";
  return "history-aged";
}

function historyFreshnessLegend() {
  return `
    <div class="history-legend" aria-label="履歴のデータ鮮度">
      <span><i class="legend-dot legend-fresh"></i>当日: 最新取得</span>
      <span><i class="legend-dot legend-aged"></i>1日前: 空室状況を確認</span>
      <span><i class="legend-dot legend-stale"></i>2日前以上: 再取得推奨</span>
    </div>
  `;
}

function readCsvHistory() {
  try {
    const history = JSON.parse(localStorage.getItem("csvHistory") || "[]");
    return Array.isArray(history) ? history : [];
  } catch {
    return [];
  }
}

function saveCsvHistory(entry) {
  const history = [entry, ...readCsvHistory()].slice(0, 5);
  localStorage.setItem("csvHistory", JSON.stringify(history));
  renderCsvHistory();
}

function renderCsvHistory() {
  if (!csvHistory) return;
  const history = readCsvHistory();
  if (!history.length) {
    csvHistory.hidden = true;
    csvHistory.innerHTML = "";
    return;
  }

  csvHistory.hidden = false;
  const latest = history[0];
  const latestText = latest ? `直近:${formatDateTime(latest.exportedAt)} ${latest.label ?? "CSV"} ${latest.count ?? 0}件` : "";
  csvHistory.innerHTML = `
    <div class="history-title-row">
      <strong>CSV出力履歴</strong>
      <span class="restore-history-count">${history.length}件${latestText ? ` / ${latestText}` : ""}</span>
      <button class="text-button" type="button" data-clear-csv-history>履歴をクリア</button>
    </div>
    ${historyFreshnessLegend()}
    <ul>
      ${history.map((item) => `
        <li class="${historyFreshnessClass(item, item.exportedAt)}">
          ${escapeHtml(formatDateTime(item.exportedAt))} /
          ${escapeHtml(item.label)} /
          ${escapeHtml(item.count)}件 /
          ${escapeHtml(item.filename)}
          <div class="history-condition">CSV形式: ${escapeHtml(item.csvSchemaVersion ?? "不明")}</div>
          ${item.presetName ? `<div class="history-condition">プリセット: ${escapeHtml(item.presetName)}</div>` : ""}
          ${item.exportScopeText ? `<div class="history-condition">出力範囲: ${escapeHtml(item.exportScopeText)}</div>` : ""}
          ${item.resultFilterText ? `<div class="history-condition">表示絞り込み: ${escapeHtml(item.resultFilterText)}</div>` : ""}
          <div class="history-condition">取得元: ${escapeHtml(item.importFilename ?? "不明")}</div>
          <div class="history-condition">取得日時: ${escapeHtml(item.capturedAt ? formatDateTime(item.capturedAt) : "不明")}</div>
          <div class="history-condition">データ鮮度: ${escapeHtml(csvHistoryFreshnessText(item))}</div>
          ${item.freshnessReviewHistoryText ? `<div class="history-condition restore-history-snapshot ${item.freshnessReviewHistoryText.includes("再取得推奨") ? "restore-history-snapshot-warn" : ""}">データ鮮度確認履歴(出力時点): ${escapeHtml(item.freshnessReviewHistoryText)}</div>` : ""}
          ${item.roomMatchText ? `<div class="history-condition">${escapeHtml(item.roomMatchText)}</div>` : ""}
          ${item.captureScaleText ? `<div class="history-condition ${item.captureScaleValue === "大規模" ? "restore-history-snapshot-warn" : ""}">取得規模: ${escapeHtml(item.captureScaleText)}</div>` : ""}
          <div class="history-condition">取得品質: ${Number(item.qualityWarningCount) ? `注意${escapeHtml(item.qualityWarningCount)}件` : "OK"}</div>
          ${item.captureQualityReviewHistoryText ? `<div class="history-condition restore-history-snapshot ${item.captureQualityReviewHistoryText.includes("注意あり") ? "restore-history-snapshot-warn" : ""}">取得品質確認履歴(出力時点): ${escapeHtml(item.captureQualityReviewHistoryText)}</div>` : ""}
          ${item.candidateBreakdownText ? `<div class="history-condition">候補内訳: ${escapeHtml(item.candidateBreakdownText)}</div>` : ""}
          ${item.confirmationReasonBreakdownText ? `<div class="history-condition">確認理由内訳: ${escapeHtml(item.confirmationReasonBreakdownText)}</div>` : ""}
          ${item.detailUnconfirmedReviewStatusText ? `<div class="history-condition restore-history-snapshot ${item.detailUnconfirmedReviewStatusText === "未実施" ? "restore-history-snapshot-warn" : ""}">詳細未確認検証状態: ${escapeHtml(item.detailUnconfirmedReviewStatusText)}</div>` : ""}
          ${item.detailUnconfirmedText ? `<div class="history-condition restore-history-snapshot-warn">詳細未確認検証: ${escapeHtml(item.detailUnconfirmedText)}</div>` : ""}
          ${item.detailUnconfirmedReviewHistoryText ? `<div class="history-condition restore-history-snapshot ${item.detailUnconfirmedReviewHistoryText.includes("未確認あり") ? "restore-history-snapshot-warn" : ""}">詳細未確認検証履歴(出力時点): ${escapeHtml(item.detailUnconfirmedReviewHistoryText)}</div>` : ""}
          ${item.workTargetText ? `<div class="history-condition">作業内訳: ${escapeHtml(item.workTargetText)}</div>` : ""}
          <div class="history-condition">条件: ${escapeHtml(item.criteriaText ?? "指定なし")}</div>
          ${item.restoreHistoryText ? `<div class="history-condition restore-history-snapshot ${item.restoreHistoryText.includes("未反映") ? "restore-history-snapshot-warn" : ""}">検索条件復元履歴(出力時点): ${escapeHtml(item.restoreHistoryText)}</div>` : ""}
          ${item.criteriaJson ? `
            <details class="history-json">
              <summary>条件JSON</summary>
              <code>${escapeHtml(item.criteriaJson)}</code>
              <div class="json-actions">
                <button class="button secondary" type="button" data-apply-json>この条件を反映</button>
                <button class="text-button json-copy-button" type="button" data-copy-json>JSONをコピー</button>
              </div>
            </details>
          ` : ""}
        </li>
      `).join("")}
    </ul>
  `;
}

function csvHistoryFreshnessText(item) {
  if (item.freshnessText) return item.freshnessText;
  const freshness = captureFreshnessSummary(item.capturedAt, item.exportedAt);
  return freshness ? `${freshness.value} / ${freshness.note}` : "不明";
}

function clearCsvHistory() {
  localStorage.removeItem("csvHistory");
  renderCsvHistory();
}

function selectedConditionText() {
  const text = selectedConditions?.querySelector("[data-selected-condition-text]")?.textContent?.trim()
    || selectedConditions?.textContent?.trim();
  return text && text !== "指定なし" ? text : "指定なし";
}

function selectedConditionJson() {
  return JSON.stringify(collectCriteria());
}

function normalizeCriteriaJson(value) {
  if (value == null) return "";
  if (typeof value !== "string") {
    try {
      return JSON.stringify(value);
    } catch {
      return String(value);
    }
  }
  const text = value.trim();
  if (!text) return "";
  try {
    const parsed = JSON.parse(text);
    return typeof parsed === "string" ? normalizeCriteriaJson(parsed) : JSON.stringify(parsed);
  } catch {
    return text;
  }
}

function captureCriteriaQueryParams() {
  return `criteriaJson=${encodeURIComponent(selectedConditionJson())}&criteriaText=${encodeURIComponent(selectedConditionText())}`;
}

async function copyTextToClipboard(text) {
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(text);
    return true;
  }

  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.left = "-9999px";
  document.body.appendChild(textarea);
  textarea.select();
  const copied = document.execCommand("copy");
  textarea.remove();
  return copied;
}

function selectElementText(element) {
  if (!element) return false;
  const range = document.createRange();
  range.selectNodeContents(element);
  const selection = window.getSelection();
  selection.removeAllRanges();
  selection.addRange(range);
  return true;
}

function showJsonCopyStatus(status) {
  const messages = {
    copied: "検索条件JSONをコピーしました。",
    selected: "クリップボードに直接コピーできないため、検索条件JSONを選択しました。Command+Cでコピーできます。",
    failed: "検索条件JSONをコピーできませんでした。",
  };
  const success = status === "copied" || status === "selected";
  const message = messages[status] ?? messages.failed;
  if (conditionStatus) {
    conditionStatus.textContent = message;
    conditionStatus.className = `condition-status ${success ? "status-ok-inline" : "status-warn-inline"}`;
  }
  if (csvSummary && hasLoadedCaptureData) {
    csvSummary.textContent = message;
    csvSummary.className = `note csv-summary ${success ? "" : "status-warn-inline"}`.trim();
  }
}

function isDefaultSearchCriteria() {
  return (
    !checkedValues("line").length &&
    !checkedValues("station").length &&
    !checkedValues("layout").length &&
    !checkedValues("equipment").length &&
    !searchForm.elements.rentMin.value &&
    !searchForm.elements.rentMax.value &&
    !searchForm.elements.updated.value &&
    !searchForm.elements.accessMethod.value &&
    !searchForm.elements.walkMinutes.value &&
    !searchForm.elements.availability.value &&
    searchForm.elements.sapporoOnly.checked &&
    !searchForm.elements.includeManagementFee.checked &&
    !searchForm.elements.immediate.checked &&
    searchForm.elements.webAllowed.checked &&
    searchForm.elements.excludeNegotiating.checked
  );
}

function requireLoadedCaptureData(actionLabel) {
  if (hasLoadedCaptureData) return true;
  importStatus.textContent = `${actionLabel}の前に、Chrome取得・最新取得JSON・検証サンプルのいずれかを読み込んでください。`;
  return false;
}

function updateResultSummaryText(prefix = "") {
  const fetchedCount = importedRealproRooms.length || latestStats.total;
  const scopeText = fetchedCount && !latestStats.total
    ? `取得${fetchedCount}戸のうち、現在のシステム条件に合う判定対象は0件でした。`
    : fetchedCount && fetchedCount !== latestStats.total
    ? `取得${fetchedCount}戸のうち、現在の条件で${latestStats.total}件を判定しました。`
    : `${latestStats.total}件を判定しました。`;
  const message = `${scopeText} 表示候補 ${latestStats.shown}件、除外 ${latestStats.excluded}件、同間取重複 ${latestStats.duplicated}件。`;
  resultSummary.textContent = prefix ? `${prefix} ${message}` : message;
  renderWorkflowComplete();
}

function renderWorkflowComplete() {
  if (!hasLoadedCaptureData || !workflowComplete || captureIsRunning) return;
  const candidateRows = buildRowsPreservingStats({ includeExcluded: false });
  const workCount = candidateRows.filter((row) => workTargetLabel(row) === "作業対象").length;
  const reviewCount = candidateRows.filter((row) => workTargetLabel(row) === "確認後判断").length;
  const unknownCount = detailUnconfirmedRooms(importedRealproRooms).length;
  if (workflowWorkCount) workflowWorkCount.textContent = String(workCount);
  if (workflowReviewCount) workflowReviewCount.textContent = String(reviewCount);
  if (workflowExcludedCount) workflowExcludedCount.textContent = String(latestStats.excluded);
  if (workflowUnknownCount) workflowUnknownCount.textContent = String(unknownCount);
  const coverageState = currentCoverageState();
  const hasIncompleteData = coverageState.hasIncompleteData;
  const waitingForESeikatsu = candidateListWaitingForESeikatsu();
  if (workflowCompleteTitle) workflowCompleteTitle.textContent = waitingForESeikatsu ? "候補見込みを表示しています" : "候補リストが完成しました";
  if (workflowCompleteText) {
    const checkedRoomCount = importedRealproRooms.length || latestStats.total;
    workflowCompleteText.textContent = waitingForESeikatsu
      ? `${coverageState.reasonText} 現時点では${checkedRoomCount}戸を確認し、${candidateRows.length}件の候補見込みがあります。`
      : hasIncompleteData
      ? `${coverageState.reasonText} 現時点では${checkedRoomCount}戸を確認し、${candidateRows.length}件の候補リストを表示しています。`
      : `${checkedRoomCount}戸を確認し、現在の条件で${candidateRows.length}件の候補を抽出しました。`;
  }
  updateWorkflowMonitor({
    state: "complete",
    stage: "done",
    title: waitingForESeikatsu ? "候補見込みを表示しています" : "候補リスト作成完了",
    text: workflowCompleteText?.textContent || `${candidateRows.length}件の候補を抽出しました。`,
    nextAction: waitingForESeikatsu ? "いい生活確認を待つ" : "候補を確認",
  });
  workflowReady.hidden = true;
  workflowRunning.hidden = true;
  workflowComplete.hidden = false;
  renderOpsDashboard();
}

function refreshCandidateRows(prefix = "") {
  if (!hasLoadedCaptureData) {
    latestRows = [];
    renderPreview(latestRows);
    return;
  }

  latestRows = buildCandidateRows();
  if (prefix) latestStats.expected = null;
  renderPreview(latestRows);
  updateResultSummaryText(prefix);
}

function buildRowsPreservingStats(options = {}) {
  const statsBefore = latestStats;
  const rows = buildCandidateRows(options);
  latestStats = statsBefore;
  return rows;
}

function buildDetailUnconfirmedCsvRows() {
  const criteria = collectCriteria();
  return detailUnconfirmedRooms(importedRealproRooms)
    .filter((room) => matchesCriteria(room, criteria))
    .map((room) => ({
      type: "詳細未確認・改善用",
      action: "取得ルール改善",
      nextStep: "候補には入れず、リアプロ詳細取得で確認できなかった理由を検証する",
      priority: 0,
      priorityLabel: "対象外",
      building: room.building,
      room: room.room,
      address: room.address,
      line: room.line,
      station: room.station,
      accessMethod: room.accessMethod ?? "徒歩",
      walkMinutes: room.walkMinutes,
      layout: room.layout,
      area: room.area,
      rent: room.rent,
      fee: room.fee,
      realproStatus: room.status,
      availableDate: room.availableDate,
      adFee: room.adFee,
      applicationCount: room.applicationCount,
      equipment: room.equipment ?? [],
      ad: "詳細未確認・除外",
      status: "改善用",
      matchStatus: "リアプロ詳細未確認",
      confirmationReason: "詳細未確認検証",
      note: detailUnconfirmedDecisionNote(room),
      detailUnconfirmedCause: detailUnconfirmedCauseLabel(room),
      detailCaptureStatus: room.detailCaptureStatus ?? "",
      detailCaptureReason: room.detailCaptureReason ?? "",
      detailHttpStatus: room.detailHttpStatus ?? "",
      detailTextLength: room.detailTextLength ?? "",
      realproRoomId: realproRoomId(room),
      realproUrl: realproDetailUrl(room),
      eSeikatsuUrl: "",
    }));
}

function clearLoadedCaptureData() {
  importedRealproRooms = [];
  importedESeikatsuRooms = [];
  latestRows = [];
  latestStats = { total: 0, shown: 0, excluded: 0, duplicated: 0 };
  currentImportMeta = null;
  hasLoadedCaptureData = false;
  if (captureFile) captureFile.value = "";
  setCsvControls();
  renderCaptureSummary();
  renderPreview(latestRows);
}

function handleCurrentCaptureClear() {
  clearLoadedCaptureData();
  importStatus.textContent = "読み込みデータをクリアしました。読み込み履歴は残っています。";
  resultSummary.textContent = "データを読み込むと、号室単位の判定結果が表示されます。";
}

function resetWorkflowToStart() {
  cancelESeikatsuReview();
  eSeikatsuReviewPromise = null;
  captureLastError = "";
  lastLiveCaptureProgress = null;
  // リセットは新しい検索の開始なので、前回の追加取得位置を引き継がない。
  if (realproStartPage) realproStartPage.value = "1";
  clearLoadedCaptureData();
  lastRealproSearchResult = null;
  localStorage.removeItem("lastRealproSearchResult");
  if (resultTypeFilter) resultTypeFilter.value = "";
  if (resultTextFilter) resultTextFilter.value = "";
  if (showExcludedToggle) showExcludedToggle.checked = false;
  if (resultSummary) resultSummary.textContent = "リセットしました。上の「1. Chromeタブ確認」から進めてください。";
  if (importStatus) importStatus.textContent = "リセットしました。保存済みCSVは残しています。";
  setCsvControls();
  renderCapturePlan();
  renderOpsDashboard();
  document.getElementById("opsDashboard")?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function toCsv(rows, exportType = "") {
  const headers = [
    "CSV形式バージョン",
    "CSV種別",
    "CSV対象件数",
    "CSV作業内訳",
    "CSV出力範囲",
    "作業指示",
    "次にやること",
    "判定区分",
    "優先度",
    "優先度ラベル",
    "作業対象",
    "建物名",
    "号室",
    "リアプロ号室ID",
    "住所",
    "路線",
    "駅",
    "駅までの移動手段",
    "徒歩分",
    "間取",
    "面積",
    "賃料",
    "管理費",
    "リアプロ状態",
    "入居可能日",
    "AD",
    "電子入居申込件数",
    "設備",
    "広告判定",
    "いい生活状態",
    "確認理由",
    "行別照合",
    "注意",
    "リアプロ詳細取得状態",
    "リアプロ詳細取得理由",
    "リアプロ詳細未確認原因分類",
    "リアプロ詳細HTTP",
    "リアプロ詳細文字数",
    "リアプロURL",
    "いい生活URL",
    "取得JSON",
    "データ取得日時",
    "データ取得日時ISO",
    "データ鮮度",
    "データ鮮度確認履歴(出力時点)",
    "CSV出力日時",
    "CSV出力日時ISO",
    "検索条件プリセット",
    "出力時検索条件",
    "出力時検索条件JSON",
    "出力時表示絞り込み",
    "検索条件復元履歴(出力時点)",
    "本番検証進捗",
    "本番検証チェック",
    "本番検証メモ",
    "号室照合",
    "取得規模",
    "取得規模詳細",
    "候補内訳",
    "確認理由内訳",
    "詳細未確認検証状態",
    "詳細未確認検証",
    "詳細未確認検証履歴(出力時点)",
    "取得品質注意件数",
    "取得品質確認",
    "取得品質確認履歴(出力時点)",
    "システム範囲",
  ];
  const exportedAtDate = new Date();
  const exportedAt = formatDateTime(exportedAtDate);
  const exportedAtIso = exportedAtDate.toISOString();
  const capturedAtIso = currentImportMeta?.capturedAt ?? "";
  const capturedAt = capturedAtIso ? formatDateTime(capturedAtIso) : "";
  const freshness = captureFreshnessSummary(capturedAtIso, exportedAtDate);
  const freshnessReviewHistoryText = freshnessReviewHistorySummaryText();
  const importFilename = currentImportMeta?.filename ?? "";
  const criteriaText = selectedConditionText();
  const criteriaJson = selectedConditionJson();
  const resultFilterText = currentResultFilterSummaryText();
  const exportScopeText = csvExportScopeText(exportType);
  const restoreHistoryText = conditionRestoreHistorySummaryText();
  const checklistProgress = productionChecklistProgressText();
  const checklistText = productionChecklistCsvText();
  const memoText = productionMemoText();
  const roomMatchText = currentImportMeta?.roomMatchSummary ? formatRoomMatchSummary(currentImportMeta.roomMatchSummary) : "";
  const captureScale = currentImportMeta?.captureScaleSummary;
  const captureScaleValue = captureScale?.value ?? "";
  const captureScaleText = formatCaptureScaleSummary(captureScale);
  const captureQualityText = (currentImportMeta?.captureQuality ?? []).join(" / ");
  const captureQualityWarningCount = currentQualityWarningCount();
  const captureQualityReviewHistoryText = captureQualityReviewHistorySummaryText();
  const csvCount = rows.length;
  const csvWorkTargetText = workTargetHistoryText(rows);
  const csvCandidateBreakdownText = candidateBreakdownText(rows);
  const csvConfirmationReasonBreakdownText = confirmationReasonBreakdownText(rows);
  const detailUnconfirmedReviewStatusText = currentDetailUnconfirmedReviewStatusText();
  const detailUnconfirmedText = detailUnconfirmedSummaryText();
  const detailUnconfirmedReviewHistoryText = detailUnconfirmedReviewHistorySummaryText();
  const body = rows.map((row) => [
    CSV_SCHEMA_VERSION,
    exportType,
    csvCount,
    csvWorkTargetText,
    exportScopeText,
    row.action,
    row.nextStep,
    row.type,
    row.priority,
    row.priorityLabel,
    workTargetLabel(row),
    row.building,
    row.room,
    row.realproRoomId ?? realproRoomId(row),
    row.address,
    row.line,
    row.station,
    row.accessMethod,
    row.walkMinutes,
    row.layout,
    row.area,
    row.rent,
    row.fee,
    row.realproStatus,
    row.availableDate,
    row.adFee,
    row.applicationCount,
    row.equipment.join("、"),
    row.ad,
    row.status,
    row.confirmationReason,
    row.matchStatus,
    row.note,
    row.detailCaptureStatus ?? "",
    row.detailCaptureReason ?? "",
    row.detailUnconfirmedCause ?? detailUnconfirmedCauseLabel(row),
    row.detailHttpStatus ?? "",
    row.detailTextLength ?? "",
    realproDetailUrl(row),
    row.eSeikatsuUrl,
    importFilename,
    capturedAt,
    capturedAtIso,
    freshness?.value ?? "",
    freshnessReviewHistoryText,
    exportedAt,
    exportedAtIso,
    currentSearchPresetName,
    criteriaText,
    criteriaJson,
    resultFilterText,
    restoreHistoryText,
    checklistProgress,
    checklistText,
    memoText,
    roomMatchText,
    captureScaleValue,
    captureScaleText,
    csvCandidateBreakdownText,
    csvConfirmationReasonBreakdownText,
    detailUnconfirmedReviewStatusText,
    detailUnconfirmedText,
    detailUnconfirmedReviewHistoryText,
    captureQualityWarningCount,
    captureQualityText,
    captureQualityReviewHistoryText,
    "自動登録なし。候補リスト作成と作業メモ出力まで。登録・差替・掲載変更は人が確認して行う。",
  ]);
  return [headers, ...body]
    .map((line) => line.map(csvCell).join(","))
    .join("\n");
}

function toPracticalCsv(rows, exportType = "現場用CSV") {
  const headers = [
    "作業順",
    "作業ステータス",
    "担当者",
    "対応日",
    "リアプロ目視",
    "いい生活確認",
    "管理会社確認",
    "登録結果",
    "登録後いい生活URL",
    "作業メモ",
    "作業対象",
    "作業指示",
    "次にやること",
    "建物名",
    "号室",
    "間取",
    "賃料",
    "管理費",
    "月額目安",
    "広告判定",
    "確認理由",
    "差替元号室",
    "差替元状況",
    "リアプロ状態",
    "入居可能日",
    "AD",
    "住所",
    "路線",
    "駅",
    "駅まで",
    "設備",
    "注意",
    "リアプロURL",
    "いい生活URL",
    "リアプロ号室ID",
    "電子入居申込件数",
    "判定区分",
    "CSV種別",
    "CSV対象件数",
    "CSV出力日時",
  ];
  const exportedAt = formatDateTime(new Date());
  const csvCount = rows.length;
  const practicalRows = [...rows].sort(practicalRowCompare);
  const body = practicalRows.map((row, index) => {
    const replacement = replacementSourceInfo(row);
    return [
      index + 1,
      practicalWorkStatus(row),
      "",
      "",
      "未確認",
      "未確認",
      practicalManagementCheckStatus(row),
      "",
      "",
      "",
      workTargetLabel(row),
      row.action,
      row.nextStep,
      row.building,
      roomLabel(row.room),
      row.layout,
      row.rent,
      row.fee,
      monthlyEstimate(row),
      row.ad,
      row.confirmationReason,
      replacement.room,
      replacement.status,
      row.realproStatus,
      row.availableDate,
      row.adFee,
      row.address,
      row.line,
      row.station,
      `${row.accessMethod || "徒歩"}${row.walkMinutes ? `${row.walkMinutes}分` : ""}`,
      Array.isArray(row.equipment) ? row.equipment.join("、") : "",
      row.note,
      realproDetailUrl(row),
      row.eSeikatsuUrl,
      row.realproRoomId ?? realproRoomId(row),
      row.applicationCount,
      row.type,
      exportType,
      csvCount,
      exportedAt,
    ];
  });
  return [headers, ...body]
    .map((line) => line.map(csvCell).join(","))
    .join("\n");
}

function csvCell(cell) {
  const text = String(cell ?? "");
  const safeText = /^[=+\-@]/.test(text.trimStart()) ? `'${text}` : text;
  return `"${safeText.replaceAll("\"", "\"\"")}"`;
}

function practicalRowCompare(a, b) {
  const workRank = (row) => {
    const label = workTargetLabel(row);
    if (label === "作業対象") return 1;
    if (label === "確認後判断") return 2;
    return 3;
  };
  const rankDiff = workRank(a) - workRank(b);
  if (rankDiff) return rankDiff;
  const priorityDiff = candidatePriority(a.type) - candidatePriority(b.type);
  if (priorityDiff) return priorityDiff;
  const buildingDiff = String(a.building ?? "").localeCompare(String(b.building ?? ""), "ja");
  if (buildingDiff) return buildingDiff;
  return String(a.room ?? "").localeCompare(String(b.room ?? ""), "ja", { numeric: true });
}

function practicalWorkStatus(row) {
  return workTargetLabel(row) === "確認後判断" ? "確認待ち" : "未対応";
}

function practicalManagementCheckStatus(row) {
  return row?.ad === "管理会社確認必要" ? "未確認" : "不要";
}

function monthlyEstimate(row = {}) {
  const rent = numberFromText(row.rent);
  const fee = numberFromText(row.fee);
  if (!rent && !fee) return "";
  return String(rent + fee);
}

function numberFromText(value) {
  const normalized = String(value ?? "").replace(/[^\d.-]/g, "");
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : 0;
}

function replacementSourceInfo(row = {}) {
  const note = String(row.note ?? "");
  const matchStatus = String(row.matchStatus ?? "");
  const fromNote = note.match(/いい生活掲載中の(.+?号室)はリアプロで([^/]+)/);
  if (fromNote) return { room: fromNote[1].trim(), status: fromNote[2].trim() };
  const fromMatchStatus = matchStatus.match(/差替候補:\s*いい生活(.+?号室)/);
  if (fromMatchStatus) return { room: fromMatchStatus[1].trim(), status: "" };
  return { room: "", status: "" };
}

function currentRoomMatchText() {
  return currentImportMeta?.roomMatchSummary ? formatRoomMatchSummary(currentImportMeta.roomMatchSummary) : "";
}

function currentQualityWarningCount() {
  return (currentImportMeta?.captureQuality ?? []).filter((message) => message.startsWith("注意")).length;
}

function currentQualityWarningText() {
  const warnings = (currentImportMeta?.captureQuality ?? []).filter((message) => message.startsWith("注意"));
  if (!warnings.length) return "";
  return `取得品質注意 ${warnings.length}件: ${warnings.join(" / ")}`;
}

function currentFreshnessMemoText() {
  const freshness = captureFreshnessSummary(currentImportMeta?.capturedAt);
  if (!freshness) return "データ鮮度確認: 取得日時が不明です。登録前にリアプロ・いい生活を再取得する。";
  const capturedAt = currentImportMeta?.capturedAt ? formatDateTime(currentImportMeta.capturedAt) : "不明";
  const nextAction = freshness.value === "当日"
    ? "この取得データで候補確認を進める。"
    : "登録前にリアプロ・いい生活の最新状態を再取得する。";
  return `データ鮮度確認: ${freshness.message} 取得日時 ${capturedAt}。${nextAction}`;
}

function detailUnconfirmedRooms(rooms = importedRealproRooms) {
  return rooms.filter((room) => (
    room.webAd === "判定不可" &&
    room.detailCaptureStatus !== "候補外のため省略"
  ));
}

function detailUnconfirmedReason(room) {
  const reasons = [];
  if (room.webAd === "判定不可") reasons.push("WEB広告掲載可否を確認できていない");
  if (room.detailCaptureStatus) reasons.push(`詳細取得状態:${room.detailCaptureStatus}`);
  if (room.detailCaptureReason) reasons.push(`詳細取得理由:${room.detailCaptureReason}`);
  if (room.detailHttpStatus) reasons.push(`HTTP:${room.detailHttpStatus}`);
  if (room.detailTextLength) reasons.push(`詳細文字数:${room.detailTextLength}`);
  if (!room.detailTitle && !room.url?.includes("room_detail.php")) reasons.push("リアプロ詳細画面の取得根拠が弱い");
  if (Number(room.applicationCount ?? 0) === 0 && room.webAd === "判定不可") reasons.push("電子入居申込件数も詳細確認前として扱う");
  return reasons.join(" / ") || "詳細確認が必要";
}

function detailUnconfirmedDecisionNote(room) {
  const cause = detailUnconfirmedCauseLabel(room);
  const reason = detailUnconfirmedReason(room);
  return [
    "リアプロ詳細未確認のため候補に入れない",
    cause ? `原因分類:${cause}` : "",
    reason,
  ].filter(Boolean).join(" / ");
}

function detailUnconfirmedCauseLabel(room) {
  if (room.webAd !== "判定不可" && room.ad !== "詳細未確認・除外") return "";
  const status = String(room.detailCaptureStatus ?? "").normalize("NFKC");
  const reason = String(room.detailCaptureReason ?? "").normalize("NFKC");
  const httpStatus = String(room.detailHttpStatus ?? "").trim();
  const textLength = Number(room.detailTextLength ?? 0);
  const combined = `${status} ${reason}`;

  if (httpStatus && httpStatus !== "200") return `通信/HTTP ${httpStatus}`;
  if (/広告掲載欄|広告掲載|webサービス|WEB広告/.test(combined)) return "広告掲載欄未検出";
  if (/詳細ID|detail|room_detail|URL|リンク/.test(combined) || !room.url) return "詳細ID/URL不足";
  if (/本文|文字数|HTML|テキスト/.test(combined) || (textLength > 0 && textLength < 500)) return "詳細本文不足";
  if (/タイムアウト|timeout|通信|取得失敗|fetch|HTTP/.test(combined)) return "通信/取得失敗";
  if (status || reason) return "詳細取得条件不一致";
  return "詳細取得状態不明";
}

function detailUnconfirmedSummaryText(rooms = importedRealproRooms) {
  const targets = detailUnconfirmedRooms(rooms);
  if (!targets.length) return "";
  const samples = targets
    .slice(0, 5)
    .map((room) => `${room.building || "建物名不明"} ${roomLabel(room.room || "")}: ${detailUnconfirmedReason(room)}`);
  const extra = targets.length > samples.length ? ` 他${targets.length - samples.length}件` : "";
  const breakdown = detailUnconfirmedBreakdownText(targets);
  return `詳細未確認 ${targets.length}件${breakdown ? ` / 内訳: ${breakdown}` : ""} / 理由: ${samples.join(" / ")}${extra}`;
}

function detailUnconfirmedBreakdownText(rooms = detailUnconfirmedRooms()) {
  const counts = rooms.reduce((result, room) => {
    const cause = detailUnconfirmedCauseLabel(room) || "原因不明";
    const status = room.detailCaptureStatus || "状態不明";
    const reason = room.detailCaptureReason || "理由不明";
    const key = `${cause}(${status}:${reason})`;
    result.set(key, (result.get(key) || 0) + 1);
    return result;
  }, new Map());
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], "ja"))
    .slice(0, 5)
    .map(([label, count]) => `${label}${count}件`)
    .join(" / ");
}

function detailUnconfirmedCauseBreakdownText(rooms = importedRealproRooms) {
  const counts = detailUnconfirmedRooms(rooms).reduce((result, room) => {
    const cause = detailUnconfirmedCauseLabel(room) || "原因不明";
    result.set(cause, (result.get(cause) || 0) + 1);
    return result;
  }, new Map());
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], "ja"))
    .slice(0, 4)
    .map(([label, count]) => `${label}${count}件`)
    .join(" / ");
}

function normalize(value) {
  return String(value ?? "")
    .normalize("NFKC")
    .replace(/\s+/g, "")
    .toLowerCase();
}

function normalizeBuilding(value) {
  return normalize(value)
    .replace(/\(.+?\)/g, "")
    .replace(/\[.+?\]/g, "")
    .replace(/【.+?】/g, "");
}

function normalizeRoom(value) {
  const normalized = normalize(value)
    .replace(/\(.+?\)/g, "")
    .replace(/（.+?）/g, "")
    .replace(/号室$/g, "")
    .replace(/部屋$/g, "");
  const numeric = normalized.match(/^[0-9]+$/);
  if (numeric) return String(Number(normalized));
  return normalized;
}

function realproRoomId(room = {}) {
  const directId = String(room.realproRoomId ?? room.roomId ?? "").trim();
  if (directId) return directId;
  const url = String(room.realproUrl ?? room.url ?? "").trim();
  if (!url) return "";
  try {
    return new URL(url, "https://www.realnetpro.com/").searchParams.get("id")?.trim() ?? "";
  } catch {
    const match = url.match(/[?&]id=([^&#]+)/);
    return match ? decodeURIComponent(match[1]) : "";
  }
}

function realproDetailUrl(room = {}) {
  const id = realproRoomId(room);
  if (id) return `https://www.realnetpro.com/room_detail.php?id=${encodeURIComponent(id)}&type=room`;
  const url = String(room.realproUrl ?? room.url ?? "").trim();
  if (!url) return "";
  try {
    const parsed = new URL(url);
    return parsed.hostname === "www.realnetpro.com" && parsed.pathname.endsWith("/room_detail.php")
      ? parsed.href
      : "";
  } catch {
    return "";
  }
}

function roomKey(room) {
  return `${normalizeBuilding(room.building)}::${normalizeRoom(room.room)}`;
}

function buildingLayoutKey(room) {
  return `${normalizeBuilding(room.building)}::${normalize(room.layout)}`;
}

function layoutMatchesSelected(roomLayout, selectedLayouts = []) {
  if (!selectedLayouts.length) return true;
  if (selectedLayouts.includes(roomLayout)) return true;
  if (!selectedLayouts.includes("3LDK〜")) return false;

  const normalizedLayout = normalize(roomLayout);
  if (normalizedLayout === "3LDK") return true;
  const match = normalizedLayout.match(/^([0-9]+)(K|DK|LDK)$/);
  if (!match) return false;
  return Number(match[1]) >= 4;
}

function collectCriteria() {
  return {
    lines: checkedValues("line"),
    stations: checkedStationKeys(),
    layouts: checkedValues("layout"),
    equipment: checkedValues("equipment"),
    rentMin: Number(searchForm.elements.rentMin.value || 0),
    rentMax: Number(searchForm.elements.rentMax.value || 0),
    updated: searchForm.elements.updated.value,
    accessMethod: searchForm.elements.accessMethod.value,
    walkMinutes: Number(searchForm.elements.walkMinutes.value || 0),
    availability: searchForm.elements.availability.value,
    sapporoOnly: searchForm.elements.sapporoOnly.checked,
    includeManagementFee: searchForm.elements.includeManagementFee.checked,
    immediate: searchForm.elements.immediate.checked,
    webAllowed: searchForm.elements.webAllowed.checked,
    excludeNegotiating: searchForm.elements.excludeNegotiating.checked,
  };
}

function matchesCriteria(room, criteria) {
  const totalRent = criteria.includeManagementFee ? room.rent + room.fee : room.rent;
  const stationKey = `${room.line}:${room.station}`;

  if (criteria.sapporoOnly && !String(room.address || "").includes("札幌市")) return false;
  if (criteria.lines.length && !criteria.lines.includes(room.line)) return false;
  if (criteria.stations.length && !criteria.stations.includes(stationKey)) return false;
  if (!layoutMatchesSelected(room.layout, criteria.layouts)) return false;
  if (criteria.rentMin && totalRent < criteria.rentMin) return false;
  if (criteria.rentMax && totalRent > criteria.rentMax) return false;
  if (criteria.accessMethod && (room.accessMethod ?? "徒歩") !== criteria.accessMethod) return false;
  if (criteria.walkMinutes && room.walkMinutes > criteria.walkMinutes) return false;
  if (criteria.immediate && room.availableDate !== "即入") return false;
  if (criteria.availability === "空室" && !room.status.includes("空室")) return false;
  if (criteria.availability === "退去予定" && !room.status.includes("退去予定")) return false;
  if (criteria.availability === "空室・退去予定" && !["空室", "退去予定"].some((status) => room.status.includes(status))) return false;
  if (criteria.equipment.length && !criteria.equipment.every((item) => room.equipment.includes(item))) return false;

  return true;
}

function judgeAd(room) {
  if (room.webAd === "許可されていません") {
    return { ad: "掲載不可・除外", note: "WEB広告掲載が不可" };
  }

  if (room.webAd === "判定不可") {
    return { ad: "詳細未確認・除外", note: detailUnconfirmedDecisionNote(room) };
  }

  if (room.webAd === "管理会社に確認") {
    return { ad: "管理会社確認必要", note: "WEB広告掲載は管理会社に確認" };
  }

  return { ad: "掲載可", note: "" };
}

function buildCandidateRows(options = {}) {
  const includeExcluded = options.includeExcluded ?? showExcludedToggle?.checked;
  const criteria = collectCriteria();
  const sourceRealproRooms = importedRealproRooms.length ? importedRealproRooms : realproRooms;
  const sourceESeikatsuRooms = importedESeikatsuRooms.length ? importedESeikatsuRooms : eSeikatsuRooms;
  const eSeikatsuByKey = new Map(sourceESeikatsuRooms.map((room) => [roomKey(room), room]));
  const realproByKey = new Map(sourceRealproRooms.map((room) => [roomKey(room), room]));
  const activeLayouts = buildActiveLayoutStatus(realproByKey, sourceESeikatsuRooms);

  const judgedRows = sourceRealproRooms
    .filter((room) => matchesCriteria(room, criteria))
    .map((room) => {
      const adJudge = judgeAd(room);
      const eRoom = eSeikatsuByKey.get(roomKey(room));
      let relatedESeikatsuUrl = eRoom?.url ?? "";
      let type = "新規登録候補";
      let status = "未登録";
      let note = adJudge.note;
      let matchStatus = eRoom ? "リアプロ・いい生活 完全一致" : "リアプロのみ";

      if (isLeopalaceBuilding(room)) {
        type = "レオパレス物件除外";
        note = appendNote(note, "レオパレス物件は候補対象外");
      } else if (room.applicationCount > 0 || room.realproStatus?.includes("申込あり") || room.status?.includes("申込あり")) {
        type = "申込あり・除外";
        note = appendNote(note, Number(room.applicationCount) > 0 ? `電子入居申込${room.applicationCount}件` : "申込あり");
      } else if (criteria.excludeNegotiating && /(商談中|審査中)/.test(room.status)) {
        type = "商談中・審査中除外";
        note = appendNote(note, room.status);
      } else if (eRoom && isESeikatsuRecruiting(eRoom) && isESeikatsuListed(eRoom)) {
        status = eRoom.status;
        type = "候補外";
        note = appendNote(note, "いい生活で募集中・掲載中");
      } else if (adJudge.ad === "掲載不可・除外") {
        type = "掲載不可・除外";
      } else if (adJudge.ad === "詳細未確認・除外") {
        type = "詳細未確認・除外";
      } else if (activeLayouts.has(buildingLayoutKey(room)) && !eRoom) {
        const activeLayout = activeLayouts.get(buildingLayoutKey(room));
        if (activeLayout.shouldBlock) {
          type = "同間取募集中・候補外";
          note = appendNote(note, "いい生活で同一物件・同一間取が募集中");
          matchStatus = `同一物件・同一間取掲載あり: ${roomLabel(activeLayout.room)}`;
        } else {
          type = "掲載差替候補";
          relatedESeikatsuUrl = activeLayout.url ?? "";
          note = appendNote(note, `いい生活掲載中の${roomLabel(activeLayout.room)}はリアプロで${activeLayout.realproStatusLabel}`);
          matchStatus = `差替候補: いい生活${roomLabel(activeLayout.room)}`;
        }
      } else if (adJudge.ad === "管理会社確認必要") {
        type = "管理会社確認必要";
      } else if (eRoom) {
        status = eRoom.status;
        if (isESeikatsuRecruiting(eRoom)) {
          type = "掲載確認候補";
          note = appendNote(note, "募集中だが掲載状態の確認が必要");
        } else {
          type = "募集開始候補";
        }
      }

      const needsManagementCheck = adJudge.ad === "管理会社確認必要";
      const isBlockedType = type.includes("除外") || type === "候補外" || type === "同間取募集中・候補外";
      const rowPriorityLabel = needsManagementCheck && !isBlockedType
        ? "要確認"
        : priorityLabel(type);
      const rowConfirmationReason = needsManagementCheck
        ? ["WEB広告掲載が管理会社確認", type === "掲載差替候補" ? confirmationReasonLabel(type) : ""].filter(Boolean).join("・")
        : confirmationReasonLabel(type);
      const rowAction = needsManagementCheck && !isBlockedType
        ? managementCheckActionLabel(type)
        : actionLabel(type);
      const rowNextStep = needsManagementCheck && !isBlockedType
        ? managementCheckNextStepLabel(type)
        : nextStepLabel(type);

      return {
        type,
        action: rowAction,
        nextStep: rowNextStep,
        priority: candidatePriority(type),
        priorityLabel: rowPriorityLabel,
        building: room.building,
        room: room.room,
        address: room.address,
        line: room.line,
        station: room.station,
        accessMethod: room.accessMethod ?? "徒歩",
        walkMinutes: room.walkMinutes,
        layout: room.layout,
        area: room.area,
        rent: room.rent,
        fee: room.fee,
        realproStatus: room.status,
        availableDate: room.availableDate,
        adFee: room.adFee,
        applicationCount: room.applicationCount,
        equipment: room.equipment ?? [],
        ad: adJudge.ad,
        status,
        matchStatus,
        confirmationReason: rowConfirmationReason,
        note: note || defaultDecisionNote(type),
        detailUnconfirmedCause: detailUnconfirmedCauseLabel(room),
        detailCaptureStatus: room.detailCaptureStatus ?? "",
        detailCaptureReason: room.detailCaptureReason ?? "",
        detailHttpStatus: room.detailHttpStatus ?? "",
        detailTextLength: room.detailTextLength ?? "",
        realproRoomId: realproRoomId(room),
        realproUrl: realproDetailUrl(room),
        eSeikatsuUrl: relatedESeikatsuUrl,
      };
    });

  const hiddenTypes = ["掲載不可・除外", "申込あり・除外", "商談中・審査中除外", "詳細未確認・除外", "レオパレス物件除外", "候補外", "同間取募集中・候補外"];
  const excludedRows = judgedRows.filter((row) => hiddenTypes.includes(row.type));
  const baseRows = judgedRows.filter((row) => !hiddenTypes.includes(row.type));
  const shownRows = dedupeSameLayoutPerBuilding(baseRows);
  const shownSet = new Set(shownRows);
  const duplicatedRows = baseRows
    .filter((row) => !shownSet.has(row))
    .map((row) => ({
      ...row,
      type: "同間取重複・除外",
      action: actionLabel("同間取重複・除外"),
      nextStep: nextStepLabel("同間取重複・除外"),
      priority: candidatePriority("同間取重複・除外"),
      priorityLabel: priorityLabel("同間取重複・除外"),
      note: appendNote(row.note, "同一物件内で同じ間取は1部屋だけ表示"),
    }));
  const excludedBreakdown = hiddenTypes.reduce((counts, type) => {
    counts[type] = judgedRows.filter((row) => row.type === type).length;
    return counts;
  }, {});

  latestStats = {
    total: judgedRows.length,
    shown: shownRows.length,
    excluded: judgedRows.length - baseRows.length,
    duplicated: baseRows.length - shownRows.length,
    excludedBreakdown,
    expected: latestStats.expected,
  };

  const resultRows = includeExcluded ? [...shownRows, ...excludedRows, ...duplicatedRows] : shownRows;
  return sortResultRows(resultRows);
}

function buildActiveLayoutStatus(realproByKey, sourceESeikatsuRooms) {
  return new Map(
    sourceESeikatsuRooms
      .filter(isESeikatsuRecruiting)
      .map((room) => {
        const realproRoom = realproByKey.get(roomKey(room));
        const realproStatus = realproRoom?.status ?? "掲載なし";
        const shouldBlock = ["空室", "退去予定"].some((status) => realproStatus.includes(status));

        return [
          buildingLayoutKey(room),
          {
            room: room.room,
            url: room.url,
            realproStatus,
            realproStatusLabel: realproRoom ? realproStatus : "掲載なし",
            shouldBlock,
          },
        ];
      })
  );
}

function isESeikatsuRecruiting(room) {
  return normalizeESeikatsuStatus(room?.status) === "募集中";
}

function isESeikatsuListed(room) {
  return normalizeESeikatsuListing(room?.listing) === "掲載中";
}

function appendNote(current, addition) {
  return current ? `${current} / ${addition}` : addition;
}

function defaultDecisionNote(type) {
  const notes = {
    新規登録候補: "いい生活未登録・リアプロで募集あり",
    募集開始候補: "いい生活に号室あり・募集中ではない",
    掲載差替候補: "同一物件・同一間取の掲載差替候補",
    掲載確認候補: "いい生活側の掲載状態確認が必要",
    "詳細未確認・除外": "リアプロ詳細未確認のため候補に入れない",
    管理会社確認必要: "WEB広告掲載は管理会社確認",
    候補外: "いい生活で募集中・掲載中",
    "掲載不可・除外": "WEB広告掲載が不可",
    "申込あり・除外": "電子入居申込あり",
    "商談中・審査中除外": "リアプロで商談中または審査中",
    "レオパレス物件除外": "レオパレス物件は候補対象外",
    "同間取募集中・候補外": "いい生活で同一物件・同一間取が募集中",
    "同間取重複・除外": "同一物件内で同じ間取は1部屋だけ表示",
  };
  return notes[type] ?? "";
}

function actionLabel(type) {
  const labels = {
    募集開始候補: "いい生活で募集開始",
    新規登録候補: "いい生活へ新規登録",
    掲載差替候補: "掲載部屋を差替",
    掲載確認候補: "いい生活掲載状態を確認",
    "詳細未確認・除外": "除外",
    管理会社確認必要: "管理会社へ広告掲載確認",
    候補外: "作業不要",
    "掲載不可・除外": "除外",
    "申込あり・除外": "除外",
    "商談中・審査中除外": "除外",
    "レオパレス物件除外": "除外",
    "同間取募集中・候補外": "作業不要",
    "同間取重複・除外": "除外",
  };
  return labels[type] ?? "確認";
}

function managementCheckActionLabel(type) {
  if (type === "掲載差替候補") return "管理会社確認後に掲載部屋を差替";
  return "管理会社へ広告掲載確認";
}

function nextStepLabel(type) {
  const labels = {
    募集開始候補: "いい生活側の該当号室を確認し、募集開始の作業対象として扱う",
    新規登録候補: "いい生活で未登録か確認し、新規登録の作業対象として扱う",
    掲載差替候補: "いい生活で掲載中の同間取号室を確認し、差替の作業対象として扱う",
    掲載確認候補: "いい生活側で掲載中になっているか確認し、未掲載なら確認対象として扱う",
    "詳細未確認・除外": "リアプロ詳細でWEB広告掲載可否と電子入居申込件数を確認できていないため候補に入れない",
    管理会社確認必要: "管理会社にWEB広告掲載可否を確認し、許可が取れたら登録対象にするか判断する",
    候補外: "いい生活で募集中・掲載中のため追加作業なし",
    "掲載不可・除外": "WEB広告掲載不可のため登録しない",
    "申込あり・除外": "電子入居申込ありのため登録しない",
    "商談中・審査中除外": "商談中または審査中のため登録しない",
    "レオパレス物件除外": "レオパレス物件は候補対象外のため登録しない",
    "同間取募集中・候補外": "同じ物件・同じ間取がいい生活で募集中のため追加しない",
    "同間取重複・除外": "同じ物件・同じ間取は代表1部屋のみ扱うため登録しない",
  };
  return labels[type] ?? "内容を確認して判断する";
}

function managementCheckNextStepLabel(type) {
  if (type === "掲載差替候補") {
    return "管理会社にWEB広告掲載可否を確認し、許可が取れたらいい生活掲載中の同間取号室を確認して差替対象にする";
  }
  return "管理会社にWEB広告掲載可否を確認し、許可が取れたら登録対象にするか判断する";
}

function confirmationReasonLabel(type) {
  const labels = {
    管理会社確認必要: "WEB広告掲載が管理会社確認",
    "詳細未確認・除外": "リアプロ詳細未確認",
    掲載確認候補: "いい生活は募集中だが掲載状態確認が必要",
    掲載差替候補: "掲載中同間取の別号室がリアプロで募集対象外",
    募集開始候補: "いい生活に号室あり・募集中ではない",
    新規登録候補: "いい生活未登録",
    候補外: "いい生活で募集中・掲載中",
    "掲載不可・除外": "WEB広告掲載不可",
    "申込あり・除外": "電子入居申込あり",
    "商談中・審査中除外": "商談中または審査中",
    "レオパレス物件除外": "レオパレス物件は候補対象外",
    "同間取募集中・候補外": "同一物件・同一間取が募集中",
    "同間取重複・除外": "同一物件・同一間取の代表外",
  };
  return labels[type] ?? "";
}

function priorityLabel(type) {
  if (["募集開始候補", "新規登録候補", "掲載差替候補"].includes(type)) return "高";
  if (["掲載確認候補", "管理会社確認必要"].includes(type)) return "要確認";
  if (type.includes("除外") || type === "候補外" || type === "同間取募集中・候補外") return "対象外";
  return "確認";
}

function roomLabel(room) {
  const value = String(room ?? "").trim();
  return /号室$/.test(value) ? value : `${value}号室`;
}

function dedupeSameLayoutPerBuilding(rows) {
  const grouped = new Map();

  rows.forEach((row) => {
    const key = `${normalizeBuilding(row.building)}::${normalize(row.layout)}`;
    const existing = grouped.get(key);

    if (!existing || compareRoomPriority(row, existing) < 0) {
      grouped.set(key, row);
    }
  });

  return [...grouped.values()];
}

function compareRoomPriority(a, b) {
  if (a.rent !== b.rent) return a.rent - b.rent;
  const aRank = candidatePriority(a.type);
  const bRank = candidatePriority(b.type);
  if (aRank !== bRank) return aRank - bRank;
  return normalizeRoom(a.room).localeCompare(normalizeRoom(b.room), "ja");
}

function sortResultRows(rows) {
  return [...rows].sort((a, b) => {
    if (a.priority !== b.priority) return a.priority - b.priority;
    const buildingCompare = normalize(a.building).localeCompare(normalize(b.building), "ja");
    if (buildingCompare !== 0) return buildingCompare;
    if (a.layout !== b.layout) return normalize(a.layout).localeCompare(normalize(b.layout), "ja");
    if (a.rent !== b.rent) return a.rent - b.rent;
    return normalizeRoom(a.room).localeCompare(normalizeRoom(b.room), "ja");
  });
}

function candidatePriority(type) {
  const typeRank = {
    募集開始候補: 1,
    新規登録候補: 2,
    掲載差替候補: 3,
    掲載確認候補: 4,
    管理会社確認必要: 5,
    "掲載不可・除外": 90,
    "申込あり・除外": 91,
    "商談中・審査中除外": 92,
    "詳細未確認・除外": 93,
    "レオパレス物件除外": 94,
    候補外: 95,
    "同間取募集中・候補外": 96,
    "同間取重複・除外": 97,
  };
  return typeRank[type] ?? 99;
}

function parseCapturedText(rawText) {
  if (!rawText) {
    return { rooms: [], summary: "本文テキストがありません。" };
  }

  const lines = rawText.split(/\n+/).map((line) => line.trim()).filter(Boolean);
  const roomPattern = /^([A-Za-z0-9０-９]+)\s+(?:\d+分前|[0-9０-９]+日以上前|[0-9０-９]+日前)/;
  const roomLinePattern = /^[A-Za-z0-9０-９-]+(?:\(.+?\))?$/;
  const layoutPattern = /(ワンルーム|スタジオタイプ|メゾネット|[1-6１-６]LDK|[1-6１-６]DK|[1-6１-６]K)\s+([0-9０-９.]+㎡)/;
  const rentPattern = /([0-9０-９,]+)円\s+([0-9０-９,]+)円/;
  const rentOnlyPattern = /([0-9０-９,]+)円/;
  const rooms = [];
  let currentBuilding = "";
  let currentAddress = "";
  let currentLine = "";
  let currentStation = "";
  let currentAccessMethod = "徒歩";
  let currentWalkMinutes = 0;

  lines.forEach((line, index) => {
    const buildingMatch = line.match(/^(.+?)\s+住所：(.+?)\s+沿線：(.+?)「(.+?)」(徒歩|バス|車|自転車)([0-9０-９]+)分/);
    if (buildingMatch) {
      currentBuilding = buildingMatch[1];
      currentAddress = buildingMatch[2];
      currentLine = buildingMatch[3];
      currentStation = buildingMatch[4];
      currentAccessMethod = buildingMatch[5];
      currentWalkMinutes = Number(buildingMatch[6].normalize("NFKC"));
      return;
    }

    const separatedBuildingMatch = parseSeparatedRealproBuilding(lines, index);
    if (separatedBuildingMatch) {
      currentBuilding = separatedBuildingMatch.building;
      currentAddress = separatedBuildingMatch.address;
      currentLine = separatedBuildingMatch.line;
      currentStation = separatedBuildingMatch.station;
      currentAccessMethod = separatedBuildingMatch.accessMethod;
      currentWalkMinutes = separatedBuildingMatch.walkMinutes;
      return;
    }

    const roomMatch = line.match(roomPattern) ?? (isRealproRoomLine(lines, index, roomLinePattern) ? [line, cleanRealproRoomName(line)] : null);
    if (!roomMatch || !currentBuilding) return;

    const nextLines = lines.slice(index, index + 18).join(" ");
    const layoutMatch = nextLines.match(layoutPattern);
    const rentMatch = nextLines.match(rentPattern);
    const rentOnlyMatch = nextLines.match(rentOnlyPattern);
    const status = extractRealproStatus(nextLines);
    const availableDate = extractRealproAvailableDate(nextLines);
    const equipment = extractRealproEquipment(lines, index);

    rooms.push({
      building: currentBuilding,
      address: currentAddress,
      room: roomMatch[1],
      line: currentLine,
      station: currentStation,
      accessMethod: currentAccessMethod,
      walkMinutes: currentWalkMinutes,
      layout: layoutMatch?.[1] ?? "",
      area: layoutMatch?.[2] ?? "",
      rent: numberFromYen(rentMatch?.[1] ?? rentOnlyMatch?.[1]),
      fee: numberFromYen(rentMatch?.[2]),
      status,
      availableDate,
      adFee: "",
      equipment,
      webAd: "判定不可",
      imageReuse: "判定不可",
      floorPlanReuse: "判定不可",
      priorContact: "判定不可",
      applicationCount: 0,
      url: "",
    });
  });

  return {
    rooms,
    summary: `${lines.length}行のテキストから${rooms.length}件の号室候補を推定しました。`,
  };
}

function extractRealproStatus(text) {
  const normalized = String(text ?? "").normalize("NFKC");
  const statuses = ["空室", "退去予定", "新築", "建築中", "内装中", "清掃中", "商談中", "審査中"];
  return statuses.filter((status) => normalized.includes(status)).join(" ");
}

function cleanRealproRoomName(value) {
  return String(value ?? "").normalize("NFKC").match(/^[A-Za-z0-9-]+/)?.[0] ?? String(value ?? "").trim();
}

function extractRealproAvailableDate(text) {
  const normalized = String(text ?? "").normalize("NFKC");
  if (normalized.includes("即入")) return "即入";
  return normalized.match(/20[0-9]{2}年[0-9]{1,2}月(?:[0-9]{1,2}日|上旬|中旬|下旬)?/)?.[0] ?? "";
}

function extractRealproEquipment(lines, index) {
  const markers = ["家電", "駐車場", "駐車場有り", "駐車場あり", "駐車場空有", "駐車場空きあり", "駐車可", "ペット", "ネット無料", "エアコン", "オートロック", "宅配BOX"];
  const beforeStatus = lines.slice(index + 2, index + 6).join(" ");
  return markers.filter((marker) => beforeStatus.includes(marker));
}

function parseSeparatedRealproBuilding(lines, index) {
  if (!lines[index + 1]?.startsWith("住所：") || !lines[index + 2]?.startsWith("沿線：")) return null;

  const accessMatch = lines[index + 2].match(/^沿線：(.+?)「(.+?)」(徒歩|バス|自動車|車|自転車)([0-9０-９]+)分/);
  if (!accessMatch) return null;

  return {
    building: lines[index],
    address: lines[index + 1].replace(/^住所：/, ""),
    line: accessMatch[1],
    station: accessMatch[2],
    accessMethod: accessMatch[3] === "自動車" ? "車" : accessMatch[3],
    walkMinutes: Number(accessMatch[4].normalize("NFKC")),
  };
}

function isRealproRoomLine(lines, index, roomLinePattern) {
  const line = lines[index];
  if (!roomLinePattern.test(line)) return false;
  if (!/^(?:\d+分前|[0-9０-９]+日以上前|[0-9０-９]+日前)$/.test(lines[index + 1] ?? "")) return false;
  return lines.slice(index, index + 14).some((candidate) => /(ワンルーム|[1-6１-６]LDK|[1-6１-６]DK|[1-6１-６]K)/.test(candidate));
}

function parseRealproDetailText(rawText, title = "") {
  const text = String(rawText ?? "").normalize("NFKC");
  const webAdSection =
    text.match(/WEB広告掲載[\s\S]{0,200}/)?.[0] ??
    text.match(/webサービスにこの物件の広告を掲載[\s\S]{0,120}/i)?.[0] ??
    text.match(/広告掲載[\s\S]{0,260}/)?.[0] ??
    "";

  return {
    building: extractDetailBuilding(text, title),
    room: extractDetailRoom(text, title),
    webAd: extractAdAvailability(webAdSection || text),
    imageReuse: extractQuotedValue(text, "画像の転載", ["可能", "不可", "管理会社に確認", "判定不可"]),
    floorPlanReuse: extractQuotedValue(text, "間取図の転載", ["可能", "不可", "管理会社に確認", "判定不可"]),
    priorContact: extractQuotedValue(text, "転載事前連絡", ["不要", "必要", "管理会社に確認", "判定不可"]),
    applicationCount: extractApplicationCount(text),
    equipment: extractEquipmentFromText(text),
  };
}

function extractEquipmentFromText(text) {
  const value = String(text ?? "").normalize("NFKC");
  const labels = [
    ["バス・トイレ別", /バス・トイレ別|BT別|セパレート/],
    ["独立洗面台", /独立洗面|洗面化粧台|シャンプードレッサー/],
    ["エアコン", /エアコン/],
    ["暖房", /暖房/],
    ["オートロック", /オートロック/],
    ["宅配ボックス", /宅配ボックス|宅配BOX/],
    ["インターネット無料", /インターネット無料|ネット無料/],
    ["Wi-Fi無料", /Wi-?Fi無料|Wifi無料|ワイファイ無料/i],
    ["駐輪場あり", /駐輪場(?:有り|あり|可)/],
    ["ペット相談", /ペット相談|ペット可|ペット飼育/],
    ["灯油暖房", /灯油暖房|灯油FF/],
    ["都市ガス", /都市ガス/],
    ["プロパンガス", /プロパンガス|LPガス/],
    ["エレベーター", /エレベーター/],
    ["防犯カメラ", /防犯カメラ/],
  ];
  const equipment = labels.filter(([, pattern]) => pattern.test(value)).map(([label]) => label);
  const parkingText = value.match(/駐車場[\s\S]{0,180}/)?.[0] ?? "";
  if (parkingText && !/空きなし|空なし|無し|なし|無|不可|要確認|満車/.test(parkingText) && /空きあり|空有|空車|有り|あり|可/.test(parkingText)) {
    equipment.push("駐車場空きあり");
  }
  return equipment;
}

function extractDetailBuilding(text, title = "") {
  const titleMatch = text.match(/(?:建物名|物件名)\s*[:：]?\s*([^\n]+)/);
  if (titleMatch) return titleMatch[1].trim();

  const roomLineMatch = text.match(/^(.+?)\s+[A-Za-z0-9０-９-]+号室/m);
  if (roomLineMatch) return roomLineMatch[1].trim();

  const browserTitleMatch = String(title).normalize("NFKC").match(/^(.+?)\s+[A-Za-z0-9-]+号室/);
  return browserTitleMatch?.[1]?.trim() ?? "";
}

function extractDetailRoom(text, title = "") {
  const labelMatch = text.match(/(?:部屋番号|号室)\s*[:：]?\s*([A-Za-z0-9０-９-]+)/);
  if (labelMatch) return labelMatch[1].trim();

  const roomMatch = text.match(/([A-Za-z0-9０-９-]+)\s*号室/);
  if (roomMatch) return roomMatch[1].trim();

  const roomNameMatch = text.match(/号室名\s*([A-Za-z0-9０-９-]+)/);
  if (roomNameMatch) return roomNameMatch[1].trim();

  const browserTitleMatch = String(title).normalize("NFKC").match(/([A-Za-z0-9-]+)号室/);
  return browserTitleMatch?.[1]?.trim() ?? "";
}

function extractAdAvailability(text) {
  if (/許可されていません|不可/.test(text)) return "許可されていません";
  if (/管理会社に確認|要確認|管理会社へご確認|掲載希望の場合は管理会社/.test(text)) return "管理会社に確認";
  if (/[［\[]?\s*可\s*[］\]]?|許可されています/.test(text)) return "可";
  return "判定不可";
}

function extractQuotedValue(text, label, allowedValues) {
  const escapedLabel = label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = text.match(new RegExp(`${escapedLabel}\\s*[:：]?\\s*[「\\\"']?([^「」\\\"'\\s、,。]+)`));
  const value = match?.[1]?.trim();
  return allowedValues.includes(value) ? value : "判定不可";
}

function extractApplicationCount(text) {
  const applicationMatch = text.match(/(?:申込|申し込み)\s*([0-9]+)\s*件/);
  return Number(applicationMatch?.[1] ?? 0);
}

function mergeRealproDetails(rooms, details) {
  if (!details.length) return rooms;

  return rooms.map((room) => {
    const detail = findMatchingRealproDetail(room, rooms, details);
    if (!detail) return room;

    return {
      ...room,
      realproRoomId: realproRoomId(detail) || realproRoomId(room),
      webAd: detail.webAd ?? room.webAd,
      imageReuse: detail.imageReuse ?? room.imageReuse,
      floorPlanReuse: detail.floorPlanReuse ?? room.floorPlanReuse,
      priorContact: detail.priorContact ?? room.priorContact,
      equipment: normalizeEquipmentList([...(room.equipment ?? []), ...(detail.equipment ?? [])]),
      applicationCount: Number(detail.applicationCount ?? room.applicationCount ?? 0),
      detailCaptureStatus: detail.detailCaptureStatus ?? room.detailCaptureStatus ?? "",
      detailCaptureReason: detail.detailCaptureReason ?? room.detailCaptureReason ?? "",
      detailHttpStatus: detail.detailHttpStatus ?? room.detailHttpStatus ?? "",
      detailTextLength: Number(detail.detailTextLength ?? room.detailTextLength ?? 0),
      url: realproDetailUrl(detail) || realproDetailUrl(room),
    };
  });
}

function findMatchingRealproDetail(room, rooms, details) {
  const roomId = realproRoomId(room);
  if (roomId) {
    const idMatch = details.find((detail) => realproRoomId(detail) === roomId);
    if (idMatch) return idMatch;
  }
  const exactMatch = details.find((detail) => detail.building && detail.room && roomKey(detail) === roomKey(room));
  if (exactMatch) return exactMatch;

  const roomOnlyMatches = rooms.filter((candidate) => normalizeRoom(candidate.room) === normalizeRoom(room.room));
  if (roomOnlyMatches.length === 1) {
    return details.find((detail) => detail.room && normalizeRoom(detail.room) === normalizeRoom(room.room));
  }

  if (rooms.length === 1 && details.length === 1) return details[0];
  return null;
}

function normalizeRealproDetail(detail) {
  const parsedDetail = parseRealproDetailText(detail.rawText, detail.title);
  return {
    ...parsedDetail,
    realproRoomId: realproRoomId(detail),
    building: detail.building ?? parsedDetail.building,
    room: detail.room ?? parsedDetail.room,
    webAd: detail.webAd ?? parsedDetail.webAd,
    imageReuse: detail.imageReuse ?? parsedDetail.imageReuse,
    floorPlanReuse: detail.floorPlanReuse ?? parsedDetail.floorPlanReuse,
    priorContact: detail.priorContact ?? parsedDetail.priorContact,
    applicationCount: Number(detail.applicationCount ?? parsedDetail.applicationCount ?? 0),
    equipment: normalizeEquipmentList(detail.equipment ?? parsedDetail.equipment ?? []),
    detailCaptureStatus: detail.detailCaptureStatus ?? "",
    detailCaptureReason: detail.detailCaptureReason ?? "",
    detailHttpStatus: detail.detailHttpStatus ?? detail.status ?? "",
    detailTextLength: Number(detail.detailTextLength ?? 0),
    url: realproDetailUrl(detail),
  };
}

function normalizeRealproRoom(room) {
  const roomId = realproRoomId(room);
  return {
    realproRoomId: roomId,
    building: room.building ?? room.buildingName ?? "",
    address: room.address ?? "",
    room: room.room ?? room.roomNumber ?? "",
    line: room.line ?? "",
    station: room.station ?? "",
    accessMethod: room.accessMethod ?? "徒歩",
    walkMinutes: Number(room.walkMinutes ?? 0),
    layout: room.layout ?? "",
    area: room.area ?? "",
    rent: Number(room.rent ?? 0),
    fee: Number(room.fee ?? 0),
    status: normalizeRealproStatus(room.status ?? ""),
    availableDate: room.availableDate ?? "",
    adFee: room.adFee ?? "",
    equipment: normalizeEquipmentList(room.equipment),
    webAd: room.webAd ?? "判定不可",
    imageReuse: room.imageReuse ?? "判定不可",
    floorPlanReuse: room.floorPlanReuse ?? "判定不可",
    priorContact: room.priorContact ?? "判定不可",
    applicationCount: Number(room.applicationCount ?? 0),
    detailCaptureStatus: room.detailCaptureStatus ?? "",
    detailCaptureReason: room.detailCaptureReason ?? "",
    detailHttpStatus: room.detailHttpStatus ?? "",
    detailTextLength: Number(room.detailTextLength ?? 0),
    url: realproDetailUrl({ ...room, realproRoomId: roomId }),
  };
}

function normalizeEquipmentList(equipment) {
  if (!Array.isArray(equipment)) return [];
  return [...new Set(equipment.map(canonicalEquipment).filter(Boolean))].sort();
}

function canonicalEquipment(value) {
  const text = String(value ?? "").normalize("NFKC");
  if (/バス・トイレ別|BT別|セパレート/.test(text)) return "バス・トイレ別";
  if (/独立洗面|洗面化粧台|シャンプードレッサー/.test(text)) return "独立洗面台";
  if (/宅配ボックス|宅配BOX/i.test(text)) return "宅配ボックス";
  if (/インターネット無料|ネット無料/.test(text)) return "インターネット無料";
  if (/Wi-?Fi無料|Wifi無料|ワイファイ無料/i.test(text)) return "Wi-Fi無料";
  if (/駐車場|駐車可/.test(text) && !/空きなし|空なし|無し|なし|無|不可|要確認|満車/.test(text) && /空きあり|空有|空車|有り|あり|可/.test(text)) return "駐車場空きあり";
  if (/駐輪場有り|駐輪場あり|駐輪場可/.test(text)) return "駐輪場あり";
  if (/ペット相談|ペット可|ペット飼育/.test(text)) return "ペット相談";
  if (/灯油暖房|灯油FF/.test(text)) return "灯油暖房";
  if (/LPガス/.test(text)) return "プロパンガス";
  return text.trim();
}

function normalizeESeikatsuRoom(room) {
  return {
    building: room.building ?? room.buildingName ?? "",
    room: room.room ?? room.roomNumber ?? "",
    layout: room.layout ?? "",
    status: normalizeESeikatsuStatus(room.status ?? "不明"),
    listing: normalizeESeikatsuListing(room.listing ?? "不明"),
    url: room.url ?? "",
  };
}

function normalizeRealproStatus(value) {
  const text = String(value ?? "").normalize("NFKC").replace(/\s+/g, " ").trim();
  const statuses = [];
  if (/空室|即入/.test(text)) statuses.push("空室");
  if (/退去予定|退去前|退去待ち/.test(text)) statuses.push("退去予定");
  if (/商談中/.test(text)) statuses.push("商談中");
  if (/審査中/.test(text)) statuses.push("審査中");
  if (/申込|申し込み/.test(text)) statuses.push("申込あり");
  if (/募集停止|募集止|停止|成約|他決/.test(text)) statuses.push("募集停止");
  if (/新築/.test(text)) statuses.push("新築");
  if (/建築中/.test(text)) statuses.push("建築中");
  if (/内装中/.test(text)) statuses.push("内装中");
  if (/清掃中/.test(text)) statuses.push("清掃中");
  return statuses.length ? [...new Set(statuses)].join(" ") : text;
}

function normalizeESeikatsuStatus(value) {
  const text = String(value ?? "").normalize("NFKC").replace(/\s+/g, "").trim();
  if (/募集中|募集開始|公開中/.test(text)) return "募集中";
  if (/募集止|募集停止|停止|非募集/.test(text)) return "募集止";
  if (/作成中|下書き/.test(text)) return "作成中";
  if (/成約\/他決|成約|他決/.test(text)) return "成約/他決";
  return text || "不明";
}

function normalizeESeikatsuListing(value) {
  const text = String(value ?? "").normalize("NFKC").replace(/\s+/g, "").trim();
  if (/掲載中|公開中|掲載あり|掲載有|掲載/.test(text) && !/未掲載|非掲載|掲載なし|掲載無し/.test(text)) return "掲載中";
  if (/未掲載|非掲載|掲載なし|掲載無し|未公開/.test(text)) return "未掲載";
  return text || "不明";
}

function arrayFromCapture(data, keys) {
  for (const key of keys) {
    const value = key.split(".").reduce((current, part) => current?.[part], data);
    if (Array.isArray(value)) return value;
  }

  return [];
}

function parseESeikatsuText(rawText) {
  if (!rawText) {
    return { rooms: [], summary: "本文テキストがありません。" };
  }

  const parsedList = parseESeikatsuListText(rawText);
  if (parsedList.rooms.length) return parsedList;

  const parsed = parseCapturedText(rawText);
  const statusPattern = /(募集中|募集止|作成中|成約\/他決|成約|他決)/;
  const listingPattern = /(掲載中|未掲載|非掲載)/;
  const lines = rawText.split(/\n+/);

  parsed.rooms = parsed.rooms.map((room) => {
    const normalizedRoom = normalize(room.room);
    const roomIndex = lines.findIndex((line) => normalize(line).startsWith(normalizedRoom));
    const nearbyText = lines.slice(Math.max(0, roomIndex), roomIndex + 20).join(" ");
    const status = nearbyText.match(statusPattern)?.[1] ?? "不明";
    const listing = nearbyText.match(listingPattern)?.[1] ?? "不明";

    return {
      building: room.building,
      room: room.room,
      layout: room.layout,
      status,
      listing,
      url: "",
    };
  });

  parsed.summary = `${rawText.split(/\n+/).filter(Boolean).length}行のテキストから${parsed.rooms.length}件のいい生活候補を推定しました。`;
  return parsed;
}

function parseESeikatsuListText(rawText) {
  const lines = rawText.split(/\n+/).map((line) => line.trim()).filter(Boolean);
  const rooms = [];

  lines.forEach((line, index) => {
    const nameRoomMatch = line.match(/^(.+?)\s+([A-Za-z0-9０-９-]+)$/);
    if (!nameRoomMatch) return;
    if (!lines[index + 1]?.startsWith("北海道")) return;

    const nearby = lines.slice(Math.max(0, index - 6), index + 28);
    const status = nearby.find((item) => /^(募集中|募集止|作成中|成約\/他決|成約|他決)$/.test(item)) ?? "不明";
    const layoutIndex = nearby.findIndex((item) => /^(ワンルーム|[1-6１-６]LDK|[1-6１-６]DK|[1-6１-６]K)$/.test(item));

    rooms.push({
      building: nameRoomMatch[1],
      room: nameRoomMatch[2],
      layout: layoutIndex >= 0 ? nearby[layoutIndex] : "",
      status,
      listing: status === "募集中" ? "掲載中" : "不明",
      url: "",
    });
  });

  return {
    rooms,
    summary: `${lines.length}行のテキストから${rooms.length}件のいい生活候補を推定しました。`,
  };
}

function numberFromYen(value) {
  if (!value) return 0;
  return Number(value.replace(/[^\d０-９]/g, "").normalize("NFKC"));
}

async function handleCaptureFile(event) {
  const file = event.target.files?.[0];
  if (!file) return;

  try {
    const data = JSON.parse(await file.text());
    importCaptureData(data, file.name);
  } catch (error) {
    renderCaptureSummary();
    importStatus.textContent = `読み込みに失敗しました: ${error.message}`;
  }
}

async function handleLatestCaptureLoad() {
  if (location.protocol === "file:") {
    importStatus.innerHTML = `最新取得JSONはローカルサーバー版で読み込めます。${serverModeLinkText()}`;
    return;
  }

  try {
    importStatus.textContent = "最新取得JSONを読み込んでいます...";
    const result = await fetchLatestCapture();
    importCaptureData(result.data, result.filename);
    if (latestCaptureNeedsESeikatsuMerge(result.data)) {
      startESeikatsuReview();
    }
  } catch (error) {
    importStatus.textContent = `読み込みに失敗しました: ${error.message}`;
  }
}

function truthyUrlFlag(value) {
  return ["1", "true", "yes", "on"].includes(String(value ?? "").toLowerCase());
}

async function applyStartupUrlState() {
  const result = { didLoadCapture: false };
  if (location.protocol === "file:") return result;

  const params = new URLSearchParams(location.search);
  const criteriaText = params.get("criteria") || params.get("condition") || "";
  const shouldLoadLatest = truthyUrlFlag(params.get("loadLatest"));
  const shouldSaveCsv = truthyUrlFlag(params.get("saveCsv"));

  if (criteriaText) {
    try {
      applySearchConditionJson(criteriaText, "URL検索条件");
    } catch (error) {
      conditionStatus.textContent = `URL検索条件の反映に失敗しました: ${error.message}`;
      conditionStatus.className = "condition-status status-warn-inline";
    }
  }

  if (shouldLoadLatest || shouldSaveCsv) {
    await handleLatestCaptureLoad();
    result.didLoadCapture = hasLoadedCaptureData;
  }

  if (shouldSaveCsv) {
    if (hasLoadedCaptureData) {
      await saveCsvExportSet();
    } else {
      resultSummary.textContent = "URL指定のCSV保存をスキップしました。最新取得JSONを読み込めていません。";
    }
  }

  return result;
}

async function initializeStartupState() {
  const startup = await applyStartupUrlState();
  if (!startup.didLoadCapture) {
    await restoreLatestCaptureOnStartup();
  }
  await handleExtensionStatusCheck();
  checkForUpdates();
}

let latestUpdateInfo = null;

async function checkForUpdates() {
  if (location.protocol === "file:") return;
  try {
    const response = await fetch(`/api/update-check?ts=${Date.now()}`);
    if (!response.ok) return;
    const updateInfo = await response.json();
    latestUpdateInfo = updateInfo;
    renderUpdateStatus(updateInfo);
    if (updateInfo.updateAvailable) {
      showUpdateToast(updateInfo);
    }
  } catch {
    // 更新確認に失敗しても通常作業は止めない。
  }
}

function renderUpdateStatus(updateInfo = latestUpdateInfo) {
  if (!updateStatusButton || !updateInfo) return;
  if (updateInfo.updateAvailable) {
    updateStatusButton.hidden = false;
    updateStatusButton.textContent = updateInfo.required ? "重要アップデート" : "アップデートあり";
    return;
  }
  updateStatusButton.hidden = true;
}

function showUpdateToast(updateInfo = latestUpdateInfo) {
  if (!updateToast || !updateToastTitle || !updateToastMessage || !updateToastNotes || !updateInfo?.updateAvailable) return;
  updateToastTitle.textContent = "新しいアップデートがあります";
  updateToastMessage.textContent = `現在 ${updateInfo.currentVersion || "-"} → 最新 ${updateInfo.latestVersion || "-"}。`;
  const notes = Array.isArray(updateInfo.notes) ? updateInfo.notes.slice(0, 4) : [];
  updateToastNotes.innerHTML = notes.length
    ? notes.map((note) => `<li>${escapeHtml(note)}</li>`).join("")
    : "<li>更新内容はダウンロードページで確認できます。</li>";
  updateToast.hidden = false;
}

function hideUpdateToast() {
  if (updateToast) updateToast.hidden = true;
}

async function openUpdateDownload(updateInfo = latestUpdateInfo) {
  if (!updateInfo?.downloadUrl) {
    alert("最新版のダウンロードURLがまだ設定されていません。管理者側でサーバーの最新版情報を更新してください。");
    return;
  }
  if (updateNowButton) {
    updateNowButton.disabled = true;
    updateNowButton.textContent = "バックアップ中";
  }
  let backup = null;
  const isWindowsInstaller = updateInfo.packageType === "exe" || /\.exe(?:$|\?)/i.test(updateInfo.downloadUrl || "");
  let downloadWindow = isWindowsInstaller ? window.open("about:blank", "_blank", "noopener") : null;
  if (downloadWindow) {
    downloadWindow.document.title = "Windows更新ファイルを準備中";
    downloadWindow.document.body.innerHTML = "<p>Windows更新ファイルを確認しています。このタブは自動でダウンロードへ進みます。</p>";
  }
  try {
    backup = await createUpdateBackup(updateInfo);
    if (updateToastMessage) {
      updateToastMessage.textContent = `更新前バックアップを作成しました: ${backup.backupPath || backup.backupName || "完了"}`;
    }
    if (updateNowButton) updateNowButton.textContent = "更新ファイル確認中";
    const prepared = await prepareUpdatePackage(updateInfo);
    if (prepared.packageType === "exe") {
      if (downloadWindow && !downloadWindow.closed) {
        downloadWindow.location.href = updateInfo.downloadUrl;
      } else {
        downloadWindow = window.open(updateInfo.downloadUrl, "_blank", "noopener");
      }
      alert(`更新前バックアップを作成し、Windowsインストーラーを取得確認しました。\nバックアップ: ${backup.backupPath}\n取得ファイル: ${prepared.downloadedFile}\n\nダウンロードされたインストーラーを実行して更新してください。\n別タブが開かない場合は、次のURLをブラウザで開いてください。\n${updateInfo.downloadUrl}`);
    } else {
      if (updateNowButton) updateNowButton.textContent = "本体更新中";
      const applied = await applyPreparedUpdate();
      alert(`更新が完了しました。システムを再起動してください。\nバックアップ: ${backup.backupPath}\n展開先: ${prepared.packageRoot || prepared.stagedPath}\n更新ファイル数: ${applied.copiedFiles}件`);
    }
    hideUpdateToast();
  } catch (error) {
    if (downloadWindow) downloadWindow.close();
    const restoreMessage = backup?.backupName
      ? "\n\n更新前バックアップから復元しますか？"
      : "";
    const shouldRestore = backup?.backupName
      ? confirm(`更新準備に失敗しました。本体の入れ替えが途中だった可能性があります。\n${error.message}${restoreMessage}`)
      : false;
    if (shouldRestore) {
      try {
        if (updateNowButton) updateNowButton.textContent = "復元中";
        const restored = await restoreUpdateBackup(backup.backupName);
        alert(`バックアップから復元しました。システムを再起動してください。\n復元元: ${restored.backupName}\n復元ファイル数: ${restored.copiedFiles}件`);
      } catch (restoreError) {
        alert(`バックアップ復元に失敗しました。\n${restoreError.message}`);
      }
    } else if (!backup?.backupName) {
      alert(`更新準備に失敗しました。本体の入れ替えは行っていません。\n${error.message}`);
    }
  } finally {
    if (updateNowButton) {
      updateNowButton.disabled = false;
      updateNowButton.textContent = "今すぐ更新";
    }
  }
}

async function createUpdateBackup(updateInfo = latestUpdateInfo) {
  const response = await fetch("/api/update-backup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(updateInfo || {}),
  });
  if (!response.ok) {
    const errorPayload = await readErrorResponse(response);
    throw new Error(errorPayload);
  }
  return response.json();
}

async function prepareUpdatePackage(updateInfo = latestUpdateInfo) {
  const response = await fetch("/api/update-prepare", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(updateInfo || {}),
  });
  if (!response.ok) {
    const errorPayload = await readErrorResponse(response);
    throw new Error(errorPayload);
  }
  return response.json();
}

async function applyPreparedUpdate(options = {}) {
  const response = await fetch("/api/update-apply", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(options || {}),
  });
  if (!response.ok) {
    const errorPayload = await readErrorResponse(response);
    throw new Error(errorPayload);
  }
  return response.json();
}

async function restoreUpdateBackup(backupName) {
  const response = await fetch("/api/update-restore", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ backupName }),
  });
  if (!response.ok) {
    const errorPayload = await readErrorResponse(response);
    throw new Error(errorPayload);
  }
  return response.json();
}

async function handleExtensionStatusCheck() {
  if (location.protocol === "file:") {
    if (extensionStatusText) extensionStatusText.innerHTML = `Chrome拡張連携はローカルサーバー版で確認できます。${serverModeLinkText()}`;
    return;
  }

  const bridgeStatus = await checkExtensionBridgeStatus();
  try {
    setExtensionStatusText(bridgeStatus.connected
      ? "Chrome拡張の接続と取得データを確認しています..."
      : bridgeStatus.message, bridgeStatus.connected ? "" : "warn");
    const response = await fetch(`/api/extension/status?ts=${Date.now()}`);
    if (!response.ok) {
      const errorPayload = await readErrorResponse(response);
      throw new Error(errorPayload);
    }
    const status = await response.json();
    renderExtensionStatus(status, bridgeStatus);
  } catch (error) {
    setExtensionStatusText(`拡張取得の確認に失敗しました: ${error.message}`, "warn");
  }
}

async function handleExtensionCaptureLoad() {
  await handleLatestCaptureLoad();
  await handleExtensionStatusCheck();
}

function extensionCaptureServerUrl() {
  if (location.protocol === "file:") return serverIndexUrl().replace(/\/index\.html$/, "");
  return location.origin;
}

function requestExtensionPing(timeoutMs = 1800) {
  return new Promise((resolve, reject) => {
    const requestId = `extension-ping-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    let timeoutId = 0;

    const cleanup = () => {
      window.removeEventListener("message", onMessage);
      if (timeoutId) window.clearTimeout(timeoutId);
    };

    const onMessage = (event) => {
      if (event.source !== window) return;
      const message = event.data || {};
      if (message.type !== "PROPERTY_LIST_EXTENSION_CAPTURE_EVENT" || message.requestId !== requestId) return;
      cleanup();
      if (message.event === "pong") {
        resolve(message.payload || {});
        return;
      }
      reject(new Error(message.payload?.error || "Chrome拡張の接続確認に失敗しました。"));
    };

    window.addEventListener("message", onMessage);
    window.postMessage({
      type: "PROPERTY_LIST_EXTENSION_PING",
      requestId,
    }, window.location.origin);
    timeoutId = window.setTimeout(() => {
      cleanup();
      reject(new Error("Chrome拡張から応答がありません。"));
    }, timeoutMs);
  });
}

function requestExtensionTabStatus(timeoutMs = 2500) {
  return new Promise((resolve, reject) => {
    const requestId = `extension-status-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    let timeoutId = 0;

    const cleanup = () => {
      window.removeEventListener("message", onMessage);
      if (timeoutId) window.clearTimeout(timeoutId);
    };

    const onMessage = (event) => {
      if (event.source !== window) return;
      const message = event.data || {};
      if (message.type !== "PROPERTY_LIST_EXTENSION_CAPTURE_EVENT" || message.requestId !== requestId) return;
      cleanup();
      if (message.event === "status") {
        resolve(message.payload || {});
        return;
      }
      reject(new Error(message.payload?.error || "Chrome拡張のタブ確認に失敗しました。"));
    };

    window.addEventListener("message", onMessage);
    window.postMessage({
      type: "PROPERTY_LIST_EXTENSION_STATUS",
      requestId,
    }, window.location.origin);
    timeoutId = window.setTimeout(() => {
      cleanup();
      reject(new Error("Chrome拡張からタブ確認の応答がありません。"));
    }, timeoutMs);
  });
}

async function checkExtensionBridgeStatus() {
  if (location.protocol === "file:") {
    return {
      connected: false,
      message: `Chrome拡張連携はローカルサーバー版で確認できます。${serverModeLinkText()}`,
    };
  }

  try {
    const response = await requestExtensionPing();
    return {
      connected: Boolean(response?.ok),
      version: response?.version || "",
      message: response?.version
        ? `Chrome拡張: 接続OK v${response.version}`
        : "Chrome拡張: 接続OK",
    };
  } catch (error) {
    return {
      connected: false,
      message: "Chrome拡張: 未接続です。chrome://extensions で「物件候補リスト 取得補助」を再読み込みし、リアプロタブも再読み込みしてください。",
      error: error.message,
    };
  }
}

function renderExtensionCaptureProgress(payload = {}) {
  const phase = payload.phase || "list";
  const current = Number(payload.current || 0);
  const total = Number(payload.total || 0);
  const progress = {
    phase: phase === "details" ? "details" : phase === "saving" ? "saving" : "list",
    label: phase === "details"
      ? "Chrome拡張でリアプロ詳細を確認中"
      : phase === "saving"
      ? "Chrome拡張の取得結果を保存中"
      : "Chrome拡張でリアプロ一覧を取得中",
    currentPage: phase === "list" ? current : 0,
    totalPages: phase === "list" ? total : 0,
    currentDetails: phase === "details" ? current : 0,
    totalDetails: phase === "details" ? total : 0,
    rooms: Number(payload.rooms || 0),
    realproRooms: Number(payload.rooms || 0),
    message: payload.text || "Chrome拡張で取得しています...",
    updatedAt: new Date().toISOString(),
  };
  renderLiveCaptureProgress(progress);
}

function requestExtensionRealproCapture(payload = {}) {
  return new Promise((resolve, reject) => {
    const requestId = `realpro-extension-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    activeExtensionCaptureRequestId = requestId;
    let accepted = false;
    let timeoutId = 0;

    const cleanup = () => {
      window.removeEventListener("message", onMessage);
      if (timeoutId) window.clearTimeout(timeoutId);
      if (activeExtensionCaptureRequestId === requestId) activeExtensionCaptureRequestId = "";
    };

    const resetTimeout = (milliseconds, message) => {
      if (timeoutId) window.clearTimeout(timeoutId);
      timeoutId = window.setTimeout(() => {
        cleanup();
        reject(new Error(message));
      }, milliseconds);
    };

    const onMessage = (event) => {
      if (event.source !== window) return;
      const message = event.data || {};
      if (message.type !== "PROPERTY_LIST_EXTENSION_CAPTURE_EVENT" || message.requestId !== requestId) return;
      const eventPayload = message.payload || {};
      if (message.event === "accepted") {
        accepted = true;
        resetTimeout(45 * 60 * 1000, "Chrome拡張から取得完了の返答がありませんでした。リアプロタブと拡張機能を確認してください。");
        setOpsText("opsProgressTitle", "Chrome拡張で取得を開始しました");
        setOpsText("opsProgressMessage", "Chromeは別作業に使えます。リアプロタブを閉じずに待ってください。");
        return;
      }
      if (message.event === "progress") {
        accepted = true;
        resetTimeout(45 * 60 * 1000, "Chrome拡張の取得が途中で止まりました。リアプロタブと拡張機能を確認してください。");
        renderExtensionCaptureProgress(eventPayload);
        return;
      }
      if (message.event === "done") {
        cleanup();
        resolve(eventPayload);
        return;
      }
      if (message.event === "error") {
        cleanup();
        reject(new Error(eventPayload.error || "Chrome拡張取得に失敗しました。"));
      }
    };

    window.addEventListener("message", onMessage);
    window.postMessage({
      type: "PROPERTY_LIST_EXTENSION_CAPTURE",
      requestId,
      payload,
    }, window.location.origin);
    resetTimeout(3500, accepted
      ? "Chrome拡張の取得開始後に応答が止まりました。"
      : "Chrome拡張機能から応答がありません。拡張機能を更新/再読み込みしてください。");
  });
}

function requestExtensionRealproConditions(payload = {}) {
  return new Promise((resolve, reject) => {
    const requestId = `realpro-conditions-extension-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    let timeoutId = 0;

    const cleanup = () => {
      window.removeEventListener("message", onMessage);
      if (timeoutId) window.clearTimeout(timeoutId);
    };

    const onMessage = (event) => {
      if (event.source !== window) return;
      const message = event.data || {};
      if (message.type !== "PROPERTY_LIST_EXTENSION_CAPTURE_EVENT" || message.requestId !== requestId) return;
      if (message.event === "accepted" || message.event === "progress") return;
      cleanup();
      if (message.event === "done") {
        resolve(message.payload || {});
        return;
      }
      reject(new Error(message.payload?.error || "Chrome拡張で検索条件を反映できませんでした。"));
    };

    window.addEventListener("message", onMessage);
    window.postMessage({
      type: "PROPERTY_LIST_EXTENSION_APPLY_CONDITIONS",
      requestId,
      payload,
    }, window.location.origin);
    timeoutId = window.setTimeout(() => {
      cleanup();
      reject(new Error("Chrome拡張から条件反映の応答がありません。拡張機能を再読み込みしてください。"));
    }, 30000);
  });
}

async function handleExtensionPrimaryCaptureRun() {
  if (location.protocol === "file:") {
    const message = `Chrome拡張取得はサーバー版で使います。${serverModeLinkText()}`;
    importStatus.innerHTML = message;
    setOpsText("opsProgressTitle", "サーバー版で開いてください");
    setOpsText("opsProgressMessage", "file:// では拡張機能との連携ができません。");
    return;
  }

  syncOpsCapturePageInput();
  const capturedPages = opsCapturedRealproPageNumbers();
  let startPage = clampCapturePages(realproStartPage?.value, 1, 10000);
  const pages = clampCapturePages(opsRealproCapturePages?.value || realproCapturePages?.value, 2, 200);
  if (loadedCaptureMatchesCurrentCriteria() && capturedPages.has(startPage)) {
    startPage = opsFirstMissingRealproPage();
    if (realproStartPage) realproStartPage.value = String(startPage);
    updateOpsCaptureRangeSummary();
  }
  const requiredPages = realproRequiredPagesForOps();
  if (loadedCaptureMatchesCurrentCriteria() && requiredPages && startPage > requiredPages) {
    importStatus.textContent = "この検索条件のリアプロページは全て取得済みです。条件を変えるか、リセットしてから再取得してください。";
    setOpsText("opsProgressTitle", "全ページ取得済みです");
    setOpsText("opsProgressMessage", "追加で取得するページはありません。候補一覧を確認できます。");
    scrollToOpsProgress();
    return;
  }

  const readinessMessage = captureReadinessMessage();
  if (readinessMessage) {
    importStatus.textContent = readinessMessage;
    setOpsText("opsProgressTitle", "取得前チェックが必要です");
    setOpsText("opsProgressMessage", readinessMessage);
    scrollToOpsProgress();
    return;
  }

  captureLastError = "";
  lastLiveCaptureProgress = null;
  captureProgressSource = "extension";
  try {
    setOpsText("opsProgressTitle", "Chrome拡張の接続を確認しています");
    setOpsText("opsProgressMessage", "未接続の場合は取得を始めずに止めます。");
    const bridgeStatus = await checkExtensionBridgeStatus();
    if (!bridgeStatus.connected) {
      const message = `${bridgeStatus.message} 取得はまだ開始していません。`;
      importStatus.textContent = message;
      setOpsText("opsProgressTitle", "Chrome拡張が未接続です");
      setOpsText("opsProgressMessage", message);
      setExtensionStatusText(bridgeStatus.message, "warn");
      showWorkflowProblem(message, currentWorkflowStage || "prepare");
      return;
    }

    setExtensionStatusText(bridgeStatus.message, "ok");
    setCaptureRunning(true, "拡張取得中...");
    renderExtensionCaptureProgress({
      phase: "list",
      current: 0,
      total: pages,
      text: `Chrome拡張へ取得依頼中... ${startPage}ページ目から${pages}ページ`,
    });
    importStatus.textContent = `Chrome拡張へ取得依頼中... ${startPage}ページ目から${pages}ページ`;
    const result = await requestExtensionRealproCapture({
      serverUrl: extensionCaptureServerUrl(),
      startPage,
      pages,
      withDetails: true,
      reset: startPage <= 1,
      criteriaJson: selectedConditionJson(),
      criteriaText: selectedConditionText(),
    });
    importStatus.textContent = result.text || "Chrome拡張取得を保存しました。最新取得JSONを読み込みます...";
    await handleLatestCaptureLoad();
    if (realproStartPage) realproStartPage.value = String(startPage + pages);
    saveSearchConditions();
    renderCapturePlan();
    await handleExtensionStatusCheck();
    resultSummary.textContent = `Chrome拡張取得OK: ${importedRealproRooms.length}戸を読み込みました。`;
    showCompletionToast(startPage > 1 ? "追加取得が完了しました" : "取得が完了しました");
  } catch (error) {
    const message = `Chrome拡張取得に失敗しました: ${error.message}`;
    importStatus.textContent = message;
    showWorkflowProblem(`${message} 詳細設定内のMacバックアップ取得は残しています。`, currentWorkflowStage || "prepare");
  } finally {
    setCaptureRunning(false);
  }
}

function renderExtensionStatus(status = {}, bridgeStatus = null) {
  const extensionCapture = status.extensionCapture;
  const latestCapture = status.latestCapture;
  if (extensionCaptureState) {
    extensionCaptureState.textContent = extensionCapture
      ? `リアプロ${extensionCapture.realproRooms}戸`
      : "未取得";
  }
  if (extensionLatestState) {
    extensionLatestState.textContent = latestCapture
      ? `リアプロ${latestCapture.realproRooms}戸 / いい生活${latestCapture.eSeikatsuRooms}件`
      : "未取得";
  }
  const lines = [
    bridgeStatus
      ? bridgeStatus.message
      : "Chrome拡張: 未確認",
    extensionCapture
      ? `前回の拡張送信: ${formatDateTime(extensionCapture.updatedAt)} / リアプロ${extensionCapture.realproRooms}戸`
      : "拡張から届いた送信データはまだありません。",
    latestCapture
      ? `現在の読込データ: ${formatDateTime(latestCapture.updatedAt)} / リアプロ${latestCapture.realproRooms}戸 / いい生活${latestCapture.eSeikatsuRooms}件`
      : "現在読み込める取得JSONはまだありません。",
  ];
  setExtensionStatusText(lines.join(" / "), bridgeStatus?.connected ? "ok" : "warn");
}

function setExtensionStatusText(message, state = "") {
  if (!extensionStatusText) return;
  extensionStatusText.textContent = message;
  extensionStatusText.className = `note ${state === "ok" ? "status-ok-inline" : state === "warn" ? "status-warn-inline" : ""}`.trim();
}

async function restoreLatestCaptureOnStartup() {
  if (location.protocol === "file:" || hasLoadedCaptureData) return;
  if (truthyUrlFlag(new URLSearchParams(location.search).get("noRestore"))) {
    importStatus.textContent = "前回データの自動復元を省略しています。";
    return;
  }
  try {
    importStatus.textContent = "前回の候補リストを復元しています...";
    const result = await fetchLatestCapture();
    importCaptureData(result.data, result.filename);
    if (latestCaptureNeedsESeikatsuMerge(result.data)) {
      startESeikatsuReview();
    }
  } catch {
    importStatus.textContent = "まだ候補リストを作成していません。";
  }
}

async function handleVerificationSampleLoad() {
  return loadVerificationSampleData();
}

async function handleVerificationSampleDefaultLoad() {
  resetAllSearchConditions();
  importStatus.textContent = "検索条件を初期状態に戻して、検証サンプルを読み込んでいます...";
  return loadVerificationSampleData();
}

async function loadVerificationSampleData() {
  if (location.protocol === "file:") {
    importStatus.innerHTML = `検証サンプルはローカルサーバー版で読み込めます。${serverModeLinkText()}`;
    return;
  }

  try {
    importStatus.textContent = "検証サンプルを読み込んでいます...";
    const response = await fetch(`/data/verification_sample.json?ts=${Date.now()}`);
    if (!response.ok) throw new Error("data/verification_sample.json を取得できませんでした。");
    importCaptureData(await response.json(), "data/verification_sample.json");
  } catch (error) {
    importStatus.textContent = `読み込みに失敗しました: ${error.message}`;
  }
}

async function handleVerificationJsonCheck() {
  if (location.protocol === "file:") {
    importStatus.innerHTML = `検証JSON確認はローカルサーバー版で使えます。${serverModeLinkText()}`;
    return;
  }

  try {
    importStatus.textContent = "検証サンプルJSONを確認しています...";
    const [data, rules] = await Promise.all([
      fetchJson(`/data/verification_sample.json?ts=${Date.now()}`, "data/verification_sample.json"),
      fetchJson(`/data/verification_rules.json?ts=${Date.now()}`, "data/verification_rules.json"),
    ]);
    const result = validateVerificationSampleJson(data, rules);
    renderCaptureSummary([
      {
        label: "JSON確認",
        value: "OK",
        note: "検証サンプル",
        kind: "ok",
      },
      {
        label: "検証ルール",
        value: "OK",
        note: `必須項目 ${result.ruleSummary.requiredRealproFields.length + result.ruleSummary.requiredESeikatsuFields.length}項目`,
        kind: "ok",
      },
      {
        label: "リアプロ",
        value: `${result.realproCount}件`,
        note: `期待 ${result.expectedTotal}件 / raw ${result.realproRawCount.buildings}棟${result.realproRawCount.rooms}戸 / ${result.realproPageSummary.pages}ページ`,
        kind: "ok",
      },
      {
        label: "いい生活",
        value: `${result.eSeikatsuCount}件`,
        note: `API ${result.eSeikatsuApiCount.total}件 / item ${result.eSeikatsuApiCount.items}件 / ${result.eSeikatsuApiCount.pages}ページ`,
        kind: "ok",
      },
      {
        label: "表示候補",
        value: `${result.expectedShown}件`,
        note: "期待値",
        kind: "ok",
      },
      {
        label: "除外期待",
        value: `${result.expectedExcluded}件`,
        note: `重複 ${result.expectedDuplicated}件`,
        kind: "ok",
      },
      {
        label: "除外内訳",
        value: `${result.excludedBreakdownCount}種類`,
        note: `${result.excludedBreakdownTotal}件を確認`,
        kind: "ok",
      },
      {
        label: "詳細未確認CSV",
        value: `${result.expectedDetailUnconfirmedCsv}件`,
        note: `判定不可 ${result.detailUnconfirmedCount}件`,
        kind: "ok",
      },
      {
        label: "必須項目",
        value: "OK",
        note: `リアプロ${result.realproRequiredChecked}件 / いい生活${result.eSeikatsuRequiredChecked}件`,
        kind: "ok",
      },
      {
        label: "リンク確認",
        value: "OK",
        note: `${result.realproHost} / ${result.eSeikatsuHost}`,
        kind: "ok",
      },
      {
        label: "取得日時",
        value: formatDateTime(result.capturedAt),
        note: "サンプル",
        kind: "ok",
      },
    ]);
    importStatus.textContent = `検証サンプルJSON確認OKです。取得日時 ${formatDateTime(result.capturedAt)} / リアプロ ${result.realproCount}件(raw ${result.realproRawCount.buildings}棟${result.realproRawCount.rooms}戸/${result.realproPageSummary.pages}ページ) / いい生活 ${result.eSeikatsuCount}件(API ${result.eSeikatsuApiCount.total}件/${result.eSeikatsuApiCount.pages}ページ) / 期待表示候補 ${result.expectedShown}件 / 期待除外 ${result.expectedExcluded}件 / 期待重複 ${result.expectedDuplicated}件 / 詳細未確認CSV ${result.expectedDetailUnconfirmedCsv}件 / 除外内訳 ${result.excludedBreakdownText} / 必須項目OK / リンクOK (${result.realproHost}, ${result.eSeikatsuHost})。`;
  } catch (error) {
    renderCaptureSummary([
      {
        label: "JSON確認",
        value: "失敗",
        note: error.message,
        kind: "error",
      },
    ]);
    importStatus.textContent = `検証サンプルJSON確認に失敗しました: ${error.message}`;
  }
}

async function handleVerificationRulesCheck() {
  if (location.protocol === "file:") {
    importStatus.innerHTML = `検証ルール確認はローカルサーバー版で使えます。${serverModeLinkText()}`;
    return;
  }

  try {
    importStatus.textContent = "検証ルールJSONを確認しています...";
    const rules = await fetchJson(`/data/verification_rules.json?ts=${Date.now()}`, "data/verification_rules.json");
    const result = validateVerificationRules(rules);
    const realproCount = result.requiredRealproFields.length;
    const eSeikatsuCount = result.requiredESeikatsuFields.length;

    renderCaptureSummary([
      {
        label: "検証ルール",
        value: "OK",
        note: "verification_rules.json",
        kind: "ok",
      },
      {
        label: "リアプロ必須",
        value: `${realproCount}項目`,
        note: result.realproHost,
        kind: "ok",
      },
      {
        label: "いい生活必須",
        value: `${eSeikatsuCount}項目`,
        note: result.eSeikatsuHost,
        kind: "ok",
      },
      {
        label: "必須項目合計",
        value: `${realproCount + eSeikatsuCount}項目`,
        note: "空欄・重複なし",
        kind: "ok",
      },
      {
        label: "想定ドメイン",
        value: "OK",
        note: `${result.realproHost} / ${result.eSeikatsuHost}`,
        kind: "ok",
      },
    ]);
    importStatus.textContent = `検証ルールJSON確認OKです。リアプロ必須 ${realproCount}項目 / いい生活必須 ${eSeikatsuCount}項目 / 想定ドメイン ${result.realproHost}, ${result.eSeikatsuHost}。`;
  } catch (error) {
    renderCaptureSummary([
      {
        label: "検証ルール",
        value: "失敗",
        note: error.message,
        kind: "error",
      },
    ]);
    importStatus.textContent = `検証ルールJSON確認に失敗しました: ${error.message}`;
  }
}

async function handleVerificationBasicCheck() {
  if (location.protocol === "file:") {
    importStatus.innerHTML = `総合確認はローカルサーバー版で使えます。${serverModeLinkText()}`;
    return;
  }

  try {
    importStatus.textContent = "サンプルJSON・検証ルール・ドキュメントを確認しています...";
    const [data, rules, docs] = await Promise.all([
      fetchJson(`/data/verification_sample.json?ts=${Date.now()}`, "data/verification_sample.json"),
      fetchJson(`/data/verification_rules.json?ts=${Date.now()}`, "data/verification_rules.json"),
      fetchDocumentationFiles(),
    ]);
    const sampleResult = validateVerificationSampleJson(data, rules);
    const docsResult = validateDocumentationConsistency(docs);
    const rulesTotal = sampleResult.ruleSummary.requiredRealproFields.length + sampleResult.ruleSummary.requiredESeikatsuFields.length;
    renderCaptureSummary([
      {
        label: "総合確認",
        value: "OK",
        note: "サンプル・ルール・ドキュメント",
        kind: "ok",
      },
      {
        label: "サンプル",
        value: `${sampleResult.realproCount}件`,
        note: `詳細未確認 ${sampleResult.detailUnconfirmedCount}件`,
        kind: "ok",
      },
      {
        label: "いい生活",
        value: `${sampleResult.eSeikatsuCount}件`,
        note: `API ${sampleResult.eSeikatsuApiCount.total}件`,
        kind: "ok",
      },
      {
        label: "検証ルール",
        value: `${rulesTotal}項目`,
        note: `${sampleResult.realproHost} / ${sampleResult.eSeikatsuHost}`,
        kind: "ok",
      },
      {
        label: "ドキュメント",
        value: `${docsResult.checkedFiles}件`,
        note: "古い表現なし",
        kind: "ok",
      },
    ]);
    importStatus.textContent = `総合確認OKです。サンプル ${sampleResult.realproCount}件 / いい生活 ${sampleResult.eSeikatsuCount}件 / 詳細未確認 ${sampleResult.detailUnconfirmedCount}件 / ルール ${rulesTotal}項目 / ドキュメント ${docsResult.checkedFiles}件。`;
  } catch (error) {
    renderCaptureSummary([
      {
        label: "総合確認",
        value: "失敗",
        note: error.message,
        kind: "error",
      },
    ]);
    importStatus.textContent = `総合確認に失敗しました: ${error.message}`;
  }
}

async function handlePreflightCheck() {
  if (location.protocol === "file:") {
    importStatus.innerHTML = `本番前確認はローカルサーバー版で使えます。${serverModeLinkText()}`;
    updateServerUrlStripStatus("warn", "サーバー版ではありません");
    savePreflightHistory({
      checkedAt: new Date().toISOString(),
      status: "失敗",
      sourceLabel: "本番前確認",
      csvSchemaVersion: CSV_SCHEMA_VERSION,
      serverStatusText: "サーバー版ではありません",
      message: "file:// では本番前確認を実行できません。",
    });
    return;
  }

  try {
    importStatus.textContent = "本番前確認を実行しています...";
    const serverStatus = await refreshServerUrlStatus();
    const [data, rules, docs] = await Promise.all([
      fetchJson(`/data/verification_sample.json?ts=${Date.now()}`, "data/verification_sample.json"),
      fetchJson(`/data/verification_rules.json?ts=${Date.now()}`, "data/verification_rules.json"),
      fetchDocumentationFiles(),
    ]);
    const sampleResult = validateVerificationSampleJson(data, rules);
    const docsResult = validateDocumentationConsistency(docs);
    importCaptureData(data, "data/verification_sample.json");
    renderCaptureSummary([
      {
        label: "本番前確認",
        value: "OK",
        note: "サーバー・総合・サンプル",
        kind: "ok",
      },
      {
        label: "判定総数",
        value: `${sampleResult.realproCount}件`,
        note: `いい生活 ${sampleResult.eSeikatsuCount}件`,
        kind: "ok",
      },
      {
        label: "詳細未確認",
        value: `${sampleResult.detailUnconfirmedCount}件`,
        note: `CSV ${sampleResult.expectedDetailUnconfirmedCsv}件`,
        kind: sampleResult.detailUnconfirmedCount ? "warn" : "ok",
      },
      {
        label: "ドキュメント",
        value: `${docsResult.checkedFiles}件`,
        note: "整合性OK",
        kind: "ok",
      },
    ]);
    importStatus.textContent = `本番前確認OKです。サーバー状態、総合確認、検証サンプル読み込みを確認しました。サンプル ${sampleResult.realproCount}件 / いい生活 ${sampleResult.eSeikatsuCount}件 / 詳細未確認 ${sampleResult.detailUnconfirmedCount}件 / ドキュメント ${docsResult.checkedFiles}件。`;
    importStatus.className = "import-status status-ok-inline";
    savePreflightHistory({
      checkedAt: new Date().toISOString(),
      status: "OK",
      sourceLabel: "data/verification_sample.json",
      realproCount: sampleResult.realproCount,
      eSeikatsuCount: sampleResult.eSeikatsuCount,
      detailUnconfirmedCount: sampleResult.detailUnconfirmedCount,
      docsChecked: docsResult.checkedFiles,
      csvSchemaVersion: CSV_SCHEMA_VERSION,
      serverStatusText: serverStatus?.ok ? `OK / ${serverStatus.port ?? location.port}番` : "確認済み",
      message: "サーバー・総合確認・検証サンプル読み込みを確認しました。",
    });
  } catch (error) {
    renderCaptureSummary([
      {
        label: "本番前確認",
        value: "失敗",
        note: error.message,
        kind: "error",
      },
    ]);
    importStatus.textContent = `本番前確認に失敗しました: ${error.message}`;
    importStatus.className = "import-status status-warn-inline";
    updateServerUrlStripStatus("warn", "確認失敗");
    savePreflightHistory({
      checkedAt: new Date().toISOString(),
      status: "失敗",
      sourceLabel: "本番前確認",
      csvSchemaVersion: CSV_SCHEMA_VERSION,
      serverStatusText: "確認失敗",
      message: error.message,
    });
  }
}

async function fetchJson(url, label) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`${label} を取得できませんでした。`);
  return response.json();
}

async function fetchText(url, label) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`${label} を取得できませんでした。`);
  return response.text();
}

async function fetchDocumentationFiles() {
  const docs = [
    ["README.md", "/README.md"],
    ["docs/spec.md", "/docs/spec.md"],
    ["docs/automation.md", "/docs/automation.md"],
    ["docs/verification.md", "/docs/verification.md"],
  ];
  const entries = await Promise.all(docs.map(async ([label, path]) => [
    label,
    await fetchText(`${path}?ts=${Date.now()}`, label),
  ]));
  return Object.fromEntries(entries);
}

function validateDocumentationConsistency(docs) {
  const forbidden = ["判定不可・要確認", "広告判定不可", "判定総数: 12件", "除外: 6件"];
  const requiredByFile = {
    "README.md": ["詳細未確認検証状態", "詳細未確認CSV", "本番前確認履歴", "未確認原因分類"],
    "docs/spec.md": ["詳細未確認・除外", "詳細未確認CSV", "リアプロ詳細取得状態", "リアプロ詳細未確認原因分類"],
    "docs/automation.md": ["詳細未確認検証状態", "詳細未確認CSV"],
    "docs/verification.md": ["判定総数: 13件", "詳細未確認CSV: 1件", "詳細未確認検証状態", "本番前確認履歴", "リアプロ詳細未確認原因分類"],
  };

  Object.entries(docs).forEach(([label, content]) => {
    forbidden.forEach((text) => {
      if (content.includes(text)) throw new Error(`${label} に古い表現が残っています: ${text}`);
    });
    (requiredByFile[label] ?? []).forEach((text) => {
      if (!content.includes(text)) throw new Error(`${label} に必要な説明がありません: ${text}`);
    });
  });

  return { checkedFiles: Object.keys(docs).length };
}

function validateVerificationSampleJson(data, rules) {
  const expected = data?.meta?.expectedStats;
  const capturedAt = data?.meta?.capturedAt;
  const realproRooms = data?.realpro?.rooms;
  const eSeikatsuRooms = data?.eSeikatsu?.rooms;
  const ruleSummary = validateVerificationRules(rules);
  const realproHost = ruleSummary.realproHost;
  const eSeikatsuHost = ruleSummary.eSeikatsuHost;
  const requiredRealproFields = ruleSummary.requiredRealproFields;
  const requiredESeikatsuFields = ruleSummary.requiredESeikatsuFields;

  if (!capturedAt || Number.isNaN(new Date(capturedAt).getTime())) {
    throw new Error("meta.capturedAt が不正です。");
  }
  if (!expected) {
    throw new Error("meta.expectedStats がありません。");
  }
  ["total", "shown", "excluded", "duplicated", "detailUnconfirmedCsv"].forEach((field) => {
    if (!Number.isFinite(Number(expected[field]))) {
      throw new Error(`meta.expectedStats.${field} が不正です。`);
    }
  });
  const excludedBreakdown = expected.excludedBreakdown ?? {};
  const excludedBreakdownTotal = Object.values(excludedBreakdown).reduce((total, count) => total + Number(count || 0), 0);
  if (excludedBreakdownTotal !== Number(expected.excluded)) {
    throw new Error(`除外内訳の合計が期待除外件数と一致しません: ${excludedBreakdownTotal} / ${expected.excluded}`);
  }
  if (!Array.isArray(realproRooms) || realproRooms.length !== expected.total) {
    throw new Error(`リアプロ件数が期待値と一致しません: ${realproRooms?.length ?? "なし"} / ${expected.total}`);
  }
  const realproPageSummary = validateRealproPageCaptures(data?.realpro?.pageCaptures);
  validateRealproRawCount(data?.realpro?.rawText, realproRooms);
  const detailUnconfirmedCount = realproRooms.filter((room) => room.webAd === "判定不可").length;
  if (detailUnconfirmedCount !== Number(expected.detailUnconfirmedCsv)) {
    throw new Error(`詳細未確認CSVの期待件数が判定不可件数と一致しません: ${detailUnconfirmedCount} / ${expected.detailUnconfirmedCsv}`);
  }
  if (!Array.isArray(eSeikatsuRooms) || !eSeikatsuRooms.length) {
    throw new Error("いい生活データがありません。");
  }
  const eSeikatsuApiCount = validateESeikatsuApiCount(data?.eSeikatsu?.apiPageCaptures, eSeikatsuRooms);

  realproRooms.forEach((room, index) => {
    requiredRealproFields.forEach((field) => {
      if (room[field] === undefined || room[field] === "") {
        throw new Error(`リアプロ${index + 1}件目に ${field} がありません。`);
      }
    });
    validateSampleUrl(room.url, `リアプロ${index + 1}件目`, [realproHost]);
  });

  eSeikatsuRooms.forEach((room, index) => {
    requiredESeikatsuFields.forEach((field) => {
      if (room[field] === undefined || room[field] === "") {
        throw new Error(`いい生活${index + 1}件目に ${field} がありません。`);
      }
    });
    validateSampleUrl(room.url, `いい生活${index + 1}件目`, [eSeikatsuHost]);
  });

  return {
    capturedAt,
    realproCount: realproRooms.length,
    eSeikatsuCount: eSeikatsuRooms.length,
    eSeikatsuApiCount,
    realproPageSummary,
    expectedTotal: expected.total,
    expectedShown: expected.shown,
    expectedExcluded: expected.excluded,
    expectedDuplicated: expected.duplicated,
    expectedDetailUnconfirmedCsv: expected.detailUnconfirmedCsv,
    detailUnconfirmedCount,
    realproRawCount: extractRealproResultCount(data?.realpro?.rawText),
    excludedBreakdownCount: Object.keys(excludedBreakdown).length,
    excludedBreakdownTotal,
    excludedBreakdownText: formatExcludedBreakdownShort(excludedBreakdown),
    realproRequiredChecked: realproRooms.length,
    eSeikatsuRequiredChecked: eSeikatsuRooms.length,
    realproUrlChecked: realproRooms.length,
    eSeikatsuUrlChecked: eSeikatsuRooms.length,
    realproHost,
    eSeikatsuHost,
    ruleSummary,
  };
}

function validateESeikatsuApiCount(apiPageCaptures, eSeikatsuRooms) {
  if (!Array.isArray(apiPageCaptures) || !apiPageCaptures.length) {
    throw new Error("いい生活apiPageCapturesがありません。");
  }
  const totalCount = Number(apiPageCaptures[0]?.totalCount);
  const itemCountTotal = apiPageCaptures.reduce((total, page, index) => {
    const pageNumber = Number(page.pageNumber);
    const itemCount = Number(page.itemCount);
    const pageTotalCount = Number(page.totalCount);
    if (pageNumber !== index + 1) {
      throw new Error(`いい生活ページ番号が不正です: ${page.pageNumber} / 期待 ${index + 1}`);
    }
    if (!Number.isFinite(itemCount) || itemCount < 0) {
      throw new Error(`いい生活itemCountが不正です: ${page.itemCount}`);
    }
    if (!Number.isFinite(pageTotalCount) || pageTotalCount !== totalCount) {
      throw new Error(`いい生活totalCountがページ間で一致しません: ${page.totalCount} / 期待 ${totalCount}`);
    }
    return total + itemCount;
  }, 0);
  if (!Number.isFinite(totalCount) || totalCount <= 0) {
    throw new Error("いい生活totalCountが不正です。");
  }
  if (totalCount !== eSeikatsuRooms.length || itemCountTotal !== eSeikatsuRooms.length) {
    throw new Error(`いい生活API件数が実データと一致しません: total ${totalCount}件 / item ${itemCountTotal}件 / 実データ ${eSeikatsuRooms.length}件`);
  }
  return {
    total: totalCount,
    items: itemCountTotal,
    pages: apiPageCaptures.length,
  };
}

function validateRealproPageCaptures(pageCaptures) {
  if (!Array.isArray(pageCaptures) || !pageCaptures.length) {
    throw new Error("リアプロpageCapturesがありません。");
  }
  pageCaptures.forEach((page, index) => {
    if (Number(page.pageNumber) !== index + 1) {
      throw new Error(`リアプロページ番号が不正です: ${page.pageNumber} / 期待 ${index + 1}`);
    }
    if (!page.url || typeof page.url !== "string") {
      throw new Error(`リアプロ${index + 1}ページ目URLがありません。`);
    }
    if (!Number.isFinite(Number(page.lineCount)) || Number(page.lineCount) <= 0) {
      throw new Error(`リアプロ${index + 1}ページ目lineCountが不正です: ${page.lineCount}`);
    }
    if (!Number.isFinite(Number(page.textLength)) || Number(page.textLength) <= 0) {
      throw new Error(`リアプロ${index + 1}ページ目textLengthが不正です: ${page.textLength}`);
    }
  });
  return {
    pages: pageCaptures.length,
    lines: pageCaptures.reduce((total, page) => total + Number(page.lineCount), 0),
    textLength: pageCaptures.reduce((total, page) => total + Number(page.textLength), 0),
  };
}

function validateRealproRawCount(rawText, realproRooms) {
  const rawCount = extractRealproResultCount(rawText);
  if (!rawCount) {
    throw new Error("リアプロrawTextに棟数・戸数がありません。");
  }
  const buildingCount = new Set(realproRooms.map((room) => room.building)).size;
  if (rawCount.buildings !== buildingCount || rawCount.rooms !== realproRooms.length) {
    throw new Error(`リアプロrawText件数が実データと一致しません: raw ${rawCount.buildings}棟${rawCount.rooms}戸 / 実データ ${buildingCount}棟${realproRooms.length}戸`);
  }
}

function validateVerificationRules(rules) {
  const realproHost = rules?.hosts?.realpro;
  const eSeikatsuHost = rules?.hosts?.eSeikatsu;
  const requiredRealproFields = rules?.requiredFields?.realpro ?? [];
  const requiredESeikatsuFields = rules?.requiredFields?.eSeikatsu ?? [];

  validateRuleHost(realproHost, "リアプロ");
  validateRuleHost(eSeikatsuHost, "いい生活");
  validateRequiredFieldList(requiredRealproFields, "リアプロ");
  validateRequiredFieldList(requiredESeikatsuFields, "いい生活");

  return {
    realproHost,
    eSeikatsuHost,
    requiredRealproFields,
    requiredESeikatsuFields,
  };
}

function validateRuleHost(host, label) {
  if (!host || typeof host !== "string" || host.includes("/") || host.includes(":")) {
    throw new Error(`検証ルールの${label}ドメインが不正です。`);
  }
}

function validateRequiredFieldList(fields, label) {
  if (!Array.isArray(fields) || !fields.length) {
    throw new Error(`検証ルールの${label}必須項目がありません。`);
  }
  const unique = new Set(fields);
  if (unique.size !== fields.length || fields.some((field) => !field || typeof field !== "string")) {
    throw new Error(`検証ルールの${label}必須項目が不正です。`);
  }
}

function validateSampleUrl(value, label, allowedHosts = []) {
  try {
    const url = new URL(value);
    if (!["https:", "http:", "verification:"].includes(url.protocol)) {
      throw new Error("unsupported");
    }
    if (allowedHosts.length && !allowedHosts.includes(url.hostname)) {
      throw new Error("unexpected-host");
    }
  } catch {
    throw new Error(`${label}のURLが不正です。`);
  }
}

function formatExcludedBreakdownShort(breakdown) {
  return Object.entries(breakdown)
    .map(([type, count]) => `${type.replace("・除外", "").replace("除外", "")}${count}`)
    .join(" / ");
}

async function handleServerStatusCheck() {
  if (location.protocol === "file:") {
    importStatus.innerHTML = `現在 file:// で開いています。${serverModeLinkText("ローカルサーバー版")} を開いてください。`;
    return;
  }

  try {
    importStatus.textContent = "サーバーを確認しています...";
    const [sampleResponse, statusResponse] = await Promise.all([
      fetch(`/data/verification_sample.json?ts=${Date.now()}`),
      fetch(`/api/status?ts=${Date.now()}`),
    ]);
    if (!sampleResponse.ok) throw new Error(`サンプルJSON HTTP ${sampleResponse.status}`);
    if (!statusResponse.ok) throw new Error(`サーバー状態 HTTP ${statusResponse.status}`);
    const status = await statusResponse.json();
    if (status.csvSchemaVersion !== CSV_SCHEMA_VERSION) {
      importStatus.textContent = `サーバー確認はできましたが、画面とサーバーのCSV形式が違います。画面 ${CSV_SCHEMA_VERSION} / サーバー ${status.csvSchemaVersion || "不明"}。サーバーを再起動してから再読み込みしてください。`;
      importStatus.className = "import-status status-warn-inline";
      updateServerUrlStripStatus("warn", "CSV形式違い");
      return;
    }
    if (!status.docsAvailable) {
      importStatus.textContent = "サーバー確認はできましたが、ドキュメント配信を確認できませんでした。総合確認を使う場合はサーバーを再起動してください。";
      importStatus.className = "import-status status-warn-inline";
      updateServerUrlStripStatus("warn", "注意");
      return;
    }
    const environmentMessages = serverEnvironmentMessages(status);
    importStatus.textContent = [
      `サーバー確認OKです。Chrome取得、JSON読み込み、総合確認を使えます。CSV形式 ${CSV_SCHEMA_VERSION}。`,
      ...environmentMessages,
    ].join(" / ");
    importStatus.className = environmentMessages.some((message) => message.startsWith("注意"))
      ? "import-status status-warn-inline"
      : "import-status status-ok-inline";
    updateServerUrlStripStatus(environmentMessages.some((message) => message.startsWith("注意")) ? "warn" : "ok", environmentMessages.some((message) => message.startsWith("注意")) ? "注意" : "OK");
  } catch (error) {
    importStatus.textContent = `サーバー確認に失敗しました: ${error.message}`;
    importStatus.className = "import-status status-warn-inline";
    updateServerUrlStripStatus("warn", "確認失敗");
  }
}

function serverEnvironmentMessages(status) {
  const messages = [];
  if (status.nodeVersion) {
    messages.push(`Node.js v${status.nodeVersion}`);
  }
  if (status.requiredFilesAvailable === false) {
    const missingFiles = Array.isArray(status.missingFiles) ? status.missingFiles : [];
    messages.push(`注意: 必要ファイル不足 ${missingFiles.slice(0, 3).join("、") || "詳細不明"}`);
  } else if (status.requiredFilesAvailable === true) {
    messages.push("必要ファイルOK");
  }
  if (status.chrome?.available === false) {
    messages.push(`注意: Google Chrome ${status.chrome.detail || "未確認"}`);
  } else if (status.chrome?.available === true) {
    messages.push("Google Chrome OK");
  }
  if (status.python3?.available === false) {
    messages.push(`注意: Python3 ${status.python3.detail || "未確認"}`);
  } else if (status.python3?.available === true) {
    messages.push(`Python3 OK`);
  }
  if (status.chromeBridge?.available === false) {
    messages.push(`注意: Windows Chrome接続 ${status.chromeBridge.detail || "未確認"}`);
  } else if (status.chromeBridge?.available === true) {
    messages.push(`Windows Chrome接続 OK`);
  }
  return messages;
}

async function handleChromeCaptureRun() {
  syncOpsCapturePageInput();
  const realproPages = clampCapturePages(opsRealproCapturePages?.value || realproCapturePages?.value, 2, 200);
  const startPage = clampCapturePages(realproStartPage?.value, 1, 10000);
  const eSeikatsuPages = clampCapturePages(eSeikatsuCapturePages?.value, 2, 200);
  captureLastError = "";
  lastLiveCaptureProgress = null;

  try {
    updateWorkflowMonitor({
      state: "running",
      stage: "prepare",
      title: "Chromeタブを確認中",
      text: "リアプロの検索結果一覧と、いい生活の物件広告一覧が開いているか確認しています。",
      nextAction: "タブ確認中",
    });
    setCaptureRunning(true);
    importStatus.textContent = "Chromeタブを確認しています...";
    const tabStatus = await fetchChromeTabStatus();
    renderChromeTabStatus(tabStatus);
    syncListingOpenCheckFromTabStatus(tabStatus);
    saveChromeTabHistory(chromeTabHistoryEntry(tabStatus, "取得前自動確認"));
    if (!tabStatus.ok) {
      throw new Error(`${tabStatus.summary || "Chromeタブ確認がOKではありません。"}。Chromeタブ確認の結果を見て、リアプロ一覧と rent.e-bukken.app のいい生活画面を開いてください。`);
    }
    const tabUsageText = chromeTabUsageText(tabStatus);
    const readinessMessage = captureReadinessMessage();
    if (readinessMessage) {
      throw new Error(readinessMessage);
    }
    updateWorkflowMonitor({
      state: "running",
      stage: "list",
      title: "リアプロ一覧取得を開始",
      text: [`リアプロ${startPage}ページ目から${realproPages}ページ分を取得します。`, tabUsageText].filter(Boolean).join(" "),
      nextAction: "一覧ページを取得中",
    });
    importStatus.textContent = `Chromeから取得しています... リアプロ${startPage}ページ目から${realproPages}ページ / いい生活は全件キャッシュを使用${tabUsageText ? ` / ${tabUsageText}` : ""}`;
    const response = await fetch(`/api/capture?realproStartPage=${startPage}&realproPages=${realproPages}&eseikatsuPages=${eSeikatsuPages}&useESeikatsuCache=1&${captureCriteriaQueryParams()}&ts=${Date.now()}`);
    if (!response.ok) {
      const errorPayload = await readErrorResponse(response);
      throw new Error(errorPayload);
    }
    updateWorkflowMonitor({
      state: "running",
      stage: "compare",
      title: "いい生活と照合中",
      text: "リアプロで取得した号室を、いい生活の掲載状況と照合しています。",
      nextAction: "候補を整理中",
    });
    const result = await response.json();
    updateWorkflowMonitor({
      state: "running",
      stage: "candidates",
      title: "候補リストを整理中",
      text: "除外条件、同じ建物・同じ間取、差替候補を整理しています。",
      nextAction: "画面に反映中",
    });
    importCaptureData(result.data, result.filename ?? "data/chrome_capture.json");
    showCompletionToast(startPage > 1 ? "追加取得が完了しました" : "取得が完了しました");
  } catch (error) {
    const message = `Chrome取得に失敗しました: ${error.message}`;
    importStatus.textContent = message;
    showWorkflowProblem(message, currentWorkflowStage || "prepare");
  } finally {
    setCaptureRunning(false);
  }
}

function fastDetailTargetRoomIds() {
  const criteria = {
    ...collectCriteria(),
    equipment: [],
  };
  const sourceRealproRooms = importedRealproRooms.length ? importedRealproRooms : realproRooms;
  const sourceESeikatsuRooms = importedESeikatsuRooms.length ? importedESeikatsuRooms : eSeikatsuRooms;
  const eSeikatsuByKey = new Map(sourceESeikatsuRooms.map((room) => [roomKey(room), room]));

  return [...new Set(sourceRealproRooms
    .filter((room) => room.webAd === "判定不可")
    .filter((room) => matchesCriteria(room, criteria))
    .filter((room) => !(criteria.excludeNegotiating && /(商談中|審査中)/.test(room.status)))
    .filter((room) => {
      const eRoom = eSeikatsuByKey.get(roomKey(room));
      if (eRoom && isESeikatsuRecruiting(eRoom) && isESeikatsuListed(eRoom)) return false;
      return true;
    })
    .map((room) => String(room.realproRoomId || "").trim())
    .filter(Boolean))];
}

function formatElapsedTime(milliseconds = 0) {
  const totalSeconds = Math.max(0, Math.round(Number(milliseconds || 0) / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return minutes ? `${minutes}分${String(seconds).padStart(2, "0")}秒` : `${seconds}秒`;
}

function savePerformanceHistory(entry) {
  try {
    const history = JSON.parse(localStorage.getItem("capturePerformanceHistory") || "[]");
    const next = [entry, ...(Array.isArray(history) ? history : [])].slice(0, 10);
    localStorage.setItem("capturePerformanceHistory", JSON.stringify(next));
  } catch {
    // 時間比較履歴は補助情報なので、保存失敗時も取得処理は継続する。
  }
}

async function handleFastCaptureRun() {
  const realproPages = clampCapturePages(realproCapturePages?.value, 2, 200);
  const startPage = clampCapturePages(realproStartPage?.value, 1, 10000);
  const eSeikatsuPages = 1;
  const readinessMessage = captureReadinessMessage();
  if (readinessMessage) {
    importStatus.textContent = readinessMessage;
    return;
  }

  const totalStartedAt = Date.now();
  try {
    setCaptureRunning(true, "高速取得中...");
    importStatus.textContent = "Chromeタブを確認しています...";
    const tabStatus = await fetchChromeTabStatus();
    renderChromeTabStatus(tabStatus);
    syncListingOpenCheckFromTabStatus(tabStatus);
    saveChromeTabHistory(chromeTabHistoryEntry(tabStatus, "高速取得前自動確認"));
    if (!tabStatus.ok) {
      throw new Error(`${tabStatus.summary || "Chromeタブ確認がOKではありません。"}。リアプロ一覧といい生活物件広告一覧を開いてください。`);
    }
    const tabUsageText = chromeTabUsageText(tabStatus);

    importStatus.textContent = `高速取得 1/3: リアプロ一覧${startPage}ページ目から${realproPages}ページを取得しています...${tabUsageText ? ` / ${tabUsageText}` : ""}`;
    const listResponse = await fetch(`/api/capture?realproStartPage=${startPage}&realproPages=${realproPages}&eseikatsuPages=${eSeikatsuPages}&useESeikatsuCache=1&skipRealproDetails=1&${captureCriteriaQueryParams()}&ts=${Date.now()}`);
    if (!listResponse.ok) throw new Error(await readErrorResponse(listResponse));
    const listResult = await listResponse.json();
    importCaptureData(listResult.data, listResult.filename ?? "data/chrome_capture.json");

    const targetIds = fastDetailTargetRoomIds();
    const totalRealproRooms = importedRealproRooms.length;
    const skippedCount = Math.max(totalRealproRooms - targetIds.length, 0);
    if (!targetIds.length) {
      const elapsedMs = Date.now() - totalStartedAt;
      savePerformanceHistory({
        mode: "高速取得",
        completedAt: new Date().toISOString(),
        totalRooms: totalRealproRooms,
        detailTargets: 0,
        skippedDetails: skippedCount,
        elapsedMs,
      });
      resultSummary.textContent = `高速取得OK: 一覧${totalRealproRooms}件 / 詳細確認対象0件 / ${formatElapsedTime(elapsedMs)}`;
      showCompletionToast(startPage > 1 ? "追加取得が完了しました" : "取得が完了しました");
      return;
    }

    await runFastDetailPhase({
      targetIds,
      totalStartedAt,
      listElapsedMs: Number(listResult.timing?.elapsedMs || 0),
      progressPrefix: "高速取得",
    });
  } catch (error) {
    importStatus.textContent = `高速取得に失敗しました: ${error.message}`;
  } finally {
    setCaptureRunning(false);
  }
}

async function runFastDetailPhase({ targetIds, totalStartedAt, listElapsedMs = 0, progressPrefix = "高速取得" }) {
  const totalRealproRooms = importedRealproRooms.length;
  const skippedCount = Math.max(totalRealproRooms - targetIds.length, 0);
  const targetIdSet = new Set(targetIds);
  const skippedRoomIds = importedRealproRooms
    .filter((room) => room.webAd === "判定不可")
    .map((room) => String(room.realproRoomId || "").trim())
    .filter((roomId) => roomId && !targetIdSet.has(roomId));
  importStatus.textContent = `${progressPrefix}: 一覧${totalRealproRooms}件から候補外${skippedCount}件を先に除外。詳細${targetIds.length}件を確認しています...`;
  const detailStartedAt = Date.now();
  const detailResponse = await fetch("/api/realpro-detail-targets", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ roomIds: targetIds, skippedRoomIds }),
  });
  if (!detailResponse.ok) throw new Error(await readErrorResponse(detailResponse));
  let detailResult = await detailResponse.json();
  importCaptureData(detailResult.data, detailResult.filename ?? "data/chrome_capture.json");

  let remaining = detailUnconfirmedRooms(importedRealproRooms)
    .filter((room) => targetIds.includes(String(room.realproRoomId || "")));
  if (remaining.length) {
    const remainingIds = remaining.map((room) => String(room.realproRoomId || "")).filter(Boolean);
    importStatus.textContent = `${progressPrefix}: 詳細未確認${remainingIds.length}件だけを再取得しています...`;
    const retryResponse = await fetch("/api/realpro-detail-targets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ roomIds: remainingIds, skippedRoomIds }),
    });
    if (!retryResponse.ok) throw new Error(await readErrorResponse(retryResponse));
    detailResult = await retryResponse.json();
    importCaptureData(detailResult.data, detailResult.filename ?? "data/chrome_capture.json");
    remaining = detailUnconfirmedRooms(importedRealproRooms)
      .filter((room) => targetIds.includes(String(room.realproRoomId || "")));
  }

  const detailElapsedMs = Date.now() - detailStartedAt;
  const elapsedMs = Date.now() - totalStartedAt;
  savePerformanceHistory({
    mode: progressPrefix,
    completedAt: new Date().toISOString(),
    totalRooms: totalRealproRooms,
    detailTargets: targetIds.length,
    skippedDetails: skippedCount,
    remainingUnconfirmed: remaining.length,
    listElapsedMs,
    detailElapsedMs,
    elapsedMs,
  });
  resultSummary.textContent = `${progressPrefix}OK: 一覧${totalRealproRooms}件 / 詳細確認${targetIds.length}件 / 詳細省略${skippedCount}件 / 未確認${remaining.length}件 / 詳細${formatElapsedTime(detailElapsedMs)} / 合計${formatElapsedTime(elapsedMs)}`;
  showCompletionToast(progressPrefix.includes("追加") || progressPrefix.includes("再開") ? "追加取得が完了しました" : "取得が完了しました");
}

async function handleFastDetailResume() {
  if (!requireLoadedCaptureData("候補詳細の再開")) return;
  const targetIds = fastDetailTargetRoomIds();
  if (!targetIds.length) {
    importStatus.textContent = "現在の読み込みデータと検索条件では、詳細確認対象がありません。";
    return;
  }

  const startedAt = Date.now();
  try {
    setCaptureRunning(true, "詳細確認中...");
    await runFastDetailPhase({
      targetIds,
      totalStartedAt: startedAt,
      progressPrefix: "候補詳細再開",
    });
  } catch (error) {
    importStatus.textContent = `候補詳細の再開に失敗しました: ${error.message}`;
  } finally {
    setCaptureRunning(false);
  }
}

async function handleRealproChunkCaptureRun() {
  const pages = clampCapturePages(realproCapturePages?.value, 10, 20);
  let startPage = clampCapturePages(realproStartPage?.value, 1, 10000);
  const capturedPages = opsCapturedRealproPageNumbers();
  if (loadedCaptureMatchesCurrentCriteria() && capturedPages.has(startPage)) {
    startPage = opsFirstMissingRealproPage();
    if (realproStartPage) realproStartPage.value = String(startPage);
    updateOpsCaptureRangeSummary();
  }
  const requiredPages = realproRequiredPagesForOps();
  if (loadedCaptureMatchesCurrentCriteria() && requiredPages && startPage > requiredPages) {
    importStatus.textContent = "この検索条件のリアプロページは全て取得済みです。条件を変えるか、リセットしてから再取得してください。";
    setOpsText("opsProgressTitle", "全ページ取得済みです");
    setOpsText("opsProgressMessage", "追加で取得するページはありません。候補一覧を確認できます。");
    scrollToOpsProgress();
    return;
  }
  const readinessMessage = captureReadinessMessage();

  if (readinessMessage) {
    importStatus.textContent = readinessMessage;
    return;
  }

  try {
    setCaptureRunning(true, "分割取得中...");
    importStatus.textContent = "Chromeタブを確認しています...";
    const tabStatus = await fetchChromeTabStatus();
    renderChromeTabStatus(tabStatus);
    syncListingOpenCheckFromTabStatus(tabStatus);
    saveChromeTabHistory(chromeTabHistoryEntry(tabStatus, "分割取得前自動確認"));
    if (!tabStatus.ok) {
      throw new Error(`${tabStatus.summary || "Chromeタブ確認がOKではありません。"}。Chromeタブ確認の結果を見て、リアプロ一覧と rent.e-bukken.app のいい生活画面を開いてください。`);
    }
    const tabUsageText = chromeTabUsageText(tabStatus);

    importStatus.textContent = `リアプロ分割取得中... ${startPage}ページ目から${pages}ページ / いい生活は全件キャッシュを使用${tabUsageText ? ` / ${tabUsageText}` : ""}`;
    const response = await fetch(`/api/realpro-chunk?startPage=${startPage}&pages=${pages}&useESeikatsuCache=1&${captureCriteriaQueryParams()}&ts=${Date.now()}`);
    if (!response.ok) {
      const errorPayload = await readErrorResponse(response);
      throw new Error(errorPayload);
    }
    const result = await response.json();
    importCaptureData(result.data, result.filename ?? "data/chrome_capture.json");

    const cache = result.realproChunkCache || {};
    if (realproStartPage) realproStartPage.value = String(startPage + pages);
    saveSearchConditions();
    renderCapturePlan();
    importStatus.textContent = `リアプロ分割取得OK: 今回${cache.latestFetchedRooms ?? "不明"}戸 / 累積${cache.accumulatedRooms ?? "不明"}戸 / ${cache.accumulatedPages ?? "不明"}ページ。次は${startPage + pages}ページ目から取得します。`;
    showCompletionToast(startPage > 1 ? "追加取得が完了しました" : "取得が完了しました");
  } catch (error) {
    importStatus.textContent = `リアプロ分割取得に失敗しました: ${error.message}`;
  } finally {
    setCaptureRunning(false);
  }
}

async function handleZeroRoomPagesRetry() {
  if (!retryZeroRoomPages) return;
  if (!requireLoadedCaptureData("0件ページ再取得")) return;
  const zeroPages = realproZeroRoomPages(currentImportMeta?.realproPages ?? []);
  if (!zeroPages.length) {
    resultSummary.textContent = "0件ページ再取得: DOM取得戸数0件のリアプロページはありません。";
    return;
  }

  const readinessMessage = captureReadinessMessage();
  if (readinessMessage) {
    importStatus.textContent = readinessMessage;
    return;
  }

  try {
    setCaptureRunning(true, "0件ページ再取得中...");
    importStatus.textContent = "Chromeタブを確認しています...";
    const tabStatus = await fetchChromeTabStatus();
    renderChromeTabStatus(tabStatus);
    syncListingOpenCheckFromTabStatus(tabStatus);
    saveChromeTabHistory(chromeTabHistoryEntry(tabStatus, "0件ページ再取得前自動確認"));
    if (!tabStatus.ok) {
      throw new Error(`${tabStatus.summary || "Chromeタブ確認がOKではありません。"}。Chromeタブ確認の結果を見て、リアプロ一覧と rent.e-bukken.app のいい生活画面を開いてください。`);
    }

    let latestResult = null;
    for (let index = 0; index < zeroPages.length; index += 1) {
      const page = zeroPages[index];
      if (realproStartPage) realproStartPage.value = String(page);
      if (realproCapturePages) realproCapturePages.value = "1";
      renderCapturePlan();
      importStatus.textContent = `0件ページ再取得中... ${page}ページ (${index + 1}/${zeroPages.length})`;
      const response = await fetch(`/api/realpro-chunk?startPage=${page}&pages=1&reset=0&useESeikatsuCache=1&${captureCriteriaQueryParams()}&ts=${Date.now()}`);
      if (!response.ok) {
        const errorPayload = await readErrorResponse(response);
        throw new Error(errorPayload);
      }
      latestResult = await response.json();
      importCaptureData(latestResult.data, latestResult.filename ?? "data/chrome_capture.json");
      const remaining = realproZeroRoomPages(currentImportMeta?.realproPages ?? []);
      if (!remaining.includes(page)) {
        importStatus.textContent = `0件ページ再取得: ${page}ページを更新しました。残り${remaining.length}ページ。`;
      }
    }

    const remaining = realproZeroRoomPages(currentImportMeta?.realproPages ?? []);
    saveSearchConditions();
    renderCapturePlan();
    resultSummary.textContent = remaining.length
      ? `0件ページ再取得後も残りがあります: ${formatNumberList(remaining)}ページ。リアプロ画面を確認してください。`
      : "0件ページ再取得OKです。候補一覧を確認できます。";
  } catch (error) {
    importStatus.textContent = `0件ページ再取得に失敗しました: ${error.message}`;
  } finally {
    setCaptureRunning(false);
  }
}

async function handleExtensionChromeTabsCheck() {
  if (!chromeTabStatus) return;
  captureLastError = "";
  updateWorkflowMonitor({
    state: "running",
    stage: "prepare",
    title: "Chrome拡張で準備確認中",
    text: "拡張機能からリアプロ一覧タブといい生活画面を確認しています。",
    nextAction: "拡張機能確認中",
  });
  chromeTabStatus.hidden = false;
  chromeTabStatus.className = "chrome-tab-status status-warn-inline";
  chromeTabStatus.textContent = "Chrome拡張でタブを確認しています...";

  try {
    const status = await requestExtensionTabStatus();
    renderChromeTabStatus(status);
    syncListingOpenCheckFromTabStatus(status);
    saveChromeTabHistory(chromeTabHistoryEntry(status, "拡張機能確認"));
    await handleExtensionStatusCheck();
    updateWorkflowMonitor({
      state: status.ok ? "ready-ok" : "error",
      stage: "prepare",
      title: status.ok ? "準備OK" : "必要なタブが見つかりません",
      text: status.summary || (status.ok ? "リアプロといい生活の準備ができています。" : "リアプロ一覧といい生活画面を開いてください。"),
      nextAction: status.ok ? "リアプロを取得" : "タブを開いて再確認",
    });
    if (!status.ok) captureLastError = status.summary || "必要なタブが見つかりません。";
    renderReadinessStatus();
    renderOpsDashboard();
  } catch (error) {
    const message = `Chrome拡張のタブ確認に失敗しました: ${error.message}`;
    chromeTabStatus.className = "chrome-tab-status status-warn-inline";
    chromeTabStatus.textContent = message;
    showWorkflowProblem(message, "prepare");
    saveChromeTabHistory({
      checkedAt: new Date().toISOString(),
      status: "注意",
      sourceLabel: "拡張機能確認",
      summary: message,
      realproList: "-",
      eSeikatsuList: "-",
      realproDetails: "0",
    });
  }
}

async function handleChromeTabsCheck() {
  if (!document.body.classList.contains("maintenance-mode")) {
    await handleExtensionChromeTabsCheck();
    return;
  }

  if (!chromeTabStatus) return;
  captureLastError = "";
  updateWorkflowMonitor({
    state: "running",
    stage: "prepare",
    title: "Chromeタブを確認中",
    text: "リアプロの検索結果一覧と、いい生活の物件広告一覧が開いているか確認しています。",
    nextAction: "タブ確認中",
  });
  chromeTabStatus.hidden = false;
  chromeTabStatus.className = "chrome-tab-status status-warn-inline";
  chromeTabStatus.textContent = "Chromeタブを確認しています...";

  try {
    const status = await fetchChromeTabStatus();
    renderChromeTabStatus(status);
    syncListingOpenCheckFromTabStatus(status);
    saveChromeTabHistory(chromeTabHistoryEntry(status, "手動確認"));
    updateWorkflowMonitor({
      state: status.ok ? "ready-ok" : "error",
      stage: "prepare",
      title: status.ok ? "準備OK" : "必要なタブが見つかりません",
      text: status.summary || (status.ok ? "リアプロといい生活の準備ができています。" : "リアプロ一覧といい生活の物件広告一覧を開いてください。"),
      nextAction: status.ok ? "リアプロを取得" : "タブを開いて再確認",
    });
    if (!status.ok) captureLastError = status.summary || "必要なタブが見つかりません。";
  } catch (error) {
    chromeTabStatus.className = "chrome-tab-status status-warn-inline";
    chromeTabStatus.textContent = `Chromeタブ確認に失敗しました: ${error.message}`;
    showWorkflowProblem(`Chromeタブ確認に失敗しました: ${error.message}`, "prepare");
    saveChromeTabHistory({
      checkedAt: new Date().toISOString(),
      status: "注意",
      sourceLabel: "手動確認",
      summary: `Chromeタブ確認に失敗: ${error.message}`,
      realproList: "-",
      eSeikatsuList: "-",
      realproDetails: "0",
    });
  }
}

async function fetchChromeTabStatus() {
  const response = await fetch(`/api/chrome-tabs?ts=${Date.now()}`);
  if (!response.ok) {
    const errorPayload = await readErrorResponse(response);
    throw new Error(errorPayload);
  }
  return response.json();
}

function renderChromeTabStatus(status) {
  if (!chromeTabStatus) return;
  lastChromeTabStatus = status || null;
  renderOpsTabTargets(lastChromeTabStatus);
  const tabs = Array.isArray(status.tabs) ? status.tabs : [];
  chromeTabStatus.hidden = false;
  chromeTabStatus.className = `chrome-tab-status ${status.ok ? "status-ok-inline" : "status-warn-inline"}`;
  chromeTabStatus.innerHTML = `
    <strong>${escapeHtml(status.summary || (status.ok ? "OK" : "注意"))}</strong>
    <div class="chrome-tab-list">
      ${tabs.map((tab) => `
        <span class="chrome-tab-pill ${chromeTabKindClass(tab.kind)}">
          ${escapeHtml(`${tab.index}. ${tab.kind}`)}
          ${tab.host ? ` / ${escapeHtml(tab.host)}` : ""}
          ${tab.title ? ` / ${escapeHtml(tab.title)}` : ""}
        </span>
      `).join("")}
    </div>
  `;
}

function chromeTabUsageText(status = lastChromeTabStatus) {
  if (!status?.realproList && !status?.eSeikatsuList) return "";
  const realproText = status.realproList ? `リアプロ${status.realproList.index}番` : "リアプロ未確認";
  const eSeikatsuText = status.eSeikatsuList ? `いい生活${status.eSeikatsuList.index}番` : "いい生活未確認";
  return `使用タブ: ${realproText} / ${eSeikatsuText}`;
}

function renderOpsTabTargets(status = lastChromeTabStatus) {
  renderOpsTabTarget(
    opsRealproTabTarget,
    status?.realproList,
    "リアプロで使うタブ",
    "リスト検索結果を確認します",
  );
  renderOpsTabTarget(
    opsESeikatsuTabTarget,
    status?.eSeikatsuList,
    "いい生活で使うタブ",
    "物件広告一覧を確認します",
  );
}

function renderOpsTabTarget(node, tab, label, fallbackText) {
  if (!node) return;
  node.classList.toggle("is-ok", Boolean(tab));
  node.classList.toggle("is-warn", !tab);
  const labelNode = node.querySelector("span");
  const strongNode = node.querySelector("strong");
  const smallNode = node.querySelector("small");
  if (labelNode) labelNode.textContent = label;
  if (strongNode) strongNode.textContent = tab ? `${tab.index}番タブ` : "未確認";
  if (smallNode) {
    smallNode.textContent = tab
      ? `${tab.kind || "対象タブ"} / ${tab.title || tab.host || "Chrome"}`
      : fallbackText;
  }
}

function syncListingOpenCheckFromTabStatus(status) {
  const realproOpen = Boolean(status?.realproList);
  const eSeikatsuOpen = Boolean(status?.eSeikatsuList);
  if (realproLoggedIn) {
    realproLoggedIn.checked = realproOpen;
    localStorage.setItem("realproLoggedIn", String(realproOpen));
  }
  if (eSeikatsuLoggedIn) {
    eSeikatsuLoggedIn.checked = eSeikatsuOpen;
    localStorage.setItem("eSeikatsuLoggedIn", String(eSeikatsuOpen));
  }
  if (eSeikatsuListingOpen) {
    eSeikatsuListingOpen.checked = eSeikatsuOpen;
    localStorage.setItem("eSeikatsuListingOpen", String(eSeikatsuOpen));
  }
  renderReadinessStatus();
}

function chromeTabHistoryEntry(status, sourceLabel) {
  return {
    checkedAt: new Date().toISOString(),
    status: status.ok ? "OK" : "注意",
    sourceLabel,
    summary: status.summary || (status.ok ? "OK" : "注意"),
    realproList: status.realproList ? `${status.realproList.index}番 ${status.realproList.kind}` : "-",
    eSeikatsuList: status.eSeikatsuList ? `${status.eSeikatsuList.index}番 ${status.eSeikatsuList.kind}` : "-",
    realproDetails: Array.isArray(status.realproDetails) ? String(status.realproDetails.length) : "0",
  };
}

function chromeTabKindClass(kind) {
  if (kind === "リアプロ一覧" || kind === "いい生活 物件一覧/広告") return "chrome-tab-pill-ok";
  if (kind === "リアプロ詳細") return "chrome-tab-pill-detail";
  if (String(kind || "").includes("対象外")) return "chrome-tab-pill-warn";
  return "";
}

async function readErrorResponse(response) {
  const contentType = response.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) {
    const payload = await response.json();
    return [payload.error, payload.detail].filter(Boolean).join(" ");
  }
  return response.text();
}

const workflowStageOrder = ["prepare", "list", "details", "compare", "candidates", "done"];

function updateWorkflowMonitor({
  state = "ready",
  stage = "prepare",
  title = "検索条件を決める",
  text = "沿線・駅、間取、賃料、設備を選び、リアプロへ反映して件数を確認してから取得します。",
  nextAction = "条件を入力",
} = {}) {
  currentWorkflowStage = stage;
  if (workflowMonitor) workflowMonitor.dataset.state = state;
  if (workflowCurrentTitle) workflowCurrentTitle.textContent = title;
  if (workflowCurrentText) workflowCurrentText.textContent = text;
  if (workflowNextAction) workflowNextAction.textContent = nextAction;

  const activeIndex = Math.max(workflowStageOrder.indexOf(stage), 0);
  workflowStageOrder.forEach((stageName, index) => {
    const item = workflowStages[stageName];
    if (!item) return;
    let stageState = index < activeIndex ? "done" : (index === activeIndex ? "active" : "waiting");
    if (state === "error" && index === activeIndex) stageState = "error";
    if (state === "complete") stageState = "done";
    item.dataset.state = stageState;
  });
}

function showWorkflowProblem(message, stage = currentWorkflowStage || "prepare") {
  captureLastError = message;
  updateWorkflowMonitor({
    state: "error",
    stage,
    title: "処理が止まっています",
    text: message,
    nextAction: "表示内容を直して再実行",
  });
  if (workflowReady && workflowRunning && workflowComplete) {
    workflowReady.hidden = false;
    workflowRunning.hidden = true;
    workflowComplete.hidden = true;
  }
  renderOpsProblem(message, stage);
}

function progressTimeText(milliseconds = 0) {
  const totalSeconds = Math.max(0, Math.round(Number(milliseconds || 0) / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

function progressUpdatedAtText(value) {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "-";
  return date.toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function liveProgressPhaseText(progress = {}) {
  const phase = progress.phase || "idle";
  const currentPage = Number(progress.currentPage || 0);
  const totalPages = Number(progress.totalPages || 0);
  const startPage = Number(progress.startPage || 1);
  const currentDetails = Number(progress.currentDetails || 0);
  const totalDetails = Number(progress.totalDetails || 0);
  const realproRooms = Number(progress.realproRooms || (!["compare", "saving"].includes(phase) ? progress.rooms : 0) || totalDetails || 0);
  const eSeikatsuRows = Number(progress.eSeikatsuRows || (phase === "compare" ? progress.rooms : 0) || 0);
  const currentRealproPage = currentPage ? startPage + currentPage - 1 : startPage;

  if (phase === "list") {
    return {
      operation: "リアプロ一覧を取得",
      position: totalPages ? `${currentRealproPage}ページ目 / ${totalPages}ページ` : "ページ確認中",
      check: realproRooms ? `一覧から${realproRooms}戸を取得済み` : "建物・号室・家賃を取得中",
      page: totalPages ? `${currentPage || 0}/${totalPages}ページ` : "ページ確認中",
      eSeikatsu: "確認中",
    };
  }
  if (phase === "details") {
    return {
      operation: "リアプロ詳細を確認",
      position: totalDetails ? `${currentDetails} / ${totalDetails}戸` : "詳細確認中",
      check: "WEB広告掲載可否・電子入居申込を確認中",
      page: "一覧取得済み",
      eSeikatsu: "照合前",
    };
  }
  if (phase === "compare") {
    return {
      operation: "いい生活と照合",
      position: totalPages ? `いい生活 ${currentPage || 0} / ${totalPages}ページ` : "いい生活確認中",
      check: "同一号室・同間取掲載状況を確認中",
      page: "リアプロ完了",
      eSeikatsu: eSeikatsuRows ? `${eSeikatsuRows}件` : "全件確認中",
    };
  }
  if (phase === "saving") {
    return {
      operation: "取得結果を保存",
      position: "最終整理中",
      check: "候補CSV用データへ反映中",
      page: "リアプロ完了",
      eSeikatsu: eSeikatsuRows ? `${eSeikatsuRows}件` : formatOpsESeikatsuStatus(),
    };
  }
  if (phase === "complete") {
    return {
      operation: "候補判定完了",
      position: "完了",
      check: "作業表へ反映済み",
      page: "完了",
      eSeikatsu: eSeikatsuRows ? `${eSeikatsuRows}件` : formatOpsESeikatsuStatus(),
    };
  }
  if (phase === "error") {
    return {
      operation: "処理停止",
      position: "エラー",
      check: progress.message || "取得内容を確認してください",
      page: "-",
      eSeikatsu: formatOpsESeikatsuStatus(),
    };
  }
  return {
    operation: "取得準備中",
    position: "-",
    check: "Chromeタブを確認中",
    page: "-",
    eSeikatsu: formatOpsESeikatsuStatus(),
  };
}

function liveProgressPercentage(progress = {}) {
  const phase = progress.phase || "idle";
  if (phase === "saving") return 98;
  if (phase === "complete") return 100;
  if (phase === "error") return 100;
  const current = Number(phase === "details" ? progress.currentDetails : progress.currentPage) || 0;
  const total = Number(phase === "details" ? progress.totalDetails : progress.totalPages) || 0;
  return total ? Math.min(Math.max((current / total) * 100, 3), 100) : 3;
}

function renderLiveCaptureProgress(progress = {}) {
  lastLiveCaptureProgress = progress || null;
  const isDetails = progress.phase === "details";
  const isCompare = progress.phase === "compare";
  const isSaving = progress.phase === "saving";
  const isComplete = progress.phase === "complete";
  const current = Number(isDetails ? progress.currentDetails : progress.currentPage) || 0;
  const total = Number(isDetails ? progress.totalDetails : progress.totalPages) || 0;
  const percentage = liveProgressPercentage(progress);
  const phaseText = liveProgressPhaseText(progress);
  const realproRooms = Number(progress.realproRooms || (!isCompare && !isSaving ? progress.rooms : 0) || progress.totalDetails || 0);
  const eSeikatsuRows = Number(progress.eSeikatsuRows || (isCompare ? progress.rooms : 0) || 0);
  const judged = Number(progress.judged || (isDetails ? current : 0) || 0);
  const candidates = Number(progress.candidates || 0);
  updateWorkflowMonitor({
    state: "running",
    stage: isComplete ? "done" : (isSaving ? "candidates" : (isCompare ? "compare" : (isDetails ? "details" : "list"))),
    title: progress.label || (isSaving ? "取得結果を保存中" : (isCompare ? "いい生活と照合中" : (isDetails ? "リアプロ詳細を確認中" : "リアプロ一覧を取得中"))),
    text: progress.message || "取得処理を開始しています。",
    nextAction: isSaving ? "作業表へ反映中" : (isCompare ? "いい生活全件を取得中" : (isDetails ? "WEB広告・申込状況を確認中" : "一覧ページを取得中")),
  });
  if (workflowRunningTitle) workflowRunningTitle.textContent = progress.label || phaseText.operation;
  if (workflowRunningMessage) workflowRunningMessage.textContent = progress.message || "取得処理を開始しています...";
  if (workflowElapsedTime) workflowElapsedTime.textContent = progressTimeText(progress.elapsedMs);
  if (workflowProgressBar) workflowProgressBar.style.width = `${percentage}%`;
  if (workflowPageProgress) {
    if (isCompare) {
      workflowPageProgress.textContent = progress.totalPages ? `いい生活 ${current} / ${total}ページ` : "いい生活確認中";
    } else if (isDetails) {
      workflowPageProgress.textContent = "一覧取得完了";
    } else {
      const startPage = Number(progress.startPage || 1);
      const pageNumber = current ? startPage + current - 1 : startPage;
      workflowPageProgress.textContent = progress.totalPages ? `${pageNumber}ページ目 / ${progress.totalPages}ページ` : "確認中";
    }
  }
  if (workflowRoomProgress) workflowRoomProgress.textContent = isCompare && eSeikatsuRows ? `いい生活 ${eSeikatsuRows}件` : `${realproRooms || Number(progress.rooms || 0)}戸`;
  if (workflowJudgedProgress) workflowJudgedProgress.textContent = `${judged}戸`;
  if (workflowCandidateProgress) workflowCandidateProgress.textContent = `${candidates}件`;
  if (workflowRemainingTime) {
    workflowRemainingTime.textContent = progress.remainingMs > 0
      ? `約${progressTimeText(progress.remainingMs)}`
      : (progress.status === "complete" ? "完了" : (total && current >= total ? "まもなく完了" : "計算中"));
  }
  document.querySelector(".ops-progress-panel")?.classList.toggle("is-running", (captureIsRunning || eSeikatsuReviewRunning) && !isComplete);
  setOpsText("opsTopbarState", isSaving ? "作業表反映中" : (isCompare ? "いい生活照合中" : (isDetails ? "詳細確認中" : "リアプロ取得中")));
  setOpsText("opsProgressState", isSaving ? "保存中" : (isCompare ? "照合中" : (isDetails ? "詳細確認中" : "取得中")));
  setOpsText("opsProgressTitle", progress.label || phaseText.operation);
  setOpsText("opsMetricPages", phaseText.page);
  setOpsText("opsMetricRealpro", realproRooms ? `${realproRooms}戸` : "確認中");
  setOpsText("opsMetricJudged", isDetails ? `${judged} / ${total || realproRooms || 0}` : (judged ? `${judged}戸` : "0 / 0"));
  setOpsText("opsMetricCandidates", `${candidates}件`);
  setOpsText("opsMetricESeikatsu", phaseText.eSeikatsu);
  setOpsText("opsTimeLabel", "残り目安");
  setOpsText("opsRemainingTime", progress.remainingMs > 0 ? `約${progressTimeText(progress.remainingMs)}` : (isComplete ? "完了" : "計算中"));
  setOpsText("opsCurrentOperation", phaseText.operation);
  setOpsText("opsCurrentPosition", phaseText.position);
  setOpsText("opsCurrentCheck", phaseText.check);
  setOpsText("opsProgressUpdatedAt", progressUpdatedAtText(progress.updatedAt));
  const chromeFocusNote = isComplete || progress.phase === "error"
    ? ""
    : captureProgressSource === "extension"
    ? "拡張機能で裏側取得中です。Chromeは別作業に使えます。リアプロタブは閉じないでください。"
    : "取得中はChromeがリアプロ/いい生活タブへ自動で切り替わることがあります。完了後に元のタブへ戻します。";
  setOpsText("opsProgressMessage", [progress.message || "取得処理を開始しています...", chromeFocusNote].filter(Boolean).join(" "));
  const opsBar = document.getElementById("opsProgressBar");
  if (opsBar) opsBar.style.width = `${percentage}%`;
}

function stopCaptureProgressPolling() {
  if (captureProgressTimer) window.clearTimeout(captureProgressTimer);
  captureProgressTimer = 0;
}

async function pollCaptureProgress() {
  if (!captureIsRunning) return;
  if (captureProgressSource === "extension") return;
  try {
    const response = await fetch(`/api/capture-progress?ts=${Date.now()}`);
    if (response.ok) renderLiveCaptureProgress(await response.json());
  } catch {
    // 取得本体を止めず、次のポーリングで回復を試す。
  }
  if (captureIsRunning) captureProgressTimer = window.setTimeout(pollCaptureProgress, 700);
}

function startCaptureProgressPolling() {
  stopCaptureProgressPolling();
  renderLiveCaptureProgress({});
  if (captureProgressSource === "extension") return;
  pollCaptureProgress();
}

function setCaptureRunning(isRunning, label = "取得中...") {
  captureIsRunning = isRunning;
  if (isRunning) startCaptureProgressPolling();
  else {
    stopCaptureProgressPolling();
    captureProgressSource = "";
    document.querySelector(".ops-progress-panel")?.classList.remove("is-running");
  }
  if (workflowReady && workflowRunning && workflowComplete) {
    if (isRunning) {
      workflowReady.hidden = true;
      workflowRunning.hidden = false;
      workflowComplete.hidden = true;
    } else if (captureLastError) {
      workflowReady.hidden = false;
      workflowRunning.hidden = true;
      workflowComplete.hidden = true;
    } else if (hasLoadedCaptureData) {
      renderWorkflowComplete();
    } else {
      workflowReady.hidden = false;
      workflowRunning.hidden = true;
      workflowComplete.hidden = true;
    }
  }
  if (runChromeCaptureButton) {
    runChromeCaptureButton.disabled = isRunning;
    runChromeCaptureButton.textContent = isRunning ? label : "リアプロを取得して候補作成";
  }
  if (runFastCaptureButton) {
    runFastCaptureButton.disabled = isRunning;
    runFastCaptureButton.textContent = isRunning ? label : "高速取得して候補作成";
  }
  if (resumeFastDetailsButton) {
    resumeFastDetailsButton.disabled = isRunning;
    resumeFastDetailsButton.textContent = isRunning ? label : "候補詳細のみ再開";
  }
  if (runRealproChunkCaptureButton) {
    runRealproChunkCaptureButton.disabled = isRunning;
    runRealproChunkCaptureButton.textContent = isRunning ? label : "Macバックアップ取得で追加";
  }
  if (retryZeroRoomPages) {
    retryZeroRoomPages.disabled = isRunning;
    retryZeroRoomPages.textContent = isRunning ? label : "0件ページを再取得";
  }
  const opsApplyButton = document.querySelector("#opsApplyConditions");
  const opsRunButton = document.querySelector("#opsRunCapture");
  if (opsApplyButton) opsApplyButton.disabled = isRunning;
  if (opsRunButton) {
    opsRunButton.disabled = isRunning;
    opsRunButton.textContent = isRunning ? label : "リアプロを取得して候補作成";
  }
  if (!isRunning) renderOpsDashboard();
}

function clampCapturePages(value, fallback, max = 10) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(Math.max(Math.trunc(number), 1), max);
}

function syncOpsCapturePageInput(source = null) {
  if (!opsRealproCapturePages || !realproCapturePages) return;
  const sourceValue = source === realproCapturePages
    ? realproCapturePages.value
    : opsRealproCapturePages.value;
  const pages = clampCapturePages(sourceValue, 2, 200);
  opsRealproCapturePages.value = String(pages);
  realproCapturePages.value = String(pages);
}

async function fetchLatestCapture() {
  const filenames = ["extension_capture.json", "chrome_capture.json", "capture.json"];

  for (const filename of filenames) {
    const response = await fetch(`/data/${filename}?ts=${Date.now()}`);
    if (response.ok) {
      return { filename: `data/${filename}`, data: await response.json() };
    }
  }

  throw new Error("data/chrome_capture.json または data/capture.json を取得できませんでした。npm startで起動しているか確認してください。");
}

function captureESeikatsuRoomCount(data = {}) {
  const candidates = [
    data?.eSeikatsu?.rooms,
    data?.eSeikatsuRooms,
    data?.rooms?.eSeikatsu,
  ];
  const rooms = candidates.find((value) => Array.isArray(value));
  return rooms ? rooms.length : 0;
}

function latestCaptureNeedsESeikatsuMerge(data = {}) {
  const cache = data?.eSeikatsuCache;
  return !(cache?.used && cache?.meta?.isFull && captureESeikatsuRoomCount(data) > 0);
}

async function mergeLatestCaptureWithESeikatsuCacheIfNeeded(result) {
  if (location.protocol === "file:" || !latestCaptureNeedsESeikatsuMerge(result?.data)) return result;
  try {
    const response = await fetch(`/api/merge-eseikatsu-cache?ts=${Date.now()}`);
    if (!response.ok) return result;
    const merged = await response.json();
    if (merged?.data && merged?.eSeikatsuCache?.used) {
      return {
        filename: merged.filename || result.filename,
        data: merged.data,
      };
    }
  } catch {
    // 保存済みキャッシュが使えない場合は、元の最新取得JSONをそのまま読み込む。
  }
  return result;
}

function clearESeikatsuReviewPoll() {
  if (eSeikatsuReviewPollTimer) window.clearTimeout(eSeikatsuReviewPollTimer);
  eSeikatsuReviewPollTimer = 0;
}

function cancelESeikatsuReview() {
  eSeikatsuReviewGeneration += 1;
  eSeikatsuReviewAbortController?.abort();
  eSeikatsuReviewAbortController = null;
  eSeikatsuReviewRunning = false;
  clearESeikatsuReviewPoll();
  document.querySelector(".ops-progress-panel")?.classList.remove("is-running");
}

async function pollESeikatsuReviewProgress() {
  if (!eSeikatsuReviewRunning) return;
  try {
    const response = await fetch(`/api/capture-progress?ts=${Date.now()}`);
    if (response.ok) {
      const progress = await response.json();
      const current = Number(progress.eSeikatsuCurrentPage || (progress.phase === "compare" ? progress.currentPage : 0) || 0);
      const total = Number(progress.eSeikatsuTotalPages || (progress.phase === "compare" ? progress.totalPages : 0) || 0);
      renderLiveCaptureProgress({
        ...progress,
        phase: "compare",
        status: "running",
        label: "いい生活全件照合中",
        currentPage: current,
        totalPages: total,
        eSeikatsuRows: Number(progress.eSeikatsuRows || 0),
        message: total
          ? `いい生活全件を確認中です。${current}/${total}ページ`
          : "いい生活全件の確認を開始しています...",
      });
    }
  } catch {
    // 照合本体を止めず、次のポーリングで画面更新を再試行する。
  }
  if (eSeikatsuReviewRunning) {
    eSeikatsuReviewPollTimer = window.setTimeout(() => void pollESeikatsuReviewProgress(), 1000);
  }
}

function startESeikatsuReview() {
  if (location.protocol === "file:" || eSeikatsuReviewPromise) return eSeikatsuReviewPromise;

  const reviewGeneration = ++eSeikatsuReviewGeneration;
  eSeikatsuReviewAbortController = new AbortController();
  const requestOptions = { signal: eSeikatsuReviewAbortController.signal };
  eSeikatsuReviewRunning = true;
  document.querySelector(".ops-progress-panel")?.classList.add("is-running");
  renderLiveCaptureProgress({
    phase: "compare",
    status: "running",
    label: "いい生活全件照合中",
    currentPage: 0,
    totalPages: 0,
    eSeikatsuRows: 0,
    message: "いい生活全件の確認を開始しています...",
    updatedAt: new Date().toISOString(),
  });
  void pollESeikatsuReviewProgress();

  eSeikatsuReviewPromise = (async () => {
    // 件数が変わった場合は、保存済みキャッシュを使わず現在件数で全件を作り直す。
    const totalResponse = await fetch(`/api/eseikatsu-total?ts=${Date.now()}`, requestOptions);
    if (!totalResponse.ok) {
      throw new Error(await readErrorResponse(totalResponse));
    }
    const totalStatus = await totalResponse.json();
    const totalCount = Number(totalStatus.totalCount || 0);
    const pages = Math.min(Math.max(totalCount ? Math.ceil(totalCount / 100) : Number(totalStatus.requiredPages || 0), 1), 200);
    if (!pages) {
      throw new Error(totalStatus.summary || "いい生活全件の必要ページ数を確認できませんでした。");
    }
    renderLiveCaptureProgress({
      phase: "compare",
      status: "running",
      label: "いい生活全件確認中",
      currentPage: 0,
      totalPages: pages,
      eSeikatsuCurrentPage: 0,
      eSeikatsuTotalPages: pages,
      eSeikatsuRows: 0,
      message: `いい生活全件を確認中です。0/${pages}ページ`,
      updatedAt: new Date().toISOString(),
    });
    const response = await fetch(`/api/eseikatsu-cache?pages=${pages}&pageSize=100&concurrency=5&ts=${Date.now()}`, requestOptions);
    if (!response.ok) {
      throw new Error(await readErrorResponse(response));
    }
    const result = await response.json();
    if (!result?.eSeikatsuCache?.used || !result?.data) {
      throw new Error(result?.eSeikatsuCache?.reason || "いい生活全件照合が完了しませんでした。");
    }
    if (reviewGeneration !== eSeikatsuReviewGeneration) return;
    importCaptureData(result.data, result.filename || "data/extension_capture.json");
    showCompletionToast("いい生活確認が完了しました。候補リストを確認できます");
  })()
    .catch((error) => {
      if (reviewGeneration !== eSeikatsuReviewGeneration || error?.name === "AbortError") return;
      importStatus.textContent = `いい生活全件照合に失敗しました: ${error.message}`;
      showWorkflowProblem(`いい生活全件照合に失敗しました: ${error.message}。再取得して再試行してください。`, "compare");
    })
    .finally(() => {
      if (reviewGeneration !== eSeikatsuReviewGeneration) return;
      eSeikatsuReviewRunning = false;
      clearESeikatsuReviewPoll();
      document.querySelector(".ops-progress-panel")?.classList.remove("is-running");
      eSeikatsuReviewAbortController = null;
      eSeikatsuReviewPromise = null;
      renderOpsDashboard();
    });

  return eSeikatsuReviewPromise;
}

function importCaptureData(data, filename = "取得JSON") {
  try {
    const importedAt = new Date();
    currentImportMeta = {
      filename,
      capturedAt: data.capturedAt ?? data.meta?.capturedAt ?? "",
      importedAt: importedAt.toISOString(),
      captureQuality: [],
      eSeikatsuCache: data.eSeikatsuCache ?? null,
      criteriaJson: normalizeCriteriaJson(data.meta?.criteriaJson ?? data.realpro?.criteriaJson ?? currentRealproSearchResult()?.criteriaJson ?? selectedConditionJson()),
      criteriaText: data.meta?.criteriaText ?? selectedConditionText(),
    };
    const rawExpectedStats = data.meta?.expectedStats ?? data.expectedStats ?? null;
    const expectedStats = isDefaultSearchCriteria() ? rawExpectedStats : null;
    const realproArray = arrayFromCapture(data, ["realpro.rooms", "realproRooms", "rooms.realpro"]);
    const eSeikatsuArray = arrayFromCapture(data, ["eSeikatsu.rooms", "eSeikatsuRooms", "rooms.eSeikatsu"]);
    const realproDetailArray = arrayFromCapture(data, ["realpro.details", "realproDetails", "details.realpro"]);
    const realproText = data.realpro?.rawText ?? data.realproRooms?.rawText ?? "";
    const eSeikatsuText = data.eSeikatsu?.rawText ?? data.eSeikatsuRooms?.rawText ?? "";
    const realproPages = data.realpro?.pageCaptures ?? data.realproRooms?.pageCaptures ?? [];
    const eSeikatsuPages = data.eSeikatsu?.pageCaptures ?? data.eSeikatsuRooms?.pageCaptures ?? [];
    const eSeikatsuApiPages = data.eSeikatsu?.apiPageCaptures ?? data.eSeikatsuRooms?.apiPageCaptures ?? [];
    currentImportMeta.realproPages = realproPages;
    syncNextRealproStartPage(data.realpro?.chunkMeta, realproPages);
    const parsedRealpro = parseCapturedText(realproText);
    const parsedESeikatsu = parseESeikatsuText(eSeikatsuText);
    const parsedRealproRooms = dedupeImportedRooms(parsedRealpro.rooms);
    const parsedESeikatsuRooms = dedupeImportedRooms(parsedESeikatsu.rooms);
    const parsedRealproDetails = realproDetailArray.map(normalizeRealproDetail);
    const baseRealproRooms = dedupeImportedRooms(realproArray.length ? realproArray.map(normalizeRealproRoom) : parsedRealproRooms);
    importedRealproRooms = mergeRealproDetails(baseRealproRooms, parsedRealproDetails);
    importedESeikatsuRooms = dedupeImportedRooms(eSeikatsuArray.length ? eSeikatsuArray.map(normalizeESeikatsuRoom) : parsedESeikatsuRooms);
    currentImportMeta.realproCoverage = buildRealproCoverageSummary(realproText, importedRealproRooms, realproPages);
    currentImportMeta.eSeikatsuCoverage = buildESeikatsuCoverageSummary(importedESeikatsuRooms, eSeikatsuApiPages, currentImportMeta.eSeikatsuCache);
    const matchSummary = buildRoomMatchSummary(importedRealproRooms, importedESeikatsuRooms);
    currentImportMeta.roomMatchSummary = matchSummary;
    const captureQuality = buildCaptureQuality(
      realproText,
      eSeikatsuText,
      parsedRealproRooms,
      importedESeikatsuRooms,
      eSeikatsuApiPages,
      realproPages,
      eSeikatsuPages,
      realproArray,
      importedRealproRooms,
      matchSummary,
      currentImportMeta.eSeikatsuCache
    );
    currentImportMeta.captureQuality = captureQuality;
    const realproSummary = realproArray.length
      ? `構造化データ${importedRealproRooms.length}件を読み込みました。`
      : buildParsedSummary(realproText, parsedRealpro.rooms.length, parsedRealproRooms.length, "号室候補");
    const realproDetailSummary = buildRealproDetailSummary(importedRealproRooms, parsedRealproDetails);
    const scaleSummary = buildCaptureScaleSummary(importedRealproRooms, importedESeikatsuRooms, realproPages, eSeikatsuPages, eSeikatsuApiPages);
    currentImportMeta.captureScaleSummary = scaleSummary;
    const eSeikatsuSummary = eSeikatsuArray.length
      ? formatESeikatsuStructuredSummary(eSeikatsuArray.length, importedESeikatsuRooms.length)
      : buildParsedSummary(eSeikatsuText, parsedESeikatsu.rooms.length, parsedESeikatsuRooms.length, "いい生活候補");
    hasLoadedCaptureData = true;
    setCsvControls();
    latestRows = buildCandidateRows();
    latestStats.expected = expectedStats;
    renderPreview(latestRows);
    const detailMergedCount = importedRealproRooms.filter((room) => room.webAd || Number(room.applicationCount) > 0).length;
    const detailUnconfirmedCount = detailUnconfirmedRooms(importedRealproRooms).length;
    const detailUnconfirmedCauseText = detailUnconfirmedCauseBreakdownText(importedRealproRooms);
    const qualityWarningCount = captureQuality.filter((message) => message.startsWith("注意")).length;
    const freshness = captureFreshnessSummary(currentImportMeta.capturedAt, importedAt);
    autoCheckProductionItems([
      "source",
      importedRealproRooms.length && detailMergedCount ? "realproDetail" : "",
      latestStats.excluded ? "excluded" : "",
      !detailUnconfirmedSummaryText(importedRealproRooms) ? "detailUnconfirmedReview" : "",
      latestRows.some((row) => row.type === "掲載差替候補") ? "replacement" : "",
    ].filter(Boolean));
    saveImportHistory({
      filename,
      importedAt: importedAt.toISOString(),
      capturedAt: currentImportMeta.capturedAt,
      realproCount: importedRealproRooms.length,
      eSeikatsuCount: importedESeikatsuRooms.length,
      shownCount: latestStats.shown,
      excludedCount: latestStats.excluded,
      duplicatedCount: latestStats.duplicated,
      captureScaleValue: scaleSummary.value,
      captureScaleText: scaleSummary.statusText,
      criteriaText: selectedConditionText(),
      presetName: currentSearchPresetName,
      qualityWarningCount,
      freshnessText: freshness ? `${freshness.value} / ${freshness.note}` : "",
      freshnessWarning: freshness && freshness.value !== "当日" ? freshness.message : "",
    });
    renderCaptureSummary([
      {
        label: "リアプロ号室",
        value: `${importedRealproRooms.length}件`,
        note: realproArray.length ? "構造化データ" : "画面本文から解析",
        kind: importedRealproRooms.length ? "ok" : "error",
      },
      {
        label: "取得規模",
        value: scaleSummary.value,
        note: scaleSummary.note,
        kind: scaleSummary.kind,
      },
      {
        label: "詳細反映",
        value: `${detailMergedCount}件`,
        note: "広告掲載・申込件数",
        kind: importedRealproRooms.length && detailMergedCount === 0 ? "warn" : "ok",
      },
      detailUnconfirmedCount ? {
        label: "未確認原因",
        value: `${detailUnconfirmedCount}件`,
        note: detailUnconfirmedCauseText || "原因分類なし",
        kind: "warn",
      } : null,
      {
        label: "いい生活号室",
        value: `${importedESeikatsuRooms.length}件`,
        note: eSeikatsuArray.length && eSeikatsuArray.length !== importedESeikatsuRooms.length ? `取得${eSeikatsuArray.length}件から重複除去` : (eSeikatsuArray.length ? "API/構造化データ" : "画面本文から解析"),
        kind: importedESeikatsuRooms.length ? "ok" : "warn",
      },
      {
        label: "表示候補",
        value: `${latestStats.shown}件`,
        note: `除外 ${latestStats.excluded}件 / 重複 ${latestStats.duplicated}件`,
        kind: latestStats.shown ? "ok" : "warn",
      },
      {
        label: "取得品質",
        value: qualityWarningCount ? `注意 ${qualityWarningCount}件` : "OK",
        note: qualityWarningCount ? "下の詳細を確認" : "大きな注意なし",
        kind: qualityWarningCount ? "warn" : "ok",
      },
      freshness ? {
        label: "データ鮮度",
        value: freshness.value,
        note: freshness.note,
        kind: freshness.kind,
      } : null,
      {
        label: "読込日時",
        value: formatDateTime(importedAt),
        note: filename,
        kind: "ok",
      },
    ]);

    setImportStatusLines([
      `読み込み: ${filename}`,
      currentImportMeta.capturedAt ? `取得日時: ${formatDateTime(currentImportMeta.capturedAt)} / 読込日時: ${formatDateTime(importedAt)}` : `読込日時: ${formatDateTime(importedAt)}`,
      freshness?.message ?? "",
      rawExpectedStats && !expectedStats ? "検証サンプル確認: 検索条件が初期状態ではないため、期待件数チェックは省略しました。" : "",
      `リアプロ: ${data.realpro?.title ?? data.realproRooms?.title ?? "不明"} / ${realproSummary}`,
      currentImportMeta.realproCoverage?.hasTotal ? currentImportMeta.realproCoverage.statusText : "",
      formatCaptureScaleSummary(scaleSummary),
      formatPageCaptureSummary("リアプロ取得ページ", realproPages),
      realproDetailSummary,
      `いい生活: ${data.eSeikatsu?.title ?? data.eSeikatsuRooms?.title ?? "不明"} / ${eSeikatsuSummary}`,
      formatESeikatsuCacheSummary(currentImportMeta.eSeikatsuCache),
      formatPageCaptureSummary("いい生活取得ページ", eSeikatsuPages),
      eSeikatsuApiPages.length ? formatApiPageCaptureSummary("いい生活API取得", eSeikatsuApiPages) : "",
      formatRoomMatchSummary(matchSummary),
      data.eSeikatsu?.apiError || data.eSeikatsuRooms?.apiError ? `いい生活API注意: ${data.eSeikatsu?.apiError ?? data.eSeikatsuRooms?.apiError}` : "",
      ...captureQuality,
      importedRealproRooms.length ? "次回の候補作成は読み込みデータを使用します。" : "リアプロ本文が取得できていないため、サンプルデータを使用します。",
    ]);
    updateResultSummaryText();
  } catch (error) {
    clearLoadedCaptureData();
    importStatus.textContent = `読み込みに失敗しました: ${error.message}`;
  }
}

function syncNextRealproStartPage(chunkMeta, realproPages = []) {
  if (!realproStartPage || !chunkMeta?.chunked && !chunkMeta?.accumulatedPages) return;
  const latestStart = Number(chunkMeta.latestStartPage || 0);
  const latestPages = Number(chunkMeta.latestPages || 0);
  const maxPage = Math.max(
    0,
    ...realproPages.map((page) => Number(page?.pageNumber || 0)).filter(Number.isFinite)
  );
  const nextPage = Math.max(latestStart + latestPages, maxPage + 1, 1);
  realproStartPage.value = String(nextPage);
  renderCapturePlan();
}

window.importCaptureData = importCaptureData;

function buildRealproDetailSummary(realproRooms, realproDetails) {
  if (realproDetails.length) return `リアプロ詳細: ${realproDetails.length}件を読み込みました。`;

  const enrichedCount = realproRooms.filter((room) =>
    room.detailTitle || room.url?.includes("room_detail.php") || room.webAd !== "判定不可" || Number(room.applicationCount) > 0
  ).length;
  if (enrichedCount) return `リアプロ詳細: ${enrichedCount}件を号室データに統合済みです。`;

  return "リアプロ詳細: 未取得です。";
}

function formatPageCaptureSummary(label, pageCaptures) {
  if (!pageCaptures.length) return `${label}: 記録なし`;
  const details = pageCaptures
    .map((page) => `${page.pageNumber || "?"}ページ目 ${page.lineCount ?? 0}行${page.stopReason ? ` (${pageStopReasonLabel(page.stopReason)})` : ""}`)
    .join(" / ");
  return `${label}: ${pageCaptures.length}ページ (${details})`;
}

function pageStopReasonLabel(reason) {
  const labels = {
    "requested-pages-reached": "指定ページ数まで取得",
    "next-not-found": "次ページなし",
    "next-not-clicked": "次ページへ進めず停止",
    "click-error": "次ページクリック失敗",
    "legacy-result": "ページ送り結果不明",
  };
  return labels[reason] ?? reason;
}

function formatESeikatsuStructuredSummary(rawCount, dedupedCount) {
  if (rawCount === dedupedCount) return `構造化データ${dedupedCount}件を読み込みました。`;
  return `構造化データ${rawCount}件を読み込み、同一号室の重複を除いて${dedupedCount}件で照合します。`;
}

function formatESeikatsuCacheSummary(cache) {
  if (!cache) return "";
  if (!cache.used) return `いい生活全件キャッシュ: 未使用 (${cache.reason || "理由不明"})`;
  const total = Number(cache.meta?.totalCount || 0);
  const fetched = Number(cache.meta?.fetchedCount || 0);
  const currentTotal = Number(cache.meta?.currentTotalCount || 0);
  const totalDiff = Number(cache.meta?.totalDiff || 0);
  const capturedAt = cache.capturedAt ? ` / 取得日時 ${formatDateTime(cache.capturedAt)}` : "";
  const diffText = totalDiff ? ` / 現在総件数${currentTotal}件との差${totalDiff}件` : "";
  const warningText = cache.totalMismatchWarning ? ` / 注意: ${cache.totalMismatchWarning}` : "";
  return `いい生活全件キャッシュ: 使用中 (${fetched || "不明"}件${total ? ` / 全${total}件` : ""}${diffText}${capturedAt})${warningText}`;
}

function buildCaptureScaleSummary(realproRooms, eSeikatsuRooms, realproPages = [], eSeikatsuPages = [], eSeikatsuApiPages = []) {
  const realproCount = realproRooms.length;
  const eSeikatsuCount = eSeikatsuRooms.length;
  const realproPageCount = realproPages.length;
  const eSeikatsuPageCount = eSeikatsuApiPages.length || eSeikatsuPages.length;

  if (realproCount >= 500) {
    return {
      level: "large",
      value: "大規模",
      note: `リアプロ${realproCount}件 / ${realproPageCount || "?"}ページ`,
      kind: "warn",
      statusText: `取得規模: 大規模です。リアプロ${realproCount}件、いい生活${eSeikatsuCount}件、リアプロ取得ページ${realproPageCount || "記録なし"}、いい生活取得ページ${eSeikatsuPageCount || "記録なし"}。`,
    };
  }

  if (realproCount >= 100) {
    return {
      level: "medium",
      value: "中規模",
      note: `リアプロ${realproCount}件 / ${realproPageCount || "?"}ページ`,
      kind: "ok",
      statusText: `取得規模: 中規模です。リアプロ${realproCount}件、いい生活${eSeikatsuCount}件、リアプロ取得ページ${realproPageCount || "記録なし"}、いい生活取得ページ${eSeikatsuPageCount || "記録なし"}。`,
    };
  }

  return {
    level: "normal",
    value: "通常",
    note: `リアプロ${realproCount}件 / いい生活${eSeikatsuCount}件`,
    kind: "ok",
    statusText: `取得規模: 通常です。リアプロ${realproCount}件、いい生活${eSeikatsuCount}件。`,
  };
}

function formatCaptureScaleSummary(scaleSummary) {
  return scaleSummary?.statusText ?? "";
}

function formatApiPageCaptureSummary(label, pageCaptures) {
  const total = pageCaptures.find((page) => Number(page.totalCount))?.totalCount;
  const itemTotal = pageCaptures.reduce((sum, page) => sum + Number(page.itemCount || 0), 0);
  const visiblePages = pageCaptures.length > 10
    ? [...pageCaptures.slice(0, 3), pageCaptures[pageCaptures.length - 1]]
    : pageCaptures;
  const details = visiblePages
    .map((page) => `${page.pageNumber || "?"}ページ目 ${page.itemCount ?? 0}件`)
    .join(" / ");
  const omitted = pageCaptures.length > 10 ? ` / 中略${pageCaptures.length - visiblePages.length}ページ` : "";
  return `${label}: ${pageCaptures.length}ページ・取得${itemTotal}件 (${details}${omitted}${total ? ` / 全${total}件` : ""})`;
}

function buildESeikatsuCoverageSummary(eSeikatsuRooms = [], apiPageCaptures = [], cache = null) {
  if (cache?.used && cache.meta?.isFull) {
    const total = Number(cache.meta.totalCount || 0);
    const fetched = Number(cache.meta.fetchedCount || eSeikatsuRooms.length || 0);
    const pageSize = Number(cache.meta.pageSize || 20);
    const requiredPages = Number(cache.meta.requiredPages || (total ? Math.ceil(total / pageSize) : 0));
    const fetchedPages = Array.isArray(apiPageCaptures) ? apiPageCaptures.length : 0;
    return {
      hasApi: true,
      isFull: true,
      total,
      fetched,
      missing: 0,
      pageSize,
      fetchedPages,
      requiredPages,
      statusText: `いい生活全件取得済み: 全${total || fetched}件`,
    };
  }
  if (cache && cache.used === false && cache.meta?.currentTotalCount) {
    const total = Number(cache.meta.currentTotalCount || 0);
    const fetched = Number(cache.meta.fetchedCount || eSeikatsuRooms.length || 0);
    const pageSize = Number(cache.meta.pageSize || 20);
    const requiredPages = Number(cache.meta.currentRequiredPages || (total ? Math.ceil(total / pageSize) : 0));
    return {
      hasApi: true,
      isFull: false,
      total,
      fetched,
      missing: Math.max(total - fetched, 0),
      pageSize,
      fetchedPages: Array.isArray(apiPageCaptures) ? apiPageCaptures.length : 0,
      requiredPages,
      statusText: cache.reason || `いい生活全件キャッシュ要更新: 全${total}件中${fetched}件`,
    };
  }

  const pages = Array.isArray(apiPageCaptures) ? apiPageCaptures : [];
  const total = Number(pages.find((page) => Number(page.totalCount))?.totalCount || 0);
  const rawFetched = pages.reduce((sum, page) => sum + (Number(page.itemCount) || 0), 0);
  const fetched = Math.max(eSeikatsuRooms.length, rawFetched);
  const pageSize = Math.max(...pages.map((page) => Number(page.itemCount) || 0), 20);
  const requiredPages = total ? Math.ceil(total / pageSize) : 0;
  const fetchedPages = pages.length;
  const missing = total ? Math.max(total - fetched, 0) : 0;
  const isFull = Boolean(total && fetched >= total && missing === 0);
  const hasApi = pages.length > 0;

  return {
    hasApi,
    isFull,
    total,
    fetched,
    missing,
    pageSize,
    fetchedPages,
    requiredPages,
    statusText: hasApi
      ? (isFull
        ? `いい生活全件取得済み: 全${total}件`
        : `いい生活全件未取得: 全${total || "不明"}件中${fetched}件取得 / 残り${missing || "不明"}件 / 目安${requiredPages || "不明"}ページ`)
      : "いい生活API全件確認なし",
  };
}

function buildRealproCoverageSummary(rawText, realproRooms = [], pageCaptures = []) {
  const count = extractRealproResultCount(rawText);
  const fetched = realproRooms.length;
  const capturedPages = Array.isArray(pageCaptures) ? pageCaptures.length : 0;
  const pagerTotalPages = realproPagerTotalPages(pageCaptures);
  const capturedPageNumbers = new Set(pageCaptures.map((page) => Number(page?.pageNumber)).filter((number) => Number.isFinite(number) && number > 0));
  const pagerCoverageComplete = Boolean(
    pagerTotalPages
    && [...Array(pagerTotalPages)].every((_, index) => capturedPageNumbers.has(index + 1))
    && !realproZeroRoomPages(pageCaptures).length
  );
  const rawFetched = pageCaptures.reduce((sum, page) => sum + (Number(page?.roomCount) || 0), 0);
  if (pagerCoverageComplete) {
    return {
      hasTotal: true,
      isFull: true,
      total: Math.max(fetched, rawFetched),
      fetched,
      rawFetched,
      missing: 0,
      pageSize: Math.max(1, Math.ceil(rawFetched / pagerTotalPages)),
      capturedPages,
      requiredPages: pagerTotalPages,
      pagerTotalPages,
      buildings: 0,
      missingPages: [],
      statusText: `リアプロ検索結果ページ取得済み: 全${pagerTotalPages}ページ / ページ読取${rawFetched}戸 / 照合対象${fetched}戸`,
    };
  }
  if (!count?.rooms) {
    return {
      hasTotal: false,
      isFull: true,
      total: 0,
      fetched,
      missing: 0,
      capturedPages,
      requiredPages: 0,
      statusText: "リアプロ検索結果総数なし",
    };
  }

  const total = Number(count.rooms || 0);
  const coverageFetched = Math.max(fetched, rawFetched);
  const missing = Math.max(total - coverageFetched, 0);
  const missingPages = missingPageNumbers(pageCaptures);
  const missingPagesText = missingPages.length ? ` / 抜けページ候補 ${formatNumberList(missingPages)}ページ` : "";
  const pageSize = Math.max(1, Math.ceil(coverageFetched / Math.max(capturedPages, 1)));
  const requiredPages = Math.ceil(total / pageSize);
  const pageCoverageComplete = Boolean(!missingPages.length && capturedPages >= requiredPages && missing <= Math.max(pageSize, 20));
  const isFull = fetched >= total || pageCoverageComplete;
  return {
    hasTotal: true,
    isFull,
    total,
    fetched,
    rawFetched,
    missing,
    pageSize,
    capturedPages,
    requiredPages,
    buildings: Number(count.buildings || 0),
    missingPages,
    statusText: isFull
      ? `リアプロ検索結果ページ取得済み: 全${total}戸 / ページ読取${coverageFetched}戸 / 照合対象${fetched}戸${missingPagesText}`
      : `リアプロ検索結果未取得: 全${total}戸中${coverageFetched}戸取得 / 残り${missing}戸 / 目安${requiredPages}ページ${missingPagesText}`,
  };
}

function realproPagerTotalPages(pageCaptures = []) {
  const maxPages = pageCaptures
    .map((page) => Number(page?.next?.maxPage))
    .filter((number) => Number.isFinite(number) && number >= 0);
  return maxPages.length ? Math.max(...maxPages) + 1 : 0;
}

function eSeikatsuCoverageBlockingText() {
  const coverage = currentImportMeta?.eSeikatsuCoverage;
  if (!coverage?.hasApi) return "いい生活APIの全件確認ができていないため、実務用CSVは出力できません。";
  if (coverage.isFull) return "";
  return `${coverage.statusText}。実務ではいい生活全体との照合が必要なため、作業対象CSV・確認用CSV・候補CSVは出力できません。いい生活取得ページを${coverage.requiredPages || "必要"}ページ目安まで増やして再取得してください。`;
}

function realproCoverageBlockingText() {
  const zeroRoomPages = realproZeroRoomPages(currentImportMeta?.realproPages ?? []);
  if (zeroRoomPages.length) {
    return `リアプロ取得ページのDOM取得戸数が0件のページがあります: ${formatNumberList(zeroRoomPages)}ページ。取りこぼしの可能性があるため、実務用CSVは出力できません。該当ページを確認して再取得してください。`;
  }
  const coverage = currentImportMeta?.realproCoverage;
  if (!coverage?.hasTotal || coverage.isFull) return "";
  return `${coverage.statusText}。実務ではリアプロ検索結果全体の空室確認が必要なため、表示中CSV・作業対象CSV・確認用CSV・候補CSVは出力できません。検索条件を絞るか、リアプロ取得ページ数を${coverage.requiredPages || "必要"}ページ目安まで増やして再取得してください。`;
}

function realproZeroRoomPages(pageCaptures = []) {
  return pageCaptures
    .filter((page) => Object.prototype.hasOwnProperty.call(page, "roomCount") && Number(page.roomCount || 0) <= 0)
    .map((page) => Number(page.pageNumber))
    .filter((number) => Number.isFinite(number) && number > 0)
    .sort((a, b) => a - b);
}

function dataCoverageBlockingText() {
  return realproCoverageBlockingText() || eSeikatsuCoverageBlockingText() || captureFreshnessBlockingText();
}

function captureFreshnessBlockingText() {
  if (String(currentImportMeta?.filename || "").includes("verification_sample")) return "";
  const freshness = captureFreshnessSummary(currentImportMeta?.capturedAt);
  if (!freshness || freshness.value === "当日") return "";
  return `${freshness.message} 正確な空室候補を作るため、リアプロを当日再取得するまで実務用CSVは出力できません。`;
}

function requireESeikatsuFullCoverage(actionLabel) {
  const message = dataCoverageBlockingText();
  if (!message) return true;
  resultSummary.textContent = `${actionLabel}: ${message}`;
  return false;
}

function pageCaptureQualityMessages(label, pageCaptures) {
  if (!pageCaptures.length) return [`注意: ${label}の記録がありません。取得元画面を確認できないため、再取得時にページ情報を確認してください。`];
  const messages = [];
  const missingPages = missingPageNumbers(pageCaptures);
  if (missingPages.length) {
    messages.push(`注意: ${label}の取得ページに抜けがあります。未取得の可能性: ${formatNumberList(missingPages)}ページ`);
  }
  pageCaptures.forEach((page, index) => {
    if (Number(page.pageNumber) !== index + 1) {
      messages.push(`注意: ${label}のページ番号が不自然です。${page.pageNumber || "不明"}ページ目 / 期待 ${index + 1}ページ目`);
    }
    const urlPageNumber = pageNumberFromUrl(page.url);
    if (urlPageNumber && Number(page.pageNumber) !== urlPageNumber) {
      messages.push(`注意: ${label}${index + 1}ページ目のURLとページ番号が一致しません。記録${page.pageNumber || "不明"}ページ目 / URL ${urlPageNumber}ページ目`);
    }
    if (!page.url) {
      messages.push(`注意: ${label}${index + 1}ページ目のURL記録がありません。`);
    }
    if (!Number.isFinite(Number(page.lineCount)) || Number(page.lineCount) <= 0) {
      messages.push(`注意: ${label}${index + 1}ページ目の行数が不正です。`);
    }
    if (!Number.isFinite(Number(page.textLength)) || Number(page.textLength) <= 0) {
      messages.push(`注意: ${label}${index + 1}ページ目の文字数が不正です。`);
    }
    if (Object.prototype.hasOwnProperty.call(page, "roomCount") && Number(page.roomCount || 0) <= 0) {
      messages.push(`注意: ${label}${page.pageNumber || index + 1}ページ目のDOM取得戸数が0件です。画面構造またはページ内容を確認してください。`);
    }
  });
  const lastPage = pageCaptures[pageCaptures.length - 1];
  const stopText = lastPage?.stopReason ? ` / 停止理由: ${pageStopReasonLabel(lastPage.stopReason)}` : "";
  return messages.length ? messages : [`確認: ${label}は${pageCaptures.length}ページ分の取得記録があります${stopText}。`];
}

function pageNumberFromUrl(url = "") {
  try {
    const parsed = new URL(String(url));
    const pageNumber = Number(parsed.searchParams.get("page"));
    return Number.isFinite(pageNumber) && pageNumber > 0 ? pageNumber + 1 : 0;
  } catch {
    const match = String(url).match(/[?&]page=(\d+)/);
    const pageNumber = Number(match?.[1]);
    return Number.isFinite(pageNumber) && pageNumber > 0 ? pageNumber + 1 : 0;
  }
}

function missingPageNumbers(pageCaptures = []) {
  const numbers = pageCaptures
    .map((page) => Number(page?.pageNumber))
    .filter((number) => Number.isFinite(number) && number > 0)
    .sort((a, b) => a - b);
  if (!numbers.length) return [];
  const unique = [...new Set(numbers)];
  const missing = [];
  for (let number = unique[0]; number <= unique[unique.length - 1]; number += 1) {
    if (!unique.includes(number)) missing.push(number);
  }
  return missing;
}

function formatNumberList(numbers = []) {
  if (numbers.length <= 12) return numbers.join("、");
  return `${numbers.slice(0, 12).join("、")}、ほか${numbers.length - 12}件`;
}

function apiPageCaptureQualityMessages(label, pageCaptures) {
  if (!pageCaptures.length) return [`注意: ${label}の記録がありません。`];
  const messages = [];
  const totalCount = Number(pageCaptures[0]?.totalCount);
  const totalCounts = pageCaptures.map((page) => Number(page.totalCount)).filter(Number.isFinite);
  pageCaptures.forEach((page, index) => {
    const pageNumber = Number(page.pageNumber);
    const itemCount = Number(page.itemCount);
    if (pageNumber !== index + 1) {
      messages.push(`注意: ${label}のページ番号が不自然です。${page.pageNumber || "不明"}ページ目 / 期待 ${index + 1}ページ目`);
    }
    if (!Number.isFinite(itemCount) || itemCount < 0) {
      messages.push(`注意: ${label}${index + 1}ページ目の取得件数が不正です。`);
    }
  });
  if (totalCounts.length !== pageCaptures.length) {
    messages.push(`注意: ${label}の全件数を確認できないページがあります。`);
  } else if (totalCounts.length) {
    const minTotal = Math.min(...totalCounts);
    const maxTotal = Math.max(...totalCounts);
    const totalDiff = maxTotal - minTotal;
    if (totalDiff > 20) {
      messages.push(`注意: ${label}の全件数がページ間で大きく変動しています。最小${minTotal}件 / 最大${maxTotal}件。`);
    } else if (totalDiff > 0) {
      messages.push(`確認: ${label}の全件数が取得中に${totalDiff}件変動しました。掲載更新による1ページ以内の差として扱います。`);
    }
  }
  return messages.length ? messages : [`確認: ${label}は${pageCaptures.length}ページ分のAPI取得記録があります。`];
}

function buildParsedSummary(rawText, parsedCount, uniqueCount, label) {
  const lineCount = String(rawText ?? "").split(/\n+/).filter(Boolean).length;
  if (parsedCount === uniqueCount) return `${lineCount}行のテキストから${uniqueCount}件の${label}を推定しました。`;
  return `${lineCount}行のテキストから${parsedCount}件を推定し、重複整理後${uniqueCount}件の${label}を読み込みました。`;
}

function buildRoomMatchSummary(realproRooms, eSeikatsuRooms) {
  const realproKeys = new Set(realproRooms.map(roomKey));
  const eSeikatsuKeys = new Set(eSeikatsuRooms.map(roomKey));
  const exactMatches = [...realproKeys].filter((key) => eSeikatsuKeys.has(key)).length;
  const eSeikatsuOnly = eSeikatsuRooms.filter((room) => !realproKeys.has(roomKey(room)));
  const realproOnly = realproRooms.filter((room) => !eSeikatsuKeys.has(roomKey(room)));
  const eSeikatsuOnlyRecruiting = eSeikatsuOnly.filter(isESeikatsuRecruiting);

  return {
    exactMatches,
    realproOnlyCount: realproOnly.length,
    eSeikatsuOnlyCount: eSeikatsuOnly.length,
    eSeikatsuOnlyRecruitingCount: eSeikatsuOnlyRecruiting.length,
    eSeikatsuOnlySamples: eSeikatsuOnly.slice(0, 3).map(roomLabelForSummary),
  };
}

function formatRoomMatchSummary(summary) {
  return [
    `号室照合: 完全一致 ${summary.exactMatches}件`,
    `リアプロのみ ${summary.realproOnlyCount}件`,
    `いい生活のみ ${summary.eSeikatsuOnlyCount}件`,
    summary.eSeikatsuOnlyRecruitingCount ? `いい生活のみ募集中 ${summary.eSeikatsuOnlyRecruitingCount}件` : "",
  ].filter(Boolean).join(" / ");
}

function roomLabelForSummary(room) {
  return `${room.building || "建物名不明"} ${roomLabel(room.room || "")}`.trim();
}

function buildCaptureQuality(
  realproText,
  eSeikatsuText,
  realproRooms,
  eSeikatsuRooms,
  eSeikatsuApiPages = [],
  realproPages = [],
  eSeikatsuPages = [],
  structuredRealproRooms = [],
  importedRealproRoomsForQuality = [],
  matchSummary = null,
  eSeikatsuCache = null
) {
  const messages = [];
  const realproCount = extractRealproResultCount(realproText);
  const eSeikatsuCount = extractESeikatsuResultCount(eSeikatsuText);
  const pagerTotalPages = realproPagerTotalPages(realproPages);
  const rawCountLooksGlobal = Boolean(
    realproCount?.rooms
    && importedRealproRoomsForQuality.length
    && realproCount.rooms > Math.max(importedRealproRoomsForQuality.length * 5, 1000)
    && pagerTotalPages
    && realproPages.length >= pagerTotalPages
  );

  if (realproCount?.rooms > 0 && !rawCountLooksGlobal) {
    const parsedCount = importedRealproRoomsForQuality.length || realproRooms.length;
    const marker = realproCount.rooms > parsedCount ? "注意" : "確認";
    messages.push(`${marker}: リアプロ検索結果 ${realproCount.buildings}棟${realproCount.rooms}戸中、画面本文から${parsedCount}戸を解析しました。`);
    if (realproCount.rooms <= 1) {
      messages.push("確認: リアプロ取得元は1戸だけです。リスト検索結果全体を対象にする場合は、リアプロ側で検索結果一覧を開いてから再取得してください。");
    }
  } else if (importedRealproRoomsForQuality.length && realproPages.length) {
    messages.push(`確認: リアプロは構造化データ${importedRealproRoomsForQuality.length}件とページ記録${realproPages.length}ページで取得しています。`);
  }
  if (rawCountLooksGlobal) {
    messages.push(`確認: リアプロ本文の${realproCount.buildings}棟${realproCount.rooms}戸は全体登録数表示として扱い、検索結果はページャー${pagerTotalPages}ページで確認します。`);
  }

  if (structuredRealproRooms.length > importedRealproRoomsForQuality.length) {
    messages.push(`確認: リアプロ構造化データ${structuredRealproRooms.length}件を重複整理し、${importedRealproRoomsForQuality.length}件として読み込みました。`);
  }

  if (looksLikeRepeatedRealproPage(realproPages)) {
    messages.push("注意: リアプロは複数ページ指定されていますが、同じ画面を繰り返し取得した可能性があります。ページ送りできる検索結果一覧で再取得してください。");
  }
  messages.push(...pageCaptureQualityMessages("リアプロ取得ページ", realproPages));

  if (importedRealproRoomsForQuality.length) {
    messages.push(...captureScaleQualityMessages(importedRealproRoomsForQuality, realproPages));
    const missingRealproFields = missingRequiredFieldSummary(importedRealproRoomsForQuality, {
      building: "建物名",
      room: "号室",
      layout: "間取",
      rent: "賃料",
      status: "リアプロ状態",
      webAd: "WEB広告掲載",
    });
    const duplicateRealproKeys = duplicateRoomKeySummary(importedRealproRoomsForQuality);
    const unknownWebAdCount = detailUnconfirmedRooms(importedRealproRoomsForQuality).length;
    const detailUnconfirmedText = detailUnconfirmedSummaryText(importedRealproRoomsForQuality);
    const managementCheckCount = importedRealproRoomsForQuality.filter((room) => room.webAd === "管理会社に確認").length;
    const applicationCount = importedRealproRoomsForQuality.filter((room) => Number(room.applicationCount) > 0).length;

    if (missingRealproFields.length) {
      messages.push(`注意: リアプロ号室データに必須項目の欠けがあります。${missingRealproFields.join(" / ")}`);
    }

    if (duplicateRealproKeys.count) {
      messages.push(`注意: リアプロで同じ建物名・号室として読めるデータが${duplicateRealproKeys.count}件あります。${duplicateRealproKeys.samplesText}`);
    }

    if (unknownWebAdCount) {
      messages.push(`注意: リアプロ詳細未確認のため候補に入れない部屋があります。${detailUnconfirmedText}`);
    } else {
      messages.push(`確認: リアプロWEB広告掲載の判定を${importedRealproRoomsForQuality.length}件確認済みです。`);
    }

    if (managementCheckCount) {
      messages.push(`確認: WEB広告掲載が管理会社確認の部屋が${managementCheckCount}件あります。候補には残し、注意欄で確認できます。`);
    }

    if (applicationCount) {
      messages.push(`確認: 電子入居申込ありの部屋を${applicationCount}件検出しました。候補から除外します。`);
    }
  }

  if (eSeikatsuApiPages.length) {
    messages.push(...apiPageCaptureQualityMessages("いい生活API取得", eSeikatsuApiPages));
    const apiTotal = eSeikatsuApiPages.find((page) => Number(page.totalCount))?.totalCount;
    const totalLabel = apiTotal ? ` / 全${apiTotal}件中` : "";
    messages.push(`確認: いい生活はAPIから${eSeikatsuRooms.length}件を号室単位で取得しました${totalLabel}。`);
    const cacheMeta = eSeikatsuCache?.meta || {};
    const cacheFetchedCount = Number(cacheMeta.fetchedCount || 0);
    const cacheTotalCount = Number(cacheMeta.totalCount || apiTotal || 0);
    const cacheTotalDiff = Number(cacheMeta.totalDiff || 0);
    const cachePageSize = Math.max(Number(cacheMeta.pageSize || 0), 20);
    const fullCacheCoversApiTotal = Boolean(
      eSeikatsuCache?.used &&
      cacheMeta.isFull &&
      cacheTotalDiff <= cachePageSize
    );
    if (fullCacheCoversApiTotal) {
      messages.push(`確認: いい生活全件キャッシュを使用中です。取得${cacheFetchedCount}件を重複整理して${eSeikatsuRooms.length}件で照合しています。`);
    } else if (apiTotal && eSeikatsuRooms.length < Number(apiTotal)) {
      const pageSize = Math.max(...eSeikatsuApiPages.map((page) => Number(page.itemCount) || 0), 20);
      const requiredPages = Math.ceil(Number(apiTotal) / pageSize);
      messages.push(`注意: いい生活全件未取得です。全${apiTotal}件中${eSeikatsuRooms.length}件のみ取得。実務では全体照合が必要です。いい生活取得ページを${requiredPages}ページ目安まで増やしてください。`);
    } else if (apiTotal) {
      messages.push(`確認: いい生活全${apiTotal}件を取得済みです。`);
    }
  } else if (eSeikatsuCount) {
    messages.push(...pageCaptureQualityMessages("いい生活取得ページ", eSeikatsuPages));
    const parsedCount = eSeikatsuRooms.length;
    messages.push(`確認: いい生活 ${eSeikatsuCount.from}〜${eSeikatsuCount.to}件/${eSeikatsuCount.total}件表示中、画面本文から${parsedCount}件を解析しました。`);
  } else if (eSeikatsuPages.length) {
    messages.push(...pageCaptureQualityMessages("いい生活取得ページ", eSeikatsuPages));
  }

  if (eSeikatsuRooms.length) {
    const missingESeikatsuFields = missingRequiredFieldSummary(eSeikatsuRooms, {
      building: "建物名",
      layout: "間取",
      status: "募集状態",
      listing: "掲載状態",
    });
    const noRoomNumberCount = eSeikatsuRooms.filter((room) =>
      isMissingRequiredValue(room.room)
      && !isMissingRequiredValue(room.building)
      && !isMissingRequiredValue(room.layout)
      && !isMissingRequiredValue(room.status)
      && Boolean(room.url)
    ).length;
    const duplicateESeikatsuKeys = duplicateRoomKeySummary(eSeikatsuRooms);

    if (missingESeikatsuFields.length) {
      messages.push(`注意: いい生活号室データに必須項目の欠けがあります。${missingESeikatsuFields.join(" / ")}`);
    }
    if (noRoomNumberCount) {
      messages.push(`確認: いい生活で号室を持たない戸建・貸家等が${noRoomNumberCount}件あります。建物名・間取・募集状態で照合します。`);
    }

    if (duplicateESeikatsuKeys.count) {
      messages.push(`注意: いい生活で同じ建物名・号室として読めるデータが${duplicateESeikatsuKeys.count}件あります。${duplicateESeikatsuKeys.samplesText}`);
    }
  }

  if (matchSummary?.eSeikatsuOnlyRecruitingCount) {
    const samples = matchSummary.eSeikatsuOnlySamples.length ? ` 例: ${matchSummary.eSeikatsuOnlySamples.join("、")}` : "";
    messages.push(`確認: いい生活で募集中だがリアプロ一覧に完全一致しない部屋が${matchSummary.eSeikatsuOnlyRecruitingCount}件あります。リアプロで募集終了・審査中・商談中・掲載なしの可能性があります。${samples}`);
  }

  return messages;
}

function captureScaleQualityMessages(realproRooms, realproPages = []) {
  const count = realproRooms.length;
  const pageCount = realproPages.length;
  if (count >= 500) {
    return [
      `確認: リアプロ取得が${count}件あります。CSV出力前にリアプロ取得ページ数、詳細未確認、同じ建物名・号室の重複を確認してください。`,
    ];
  }
  if (count >= 100) {
    return [
      `確認: リアプロ取得が${count}件あります。検索条件が広い場合は、ページ取得${pageCount || "記録なし"}と詳細未確認の有無を確認してください。`,
    ];
  }
  return [];
}

function missingRequiredFieldSummary(rooms, fieldLabels) {
  return Object.entries(fieldLabels)
    .map(([field, label]) => {
      const count = rooms.filter((room) => isMissingRequiredValue(room[field])).length;
      return count ? `${label}${count}件` : "";
    })
    .filter(Boolean);
}

function isMissingRequiredValue(value) {
  return value === undefined || value === null || String(value).trim() === "";
}

function duplicateRoomKeySummary(rooms) {
  const counts = new Map();
  rooms.forEach((room) => {
    const key = roomKey(room);
    if (!key || key === "::") return;
    counts.set(key, {
      count: (counts.get(key)?.count ?? 0) + 1,
      label: roomLabelForSummary(room),
    });
  });
  const duplicated = [...counts.values()].filter((item) => item.count > 1);
  const count = duplicated.reduce((total, item) => total + item.count, 0);
  const samples = duplicated.slice(0, 3).map((item) => item.label);

  return {
    count,
    samplesText: samples.length ? `例: ${samples.join("、")}` : "",
  };
}

function looksLikeRepeatedRealproPage(pageCaptures) {
  if (pageCaptures.length < 2) return false;
  const signatures = pageCaptures.map((page) => [
    page.url ?? "",
    page.lineCount ?? "",
    page.textLength ?? "",
  ].join("::"));
  return new Set(signatures).size === 1;
}

function extractRealproResultCount(rawText) {
  const match = String(rawText ?? "").normalize("NFKC").match(/([0-9,]+)\s*棟\s*([0-9,]+)\s*戸/);
  if (!match) return null;
  return {
    buildings: Number(match[1].replaceAll(",", "")),
    rooms: Number(match[2].replaceAll(",", "")),
  };
}

function extractESeikatsuResultCount(rawText) {
  const match = String(rawText ?? "").normalize("NFKC").match(/([0-9,]+)\s*[~〜～-]\s*([0-9,]+)\s*件\s*\/\s*([0-9,]+)\s*件/);
  if (!match) return null;
  return {
    from: Number(match[1].replaceAll(",", "")),
    to: Number(match[2].replaceAll(",", "")),
    total: Number(match[3].replaceAll(",", "")),
  };
}

function dedupeImportedRooms(rooms) {
  const deduped = new Map();
  rooms.forEach((room) => {
    const key = [
      normalize(room.building),
      normalizeRoom(room.room),
      normalize(room.layout),
      normalize(room.status),
      room.rent ?? "",
      room.fee ?? "",
    ].join("::");
    if (!deduped.has(key)) deduped.set(key, room);
  });
  return [...deduped.values()];
}

function downloadCsv(filename, csv) {
  const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function csvFilename(prefix) {
  const exportedStamp = formatDateTimeStamp();
  const capturedStamp = currentImportMeta?.capturedAt ? formatDateStamp(currentImportMeta.capturedAt) : "";
  const capturedLabel = capturedStamp ? `-from-${capturedStamp}` : "";
  return `${prefix}-${exportedStamp}${capturedLabel}.csv`;
}

function exportCsvRows(label, prefix, rows) {
  const filename = csvFilename(prefix);
  downloadCsv(filename, toCsv(rows, label));
  autoCheckProductionItems(["csv"]);
  const exportedAt = new Date();
  const freshness = captureFreshnessSummary(currentImportMeta?.capturedAt, exportedAt);
  const eSeikatsuCacheFreshnessText = eSeikatsuCacheFreshnessWarning(currentImportMeta?.eSeikatsuCache, exportedAt);
  saveCsvHistory({
    label,
    csvSchemaVersion: CSV_SCHEMA_VERSION,
    filename,
    count: rows.length,
    exportedAt: exportedAt.toISOString(),
    capturedAt: currentImportMeta?.capturedAt ?? "",
    freshnessText: freshness ? `${freshness.value} / ${freshness.note}` : "",
    freshnessWarning: freshness && freshness.value !== "当日" ? freshness.message : "",
    eSeikatsuCacheFreshnessText,
    freshnessReviewHistoryText: freshnessReviewHistorySummaryText(),
    criteriaText: selectedConditionText(),
    criteriaJson: selectedConditionJson(),
    exportScopeText: csvExportScopeText(label),
    resultFilterText: currentResultFilterSummaryText(),
    importFilename: currentImportMeta?.filename ?? "",
    presetName: currentSearchPresetName,
    roomMatchText: currentRoomMatchText(),
    captureScaleValue: currentImportMeta?.captureScaleSummary?.value ?? "",
    captureScaleText: formatCaptureScaleSummary(currentImportMeta?.captureScaleSummary),
    qualityWarningCount: currentQualityWarningCount(),
    captureQualityReviewHistoryText: captureQualityReviewHistorySummaryText(),
    candidateBreakdownText: candidateBreakdownText(rows),
    confirmationReasonBreakdownText: confirmationReasonBreakdownText(rows),
    detailUnconfirmedReviewStatusText: currentDetailUnconfirmedReviewStatusText(),
    detailUnconfirmedText: detailUnconfirmedSummaryText(),
    detailUnconfirmedReviewHistoryText: detailUnconfirmedReviewHistorySummaryText(),
    workTargetText: workTargetHistoryText(rows),
    restoreHistoryText: conditionRestoreHistorySummaryText(),
  });
  const checklistWarning = productionChecklistIncompleteText();
  const freshnessWarning = freshness && freshness.value !== "当日" ? freshness.message : "";
  const cacheFreshnessWarning = eSeikatsuCacheFreshnessText;
  const freshnessReviewMissingWarning = currentFreshnessReviewMissingText();
  const restoreHistoryText = conditionRestoreHistorySummaryText();
  const restoreHistoryWarning = restoreHistoryText.includes("未反映")
    ? `検索条件復元履歴に未反映があります: ${restoreHistoryText}`
    : "";
  const detailUnconfirmedText = detailUnconfirmedSummaryText();
  const detailUnconfirmedWarning = detailUnconfirmedText
    ? `詳細未確認は候補CSVに入れません: ${detailUnconfirmedText}`
    : "";
  const detailUnconfirmedReviewStatus = detailUnconfirmedText ? `詳細未確認検証状態: ${currentDetailUnconfirmedReviewStatusText()}` : "";
  const detailUnconfirmedReviewMissingWarning = currentDetailUnconfirmedReviewMissingText();
  const exportScopeText = csvExportScopeText(label);
  const resultFilterText = currentResultFilterSummaryText();
  const confirmNotice = rows.some((row) => workTargetLabel(row) === "確認後判断")
    ? "確認後判断の行を含んでいます。登録前に注意欄を確認してください。"
    : "";
  if (csvSummary) {
    csvSummary.textContent = [`${label}を出力しました: ${rows.length}件${workTargetSummaryText(rows)} / ${filename}`, `CSV形式: ${CSV_SCHEMA_VERSION}`, `CSV出力範囲: ${exportScopeText}`, `出力時表示絞り込み: ${resultFilterText}`, confirmNotice, freshnessWarning, cacheFreshnessWarning, freshnessReviewMissingWarning, restoreHistoryWarning, detailUnconfirmedWarning, detailUnconfirmedReviewStatus, detailUnconfirmedReviewMissingWarning, checklistWarning].filter(Boolean).join(" / ");
    csvSummary.className = `note csv-summary ${confirmNotice || freshnessWarning || cacheFreshnessWarning || freshnessReviewMissingWarning || restoreHistoryWarning || detailUnconfirmedWarning || detailUnconfirmedReviewMissingWarning || checklistWarning ? "status-warn-inline" : ""}`.trim();
  }
}

function buildCsvExportSet() {
  const candidateRows = buildRowsPreservingStats({ includeExcluded: false });
  const workRows = candidateRows.filter((row) => workTargetLabel(row) === "作業対象");
  const reviewRows = candidateRows.filter((row) => workTargetLabel(row) === "確認後判断");
  const allRows = buildRowsPreservingStats({ includeExcluded: true });
  return [
    { label: "現場用CSV", prefix: "property-candidates-practical", rows: candidateRows, practical: true },
    { label: "作業対象CSV", prefix: "property-candidates-work", rows: workRows },
    { label: "確認用CSV", prefix: "property-candidates-review", rows: reviewRows },
    { label: "候補CSV", prefix: "property-candidates", rows: candidateRows },
    { label: "全件CSV", prefix: "property-candidates-all", rows: allRows },
  ];
}

async function saveCsvExportSet() {
  if (!requireLoadedCaptureData("CSV保存")) return;
  if (!requireESeikatsuFullCoverage("CSV保存")) return;
  if (!saveCsvFiles) return;
  const items = buildCsvExportSet();
  if (!items.length) {
    resultSummary.textContent = "保存できるCSVがありません。取得データを確認してください。";
    return;
  }

  saveCsvFiles.disabled = true;
  const previousText = saveCsvFiles.textContent;
  saveCsvFiles.textContent = "保存中...";
  try {
    const saved = [];
    for (const item of items) {
      const filename = csvFilename(item.prefix);
      const response = await fetch("/api/save-csv", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filename,
          csv: item.practical ? toPracticalCsv(item.rows, item.label) : toCsv(item.rows, item.label),
        }),
      });
      if (!response.ok) {
        const errorPayload = await readErrorResponse(response);
        throw new Error(errorPayload);
      }
      const result = await response.json();
      saved.push({ ...result, label: item.label, count: item.rows.length });
    }
    autoCheckProductionItems(["csv"]);
    renderCsvSummary();
    resultSummary.textContent = `CSV保存OK: ${saved.map((item) => `${item.label}${item.count}件`).join(" / ")}。保存先: exportsフォルダ`;
    renderSavedCsvLinks(saved);
    renderOpsLastSavedCsv(saved.map((item) => ({
      ...item,
      rowCount: item.count,
      updatedAt: new Date().toISOString(),
    })));
  } catch (error) {
    resultSummary.textContent = `CSV保存に失敗しました: ${error.message}`;
  } finally {
    saveCsvFiles.disabled = false;
    saveCsvFiles.textContent = previousText;
  }
}

function renderSavedCsvLinks(saved = []) {
  if (!savedCsvLinks) return;
  if (!saved.length) {
    savedCsvLinks.hidden = true;
    savedCsvLinks.innerHTML = "";
    return;
  }
  savedCsvLinks.hidden = false;
  const orderedSaved = [...saved].sort((a, b) => csvDisplayRank(a) - csvDisplayRank(b));
  const countText = (item) => {
    if (item.count === "" || item.count == null) return "";
    const count = Number(item.count);
    return Number.isFinite(count) ? ` ${count}件` : "";
  };
  savedCsvLinks.innerHTML = `
    <h3>保存したCSV</h3>
    <div class="history-list">
      ${orderedSaved.map((item) => `
        <div class="history-item">
          <strong>${escapeHtml(item.label)}${escapeHtml(countText(item))}</strong>
          <a href="/${escapeHtml(item.filename)}" download>${escapeHtml(item.filename)}</a>
          ${item.latestFilename ? `<a href="/${escapeHtml(item.latestFilename)}" download>${escapeHtml(item.latestFilename)}</a>` : ""}
        </div>
      `).join("")}
    </div>
  `;
}

function csvDisplayRank(item = {}) {
  const label = item.label || exportLabelFromFilename(item.filename || "");
  const ranks = {
    現場用CSV: 1,
    作業対象CSV: 2,
    確認用CSV: 3,
    候補CSV: 4,
    全件CSV: 5,
    表示中CSV: 6,
    詳細未確認CSV: 7,
  };
  return ranks[label] ?? 99;
}

async function loadSavedCsvLinks() {
  if (!savedCsvLinks || location.protocol === "file:") return;
  try {
    const response = await fetch(`/api/exports?ts=${Date.now()}`);
    if (!response.ok) return;
    const result = await response.json();
    const files = Array.isArray(result.files) ? result.files : [];
    const displayFiles = latestCsvFilesForDisplay(files);
    const filesWithCounts = await enrichCsvExportCounts(displayFiles);
    renderSavedCsvLinks(filesWithCounts.map((file) => ({
      ...file,
      label: exportLabelFromFilename(file.filename),
      count: file.rowCount ?? "",
    })));
    renderOpsLastSavedCsv(filesWithCounts);
  } catch {
    // 保存済みCSV一覧は補助表示なので、取得失敗時は何もしない。
  }
}

async function enrichCsvExportCounts(files = []) {
  return Promise.all(files.map(async (file) => ({
    ...file,
    rowCount: await csvExportRowCount(file.filename),
  })));
}

async function csvExportRowCount(filename = "") {
  if (!filename || location.protocol === "file:") return "";
  try {
    const response = await fetch(`/${filename}?ts=${Date.now()}`);
    if (!response.ok) return "";
    const text = await response.text();
    const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).filter((line) => line.trim() !== "");
    return Math.max(lines.length - 1, 0);
  } catch {
    return "";
  }
}

function renderOpsLastSavedCsv(files = []) {
  const latestSaved = files.find((file) => exportLabelFromFilename(file.filename) === "現場用CSV") || files[0];
  if (!latestSaved) return;
  const label = exportLabelFromFilename(latestSaved.filename);
  const countText = latestSaved.rowCount === "" || latestSaved.rowCount == null ? "" : ` ${latestSaved.rowCount}件`;
  const title = `${label}${countText}`;
  latestServerCsvForOps = {
    title,
    savedTitle: `保存済み ${title}`,
    date: latestSaved.updatedAt ? formatDateTime(latestSaved.updatedAt) : "保存日時不明",
  };
  setOpsText("opsLastRunTitle", latestServerCsvForOps.savedTitle);
  setOpsText("opsLastRunDate", latestServerCsvForOps.date);
  const coverage = currentImportMeta?.realproCoverage;
  const realproIncomplete = Boolean(hasLoadedCaptureData && coverage?.hasTotal && !coverage.isFull);
  const eSeikatsuIncomplete = Boolean(hasLoadedCaptureData && !currentImportMeta?.eSeikatsuCoverage?.isFull);
  const hasIncompleteData = Boolean(realproIncomplete || eSeikatsuIncomplete);
  setOpsText("opsCsvState", hasIncompleteData ? "未完成" : "作成可能");
  setOpsText("opsCsvText", hasIncompleteData
    ? "追加取得後に候補一覧で確認"
    : opsCsvStatusText(hasLoadedCaptureData ? buildRowsPreservingStats({ includeExcluded: false }).length : 0));
  const openLatestPractical = document.querySelector("#opsOpenLatestPractical");
  if (openLatestPractical) openLatestPractical.disabled = false;
}

function latestCsvFilesForDisplay(files = []) {
  const latestNames = [
    "exports/latest-practical.csv",
    "exports/latest-work.csv",
    "exports/latest-review.csv",
    "exports/latest-candidates.csv",
    "exports/latest-all.csv",
  ];
  const byFilename = new Map(files.map((file) => [file.filename, file]));
  const latestFiles = latestNames.map((name) => byFilename.get(name)).filter(Boolean);
  return latestFiles.length ? latestFiles : files.slice(0, 20);
}

function exportLabelFromFilename(filename = "") {
  if (filename.includes("property-candidates-practical") || filename.includes("latest-practical")) return "現場用CSV";
  if (filename.includes("property-candidates-work") || filename.includes("latest-work")) return "作業対象CSV";
  if (filename.includes("property-candidates-review") || filename.includes("latest-review")) return "確認用CSV";
  if (filename.includes("property-candidates-all") || filename.includes("latest-all")) return "全件CSV";
  if (filename.includes("latest-candidates")) return "候補CSV";
  if (filename.includes("property-candidates")) return "候補CSV";
  return "CSV";
}

searchForm.addEventListener("submit", (event) => {
  event.preventDefault();
  if (!requireLoadedCaptureData("候補作成")) return;
  updateSelectedConditions();
  refreshCandidateRows("候補を更新しました。");
});

resetSearchConditions?.addEventListener("click", resetAllSearchConditions);

function handleSearchConditionChange(event) {
  if (event.target.closest(".preset-block")) return;
  clearCurrentSearchPresetName();

  if (event.target.name === "line") {
    updateStationVisibility();
  }

  if (event.target.name === "selectAllStations") {
    const group = event.target.closest(".station-group");
    group.querySelectorAll('input[name="station"]').forEach((input) => {
      input.checked = event.target.checked;
    });
    updateStationSelectAllState(group);
  }

  if (event.target.name === "station") {
    updateStationSelectAllState(event.target.closest(".station-group"));
  }

  updateSelectedConditions();
  saveSearchConditions();
  refreshCandidateRows("検索条件を変更したため、候補を自動更新しました。");
}

searchForm.addEventListener("change", handleSearchConditionChange);
searchForm.addEventListener("input", (event) => {
  if (event.target.closest(".preset-block")) return;
  if (!["rentMin", "rentMax", "walkMinutes"].includes(event.target.name)) return;
  clearCurrentSearchPresetName();
  updateSelectedConditions();
  saveSearchConditions();
  refreshCandidateRows("検索条件を変更したため、候補を自動更新しました。");
});

document.querySelectorAll("[data-clear-group]").forEach((button) => {
  button.addEventListener("click", () => {
    clearCurrentSearchPresetName();
    const group = button.dataset.clearGroup;
    document.querySelectorAll(`[data-group="${group}"] input[type="checkbox"]`).forEach((input) => {
      input.checked = false;
    });
    if (group === "railway") updateStationVisibility();
    updateSelectedConditions();
    saveSearchConditions();
    refreshCandidateRows("検索条件を変更したため、候補を自動更新しました。");
  });
});

document.querySelectorAll("[data-open-url]").forEach((button) => {
  button.addEventListener("click", () => {
    window.open(button.dataset.openUrl, "_blank", "noopener,noreferrer");
  });
});

if (importStatus && workflowRunningMessage) {
  new MutationObserver(() => {
    const message = importStatus.textContent.trim();
    workflowRunningMessage.textContent = message || "処理状況を確認しています...";
    if (!workflowRunningTitle) return;
    if (message.includes("いい生活")) workflowRunningTitle.textContent = "いい生活の掲載情報と照合しています";
    else if (message.includes("詳細")) workflowRunningTitle.textContent = "WEB広告と申込状況を確認しています";
    else if (message.includes("候補")) workflowRunningTitle.textContent = "登録候補を整理しています";
    else workflowRunningTitle.textContent = "リアプロの部屋情報を取得しています";
  }).observe(importStatus, { childList: true, subtree: true, characterData: true });
}

document.addEventListener("click", async (event) => {
  const realproDetailCheckButton = event.target.closest("[data-open-realpro-detail-check]");
  if (realproDetailCheckButton) {
    const url = realproDetailCheckButton.dataset.openRealproDetailCheck || "https://www.realnetpro.com/";
    window.open(url, "_blank", "noopener");
    return;
  }
  const captureStepButton = event.target.closest("[data-capture-step]");
  if (captureStepButton) {
    applyCaptureStep(captureStepButton.dataset.captureStep);
    return;
  }
  if (event.target.closest("[data-clear-import-history]")) {
    clearImportHistory();
    return;
  }
  if (event.target.closest("[data-clear-preflight-history]")) {
    const count = clearPreflightHistory();
    conditionStatus.textContent = count ? `本番前確認履歴を${count}件クリアしました。` : "クリアする本番前確認履歴はありません。";
    conditionStatus.className = "condition-status status-ok-inline";
    return;
  }
  if (event.target.closest("[data-clear-chrome-tab-history]")) {
    const count = clearChromeTabHistory();
    conditionStatus.textContent = count ? `Chromeタブ確認履歴を${count}件クリアしました。` : "クリアするChromeタブ確認履歴はありません。";
    conditionStatus.className = "condition-status status-ok-inline";
    return;
  }
  if (event.target.closest("[data-clear-csv-history]")) {
    clearCsvHistory();
    return;
  }
  if (event.target.closest("[data-clear-condition-restore-history]")) {
    const count = clearConditionRestoreHistory();
    conditionStatus.textContent = count ? `復元履歴を${count}件クリアしました。` : "クリアする復元履歴はありません。";
    conditionStatus.className = "condition-status status-ok-inline";
    return;
  }
  if (event.target.closest("[data-clear-condition-restore-warnings]")) {
    const count = clearConditionRestoreWarnings();
    conditionStatus.textContent = count ? `未反映ありの復元履歴を${count}件クリアしました。` : "未反映ありの復元履歴はありません。";
    conditionStatus.className = "condition-status status-ok-inline";
    return;
  }
  if (event.target.closest("[data-clear-freshness-review-history]")) {
    const count = clearFreshnessReviewHistory();
    renderCsvSummary();
    conditionStatus.textContent = count ? `データ鮮度確認履歴を${count}件クリアしました。` : "クリアするデータ鮮度確認履歴はありません。";
    conditionStatus.className = "condition-status status-ok-inline";
    return;
  }
  if (event.target.closest("[data-clear-capture-quality-review-history]")) {
    const count = clearCaptureQualityReviewHistory();
    conditionStatus.textContent = count ? `取得品質確認履歴を${count}件クリアしました。` : "クリアする取得品質確認履歴はありません。";
    conditionStatus.className = "condition-status status-ok-inline";
    return;
  }
  if (event.target.closest("[data-clear-detail-unconfirmed-review-history]")) {
    const count = clearDetailUnconfirmedReviewHistory();
    renderCsvSummary();
    conditionStatus.textContent = count ? `詳細未確認検証履歴を${count}件クリアしました。` : "クリアする詳細未確認検証履歴はありません。";
    conditionStatus.className = "condition-status status-ok-inline";
    return;
  }
  const restoreConditionButton = event.target.closest("[data-restore-condition-index]");
  if (restoreConditionButton) {
    const history = readConditionRestoreHistory();
    const item = history[Number(restoreConditionButton.dataset.restoreConditionIndex)];
    if (!item?.criteriaJson) {
      conditionStatus.textContent = "復元履歴の検索条件JSONを読み込めませんでした。";
      conditionStatus.className = "condition-status status-warn-inline";
      return;
    }
    try {
      applySearchConditionJson(item.criteriaJson, "復元履歴の検索条件JSON");
    } catch {
      conditionStatus.textContent = "復元履歴の検索条件JSONを反映できませんでした。";
      conditionStatus.className = "condition-status status-warn-inline";
    }
    return;
  }
  const memoTemplate = event.target.closest("[data-memo-template]");
  if (memoTemplate) {
    appendProductionMemoTemplate(memoTemplate.dataset.memoTemplate);
  }
  const freshnessMemo = event.target.closest("[data-memo-freshness]");
  if (freshnessMemo) {
    const freshness = captureFreshnessSummary(currentImportMeta?.capturedAt);
    const memoText = currentFreshnessMemoText();
    saveFreshnessReviewHistory({
      reviewedAt: new Date().toISOString(),
      freshnessValue: freshness?.value || "不明",
      requiresReacquire: !freshness || freshness.value !== "当日",
      summaryText: memoText.replace(/^データ鮮度確認:\s*/, ""),
      sourceLabel: currentImportMeta?.filename || "現在の読み込みデータ",
      capturedAt: currentImportMeta?.capturedAt || "",
      criteriaText: selectedConditionText(),
    });
    appendProductionMemoTemplate(memoText);
    renderCsvSummary();
    conditionStatus.textContent = "データ鮮度確認を本番検証メモに追記しました。";
    conditionStatus.className = "condition-status status-ok-inline";
  }
  const captureQualityMemo = event.target.closest("[data-memo-capture-quality]");
  if (captureQualityMemo) {
    const warningText = currentQualityWarningText();
    saveCaptureQualityReviewHistory({
      reviewedAt: new Date().toISOString(),
      warningCount: currentQualityWarningCount(),
      summaryText: warningText || "現在の読み込みデータでは大きな注意はありません。",
      sourceLabel: currentImportMeta?.filename || "現在の読み込みデータ",
      criteriaText: selectedConditionText(),
    });
    appendProductionMemoTemplate(warningText
      ? `取得品質確認: ${warningText}。再取得または取得ルール見直しの対象にする。`
      : "取得品質確認: 現在の読み込みデータでは大きな注意はありません。");
    conditionStatus.textContent = "取得品質確認を本番検証メモに追記しました。";
    conditionStatus.className = "condition-status status-ok-inline";
  }
  const detailUnconfirmedMemo = event.target.closest("[data-memo-detail-unconfirmed]");
  if (detailUnconfirmedMemo) {
    const detailText = detailUnconfirmedSummaryText();
    const memoText = detailText
      ? `詳細未確認検証: ${detailText}。次回アップデートで取得できなかった理由を確認する。`
      : "詳細未確認検証: 現在の読み込みデータでは詳細未確認はありません。";
    saveDetailUnconfirmedReviewHistory({
      reviewedAt: new Date().toISOString(),
      hasUnconfirmed: Boolean(detailText),
      summaryText: detailText || "現在の読み込みデータでは詳細未確認はありません。",
      sourceLabel: currentImportMeta?.filename || "現在の読み込みデータ",
      capturedAt: currentImportMeta?.capturedAt || "",
      criteriaText: selectedConditionText(),
    });
    appendProductionMemoTemplate(memoText);
    autoCheckProductionItems(["detailUnconfirmedReview"]);
    renderCsvSummary();
    conditionStatus.textContent = "詳細未確認検証を本番検証メモに追記しました。";
    conditionStatus.className = "condition-status status-ok-inline";
  }
  const applyJsonButton = event.target.closest("[data-apply-json]");
  if (applyJsonButton) {
    const jsonText = applyJsonButton.closest("details")?.querySelector("code")?.textContent ?? "";
    try {
      applySearchConditionJson(jsonText, "CSV履歴の検索条件JSON");
    } catch {
      conditionStatus.textContent = "CSV履歴の検索条件JSONを反映できませんでした。";
      conditionStatus.className = "condition-status status-warn-inline";
    }
    return;
  }
  const copyJsonButton = event.target.closest("[data-copy-json]");
  if (copyJsonButton) {
    const codeElement = copyJsonButton.closest("details")?.querySelector("code");
    const jsonText = codeElement?.textContent ?? "";
    if (!jsonText) {
      showJsonCopyStatus("failed");
      return;
    }
    try {
      const copied = await copyTextToClipboard(jsonText);
      showJsonCopyStatus(copied ? "copied" : (selectElementText(codeElement) ? "selected" : "failed"));
    } catch {
      showJsonCopyStatus(selectElementText(codeElement) ? "selected" : "failed");
    }
  }
});

downloadSample.addEventListener("click", () => {
  if (!requireLoadedCaptureData("候補CSV出力")) return;
  if (!requireESeikatsuFullCoverage("候補CSV出力")) return;
  const rows = buildRowsPreservingStats({ includeExcluded: false });
  if (!rows.length) {
    resultSummary.textContent = "候補CSVに出力できる行がありません。検索条件を見直してください。";
    return;
  }
  exportCsvRows("候補CSV", "property-candidates", rows);
});

downloadVisibleRows?.addEventListener("click", () => {
  if (!requireLoadedCaptureData("表示中CSV出力")) return;
  if (!requireESeikatsuFullCoverage("表示中CSV出力")) return;
  const rows = filterResultRows(latestRows);
  if (!rows.length) {
    resultSummary.textContent = "表示中CSVに出力できる行がありません。表示区分・結果検索を見直してください。";
    return;
  }
  exportCsvRows("表示中CSV", "property-candidates-visible", rows);
});

downloadPracticalRows?.addEventListener("click", () => {
  if (!requireLoadedCaptureData("現場用CSV出力")) return;
  if (!requireESeikatsuFullCoverage("現場用CSV出力")) return;
  const rows = buildRowsPreservingStats({ includeExcluded: false });
  if (!rows.length) {
    resultSummary.textContent = "現場用CSVに出力できる行がありません。検索条件や判定結果を確認してください。";
    return;
  }
  const filename = csvFilename("property-candidates-practical");
  downloadCsv(filename, toPracticalCsv(rows, "現場用CSV"));
  autoCheckProductionItems(["csv"]);
  resultSummary.textContent = `現場用CSVを出力しました: ${rows.length}件 / ${filename}`;
  renderCsvSummary();
});

downloadWorkRows?.addEventListener("click", () => {
  if (!requireLoadedCaptureData("作業対象CSV出力")) return;
  if (!requireESeikatsuFullCoverage("作業対象CSV出力")) return;
  const rows = buildRowsPreservingStats({ includeExcluded: false }).filter((row) => workTargetLabel(row) === "作業対象");
  if (!rows.length) {
    resultSummary.textContent = "作業対象CSVに出力できる行がありません。検索条件や判定結果を確認してください。";
    return;
  }
  exportCsvRows("作業対象CSV", "property-candidates-work", rows);
});

downloadReviewRows?.addEventListener("click", () => {
  if (!requireLoadedCaptureData("確認用CSV出力")) return;
  if (!requireESeikatsuFullCoverage("確認用CSV出力")) return;
  const rows = buildRowsPreservingStats({ includeExcluded: false }).filter((row) => workTargetLabel(row) === "確認後判断");
  if (!rows.length) {
    resultSummary.textContent = "確認用CSVに出力できる行がありません。確認後判断の候補はありません。";
    return;
  }
  exportCsvRows("確認用CSV", "property-candidates-review", rows);
});

saveCsvFiles?.addEventListener("click", saveCsvExportSet);
workflowSaveCsv?.addEventListener("click", () => saveCsvFiles?.click());

downloadAllRows?.addEventListener("click", () => {
  if (!requireLoadedCaptureData("全件CSV出力")) return;
  const rows = buildRowsPreservingStats({ includeExcluded: true });
  if (!rows.length) {
    resultSummary.textContent = "全件CSVに出力できる行がありません。取得データを確認してください。";
    return;
  }
  exportCsvRows("全件CSV", "property-candidates-all", rows);
});

downloadDetailUnconfirmedRows?.addEventListener("click", () => {
  if (!requireLoadedCaptureData("詳細未確認CSV出力")) return;
  const rows = buildDetailUnconfirmedCsvRows();
  if (!rows.length) {
    resultSummary.textContent = "詳細未確認CSVに出力できる行がありません。現在の検索条件では詳細未確認はありません。";
    return;
  }
  exportCsvRows("詳細未確認CSV", "property-detail-unconfirmed", rows);
});

loadLatestCapture.addEventListener("click", handleLatestCaptureLoad);
checkExtensionStatus?.addEventListener("click", handleExtensionStatusCheck);
loadExtensionCapture?.addEventListener("click", handleExtensionCaptureLoad);
loadVerificationSample?.addEventListener("click", handleVerificationSampleLoad);
loadVerificationSampleDefault?.addEventListener("click", handleVerificationSampleDefaultLoad);
runChromeCaptureButton?.addEventListener("click", handleChromeCaptureRun);
runFastCaptureButton?.addEventListener("click", handleFastCaptureRun);
resumeFastDetailsButton?.addEventListener("click", handleFastDetailResume);
runRealproChunkCaptureButton?.addEventListener("click", handleRealproChunkCaptureRun);
runPreflightCheck?.addEventListener("click", handlePreflightCheck);
setESeikatsuFullPages?.addEventListener("click", handleESeikatsuFullPagesSet);
buildESeikatsuCache?.addEventListener("click", handleESeikatsuCacheBuild);
retryRealproDetails?.addEventListener("click", handleRealproDetailsRetry);
retryZeroRoomPages?.addEventListener("click", handleZeroRoomPagesRetry);
applyRealproConditions?.addEventListener("click", handleApplyRealproConditions);
applyRealproConditionsAndSearch?.addEventListener("click", (event) => handleApplyRealproConditions({ submitSearch: true, triggerButton: event.currentTarget }));
applyRealproConditionsMain?.addEventListener("click", handleApplyRealproConditions);
applyRealproConditionsAndSearchMain?.addEventListener("click", (event) => handleApplyRealproConditions({ submitSearch: true, triggerButton: event.currentTarget }));
document.querySelector("#opsEditConditions")?.addEventListener("click", () => {
  conditionBuilder?.scrollIntoView({ behavior: "smooth", block: "start" });
});
document.querySelectorAll("[data-ops-jump]").forEach((item) => {
  item.addEventListener("click", () => handleOpsJump(item.dataset.opsJump));
  item.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    handleOpsJump(item.dataset.opsJump);
  });
});
document.querySelector("#opsPrimaryAction")?.addEventListener("click", () => {
  if (captureIsRunning || hasLoadedCaptureData) {
    location.hash = "candidateResults";
    return;
  }
  if (currentRealproSearchResult()) {
    handleOpsRunCaptureClick();
    return;
  }
  if (!isDefaultSearchCriteria()) {
    handleApplyRealproConditions({ submitSearch: true, scrollToProgress: true });
    return;
  }
  window.open("https://www.realnetpro.com/", "_blank", "noopener,noreferrer");
});
document.querySelector("#opsSecondaryAction")?.addEventListener("click", () => {
  if (hasLoadedCaptureData) {
    const realproCoverage = currentImportMeta?.realproCoverage;
    const eSeikatsuCoverage = currentImportMeta?.eSeikatsuCoverage;
    const needsMoreCapture = Boolean((realproCoverage?.hasTotal && !realproCoverage.isFull) || !eSeikatsuCoverage?.isFull);
    if (needsMoreCapture) {
      handleOpsRunCaptureClick();
      return;
    }
    conditionBuilder?.scrollIntoView({ behavior: "smooth", block: "start" });
    return;
  }
  if (!isDefaultSearchCriteria()) {
    conditionBuilder?.scrollIntoView({ behavior: "smooth", block: "start" });
    return;
  }
  window.open("https://rent.e-bukken.app/login", "_blank", "noopener,noreferrer");
});
document.querySelector("#opsApplyConditions")?.addEventListener("click", (event) => handleApplyRealproConditions({ submitSearch: true, triggerButton: event.currentTarget, scrollToProgress: true }));
document.querySelector("#opsRunCapture")?.addEventListener("click", handleOpsRunCaptureClick);
document.querySelector("#opsOpenCandidates")?.addEventListener("click", openCandidateResultsPanel);
document.querySelector("#opsOpenLatestPractical")?.addEventListener("click", () => {
  window.open(latestPracticalCsvUrl(), "_blank", "noopener,noreferrer");
});
document.querySelector("#opsSaveCsv")?.addEventListener("click", () => saveCsvFiles?.click());
document.querySelector("#opsResetWorkflow")?.addEventListener("click", resetWorkflowToStart);
document.querySelector("#opsSetNextTwoPages")?.addEventListener("click", () => setOpsNextCapturePages(2));
document.querySelector("#opsSetNextFivePages")?.addEventListener("click", () => setOpsNextCapturePages(5));
document.querySelector("#opsSetFullRealproPages")?.addEventListener("click", setOpsCapturePagesToFull);
opsRealproCapturePages?.addEventListener("input", () => {
  syncOpsCapturePageInput(opsRealproCapturePages);
  updateOpsCaptureRangeSummary();
});
realproCapturePages?.addEventListener("input", () => {
  syncOpsCapturePageInput(realproCapturePages);
  updateOpsCaptureRangeSummary();
});
checkVerificationBasic?.addEventListener("click", handleVerificationBasicCheck);
checkVerificationJson?.addEventListener("click", handleVerificationJsonCheck);
checkVerificationRules?.addEventListener("click", handleVerificationRulesCheck);
checkChromeTabs?.addEventListener("click", handleChromeTabsCheck);
opsCheckTabs?.addEventListener("click", handleChromeTabsCheck);
checkServerStatus?.addEventListener("click", handleServerStatusCheck);
copyCurrentServerUrl?.addEventListener("click", async () => {
  const url = serverIndexUrl();
  const copied = await copyTextToClipboard(url);
  if (currentServerUrl) {
    currentServerUrl.textContent = copied ? `${url} をコピーしました` : url;
    setTimeout(renderCurrentServerUrl, 1800);
  }
});
reloadCurrentPage?.addEventListener("click", () => {
  if (location.protocol === "file:") {
    location.href = serverIndexUrl();
    return;
  }
  location.reload();
});
clearCurrentCapture?.addEventListener("click", handleCurrentCaptureClear);
realproLoggedIn?.addEventListener("change", saveLoginCheck);
eSeikatsuLoggedIn?.addEventListener("change", saveLoginCheck);
eSeikatsuListingOpen?.addEventListener("change", saveLoginCheck);
realproCapturePages?.addEventListener("change", () => {
  clearCurrentSearchPresetName();
  saveSearchConditions();
  renderCapturePlan();
});
realproCapturePages?.addEventListener("input", renderCapturePlan);
realproStartPage?.addEventListener("change", () => {
  clearCurrentSearchPresetName();
  saveSearchConditions();
  renderCapturePlan();
});
realproStartPage?.addEventListener("input", renderCapturePlan);
eSeikatsuCapturePages?.addEventListener("change", () => {
  clearCurrentSearchPresetName();
  saveSearchConditions();
  renderCapturePlan();
});
eSeikatsuCapturePages?.addEventListener("input", renderCapturePlan);
saveSearchPreset?.addEventListener("click", saveCurrentSearchPreset);
loadSearchPreset?.addEventListener("click", loadSelectedSearchPreset);
deleteSearchPreset?.addEventListener("click", deleteSelectedSearchPreset);
applyConditionJson?.addEventListener("click", handleConditionJsonApply);
clearConditionJson?.addEventListener("click", () => {
  if (conditionJsonInput) conditionJsonInput.value = "";
});
searchPresetSelect?.addEventListener("change", () => {
  const preset = readSearchPresets().find((item) => item.id === searchPresetSelect.value);
  if (searchPresetName) searchPresetName.value = preset?.name ?? "";
});
productionMemo?.addEventListener("input", saveProductionMemo);
clearProductionMemo?.addEventListener("click", clearProductionMemoText);
document.querySelectorAll('input[name="productionChecklist"]').forEach((input) => {
  input.addEventListener("change", saveProductionChecklist);
});
completeProductionChecklist?.addEventListener("click", completeProductionChecklistItems);
resetProductionChecklist?.addEventListener("click", resetProductionChecklistItems);

showExcludedToggle.addEventListener("change", () => {
  refreshCandidateRows("表示対象を変更したため、候補を自動更新しました。");
});

resultTypeFilter?.addEventListener("change", () => {
  renderPreview(latestRows);
});

resultTextFilter?.addEventListener("input", () => {
  renderPreview(latestRows);
});

clearResultFilters?.addEventListener("click", () => {
  if (resultTypeFilter) resultTypeFilter.value = "";
  if (resultTextFilter) resultTextFilter.value = "";
  renderPreview(latestRows);
});

resultTypeSummary?.addEventListener("click", (event) => {
  const button = event.target.closest("[data-result-type]");
  if (!button || !resultTypeFilter) return;
  const nextType = button.dataset.resultType;
  resultTypeFilter.value = resultTypeFilter.value === nextType ? "" : nextType;
  renderPreview(latestRows);
});

actionSummary?.addEventListener("click", (event) => {
  const button = event.target.closest("[data-action-query]");
  if (!button || !resultTextFilter) return;
  const nextQuery = button.dataset.actionQuery;
  resultTextFilter.value = resultTextFilter.value === nextQuery ? "" : nextQuery;
  renderPreview(latestRows);
});

completionToastAction?.addEventListener("click", () => {
  hideCompletionToast();
  scrollToCandidateSummaryPanel();
});
completionToastClose?.addEventListener("click", (event) => {
  event.stopPropagation();
  hideCompletionToast();
});
updateNowButton?.addEventListener("click", () => {
  hideUpdateToast();
  openUpdateDownload();
});
updateLaterButton?.addEventListener("click", () => {
  hideUpdateToast();
});
updateStatusButton?.addEventListener("click", () => {
  showUpdateToast();
});

captureFile.addEventListener("change", handleCaptureFile);
document.addEventListener("capture-data-import", (event) => {
  importCaptureData(event.detail?.data, event.detail?.filename);
});

applyUiModeFromUrl();
placeConditionBuilderAtTop();
placeCandidateResultsNearTop();
renderRuntimeNotice();
renderCurrentServerUrl();
refreshServerUrlStatus();
renderCsvSchemaVersion();
restoreLoginChecks();
renderReadinessStatus();
restoreProductionChecklist();
restoreProductionMemo();
renderImportHistory();
renderPreflightHistory();
renderChromeTabHistory();
renderCsvHistory();
renderConditionRestoreHistory();
renderFreshnessReviewHistory();
renderCaptureQualityReviewHistory();
renderDetailUnconfirmedReviewHistory();
loadSavedCsvLinks();
renderCapturePlan();
syncOpsCapturePageInput(realproCapturePages);
renderRailwayChoices();
renderSearchPresets();
restoreSearchConditions();
restoreCurrentSearchPresetName();
restoreLastRealproSearchResult();
updateStationVisibility();
setCsvControls();
latestRows = [];
renderPreview(latestRows);
updateSelectedConditions();
initializeStartupState();
