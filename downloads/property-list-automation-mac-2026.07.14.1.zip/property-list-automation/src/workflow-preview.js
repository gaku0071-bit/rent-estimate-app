const states = {
  setup: {
    topbar: "準備確認中",
    activeStep: "setup",
    label: "ステップ1 / 準備",
    title: "リアプロといい生活を開きます",
    text: "ログイン済みのChromeで、リアプロのリスト検索といい生活の物件広告一覧を開きます。",
    primary: "リアプロを開く",
    secondary: "いい生活を開く",
    progressState: "待機中",
    progressTitle: "取得開始前",
    progress: 0,
    remaining: "-",
    realpro: "未確認",
    judged: "0 / 0",
    candidates: "0件",
    eseikatsu: "全件待ち",
    message: "準備が終わると、ここに取得中の進み具合が表示されます。",
    checks: {},
    notices: ["リアプロといい生活を開いてから準備確認に進みます。"],
    counts: ["-", "-", "-"],
    csv: ["未作成", "候補完成後に保存できます"],
    rows: [],
  },
  conditions: {
    topbar: "検索条件を準備中",
    activeStep: "conditions",
    label: "ステップ2 / 条件入力",
    title: "検索条件をリアプロに反映します",
    text: "沿線・駅、間取、賃料、徒歩分数、設備、駐車場条件をシステム側で確認してからリアプロへ反映します。",
    primary: "リアプロへ条件反映",
    secondary: "条件を保存",
    progressState: "条件確認",
    progressTitle: "東西線 琴似〜西18丁目",
    progress: 12,
    remaining: "-",
    realpro: "未検索",
    judged: "0 / 0",
    candidates: "0件",
    eseikatsu: "2973件",
    message: "条件を反映したら、リアプロ画面で件数を目視確認します。",
    checks: { realpro: true, eSeikatsu: true, conditions: false, count: false },
    notices: ["検索条件はCSVにも残ります。", "反映後はリアプロ側の件数表示を確認します。"],
    counts: ["-", "-", "-"],
    csv: ["未作成", "候補完成後に保存できます"],
    rows: [],
  },
  confirm: {
    topbar: "リアプロ件数確認",
    activeStep: "confirm",
    label: "ステップ3 / リアプロ確認",
    title: "リアプロの検索結果件数を確認します",
    text: "条件反映後のリアプロ画面で、検索結果が実務サイズまで絞れているか確認します。",
    primary: "件数確認済みにする",
    secondary: "条件を戻す",
    progressState: "目視確認",
    progressTitle: "リアプロ検索結果 74棟104戸",
    progress: 26,
    remaining: "-",
    realpro: "104戸",
    judged: "0 / 104",
    candidates: "未判定",
    eseikatsu: "2973件",
    message: "件数が大きすぎる場合は、リアプロ条件を絞ってから取得します。",
    checks: { realpro: true, eSeikatsu: true, conditions: true, count: false },
    notices: ["全20,879戸のままならCSV保存は止めます。", "今回の例では104戸まで絞れています。"],
    counts: ["-", "-", "-"],
    csv: ["未作成", "候補完成後に保存できます"],
    rows: [],
  },
  running: {
    topbar: "候補作成中",
    activeStep: "running",
    label: "ステップ4 / 取得・照合",
    title: "リアプロ詳細を確認しています",
    text: "WEB広告掲載、電子入居申込、いい生活掲載状況を号室単位で照合しています。",
    primary: "進行状況を見る",
    secondary: "停止",
    progressState: "詳細確認中",
    progressTitle: "100 / 104戸を判定",
    progress: 96,
    remaining: "約7秒",
    realpro: "104戸",
    judged: "100 / 104",
    candidates: "69件",
    eseikatsu: "2973件",
    message: "候補見込みは詳細確認の進行に合わせて増減します。",
    checks: { realpro: true, eSeikatsu: true, conditions: true, count: true },
    notices: ["管理会社確認は候補に残して確認用に分けます。", "WEB広告掲載不可と申込ありは除外します。"],
    counts: ["集計中", "集計中", "集計中"],
    csv: ["未作成", "取得完了後に保存できます"],
    rows: [],
  },
  complete: {
    topbar: "CSV作成完了",
    activeStep: "complete",
    label: "ステップ5 / CSV完成",
    title: "現場用CSVが完成しました",
    text: "作業対象と確認後判断に分けて、登録作業に使うCSVを保存しました。",
    primary: "現場用CSVを開く",
    secondary: "もう一度取得",
    progressState: "完了",
    progressTitle: "104戸を取得・照合しました",
    progress: 100,
    remaining: "完了",
    realpro: "104戸",
    judged: "104 / 104",
    candidates: "4件",
    eseikatsu: "2973件",
    message: "最新CSV確認OK。いい生活で募集中の同一号室は候補に含まれていません。",
    checks: { realpro: true, eSeikatsu: true, conditions: true, count: true },
    notices: ["作業対象3件、管理会社確認1件です。", "管理会社確認は登録前にWEB広告掲載可否を確認します。"],
    counts: ["3", "1", "12"],
    csv: ["保存済み", "latest-practical.csv / 4件"],
    rows: [
      ["作業対象", "ヴィラ琴似 涼 303号室", "2LDK / 76,000円", "いい生活未登録・リアプロで募集あり"],
      ["作業対象", "ブランノワール円 0402号室", "1LDK / 54,000円", "いい生活未登録・リアプロで募集あり"],
      ["作業対象", "スペチアーレ420 505号室", "1LDK / 89,000円", "掲載中501号室はリアプロで掲載なし"],
      ["確認後判断", "リアンジュ・宮の森 405号室", "2LDK / 73,000円", "WEB広告掲載は管理会社に確認"],
    ],
  },
};

const stateOrder = ["setup", "conditions", "confirm", "running", "complete"];
let currentState = "setup";

const sapporoRoutes = {
  "地下南北線": ["麻生", "北34条", "北24条", "北18条", "北12条", "さっぽろ", "大通", "すすきの", "中島公園", "幌平橋", "中の島", "平岸", "南平岸", "澄川", "自衛隊前", "真駒内"],
  "地下東西線": ["宮の沢", "発寒南", "琴似", "二十四軒", "西28丁目", "円山公園", "西18丁目", "西11丁目", "大通", "バスセンター前", "菊水", "東札幌", "白石", "南郷7丁目", "南郷13丁目", "南郷18丁目", "大谷地", "ひばりが丘", "新さっぽろ"],
  "地下東豊線": ["栄町", "新道東", "元町", "環状通東", "東区役所前", "北13条東", "さっぽろ", "大通", "豊水すすきの", "学園前", "豊平公園", "美園", "月寒中央", "福住"],
  "札幌市電": ["西4丁目", "西8丁目", "中央区役所前", "西15丁目", "西線6条", "西線9条旭山公園通", "西線11条", "西線14条", "西線16条", "ロープウェイ入口", "電車事業所前", "中央図書館前", "石山通", "東屯田通", "幌南小学校前", "山鼻19条", "静修学園前", "行啓通", "中島公園通", "山鼻9条", "東本願寺前", "資生館小学校前", "すすきの", "狸小路"],
  "JR函館本線": ["ほしみ", "星置", "稲穂", "手稲", "稲積公園", "発寒", "発寒中央", "琴似", "桑園", "札幌", "苗穂", "白石", "厚別", "森林公園"],
  "JR千歳線": ["苗穂", "白石", "平和", "新札幌", "上野幌"],
  "JR札沼線": ["札幌", "桑園", "八軒", "新川", "新琴似", "太平", "百合が原", "篠路", "拓北", "あいの里教育大", "あいの里公園"],
};

const defaultStationSelection = new Set(["地下東西線:琴似", "地下東西線:二十四軒", "地下東西線:西28丁目", "地下東西線:円山公園", "地下東西線:西18丁目"]);

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

function setText(selector, text) {
  const node = $(selector);
  if (node) node.textContent = text;
}

function renderState(name) {
  const state = states[name] || states.setup;
  currentState = name;
  document.body.dataset.state = name;

  setText("#topbarState", state.topbar);
  setText("#stageLabel", state.label);
  setText("#actionTitle", state.title);
  setText("#actionText", state.text);
  setText("#primaryAction", state.primary);
  setText("#secondaryAction", state.secondary);
  setText("#progressState", state.progressState);
  setText("#progressTitle", state.progressTitle);
  setText("#remainingTime", state.remaining);
  setText("#metricRealpro", state.realpro);
  setText("#metricJudged", state.judged);
  setText("#metricCandidates", state.candidates);
  setText("#metricESeikatsu", state.eseikatsu);
  setText("#progressMessage", state.message);
  setText("#workCount", state.counts[0]);
  setText("#reviewCount", state.counts[1]);
  setText("#excludedCount", state.counts[2]);

  $("#progressBar")?.style.setProperty("--progress", `${state.progress}%`);
  $("#progressPanel")?.setAttribute("data-mode", name === "running" ? "running" : "");

  $$(".preview-tabs button").forEach((button) => {
    button.classList.toggle("is-active", button.dataset.previewState === name);
  });

  const activeIndex = stateOrder.indexOf(state.activeStep);
  $$(".step-rail li").forEach((item) => {
    const itemIndex = stateOrder.indexOf(item.dataset.step);
    item.classList.toggle("is-active", item.dataset.step === state.activeStep);
    item.classList.toggle("is-done", itemIndex >= 0 && activeIndex >= 0 && itemIndex < activeIndex);
  });

  renderChecks(state.checks);
  renderNotices(state.notices);
  renderCsv(state.csv);
  renderRows(state.rows);
  updateConditionSummary();
}

function renderChecks(checks = {}) {
  const map = {
    realpro: ["#checkRealpro", "リアプロ一覧OK", "未確認"],
    eSeikatsu: ["#checkESeikatsu", "いい生活全件OK", "未確認"],
    conditions: ["#checkConditions", "条件反映OK", "未反映"],
    count: ["#checkCount", "104戸を確認", "未確認"],
  };
  Object.entries(map).forEach(([key, [selector, okText, ngText]]) => {
    const node = $(selector);
    if (!node) return;
    const ok = Boolean(checks[key]);
    node.classList.toggle("is-ok", ok);
    const small = node.querySelector("small");
    if (small) small.textContent = ok ? okText : ngText;
  });
}

function renderNotices(notices = []) {
  const list = $("#noticeList");
  if (!list) return;
  list.innerHTML = notices
    .map((text) => `<p${/止め|確認|大きすぎ/.test(text) ? ' class="is-warn"' : ""}>${escapeHtml(text)}</p>`)
    .join("");
}

function renderCsv(csv = []) {
  const state = $("#csvState");
  if (!state) return;
  state.innerHTML = `<strong>${escapeHtml(csv[0] || "未作成")}</strong><span>${escapeHtml(csv[1] || "")}</span>`;
}

function renderRows(rows = []) {
  const tbody = $("#candidateRows");
  if (!tbody) return;
  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="4" class="empty-row">候補作成後に表示されます</td></tr>`;
    return;
  }
  tbody.innerHTML = rows.map(([work, room, condition, result]) => `
    <tr>
      <td><span class="work-pill ${work === "作業対象" ? "work" : "review"}">${escapeHtml(work)}</span></td>
      <td>${escapeHtml(room)}</td>
      <td>${escapeHtml(condition)}</td>
      <td>${escapeHtml(result)}</td>
    </tr>
  `).join("");
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  }[char]));
}

function nextState() {
  const index = stateOrder.indexOf(currentState);
  renderState(stateOrder[Math.min(index + 1, stateOrder.length - 1)] || "setup");
}

function checkedLabelTexts(selector) {
  return $$(selector)
    .filter((input) => input.checked)
    .map((input) => input.parentElement?.textContent?.trim() || "")
    .filter(Boolean);
}

function updateConditionSummary() {
  const chips = $("#selectedConditionChips");
  if (!chips) return;
  const selected = [];
  selected.push(...checkedLabelTexts(".route-selector input[type='checkbox']"));
  const stations = checkedLabelTexts(".station-picker input[type='checkbox']");
  if (stations.length) {
    selected.push(stations.length >= 5 ? `${stations[0]}〜${stations[stations.length - 1]}` : stations.join(" / "));
  }
  selected.push(...checkedLabelTexts(".condition-form .form-block:not(.form-block-wide) input[type='checkbox']"));

  const rentInputs = $$(".range-row input").map((input) => input.value.trim()).filter(Boolean);
  if (rentInputs.length === 2) selected.push(`${rentInputs[0]}〜${rentInputs[1]}万円`);
  const activeAccess = $(".segmented button.is-selected")?.textContent?.trim() || "徒歩";
  const minutes = $(".minute-input input")?.value?.trim();
  if (minutes) selected.push(`${activeAccess}${minutes}分以内`);

  chips.innerHTML = [...new Set(selected)]
    .map((text) => `<span>${escapeHtml(text)}</span>`)
    .join("");
}

function selectedRouteNames() {
  return $$(".route-selector input[type='checkbox']")
    .filter((input) => input.checked)
    .map((input) => input.value)
    .filter(Boolean);
}

function renderStationPicker() {
  const picker = $("#stationPicker");
  if (!picker) return;
  const selectedRoutes = selectedRouteNames();
  if (!selectedRoutes.length) {
    picker.innerHTML = `<div class="station-group-preview"><div class="station-group-heading"><strong>駅候補</strong><small>路線を選択してください</small></div></div>`;
    updateConditionSummary();
    return;
  }

  picker.innerHTML = selectedRoutes.map((route) => {
    const stations = sapporoRoutes[route] || [];
    return `
      <div class="station-group-preview" data-route="${escapeHtml(route)}">
        <div class="station-group-heading">
          <strong>${escapeHtml(route)}の駅</strong>
          <small>${stations.length}駅</small>
        </div>
        <div class="station-chip-row">
          ${stations.map((station) => {
            const key = `${route}:${station}`;
            const checked = defaultStationSelection.has(key) ? " checked" : "";
            return `<label class="check-pill"><input type="checkbox" value="${escapeHtml(key)}"${checked} />${escapeHtml(station)}</label>`;
          }).join("")}
        </div>
      </div>
    `;
  }).join("");

  $$("#stationPicker input").forEach((input) => {
    input.addEventListener("change", updateConditionSummary);
  });
  updateConditionSummary();
}

$$(".preview-tabs button").forEach((button) => {
  button.addEventListener("click", () => renderState(button.dataset.previewState));
});

$("#primaryAction")?.addEventListener("click", nextState);
$("#secondaryAction")?.addEventListener("click", () => {
  if (currentState === "complete") renderState("confirm");
  else nextState();
});

$(".mini-button")?.addEventListener("click", () => {
  $$(".station-picker input[type='checkbox']").forEach((input) => {
    input.checked = true;
  });
  updateConditionSummary();
});

$$(".condition-builder input").forEach((input) => {
  input.addEventListener("input", updateConditionSummary);
  input.addEventListener("change", updateConditionSummary);
});

$$(".route-selector input").forEach((input) => {
  input.addEventListener("change", renderStationPicker);
});

$$(".segmented button").forEach((button) => {
  button.addEventListener("click", () => {
    $$(".segmented button").forEach((item) => item.classList.toggle("is-selected", item === button));
    updateConditionSummary();
  });
});

renderStationPicker();
renderState("setup");
