const views = [...document.querySelectorAll("[data-view]")];
const previewButtons = [...document.querySelectorAll("[data-preview]")];
const connectionBand = document.querySelector(".connection-band");
const statusLabels = [...document.querySelectorAll(".status-label")];
const progressBar = document.querySelector("#progressBar");
const currentCount = document.querySelector("#currentCount");
const totalCount = document.querySelector("#totalCount");
const progressPercent = document.querySelector("#progressPercent");
const remainingTime = document.querySelector("#remainingTime");
const realproProgress = document.querySelector("#realproProgress");
const loadingTitle = document.querySelector("#loadingTitle");
const processItems = [
  document.querySelector("#processRealpro"),
  document.querySelector("#processDetail"),
  document.querySelector("#processESeikatsu"),
  document.querySelector("#processCandidate"),
];
const serviceButtons = [...document.querySelectorAll("[data-service-open]")];
const checkButton = document.querySelector('[data-action="check"]');
const toast = document.querySelector(".preview-toast");

let timer = null;
let openedServices = new Set();
let toastTimer = null;

function showToast(message) {
  clearTimeout(toastTimer);
  toast.textContent = message;
  toast.hidden = false;
  toastTimer = setTimeout(() => {
    toast.hidden = true;
  }, 2400);
}

function showView(name) {
  clearInterval(timer);
  views.forEach((view) => {
    view.hidden = view.dataset.view !== name;
  });
  previewButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.preview === name);
  });
  const connected = name !== "ready";
  connectionBand.classList.toggle("connected", connected);
  if (connected) statusLabels.forEach((label) => { label.textContent = "接続済み"; });
  if (name === "loading") startLoadingDemo();
}

function startLoadingDemo() {
  let step = 0;
  const frames = [
    { title: "リアプロの部屋情報を取得しています", current: 7, total: 23, percent: 30, eta: "約 2分40秒", stage: 0 },
    { title: "WEB広告と申込状況を確認しています", current: 14, total: 23, percent: 48, eta: "約 1分55秒", stage: 1 },
    { title: "いい生活の掲載情報と照合しています", current: 1820, total: 3248, percent: 68, eta: "約 1分10秒", stage: 2 },
    { title: "登録候補を整理しています", current: 21, total: 23, percent: 91, eta: "約 15秒", stage: 3 },
  ];

  function renderFrame(frame) {
    loadingTitle.textContent = frame.title;
    currentCount.textContent = frame.current.toLocaleString("ja-JP");
    totalCount.textContent = frame.total.toLocaleString("ja-JP");
    progressPercent.textContent = `${frame.percent}%`;
    progressBar.style.width = `${frame.percent}%`;
    remainingTime.textContent = frame.eta;
    realproProgress.textContent = frame.stage === 0 ? `${frame.current} / ${frame.total}件` : "23 / 23件";
    processItems.forEach((item, index) => {
      item.classList.toggle("done", index < frame.stage);
      item.classList.toggle("active", index === frame.stage);
    });
  }

  renderFrame(frames[step]);
  timer = setInterval(() => {
    step += 1;
    if (step >= frames.length) {
      clearInterval(timer);
      showView("complete");
      return;
    }
    renderFrame(frames[step]);
  }, 1800);
}

previewButtons.forEach((button) => {
  button.addEventListener("click", () => showView(button.dataset.preview));
});

serviceButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const service = button.dataset.serviceOpen;
    openedServices.add(service);
    const article = button.closest(".service-status");
    article.querySelector(".status-label").textContent = "確認済み";
    button.textContent = "開きました";
    button.disabled = true;
    checkButton.disabled = openedServices.size < serviceButtons.length;
    showToast(`${article.querySelector("strong").textContent}を確認しました`);
  });
});

checkButton.addEventListener("click", () => showView("connected"));
document.querySelector('[data-action="start"]').addEventListener("click", () => showView("loading"));
document.querySelector('[data-action="show-results"]').addEventListener("click", () => showView("results"));
document.querySelector('[data-action="back-complete"]').addEventListener("click", () => showView("complete"));
document.querySelector('[data-action="save-csv"]').addEventListener("click", () => {
  showToast("プレビュー：候補リスト.csv を保存しました");
});

showView("ready");
