# セットアップ手順

## 必要なもの

- Google Chrome
- Node.js LTS と npm
- Python 3

このMacのようにCodex同梱Nodeが利用できる環境では、Mac用 `.command` ファイルが同梱Nodeを自動で使う。
その場合、画面起動と基本確認だけなら `npm` のインストールは不要。

## Mac

### 画面だけ起動する

普段はプロジェクト直下の `物件候補リスト作成.command` を開く。
Mac用 `.command` は、Codex同梱Nodeがあればそれを使い、なければ通常の `node` を探す。
既に8765〜8775番でこのシステムが起動している場合は、そのURLを自動で開く。

コマンドで起動する場合:

```bash
cd property-list-automation
npm install
npm start
```

表示されたURLをChromeで開く。標準は `http://127.0.0.1:8765/index.html` だが、8765番が使用中の場合は8766番以降を自動で試す。

`src/index.html` を直接開く `file://` 表示でも画面確認はできるが、Chrome取得、最新JSON読み込み、検証サンプル読み込みはローカルサーバー版で行う。
画面の `サーバー確認` を押して `サーバー確認OKです` と表示されれば準備完了。必要ファイル、Chrome、MacではPython3の状態も同じ表示で確認できる。

### npmがない場合

このMacのように `npm` がない環境では、`automation/run_mac.command` またはプロジェクト直下の `物件候補リスト作成.command` を開く。
どちらも見つからない場合だけ、Node.js LTSのインストールが必要。

サンプルJSON・検証ルール・ドキュメントをまとめて確認する場合は、プロジェクト直下の `総合確認.command` を開く。
実データ取得前にまとめて確認する場合は、プロジェクト直下の `本番前確認.command` を開く。
このPCの準備状態を確認する場合は、プロジェクト直下の `環境確認.command` を開く。
画面操作とCSV生成まで確認する場合は、プロジェクト直下の `CSV生成確認.command` を開く。
動いているローカルサーバーが最新コードと一致しているか確認する場合は、プロジェクト直下の `サーバー確認.command` を開く。
検証サンプルJSONだけ確認する場合は、プロジェクト直下の `検証サンプルJSON確認.command` を開く。
検証ルールJSONだけ確認する場合は、プロジェクト直下の `検証ルールJSON確認.command` を開く。
ドキュメント整合性だけ確認する場合は、プロジェクト直下の `ドキュメント確認.command` を開く。

## Windows

普段はプロジェクト直下の `物件候補リスト作成.bat` を開く。
初回は必要部品を自動でインストールし、Windows取得専用Chrome、Chrome接続ブリッジ、画面サーバーを起動する。
既に8765〜8775番でこのシステムが起動している場合は、そのURLを自動で開く。

PowerShellで次を実行する。

```powershell
cd property-list-automation
.\automation\run_windows.ps1
```

起動後、ブラウザで表示されたURLを開く。標準は `http://127.0.0.1:8765/index.html`。

Windowsでは通常のChromeとは別に、`data/chrome-profile-windows` を使う取得専用Chromeが開く。初回だけ、そのChromeでリアプロといい生活へログインする。ログイン情報はChrome側へ保存され、システム側には保存されない。

Windows PowerShell 5で日本語を正しく読み取れるよう、同梱する `.ps1` はUTF-8 BOM付きで配布する。

Python 3をインストールする場合は、インストーラーの `Add Python to PATH` をオンにする。

Chrome接続経路を単独で確認する場合:

プロジェクト直下の `Windows接続確認.bat` を開く。PowerShellから実行する場合:

```powershell
npm run verify:chrome-bridge
```

`Chrome接続統合確認: OK` と表示されれば、ChromeとPythonの共通接続経路は動作している。

検証サンプルJSONだけ確認する場合は、プロジェクト直下の `検証サンプルJSON確認.bat` を開く。
実データ取得前にまとめて確認する場合は、プロジェクト直下の `本番前確認.bat` を開く。
このPCの準備状態を確認する場合は、プロジェクト直下の `環境確認.bat` を開く。
画面操作とCSV生成まで確認する場合は、プロジェクト直下の `CSV生成確認.bat` を開く。
検証ルールJSONだけ確認する場合は、プロジェクト直下の `検証ルールJSON確認.bat` を開く。

## 初回ログイン

1. `物件候補リスト作成.command` または `物件候補リスト作成.bat` から起動したChromeでリアプロを開く。
2. 同じChromeでいい生活を開く。
3. それぞれログインする。
4. Chromeのパスワード保存を使う。

システム側ではID・パスワードを保存しない。

## Mac Chrome取得の追加設定

Macで `Chromeから取得して読み込み` を使う場合は、Chromeで次をオンにする。

`表示` > `デベロッパー` > `Apple Events からのJavaScriptを許可`

## 起動後の確認

1. 画面で `検証サンプルを読み込み` を押す。
2. `検証サンプル確認: OK` と表示されることを確認する。
3. コマンド確認できる環境では次も実行する。

```bash
npm run verify:sample
```

ブラウザなしで検証サンプルJSONだけ確認する場合:

```bash
npm run verify:sample-json
```

必須項目と想定ドメインのルールだけ確認する場合:

```bash
npm run verify:rules
```
