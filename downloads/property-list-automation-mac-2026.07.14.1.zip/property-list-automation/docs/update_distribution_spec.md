# アップデート・配布・クラウド管理仕様書

作成日: 2026-07-04

## 目的

物件候補リスト作成システムを、Mac版・Windows版ともに継続的に更新できるようにする。

新しいPCへ導入する時の手順を簡単にし、アップデートがある場合はユーザー側へ通知して、利用者が迷わず更新できる状態を目指す。

## 基本方針

完全クラウド化ではなく、まずは `クラウド管理 + 各PCで取得処理` のハイブリッド型にする。

サーバー側では最新版情報、ダウンロードファイル、更新履歴、導入ページを管理する。

各PC側では、リアプロ・いい生活へログイン済みのChromeを使い、物件情報の取得、照合、候補リスト作成、CSV保存を行う。

## この方式を採用する理由

リアプロ・いい生活の取得は、ログイン済みChromeが必要になる。

すべてをクラウドサーバー側で実行すると、次のリスクがある。

- リアプロ・いい生活のID、パスワード管理が必要になる
- 2段階認証やログイン確認で止まりやすい
- サーバーIPからのアクセスが不審ログイン扱いになる可能性がある
- 実務データをすべてクラウドに置くリスクがある
- Chrome操作、拡張機能、ログインセッションの安定性が落ちる

そのため、取得処理は各PCに残し、配布・更新・状態確認をクラウド側で支援する。

## 運用体制

このMacを開発・配布元とする。

通常の流れ:

1. このMacでシステムを修正する
2. Mac版として動作確認する
3. Windows版インストーラーをこのMacで作成する
4. サーバーに最新版ファイルを配置する
5. サーバー上の最新版情報を更新する
6. 各PCのシステム起動時にアップデート確認する
7. 新しい版があればユーザーに通知する
8. ユーザーが `今すぐ更新` を押した場合だけ更新する

Windows実機でしか確認できない箇所は、Windows側の診断機能で確認できるようにする。

## 対象環境

- macOS
- Windows
- Google Chrome
- リアプロ ブラウザ版
- いい生活賃貸クラウド ブラウザ版

## サーバー側で管理するもの

サーバー側には以下を置く。

- Mac版の最新版ファイル
- Windows版の最新版ファイル
- 最新版情報JSON
- 更新履歴
- 導入ページ
- 操作マニュアル
- 必要に応じて診断結果の受信API
- 必要に応じてログ送信用API

サーバーが静的ファイル配信だけの場合でも、アップデート通知とダウンロード配布は可能。

診断結果やログをサーバーへ送る場合は、受信用APIが必要になる。

現行の公開方法:

- 更新通知用JSONとダウンロードファイルは GitHub の `property-list-updates` ブランチに置く
- システムが読む最新版情報は `raw.githubusercontent.com` の `update-manifest.json` を使う
- 利用者が見る導入ページは、同じ `index.html` をHTMLとして表示できるURLで開く
- Windows実機テスト後、警告表示や拡張機能の案内文を導入ページに反映する

## 最新版情報JSON

サーバーに `update-manifest.json` のようなファイルを置く。

現行実装では、ローカル確認用に `updates/update-manifest.json` を持つ。

本番サーバーの最新版情報を使う場合は、各PCの `updates/update-settings.json` に `manifestUrl` を保存する。

例:

```bash
npm run update:set-url -- --url=https://example.com/update-manifest.json
```

一時的に環境変数で指定することもできる。

例:

```bash
UPDATE_MANIFEST_URL=https://example.com/update-manifest.json npm start
```

例:

```json
{
  "schemaVersion": 1,
  "publishedAt": "2026-07-04T09:00:00+09:00",
  "windows": {
    "version": "2026.07.04.1",
    "url": "https://example.com/downloads/property-list-automation-windows-2026.07.04.1.exe",
    "sha256": "任意",
    "packageType": "exe",
    "fileName": "property-list-automation-windows-2026.07.04.1.exe",
    "required": false,
    "notes": [
      "いい生活全件取得を高速化",
      "候補リスト表示の安定性を改善"
    ]
  },
  "mac": {
    "version": "2026.07.04.1",
    "url": "https://example.com/downloads/property-list-automation-mac-20260704.zip",
    "sha256": "任意",
    "packageType": "zip",
    "fileName": "property-list-automation-mac-20260704.zip",
    "required": false,
    "notes": [
      "いい生活全件取得を高速化",
      "候補リスト表示の安定性を改善"
    ]
  }
}
```

## PC側で持つバージョン情報

各PCのシステム内に、現在のバージョンを記録する。

例:

```json
{
  "version": "2026.07.03.1",
  "platform": "windows",
  "channel": "stable",
  "installedAt": "2026-07-03T08:30:00+09:00"
}
```

## 更新サーバーURL設定

各PCが見に行く更新情報URLは、`updates/update-settings.json` に保存する。

例:

```json
{
  "schemaVersion": 1,
  "manifestUrl": "https://example.com/update-manifest.json"
}
```

設定方法:

```bash
npm run update:set-url -- --url=https://example.com/update-manifest.json
```

空に戻す場合:

```bash
npm run update:set-url -- --clear
```

Macでは `更新サーバーURL設定.command`、Windowsでは `SET_UPDATE_SERVER_URL.bat` から対話入力でも設定できる。

優先順:

1. 環境変数 `UPDATE_MANIFEST_URL`
2. `updates/update-settings.json` の `manifestUrl`
3. ローカル確認用 `updates/update-manifest.json`

## アップデート通知

システム起動時に最新版を確認する。

新しいバージョンがある場合、画面にポップアップ通知を出す。

通知タイトル:

`新しいアップデートがあります`

通知本文:

- 現在のバージョン
- 最新版
- 更新内容

ボタン:

- `今すぐ更新`
- `あとで`

## `今すぐ更新` の動き

ユーザーが `今すぐ更新` を押した場合:

1. 更新前チェックを行う
2. 現在のシステム本体を `backups/update-YYYYMMDD-HHMMSS` にバックアップする
3. 最新版ファイルを `updates/downloads` にダウンロードする
4. SHA-256が指定されている場合は検証する
5. ZIP形式の場合は `updates/staged` へ展開し、必須ファイルを確認する
6. ZIP形式の場合は更新対象ファイルを入れ替える
7. ユーザー固有データは残す
8. 更新完了を表示する
9. システム再起動を案内する

## `あとで` の動き

ユーザーが `あとで` を押した場合:

1. ポップアップを閉じる
2. その回の作業はそのまま続けられる
3. 画面右上に `アップデートあり` の小さな表示を残す
4. 次回起動時にも再通知する

強制アップデートが必要な場合は、最新版情報JSONの `required` を `true` にする。

現行の初期実装では、`今すぐ更新` は更新前バックアップを作成してから、更新ファイルをダウンロードし、ZIP形式は一時展開、必須ファイル確認、本体入れ替え、再起動案内まで行う。

Windowsインストーラーexeの場合は、自動展開せず、取得確認後にインストーラーを手動実行する。

インストーラーexeの自動サイレント更新は次段階で検討する。

更新途中で失敗した場合は、更新前に作成した `backups/update-YYYYMMDD-HHMMSS` から本体ファイルを復元できる。

復元後も、反映のためにシステム再起動を案内する。

## 更新時に残すもの

アップデートしても次のデータは削除しない。

- Chromeログインプロファイル
- リアプロ・いい生活のログイン状態
- Windowsの `data/chrome-profile-windows`
- MacのChromeログイン状態
- 取得済みデータ
- CSV出力
- ログ
- 各PC固有の設定
- 保存済み検索条件

## 更新時に入れ替えるもの

アップデートで入れ替える対象:

- `src`
- `automation`
- `extension`
- `docs`
- `.bat`
- `.command`
- 判定ロジック
- UI
- サンプル検証データ

## 更新前バックアップ

更新前に自動バックアップを作成する。

バックアップ例:

`backups/update-20260704-090000`

バックアップ対象:

- 旧バージョンの本体ファイル
- 更新前の設定ファイル
- 更新前のバージョン情報

実務データは削除せず残す。

## 更新失敗時の復元

更新失敗時は、更新前バックアップから本体ファイルを復元する。

復元対象:

- `src`
- `automation`
- `extension`
- `docs`
- `.bat`
- `.command`
- `app-version.json`
- `package.json`
- `updates/update-manifest.json`

復元しても残すもの:

- `data`
- `exports`
- `outputs`
- `backups`
- `updates/downloads`
- `updates/staged`

復元後はシステム再起動を案内する。

## 更新フロー自動確認

配布前に、更新機能そのものが壊れていないかを確認する。

確認コマンド:

```bash
npm run verify:update-flow
```

Macでは `更新フロー確認.command`、Windowsでは `UPDATE_FLOW_CHECK_WINDOWS.bat` からも実行できる。

確認内容:

- 一時フォルダに検証用システムをコピーする
- 検証用ローカルサーバーを起動する
- テスト用ZIPを作成する
- 更新前バックアップを作成する
- ZIPをダウンロードする
- SHA-256を確認する
- ZIPを展開して必須ファイルを確認する
- 適用前チェックを行う
- 検証用コピーへ実適用する
- バックアップ復元の事前確認を行う

この確認は検証用コピー上で行うため、実務データ、CSV、Chromeログイン状態には触れない。

## サーバー掲載用リリース配布物

サーバーへ置く更新ファイルは、開発PCでまとめて作成する。

確認コマンド:

```bash
npm run build:release-package
```

Macでは `リリース配布物作成.command`、Windowsでは `BUILD_RELEASE_PACKAGE.bat` からも実行できる。

本番サーバーのURLを反映する場合:

```bash
node automation/build_release_package.mjs --base-url=https://サーバーURL/downloads --manifest-url=https://サーバーURL/update-manifest.json
```

`--manifest-url` を指定すると、Mac更新ZIPとWindowsインストーラー配布元ZIP内の `updates/update-settings.json` にも更新サーバーURLを入れる。これにより、新規PCに導入した時点で次回以降のアップデート通知先が設定済みになる。

生成先:

`dist/releases/<version>`

生成するもの:

- `downloads/property-list-automation-mac-<version>.zip`
- `downloads/property-list-automation-windows-installer-source-<version>.zip`
- `update-manifest.template.json`
- `UPLOAD_TO_SERVER.txt`

Windowsインストーラーexeが `dist/property-list-automation-windows-<version>.exe` に存在する場合は、release package作成時に `downloads` へ取り込み、SHA-256もmanifestへ入れる。

Windowsインストーラーexeがまだない場合は、manifest内に `WINDOWS_EXE_SHA256_AFTER_BUILD` を残し、Windows実機で `BUILD_WINDOWS_INSTALLER.bat` を実行してexeを作成してから差し替える。

Windowsインストーラーexeを作成した後、最終manifestを確定する。

```bash
npm run release:finalize-manifest
```

Macでは `リリースmanifest確定.command`、Windowsでは `FINALIZE_RELEASE_MANIFEST.bat` からも実行できる。

Windows exeが標準位置にない場合:

```bash
node automation/finalize_release_manifest.mjs --windows-exe=/path/to/property-list-automation-windows-<version>.exe
```

本番サーバーのURLを反映する場合:

```bash
node automation/finalize_release_manifest.mjs --base-url=https://サーバーURL/downloads
```

確定後、`dist/releases/<version>/update-manifest.json` をサーバーへ配置する。

配布物には実務データを含めない。

含めないもの:

- `data` 内の取得済み実務データ
- `exports`
- `outputs`
- `backups`
- `updates/downloads`
- `updates/staged`
- `node_modules`
- `dist`

## サーバー公開用フォルダ

サーバーへそのままアップロードするフォルダは、次で作成する。

```bash
npm run build:update-server-public
```

Macでは `サーバー公開フォルダ作成.command`、Windowsでは `BUILD_UPDATE_SERVER_PUBLIC.bat` からも実行できる。

生成先:

`dist/update-server-public`

生成するもの:

- `downloads`
- `index.html`
- `checksums.txt`
- `SERVER_PUBLIC_STATUS.json`
- `SERVER_PUBLIC_README.txt`
- `UPLOAD_CHECKLIST.txt`
- `update-manifest.json` または `update-manifest.template.json`

Windowsインストーラーexeがまだなく `update-manifest.json` が未確定の場合は、`update-manifest.template.json` だけを置く。これにより、未完成のmanifestを誤って本番公開することを防ぐ。

公開後に確認するURL:

- `https://サーバーURL/index.html`
- `https://サーバーURL/update-manifest.json`
- `https://サーバーURL/downloads/ファイル名`

## 診断機能

Windows実機でしか確認できない情報も、システム単体でチェックできるようにする。

Codexは必須ではない。

診断項目:

- Node.jsが使える
- npmが使える
- Python 3が使える
- Google Chromeがある
- 専用Chromeが起動できる
- Chrome接続ブリッジが起動できる
- Chrome拡張機能が読み込まれている
- リアプロタブを検出できる
- いい生活タブを検出できる
- リアプロ一覧画面を検出できる
- いい生活物件広告画面を検出できる
- いい生活全件取得ができる
- リアプロ少数ページ取得ができる

## 診断結果の表示

システム画面に診断結果を表示する。

表示例:

- `OK`
- `注意`
- `NG`
- 原因
- 次にやること

ユーザーが見ても判断できる言葉にする。

例:

`Chrome拡張機能が読み込まれていません。デスクトップアイコンから起動し直してください。`

## 診断結果のサーバー送信

必要に応じて、診断結果をサーバーへ送信できるようにする。

送信対象:

- OS種別
- システムバージョン
- 診断結果
- エラー内容
- Chrome接続状態
- 拡張機能状態

送信しないもの:

- リアプロID
- いい生活ID
- パスワード
- Chromeプロファイル
- 個人情報
- 物件詳細データ

ログ送信は、ユーザーが明示的に押した場合だけにする。

## Codexが必要な場面

通常利用、アップデート確認、診断、更新作業にはCodexは不要。

Codexがあると便利な場面:

- エラー原因の調査
- ログの読み取り
- Windowsだけで起きた不具合の修正
- 新しいアップデート用インストーラーの作成
- サーバー上の最新版情報の更新
- 仕様変更

## 新規PCへの導入

サーバーに導入ページを作る。

導入ページに置くもの:

- Windows版ダウンロード
- Mac版ダウンロード
- インストール手順
- 初回ログイン手順
- 接続確認の手順
- よくあるエラー
- 困った時のログ送信方法

理想のWindows導入:

1. 導入ページを開く
2. Windows版インストーラーをダウンロード
3. インストーラーを実行する
4. デスクトップアイコン、またはスタートメニューから開く
5. 専用ChromeでGoogle、リアプロ、いい生活へログインする
6. システム画面で診断する
7. 使い始める

## インストーラー化

インストーラー化は将来対応ではなく、今の導入改善の中心作業として進める。

Windows版は、ZIP配布ではなくインストーラー配布を標準にする。

ZIP配布は、開発用、緊急時、手動復旧用の予備として残す。

インストーラー化で実現すること:

- デスクトップアイコンを作成できる
- スタートメニューに登録できる
- Node.jsなどの不足を検出しやすい
- 更新処理を安定させやすい
- ユーザーの導入手順を減らせる
- 専用Chrome、Chrome拡張機能、ローカルサーバー起動をまとめて案内できる
- アンインストール、再インストール、修復導入の導線を作れる

初期インストーラーの要件:

- インストール先を作成する
- システム本体を配置する
- `data`、`exports`、`outputs` 用フォルダを作成する
- デスクトップアイコンを作成する
- スタートメニューに登録する
- 初回起動時に必要環境を診断する
- Google Chromeがない場合は案内する
- Node.js、Python 3がない場合は案内する
- 同梱のChrome拡張機能を専用Chromeへ読み込める状態にする
- 既存データを消さずに上書き更新できる
- アンインストール時も、実務データ削除はユーザー確認にする

Mac版も導入を簡単にする対象だが、最初の優先はWindows版インストーラーとする。

## セキュリティ方針

- システムはID、パスワードを保存しない
- ログイン情報はChromeに保存する
- Chromeプロファイルはアップロードしない
- 実務データは原則PC内に保存する
- 診断ログ送信はユーザー操作時のみ行う
- 更新ファイルはHTTPSで配布する
- 可能ならSHA-256で更新ファイルを検証する
- 更新前に必ずバックアップを作成する

## 実装段階

### フェーズ1: Windowsインストーラー

- Windows版インストーラー方式は Inno Setup を採用する
- インストール先は `{localappdata}\PropertyListAutomation` とする
- デスクトップアイコンを作成する
- スタートメニュー登録を行う
- 初回起動は `START_WINDOWS.bat` 経由で専用Chrome、Chrome拡張機能、ローカルサーバーを起動する
- Mac側で `npm run build:windows-installer-source` を実行し、Windowsで `.iss` をコンパイルする
- Windows側では `BUILD_WINDOWS_INSTALLER.bat` からInno Setupを呼び出してexeを作成する
- ZIPではなくインストーラーを標準導入にする
- ZIPは予備・復旧用として残す

### フェーズ2: 導入ページ

- サーバーにダウンロードページを作る
- Windows版インストーラーを置く
- Mac版導入ファイルを置く
- 簡単手順を置く
- 更新履歴を置く

### フェーズ3: アップデート通知

- バージョン情報ファイルを追加済み
- サーバーの最新版情報JSONを読むAPIを追加済み
- 起動時にアップデート通知を出す処理を追加済み
- `今すぐ更新` は更新前バックアップ作成後にダウンロード・一時展開・必須ファイル確認・ZIP本体入れ替え・再起動案内まで実装済み
- `あとで` は閉じるだけの初期版まで実装済み

### フェーズ4: ワンクリック更新

- 更新前バックアップは実装済み
- ダウンロードは実装済み
- 展開はZIP形式のみ実装済み
- 本体ファイル入れ替えはZIP形式のみ実装済み
- 完了通知
- 再起動案内は実装済み
- 更新失敗時のバックアップ復元は実装済み

### フェーズ5: 診断結果送信

- Windows/Mac診断結果をJSON化
- ユーザー操作でサーバーへ送信
- サーバー側で診断履歴を確認

## 完了条件

初期版の完了条件:

- Windows版インストーラーをダウンロードできる
- インストーラーから導入できる
- デスクトップアイコンから起動できる
- スタートメニューから起動できる
- 専用Chromeとローカルサーバーを起動できる
- 同梱Chrome拡張機能が専用Chromeへ読み込まれる
- Mac版、Windows版で現在バージョンを表示できる
- サーバーの最新版情報を取得できる
- 新しい版がある時だけ通知が出る
- 通知文言が `新しいアップデートがあります` になっている
- ボタンが `今すぐ更新` と `あとで` になっている
- `あとで` を押すと作業を続けられる
- `アップデートあり` 表示から後で更新できる
- Windows版とMac版で別々の最新版URLを読める
- ユーザー固有データを消さない設計になっている

ワンクリック更新版の完了条件:

- 更新前バックアップが作成される
- 更新ファイルをダウンロードできる
- 更新ファイルの検証ができる
- 本体だけ入れ替わる
- Chromeログインプロファイルが残る
- CSV、ログ、取得済みデータが残る
- 更新後に新バージョンが表示される
- 更新失敗時にバックアップから復元できる
- 失敗時にバックアップから戻せる
