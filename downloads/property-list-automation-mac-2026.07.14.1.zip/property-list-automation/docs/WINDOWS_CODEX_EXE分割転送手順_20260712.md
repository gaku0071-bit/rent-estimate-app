# Windows Codex向け EXE分割転送手順

## 目的

56MBを超えるWindows EXEを、Drive連携の転送上限にかからないよう3分割して、Mac側で結合・SHA-256確認する。

## 対象ファイル

```text
property-list-automation-windows-2026.07.05.1.exe
```

期待する元ファイルSHA-256:

```text
e29501615b29cdab98202026a6b38e6dd6195561770217e6153953621b4e81ab
```

## Windows Codexで実行するPowerShell

`$src` は実際のEXEの場所に合わせて変更する。

```powershell
$src = "C:\Users\gaku0\Downloads\property-list-automation-windows-2026.07.05.1.exe"
$outDir = Join-Path (Split-Path $src -Parent) "property-list-automation-transfer"
$chunkSize = 20MB
$buffer = New-Object byte[] (4MB)

New-Item -ItemType Directory -Force $outDir | Out-Null
Get-ChildItem $outDir -Filter "property-list-automation-windows-2026.07.05.1.exe.part*" -ErrorAction SilentlyContinue | Remove-Item -Force

$inputStream = [System.IO.File]::OpenRead($src)
$part = 1
try {
  while ($inputStream.Position -lt $inputStream.Length) {
    $partPath = Join-Path $outDir ("property-list-automation-windows-2026.07.05.1.exe.part{0:D2}" -f $part)
    $outputStream = [System.IO.File]::Create($partPath)
    try {
      $remaining = $chunkSize
      while ($remaining -gt 0 -and $inputStream.Position -lt $inputStream.Length) {
        $requested = [int][Math]::Min($buffer.Length, $remaining)
        $read = $inputStream.Read($buffer, 0, $requested)
        if ($read -le 0) { break }
        $outputStream.Write($buffer, 0, $read)
        $remaining -= $read
      }
    } finally {
      $outputStream.Dispose()
    }
    $part++
  }
} finally {
  $inputStream.Dispose()
}

Get-FileHash $src -Algorithm SHA256
Get-ChildItem $outDir -Filter "*.part*" | Get-FileHash -Algorithm SHA256
Get-ChildItem $outDir -Filter "*.part*" | Select-Object Name,Length
```

## Driveへの保存

次の3ファイルを、既存のDriveフォルダへアップロードする。

`property-list-windows-build-2026.07.05.1`

- `property-list-automation-windows-2026.07.05.1.exe.part01`
- `property-list-automation-windows-2026.07.05.1.exe.part02`
- `property-list-automation-windows-2026.07.05.1.exe.part03`

3ファイルのサイズがそれぞれ20MB以下であることを確認する。

## 報告内容

アップロード後、次を報告する。

```text
part01: サイズ / SHA-256 / Drive URL
part02: サイズ / SHA-256 / Drive URL
part03: サイズ / SHA-256 / Drive URL
元EXE: SHA-256
```

Mac側で3分割ファイルを取得して結合し、元EXEのSHA-256と一致することを確認してからGitHubへ公開する。

