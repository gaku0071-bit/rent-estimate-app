# Windowsインストーラー作成手順

## 目的

Windows利用者はZIPを展開せず、インストーラーから導入できるようにする。

インストーラーは次を行う。

- システム本体をインストール先へ配置する
- システム専用のNode.js LTSとPython 3を配置する
- `data`、`exports`、`outputs` フォルダを作成する
- デスクトップアイコンを作成する
- スタートメニューへ登録する
- 起動時に専用ChromeとChrome拡張機能を読み込める状態にする

## 標準の流れ

Macで配布元を作る。

```bash
cd /Users/abukawatakehito/Documents/初期費用計算/property-list-automation
npm run build:windows-installer-source
```

このMacでは `Windowsインストーラー配布元作成.command` を開いても作成できる。

作成される配布元:

`dist/windows-installer-source/property-list-automation`

Windowsでインストーラーexeを作る。

1. Windowsに Inno Setup をインストールする
2. プロジェクト全体をWindowsへ置く
3. `BUILD_WINDOWS_INSTALLER.bat` を開く
4. `dist/property-list-automation-windows-2026.07.04.1.exe` が作成される

手動で作る場合は、Inno Setup Compilerで `installer/windows/property-list-automation.iss` を開いて `Compile` を実行する。

## 配布元に入れないもの

インストーラーには実務データを入れない。

除外するもの:

- `node_modules`
- `dist`
- `exports`
- `outputs`
- 取得済みリアプロJSON
- 取得済みいい生活キャッシュ
- Chromeプロファイル
- ログ

残すもの:

- 判定ルール
- 検証サンプル
- 性能確認用の基準ファイル
- 現在バージョン
- アップデート確認用マニフェスト
- Chrome拡張機能
- Windows起動スクリプト

## Windowsでの導入確認

インストーラーで導入したあと、次を確認する。

1. デスクトップアイコンから起動できる
2. スタートメニューから起動できる
3. 専用Chromeが開く
4. Chrome拡張機能が読み込まれる
5. Google Chrome不足時に案内が出る
6. Windows本体にNode.js/Pythonがなくても起動できる
7. 同梱Node.js/Pythonが壊れている場合に再インストール案内が出る
8. リアプロといい生活にログインできる
9. システム画面が開く
10. `Chromeタブ確認` が動く
11. 少数ページの取得テストが通る

## Windows実機チェックリスト

Mac側では配布元作成まで確認する。

Windows実機では次を必ず確認する。

- `BUILD_WINDOWS_INSTALLER.bat` でexeを作成できる
- 作成されたexeを実行できる
- インストール先が `%LOCALAPPDATA%\PropertyListAutomation` になる
- デスクトップアイコンから起動できる
- スタートメニューから起動できる
- 初回起動時に不足環境の案内が出る
- Google Chromeが入っている場合は通常起動する
- Windows本体にNode.js/Pythonが入っていなくても通常起動する
- 専用Chromeが `data\chrome-profile-windows` を使う
- Chrome拡張機能が専用Chromeへ読み込まれる
- リアプロ、いい生活へログインできる
- `Chromeタブ確認` でリアプロといい生活を検出できる
- 1〜2ページの取得で候補見込み、確認中表示、候補リスト表示が動く
- 再インストールしても `data`、`exports`、`outputs` の実務データが消えない
- アンインストール時に実務データの扱いを確認できる

MacではInno Setupのexe作成までは確認できないため、exe作成とインストール動作はWindowsで確認する。

## 注意

アンインストール時も、利用者が作った実務データは自動削除しない方針。

再インストールやアップデートでは、`data`、`exports`、`outputs` を残す前提で扱う。

アップデート通知の `今すぐ更新` は、先に `backups/update-YYYYMMDD-HHMMSS` へ現在のシステム本体を保存してから、最新版のダウンロードURLを開く。

ZIP形式の更新ファイルは `updates/downloads` に保存し、`updates/staged` へ一時展開して中身を確認する。

Windowsインストーラーexeの場合は、取得確認後にインストーラーを手動で実行する。

ZIP形式で必須ファイル確認に通った場合は、本体ファイルを入れ替えて再起動案内を表示する。実務データである `data`、`exports`、`outputs` は入れ替え対象外。

更新途中で失敗した場合は、作成済みの `backups/update-YYYYMMDD-HHMMSS` から本体ファイルを復元できる。復元後も再起動が必要。

配布前には `npm run verify:update-flow`、Macでは `更新フロー確認.command`、Windowsでは `UPDATE_FLOW_CHECK_WINDOWS.bat` を実行して、更新通知からバックアップ、更新準備、適用確認、復元確認までが通ることを確認する。

この確認は一時フォルダにコピーした検証用システムで行うため、実務データやログイン状態には触れない。

サーバーへ置く配布物は `npm run build:release-package`、Macでは `リリース配布物作成.command`、Windowsでは `BUILD_RELEASE_PACKAGE.bat` で作成する。

生成先は `dist/releases/<version>`。Mac更新ZIP、Windowsインストーラー配布元ZIP、`update-manifest.template.json`、`UPLOAD_TO_SERVER.txt` を作成する。WindowsインストーラーexeはWindows実機で `BUILD_WINDOWS_INSTALLER.bat` を実行して作成する。

本番サーバーのURLをmanifestへ入れたい場合は、`node automation/build_release_package.mjs --base-url=https://サーバーURL/downloads --manifest-url=https://サーバーURL/update-manifest.json` を使う。`--manifest-url` を指定すると、配布物内の `updates/update-settings.json` にも更新サーバーURLが入る。

Windowsインストーラーexe作成後は `npm run release:finalize-manifest`、Macでは `リリースmanifest確定.command`、Windowsでは `FINALIZE_RELEASE_MANIFEST.bat` を実行して、`update-manifest.json` を確定する。

Windows exeが別フォルダにある場合は、`node automation/finalize_release_manifest.mjs --windows-exe=ファイルパス` で取り込める。

各PCが本番サーバーの更新情報を見に行くには、`updates/update-settings.json` の `manifestUrl` を設定する。Windowsでは `SET_UPDATE_SERVER_URL.bat`、Macでは `更新サーバーURL設定.command` を開いて設定できる。

サーバーへそのままアップロードする公開用フォルダは、`npm run build:update-server-public`、Macでは `サーバー公開フォルダ作成.command`、Windowsでは `BUILD_UPDATE_SERVER_PUBLIC.bat` で作成する。生成先は `dist/update-server-public`。
