@echo off
setlocal

cd /d "%~dp0"

echo サンプルJSON・検証ルール・ドキュメントをまとめて確認します。
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode all-basic
echo.
pause
