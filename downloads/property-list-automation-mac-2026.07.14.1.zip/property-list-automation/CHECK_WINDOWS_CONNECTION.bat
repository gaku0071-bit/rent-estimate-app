@echo off
setlocal

cd /d "%~dp0"

echo Windows Chrome connection check.
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode chrome-bridge
if errorlevel 1 goto failed

echo.
echo Windows Chrome connection OK.
pause
exit /b 0

:failed
echo.
echo Windows Chrome connection failed. Check the message above.
pause
exit /b 1
