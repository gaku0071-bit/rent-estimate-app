#!/bin/zsh
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

NODE_BIN="$("$PROJECT_ROOT/automation/node_runner.command")" || {
  read -r "?Enterで閉じます..." || true
  exit 1
}

echo "サーバー掲載用リリース配布物を作成します。"
"$NODE_BIN" automation/build_release_package.mjs
echo ""
echo "完了しました。dist/releases フォルダを確認してください。"
read -r "?Enterで閉じます..." || true
