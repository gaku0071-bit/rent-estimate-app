#!/bin/zsh
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

NODE_BIN="$("$PROJECT_ROOT/automation/node_runner.command")" || {
  read -r "?Enterで閉じます..." || true
  exit 1
}

echo "このPCで物件候補リスト作成システムを使う準備ができているか確認します。"
"$NODE_BIN" automation/env_check.mjs
echo ""
read -r "?Enterで閉じます..." || true
