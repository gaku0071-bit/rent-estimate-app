@echo off
setlocal

cd /d "%~dp0"

echo 本番前確認を開始します。
echo 1. 環境確認
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode env
if errorlevel 1 goto failed
echo.

echo 2. 総合確認
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode all-basic
if errorlevel 1 goto failed
echo.

echo 3. CSV生成確認
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode sample
if errorlevel 1 goto failed
echo.

echo 4. 更新フロー確認
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode update-flow
if errorlevel 1 goto failed
echo.

echo 本番前確認OKです。
pause
exit /b 0

:failed
echo.
echo 本番前確認に失敗しました。上のメッセージを確認してください。
pause
exit /b 1
