# Codex Windows 引き継ぎ

このファイルは、Windows PCのCodexで物件候補リスト作成システムの導入・検証・開発を継続するための引き継ぎ資料です。

## Codexへの依頼

WindowsのCodexでこのフォルダをワークスペースとして開き、次のように依頼してください。

> `CODEX_WINDOWS引き継ぎ.md` を読み、書かれている順番でWindows導入確認を進めてください。エラーがあれば原因を調査して修正し、リアプロといい生活の実データ取得テストまで続けてください。既存の判定ルールとMac用処理は壊さないでください。

## システムの目的

リアプロで募集中の空室を、いい生活賃貸クラウドへ効率よく登録するための候補リストを号室単位で作成します。

いい生活全体を確認し、同じ号室または同じ建物・同じ間取の募集状況を自動照合することで、1部屋ずつ手作業で確認する工程を減らします。

現段階の対象は候補リストとCSVの作成までです。いい生活への自動登録・自動更新は行いません。

## 重要な判定ルール

- 物件単位ではなく号室単位で取得・照合する。
- WEB広告掲載が許可されていない号室は候補から除外する。
- WEB広告掲載が「管理会社に確認」の場合は候補に残し、確認が必要と明記する。
- 雑誌・チラシ広告掲載可否は判定に使わない。
- 電子入居申込が1件以上ある号室は空室候補から除外する。
- リアプロ詳細を確認できない号室は候補リストへ入れず、詳細未確認CSVに残す。
- 1つの建物内で同じ間取を掲載候補にするのは原則1部屋だけ。
- いい生活で同じ間取の別号室が募集中なら、新規候補にはしない。
- いい生活掲載中の号室がリアプロで掲載なし・審査中・商談中の場合、同じ間取でリアプロ空室の別号室を差替候補にする。
- 差替候補には、差替元のいい生活URLと、差替元がリアプロで募集されていない理由を表示する。
- 実務用CSVは、いい生活の取得時点の全件数と取得件数が一致した場合だけ出力する。
- 普段の登録作業では、まず `exports/latest-practical.csv` を開く。
- リアプロ取得データが当日でない場合、実務用CSVは出力しない。

## 実装済み

- 札幌市内の路線・駅候補と路線単位の全駅選択
- 間取、賃料帯、設備、駐車場空き、駅までの移動手段・徒歩分数
- リアプロ検索条件の画面反映
- リアプロ一覧の5ページ並列取得
- リアプロ最大200ページ取得
- リアプロ詳細のWEB広告、申込件数、設備、取得品質確認
- いい生活全件キャッシュ取得
- 号室・同間取・差替候補の照合
- 現場用、候補、作業対象、確認用、全件、詳細未確認CSV
- 大量取得時のページ抜け、0件ページ、重複、詳細未確認の検証
- Mac ChromeのApple Events接続
- Windows ChromeのCDP接続ブリッジ
- Windows専用Chromeプロファイル
- Windows用起動・環境確認・接続確認BAT
- いい生活全件取得の高速化: 100件ずつ・同時5ページ取得
- 最新取得JSON読み込み時のいい生活全件キャッシュ自動反映
- 拡張機能取得後の候補完成通知とリアプロ詳細リンク付き候補リスト表示
- いい生活確認完了前は候補見込みのみ表示し、リンク付き候補リストは確認完了後に表示

## Windowsで最初に行うこと

標準はインストーラー導入です。

1. Windows版インストーラーをダウンロードする。
2. インストーラーを実行する。
3. デスクトップアイコン、またはスタートメニューから開く。
4. Google Chromeが不足している場合は案内に従って入れる。
5. Node.js LTSとPython 3はインストーラーに同梱するため、Windows本体へ別途入れない。
6. 起動したWindows取得専用Chromeでリアプロといい生活へログインする。
7. リアプロのリスト検索結果と、いい生活の物件一覧・広告画面を別タブで開く。
8. システム画面の `Chromeタブ確認` を実行する。
9. 両方が検出されたら、少数ページで取得テストを実行する。

ZIP配布は開発用、緊急時、手動復旧用の予備です。ZIPで確認する場合だけ、ZIPを右クリックして「すべて展開」し、展開した `property-list-automation` フォルダをCodexで開きます。

## Windows用ファイル

- `物件候補リスト作成.bat`: 通常起動
- `Windows接続確認.bat`: Chrome接続・JavaScript・Python連携テスト
- `環境確認.bat`: Node.js、Python、Chrome、必要ファイル確認
- `本番前確認.bat`: 環境・判定ルール・CSVの総合確認
- `START_WINDOWS.bat`: 文字化け対策用の英字名通常起動
- `CHECK_WINDOWS_CONNECTION.bat`: 文字化け対策用の英字名Chrome接続確認
- `ENV_CHECK_WINDOWS.bat`: 文字化け対策用の英字名環境確認
- `PRE_RELEASE_CHECK_WINDOWS.bat`: 文字化け対策用の英字名本番前確認
- `Windowsで試す手順.txt`: 利用者向けの短い手順
- `automation/run_windows.ps1`: Windows起動本体
- `automation/chrome_bridge.mjs`: Chrome CDP接続ブリッジ
- `automation/test_chrome_bridge.mjs`: 接続統合テスト
- `app-version.json`: 現在バージョン
- `docs/windows_installer.md`: Windowsインストーラー作成手順
- `automation/build_windows_installer_source.mjs`: インストーラー配布元作成
- `automation/build_release_package.mjs`: サーバー掲載用リリース配布物作成
- `automation/build_update_server_public.mjs`: サーバー公開用フォルダ作成
- `automation/finalize_release_manifest.mjs`: Windows exe作成後のmanifest確定
- `automation/set_update_manifest_url.mjs`: 更新サーバーURL設定
- `installer/windows/property-list-automation.iss`: Inno Setup用インストーラー設定
- `BUILD_WINDOWS_INSTALLER.bat`: Windowsでインストーラーexeを作る補助
- `BUILD_RELEASE_PACKAGE.bat`: サーバー掲載用配布物を作る補助
- `BUILD_UPDATE_SERVER_PUBLIC.bat`: サーバー公開用フォルダを作る補助
- `FINALIZE_RELEASE_MANIFEST.bat`: Windows exeのSHA-256をmanifestへ反映する補助
- `SET_UPDATE_SERVER_URL.bat`: 更新サーバーURL設定
- `Windowsインストーラー配布元作成.command`: MacでWindowsインストーラー配布元を作る補助

## 起動後のURL

標準:

`http://127.0.0.1:8765/index.html`

このURLは起動したPCの中だけで有効です。Macで起動したURLをWindowsから開くことはできません。

8765番が使用中の場合は、8766〜8775番を自動で使用します。

## Windows Chromeの仕組み

`物件候補リスト作成.bat` は次を自動実行します。

1. 同梱Node.js、同梱npm、同梱Python 3、Chromeを確認
2. 初回のみ `npm install`
3. `data/chrome-profile-windows` を使う取得専用Chromeを起動
4. Chromeをデバッグポート `9222` で起動
5. 同梱のChrome拡張機能 `extension` を取得専用Chromeへ読み込み
6. Chrome接続ブリッジを `9223` で起動
7. システム画面サーバーを起動

ログイン情報はシステムには保存しません。Chromeの専用プロファイルに保存します。

## Windowsでの確認コマンド

PowerShellまたはコマンドプロンプトでプロジェクトへ移動して実行します。

```powershell
npm run verify:chrome-bridge
npm run verify:env
npm run verify:basic
npm run verify:sample
npm run verify:update-flow
npm run verify:latest-exports
npm run build:release-package
npm run build:update-server-public
npm run release:finalize-manifest
npm run update:set-url -- --url=https://サーバーURL/update-manifest.json
```

期待結果:

- `Chrome接続統合確認: OK`
- `環境確認: OK` または内容が説明された注意のみ
- `総合確認: OK`
- `CSV確認: OK`
- `更新フロー確認: OK`
- `サーバー掲載用リリース配布物を作成しました。`
- `サーバー公開用フォルダを作成しました。`
- Windows exe作成後は `リリースmanifestを確定しました。`
- 更新サーバーURL設定後は `更新サーバーURLを設定しました。`

## 現在までの検証結果

- 2026-07-03 Mac側環境確認: OK
- 2026-07-03 サンプル総合確認: OK
- 2026-07-03 画面読み込み確認: OK
- 2026-07-03 いい生活全件取得: 2904件 / 30ページ / 約7.6秒
- 2026-07-03 最新取得JSONへのいい生活全件キャッシュ反映: OK
- 2026-07-03 候補リスト表示: いい生活確認済み後のみ表示OK
- 2026-07-03 リアプロ詳細リンク: 号室リンク・リアプロリンクともにURL付与OK
- 2026-07-03 Chromeコンソールエラー: なし

過去の確認:

- Chrome接続統合確認: OK
- Chromeタブ取得: OK
- タブ選択: OK
- JavaScript実行: OK
- Python取得処理との連携: OK
- サンプル判定: 13/13 OK
- 表示候補: 5/5 OK
- 除外: 7/7 OK
- 同間取重複: 1/1 OK
- 詳細未確認CSV: 1/1 OK
- CSV生成確認: OK

Macでの実データ規模テスト:

- 59室: 全詳細取得OK
- 510室: 100室詳細サンプル取得OK
- 1592室: 100室詳細サンプル取得OK
- 34ページ・524室の一覧取得: 約42秒

## Windows実機で残っている確認

1. `物件候補リスト作成.bat` の初回起動
2. npm依存関係の自動インストール
3. 専用Chromeの起動
4. リアプロ・いい生活のログイン保持
5. 実画面のChromeタブ検出
6. リアプロ少数ページの一覧取得
7. リアプロ詳細取得
8. いい生活全件取得
9. 候補照合
10. CSV保存
11. Windows再起動後のログイン保持と再取得

## Windows実機確認から配布元へ反映済み

- Windows PowerShell 5向けに、Windows用 `.ps1` をUTF-8 BOM付きで配布する。
- Chrome候補が1件だけでもStrictMode下で動くよう、候補結果を必ず配列化する。

## 最初の実データテスト

いきなり大量取得を行わず、次の順で確認します。

1. リアプロを狭い条件で10〜30室程度に絞る。
2. いい生活は全件キャッシュを作成する。
3. リアプロ1〜2ページを取得する。
4. WEB広告掲載可否、申込件数、号室、間取、賃料を実画面と比較する。
5. 詳細未確認が0件か確認する。
6. 候補と除外理由を数件目視確認する。
7. 現場用CSV・作業対象CSV・確認用CSV・全件CSVを保存する。
8. 問題がなければ取得ページ数と検索条件を増やす。

## トラブル時に見る場所

- `data/chrome-bridge-windows.log`
- `data/chrome-bridge-windows-error.log`
- システム画面の `サーバー確認`
- システム画面の `Chromeタブ確認`
- システム画面の `取得品質`
- `詳細未確認CSV`

## 2026-07-03時点のWindows移行判断

Windows実機での本番利用前テストに進める状態です。

ただし、Windows実機で次の確認が終わるまでは「完全移行完了」ではなく「移行テスト段階」とします。

1. `Windows接続確認.bat` がOKになること
2. `物件候補リスト作成.bat` で専用Chromeとシステム画面が起動すること
3. 専用Chromeでリアプロ・いい生活へログイン保持できること
4. Chromeタブ確認でリアプロ一覧といい生活一覧を検出できること
5. いい生活全件取得が完了し、件数が全体件数と一致すること
6. リアプロ1〜2ページ取得で詳細未確認が出ない、または理由が明確なこと
7. 候補リストにリアプロ詳細リンクが出ること

## 開発時の注意

- ユーザーの実データ、ログイン情報、ChromeプロファイルをGitや配布ZIPへ含めない。
- `data/chrome_capture.json` と `data/eseikatsu_full_cache.json` は実データになるため、配布物へ含めない。
- Mac側のApple Events接続を壊さない。
- Windows側は `CHROME_TRANSPORT=bridge` とChrome接続ブリッジを使用する。
- 抽出・判定ロジックはMacとWindowsで共通の `automation/capture_chrome_mac.py` を使用する。
- 未確認の号室を候補へ推測で入れない。正確さを速度より優先する。
- 既存のサンプル検証とCSV検証を変更後に必ず実行する。

## 主なファイル

- `src/index.html`: 画面
- `src/app.js`: 候補判定、照合、CSV
- `src/styles.css`: 画面スタイル
- `automation/server.mjs`: ローカルAPI・起動サーバー
- `automation/capture_chrome_mac.py`: リアプロ・いい生活の取得と解析
- `automation/chrome_bridge.mjs`: Windows Chrome接続
- `automation/run_windows.ps1`: Windows起動
- `automation/verify_sample.mjs`: 総合・CSV回帰テスト
- `automation/verify_latest_exports.py`: 最新CSVと取得JSONの実務照合チェック
- `data/verification_sample.json`: 判定サンプル
- `data/verification_rules.json`: 必須項目とドメイン検証
- `docs/spec.md`: 仕様
- `docs/automation.md`: 自動取得仕様
- `docs/setup.md`: セットアップ

## 完了条件

Windows実機で次がすべて成功したら、Windows導入確認は完了です。

- Windows接続確認OK
- 環境確認OK
- 専用Chromeで両サービスへログインできる
- Chromeタブ確認OK
- 少数条件のリアプロ取得OK
- いい生活全件取得OK
- 詳細未確認0件、または理由が明確
- 候補・除外・差替判定が実画面と一致
- CSV保存OK
- Windows再起動後も再実行できる
