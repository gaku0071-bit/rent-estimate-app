#!/bin/zsh
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

NODE_BIN="$("$PROJECT_ROOT/automation/node_runner.command")" || {
  read -r "?Enterで閉じます..." || true
  exit 1
}

echo "アップデート通知・バックアップ・更新準備・適用確認をまとめて確認します。"
"$NODE_BIN" automation/verify_update_flow.mjs
echo ""
read -r "?Enterで閉じます..." || true
