#!/bin/zsh
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

NODE_BIN="$("$PROJECT_ROOT/automation/node_runner.command")" || {
  read -r "?Enterで閉じます..." || true
  exit 1
}

echo "更新サーバーURLを設定します。"
"$NODE_BIN" automation/set_update_manifest_url.mjs
echo ""
echo "完了しました。"
read -r "?Enterで閉じます..." || true
