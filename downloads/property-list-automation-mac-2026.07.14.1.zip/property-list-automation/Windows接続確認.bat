@echo off
setlocal

cd /d "%~dp0"

echo Windows Chrome接続経路を確認します。
powershell -ExecutionPolicy Bypass -File "%~dp0automation\verify_windows.ps1" -Mode chrome-bridge
if errorlevel 1 goto failed

echo.
echo Windows Chrome接続確認OKです。
pause
exit /b 0

:failed
echo.
echo Windows Chrome接続確認に失敗しました。上のメッセージを確認してください。
pause
exit /b 1
