#!/bin/zsh
set -e

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT"

NODE_BIN="$("$PROJECT_ROOT/automation/node_runner.command")" || {
  read -r "?Enterで閉じます..." || true
  exit 1
}

echo "サーバー公開用フォルダを作成します。"
"$NODE_BIN" automation/build_update_server_public.mjs
echo ""
echo "完了しました。dist/update-server-public フォルダを確認してください。"
read -r "?Enterで閉じます..." || true
