@echo off
setlocal
set "ROOT=%~dp0"
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined ISCC for /f "delims=" %%I in ('where ISCC.exe 2^>nul') do if not defined ISCC set "ISCC=%%I"
if not defined ISCC (echo Inno Setup 6 is required. & exit /b 1)
"%ISCC%" "/DSourceRoot=%ROOT%property-list-automation" "%ROOT%installer\windows\property-list-automation.iss"
exit /b %ERRORLEVEL%
