#include "version.iss.inc"

#define AppName "物件候補リスト作成システム"
#define AppId "{{B1B3B05E-6B0D-4C31-A93D-85E661949C4F}"
#ifndef SourceRoot
  #define SourceRoot "..\..\dist\windows-installer-source\property-list-automation"
#endif

[Setup]
AppId={#AppId}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={localappdata}\PropertyListAutomation
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=..\..\dist
OutputBaseFilename=property-list-automation-windows-{#AppVersion}
Compression=lzma
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName={#AppName}
SetupLogging=yes

[Languages]
Name: "japanese"; MessagesFile: "compiler:Languages\Japanese.isl"

[Files]
Source: "{#SourceRoot}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "runtime\node\node_modules\*,data\*,updates\*,exports\*,outputs\*,backups\*,dist\*"
Source: "{#SourceRoot}\updates\update-settings.json"; DestDir: "{app}\updates"; Flags: onlyifdoesntexist
Source: "{#SourceRoot}\updates\update-manifest.json"; DestDir: "{app}\updates"; Flags: ignoreversion
Source: "{#SourceRoot}\data\verification_rules.json"; DestDir: "{app}\data"; Flags: ignoreversion
Source: "{#SourceRoot}\data\verification_sample.json"; DestDir: "{app}\data"; Flags: ignoreversion
Source: "{#SourceRoot}\data\sample_capture.json"; DestDir: "{app}\data"; Flags: ignoreversion
Source: "{#SourceRoot}\data\sample_structured_capture.json"; DestDir: "{app}\data"; Flags: ignoreversion
Source: "{#SourceRoot}\data\performance_baseline.json"; DestDir: "{app}\data"; Flags: ignoreversion
Source: "{#SourceRoot}\data\performance_latest.json"; DestDir: "{app}\data"; Flags: ignoreversion

[Dirs]
Name: "{app}\data"
Name: "{app}\exports"
Name: "{app}\outputs"

[Registry]
Root: HKCU; Subkey: "Software\Policies\Google\Chrome\ExtensionInstallForcelist"; ValueName: "PropertyListAutomation"; Flags: deletevalue uninsdeletevalue

[InstallDelete]
Type: filesandordirs; Name: "{userdesktop}\PropertyListAutomation-Extension"

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\START_WINDOWS.bat"; WorkingDir: "{app}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\START_WINDOWS.bat"; WorkingDir: "{app}"

[Run]
Filename: "{app}\START_WINDOWS.bat"; WorkingDir: "{app}"; Description: "Start {#AppName}"; Flags: postinstall nowait skipifsilent

[UninstallDelete]
Type: files; Name: "{app}\data\chrome-bridge-windows.log"
Type: files; Name: "{app}\data\chrome-bridge-windows-error.log"
