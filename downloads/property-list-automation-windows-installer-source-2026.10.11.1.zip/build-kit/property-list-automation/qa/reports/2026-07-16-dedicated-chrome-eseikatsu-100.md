# Dedicated Chrome / e-Seikatsu QA report

- Version: 2026.07.16.2
- Result: 100 / 100
- e-Seikatsu test data: 3,216 records
- Full-cache page size: 100 records
- Full-cache pages: 33
- Loop result: 3 / 3 successful, each 3,216 / 3,216 and 33 / 33
- API errors: none

## Score

| Check | Points | Result |
| --- | ---: | --- |
| Node/Python syntax | 10 | PASS |
| Server runtime and bridge health | 10 | PASS |
| e-Seikatsu total count and page calculation | 10 | PASS |
| e-Seikatsu full-cache loop, 3 runs | 15 | PASS |
| Atomic cache save and readback | 5 | PASS |
| Dedicated Chrome PID/profile/port identification | 10 | PASS |
| Chrome bridge repeated health checks | 5 | PASS |
| Stable tab ID activation | 10 | PASS |
| RealPro/e-Seikatsu tab classification | 10 | PASS |
| Portable startup rules | 10 | PASS |
| Normal Chrome safety | 5 | PASS |
| **Total** | **100** | **PASS** |

## Main fixes

- Dedicated Chrome uses a runtime manifest and a free CDP port, so another Chrome instance is not terminated or mistaken for the dedicated profile.
- The bridge assigns stable tab IDs and activates tabs by ID instead of relying only on changing tab positions.
- e-Seikatsu login/auth pages are excluded from the target-tab suggestion.
- e-Seikatsu cache writes are atomic, and the server prevents duplicate simultaneous full-cache jobs.
- Full-cache progress carries fetched count, total count, current page, and total pages to the UI.
- Stalled or timed-out e-Seikatsu jobs report an error and can be safely rerun.

## Portability checks

- No user-name-specific path is embedded in the startup logic.
- Node.js and Python are resolved from the bundled runtime directory.
- The dedicated Chrome profile is under `%LOCALAPPDATA%\PropertyListAutomation`.
- The normal Chrome profile is not used or closed by the startup script.

The pre-change backup is stored under the local `backups` directory. The update ZIP includes the files needed to apply the same changes on another Windows PC.
