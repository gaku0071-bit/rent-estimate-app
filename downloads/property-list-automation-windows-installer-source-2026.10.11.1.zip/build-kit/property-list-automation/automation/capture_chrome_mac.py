import json
import argparse
import base64
import atexit
import os
import platform
import re
import subprocess
import time
import urllib.error
import urllib.request
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


ROOT = Path(__file__).resolve().parents[1]
REALPRO_STATUS_HELPERS_JS = (Path(__file__).with_name("realpro_status.js")).read_text(encoding="utf-8")
DETAIL_RULE_VERSION = "2026-10-05.1"
OUTPUT_DIR = ROOT / "data"
OUTPUT_FILE = OUTPUT_DIR / "chrome_capture.json"
ESEIKATSU_CACHE_FILE = OUTPUT_DIR / "eseikatsu_full_cache.json"
CHROME_TRANSPORT = os.environ.get("CHROME_TRANSPORT", "").strip().lower()
IS_MAC = platform.system() == "Darwin" and CHROME_TRANSPORT != "bridge"
CHROME_BRIDGE_URL = os.environ.get("CHROME_BRIDGE_URL", "http://127.0.0.1:9223").rstrip("/")
APPLE_TAB_DELIMITER = "<<<CODEX_TAB_DELIMITER_20260701>>>"
CHROME_EXECUTION_TAB_INDEX: Optional[int] = None
APPLE_EVENT_SCRIPT_CHUNK_THRESHOLD = 12000
APPLE_EVENT_SCRIPT_CHUNK_SIZE = 9000
KNOWN_APPLICATION_COUNT_STATUSES = {"API確認", "本文確認"}


def application_count_known(value: dict) -> bool:
    count = value.get("applicationCount")
    if count is None or str(count).strip() == "":
        return False
    status = str(value.get("applicationCountStatus") or "").strip()
    return not status or status in KNOWN_APPLICATION_COUNT_STATUSES


def run_osascript(script: str) -> str:
    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            check=True,
            capture_output=True,
            text=True,
            timeout=120,
        )
    except subprocess.TimeoutExpired as error:
        raise subprocess.CalledProcessError(124, ["osascript", "-e", script], output=error.stdout, stderr="AppleScript timed out") from error
    except subprocess.CalledProcessError as error:
        detail = (error.stderr or error.output or "").strip()
        if detail:
            raise subprocess.CalledProcessError(error.returncode, error.cmd, output=error.output, stderr=detail) from error
        raise
    return result.stdout.strip()


def bridge_request(path: str, payload: Optional[dict] = None) -> dict:
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
    last_error = None
    attempts = 2 if path == "/eval" else 1
    request_timeout = 25 if path == "/eval" else 120
    for attempt in range(attempts):
        request = urllib.request.Request(
            f"{CHROME_BRIDGE_URL}{path}",
            data=data,
            headers=headers,
            method="POST" if payload is not None else "GET",
        )
        try:
            with urllib.request.urlopen(request, timeout=request_timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError) as error:
            last_error = error
            if attempt + 1 >= attempts:
                break
            try:
                reconnect = urllib.request.Request(
                    f"{CHROME_BRIDGE_URL}/reconnect",
                    data=b"{}",
                    headers={"Content-Type": "application/json; charset=utf-8"},
                    method="POST",
                )
                with urllib.request.urlopen(reconnect, timeout=10):
                    pass
            except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError):
                pass
            time.sleep(0.8 * (attempt + 1))
    raise subprocess.CalledProcessError(
        1,
        ["chrome-bridge", path],
        stderr=f"専用Chromeとの通信が一時的に切れました。再接続後も復旧しませんでした: {last_error}",
    ) from last_error


def bridge_tabs() -> dict:
    return bridge_request("/tabs")


def is_realpro_tab_url(value: str) -> bool:
    try:
        url = urlsplit(str(value or ""))
        return url.scheme == "https" and url.hostname in {"realnetpro.com", "www.realnetpro.com"}
    except ValueError:
        return False


def navigate_dedicated_chrome(url: str, index: Optional[int] = None, activate: bool = False) -> dict:
    payload = {"url": url}
    if index:
        payload["index"] = int(index)
    payload["activate"] = bool(activate)
    return bridge_request("/navigate", payload)


def chrome_tab_property_values(property_name: str) -> list[str]:
    delimiter = APPLE_TAB_DELIMITER
    script = f"""
    set oldDelimiters to AppleScript's text item delimiters
    set AppleScript's text item delimiters to {json.dumps(delimiter)}
    tell application "Google Chrome"
      set tabValues to {{}}
      repeat with chromeTab in tabs of front window
        try
          set end of tabValues to ({property_name} of chromeTab as text)
        on error
          set end of tabValues to ""
        end try
      end repeat
    end tell
    set joinedValues to tabValues as text
    set AppleScript's text item delimiters to oldDelimiters
    return joinedValues
    """
    output = run_osascript(script)
    if output == "":
        return [""]
    return output.split(delimiter)


def chrome_titles() -> list[str]:
    if not IS_MAC:
        return [str(tab.get("title") or "") for tab in bridge_tabs().get("tabs", [])]
    return chrome_tab_property_values("title")


def chrome_urls() -> list[str]:
    if not IS_MAC:
        return [str(tab.get("url") or "") for tab in bridge_tabs().get("tabs", [])]
    return chrome_tab_property_values("URL")


def chrome_active_tab_index() -> Optional[int]:
    if not IS_MAC:
        try:
            value = bridge_tabs().get("activeIndex")
            return int(value) if value else None
        except (subprocess.CalledProcessError, TypeError, ValueError):
            return None
    try:
        output = run_osascript('tell application "Google Chrome" to get active tab index of front window')
        return int(output.strip())
    except (subprocess.CalledProcessError, ValueError):
        return None


def set_active_tab(index: int) -> None:
    global CHROME_EXECUTION_TAB_INDEX
    CHROME_EXECUTION_TAB_INDEX = int(index)
    if not IS_MAC:
        # Windows can address a CDP target directly. Keep the system screen in
        # front while RealPro and e-Seikatsu run in their dedicated background tabs.
        return
    run_osascript(f'tell application "Google Chrome" to set active tab index of front window to {index}')


def restore_active_tab(index: Optional[int]) -> None:
    if not index:
        return
    try:
        if IS_MAC:
            run_osascript(f'tell application "Google Chrome" to set active tab index of front window to {int(index)}')
        else:
            bridge_request("/activate", {"index": int(index)})
    except (subprocess.CalledProcessError, TypeError, ValueError):
        pass


def ensure_execution_tab_active() -> None:
    if not IS_MAC or not CHROME_EXECUTION_TAB_INDEX:
        return
    try:
        active_index = chrome_active_tab_index()
        if active_index != CHROME_EXECUTION_TAB_INDEX:
            run_osascript(
                f'tell application "Google Chrome" to set active tab index of front window to {int(CHROME_EXECUTION_TAB_INDEX)}'
            )
            time.sleep(0.15)
    except (subprocess.CalledProcessError, TypeError, ValueError):
        pass


def move_realpro_to_page(page_number: int) -> None:
    page_index = max(int(page_number or 1) - 1, 0)
    if not IS_MAC:
        tab = next((item for item in bridge_tabs().get("tabs", [])
                    if int(item.get("index") or 0) == int(CHROME_EXECUTION_TAB_INDEX or 0)), None)
        if not tab or not tab.get("id") or not is_realpro_tab_url(tab.get("url")):
            raise ValueError("リアプロ一覧タブを確認できません。システム画面は変更しません。")
        url = urlsplit(str(tab["url"]))
        query = dict(parse_qsl(url.query, keep_blank_values=True))
        query.update({"method": "estate", "display": "building", "key": "addr", "odr": "asc"})
        if page_index:
            query["page"] = str(page_index)
        else:
            query.pop("page", None)
        destination = urlunsplit((url.scheme, url.netloc, "/main.php", urlencode(query), ""))
        bridge_request("/navigate", {"id": tab["id"], "url": destination, "activate": False})
        time.sleep(1.8)
        return
    run_chrome_javascript(
        f"""
        (() => {{
          const url = new URL(location.href);
          url.pathname = '/main.php';
          url.searchParams.set('method', 'estate');
          url.searchParams.set('display', 'building');
          url.searchParams.set('key', 'addr');
          url.searchParams.set('odr', 'asc');
          if ({page_index} > 0) {{
            url.searchParams.set('page', String({page_index}));
          }} else {{
            url.searchParams.delete('page');
          }}
          location.href = url.href;
        }})()
        """
    )
    time.sleep(1.8)


def run_chrome_javascript(script: str) -> str:
    if not IS_MAC:
        payload = {"script": script}
        if CHROME_EXECUTION_TAB_INDEX:
            payload["index"] = int(CHROME_EXECUTION_TAB_INDEX)
        return str(bridge_request("/eval", payload).get("result") or "")
    ensure_execution_tab_active()
    encoded_script = base64.b64encode(script.encode("utf-8")).decode("ascii")
    wrapped_script = (
        "eval(decodeURIComponent(Array.prototype.map.call("
        f'atob("{encoded_script}"), '
        "function(c) { return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2); }"
        ").join('')))"
    )
    # Chrome's Apple Events bridge rejects large JavaScript arguments. Send the
    # base64 payload in small pieces, then evaluate it once in the target tab.
    if len(wrapped_script) > APPLE_EVENT_SCRIPT_CHUNK_THRESHOLD:
        chunks = [
            encoded_script[index:index + APPLE_EVENT_SCRIPT_CHUNK_SIZE]
            for index in range(0, len(encoded_script), APPLE_EVENT_SCRIPT_CHUNK_SIZE)
        ]
        run_osascript(
            'tell application "Google Chrome" to execute active tab of front window javascript '
            + json.dumps("window.__codexAppleEventChunks = []; true")
        )
        for chunk in chunks:
            run_osascript(
                'tell application "Google Chrome" to execute active tab of front window javascript '
                + json.dumps(f"window.__codexAppleEventChunks.push({json.dumps(chunk)}); true")
            )
        chunked_script = (
            "(() => {"
            "try {"
            "return eval(decodeURIComponent(Array.prototype.map.call("
            "atob(window.__codexAppleEventChunks.join('')), "
            "function(c) { return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2); }"
            ").join('')));"
            "} finally { window.__codexAppleEventChunks = null; }"
            "})()"
        )
        return run_osascript(
            'tell application "Google Chrome" to execute active tab of front window javascript '
            + json.dumps(chunked_script)
        )
    return run_osascript(f'tell application "Google Chrome" to execute active tab of front window javascript {json.dumps(wrapped_script)}')


def read_current_tab_info() -> dict:
    try:
        return json.loads(run_chrome_javascript(
            """
            JSON.stringify({
              title: document.title || '',
              url: location.href || ''
            })
            """
        ))
    except (subprocess.CalledProcessError, json.JSONDecodeError):
        return {"title": "", "url": ""}


def is_realpro_list_url(url: str) -> bool:
    value = str(url or "")
    return "realnetpro.com" in value and "room_detail.php" not in value and "method=estate" in value


def realpro_candidate_indexes(preferred_index: int) -> list[int]:
    titles = chrome_titles()
    urls = chrome_urls()
    active_index = chrome_active_tab_index()
    candidates = []
    for candidate in [
        preferred_index,
        suggest_realpro_index(urls, titles, active_index),
        active_index,
    ]:
        if candidate:
            candidates.append(int(candidate))
    candidates.extend(
        index
        for index, url in enumerate(urls, start=1)
        if is_realpro_list_url(url)
    )
    valid_max = max(len(urls), len(titles))
    unique = []
    for candidate in candidates:
        if 1 <= candidate <= valid_max and candidate not in unique:
            unique.append(candidate)
    return unique


def bridge_tab_info(index: int) -> dict:
    """Read the dedicated Chrome tab metadata without evaluating page JavaScript."""
    if IS_MAC:
        return {}
    try:
        tabs = bridge_tabs().get("tabs") or []
        for tab in tabs:
            if int(tab.get("index") or 0) == int(index):
                return {
                    "title": str(tab.get("title") or ""),
                    "url": str(tab.get("url") or ""),
                }
    except (subprocess.CalledProcessError, TypeError, ValueError):
        pass
    return {}


def activate_realpro_result_tab(preferred_index: int, start_page: int = 1) -> tuple[int, str, str]:
    checked = []
    for candidate in realpro_candidate_indexes(preferred_index):
        set_active_tab(candidate)
        time.sleep(0.35)
        info = read_current_tab_info()
        current_url = str(info.get("url") or "")
        if not current_url:
            # A busy RealPro page can briefly fail an evaluate request even
            # though the dedicated Chrome tab itself is valid.
            info = bridge_tab_info(candidate)
            current_url = str(info.get("url") or "")
        checked.append(f"{candidate}: {current_url}")
        if "realnetpro.com" not in current_url or "room_detail.php" in current_url:
            continue
        current_query = dict(parse_qsl(urlsplit(current_url).query, keep_blank_values=True))
        current_page = int(current_query.get("page") or 0) + 1
        if ("method=estate" not in current_url or "main.php" not in current_url
                or current_page != start_page or current_query.get("key") != "addr"
                or current_query.get("odr") != "asc"):
            move_realpro_to_page(start_page)
        # The bridge can briefly return an empty page-status response while
        # RealPro is finishing navigation. Re-select and verify the same tab a
        # few times before treating an already valid list URL as a failure.
        for attempt in range(5):
            wait_for_page_text_ready(5.0)
            status = realpro_page_status()
            if status.get("loginDetected"):
                raise SystemExit("リアプロがログイン画面です。Chromeでリアプロにログインし、リスト検索結果一覧を開いてから再取得してください。")
            if status.get("isResultPage"):
                return candidate, str(status.get("title") or info.get("title") or ""), str(status.get("url") or current_url)
            if attempt < 4:
                set_active_tab(candidate)
                time.sleep(0.6 + attempt * 0.25)
                refreshed_info = read_current_tab_info() or bridge_tab_info(candidate)
                refreshed_url = str(refreshed_info.get("url") or "")
                if refreshed_url:
                    current_url = refreshed_url
                    info = refreshed_info
                    checked.append(f"{candidate} 再確認{attempt + 1}: {current_url}")

    checked_text = " / ".join(checked) if checked else "候補タブなし"
    raise SystemExit(f"リアプロのリスト検索結果画面を確認できませんでした。リアプロのリスト検索結果一覧を開いてから再取得してください。確認したタブ: {checked_text}")


def capture_scrolled_text() -> str:
    snapshots = []
    try:
        reset_scroll_positions()
        snapshots.append(run_chrome_javascript("document.body.innerText"))
        metrics = json.loads(run_chrome_javascript(
            "JSON.stringify({height: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight), viewport: window.innerHeight})"
        ))
        height = int(metrics.get("height") or 0)
        viewport = max(int(metrics.get("viewport") or 800), 400)
        positions = list(range(0, height + viewport, max(viewport - 120, 300))) or [0]

        for position in positions:
            run_chrome_javascript(f"window.scrollTo(0, {position});")
            time.sleep(0.18)
            snapshots.append(run_chrome_javascript("document.body.innerText"))

        run_chrome_javascript("window.scrollTo(0, 0);")
        snapshots.extend(capture_scrollable_elements_text())
    except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError):
        snapshots.append(run_chrome_javascript("document.body.innerText"))

    return merge_text_snapshots(snapshots)


def capture_scrollable_elements_text() -> list[str]:
    snapshots = []
    elements = json.loads(run_chrome_javascript(
        """
        JSON.stringify(Array.from(document.querySelectorAll('body *'))
          .map((el, index) => ({ index, height: el.scrollHeight, viewport: el.clientHeight, textLength: (el.innerText || '').length }))
          .filter((item) => item.height > item.viewport + 200 && item.viewport > 120 && item.textLength > 200)
          .sort((a, b) => (b.height - b.viewport) - (a.height - a.viewport))
          .slice(0, 6))
        """
    ))

    for element in elements:
        step = max(int(element.get("viewport") or 500) - 80, 240)
        height = int(element.get("height") or 0)
        for position in range(0, height + step, step):
            run_chrome_javascript(
                f"""
                (function() {{
                  const el = Array.from(document.querySelectorAll('body *'))[{int(element["index"])}];
                  if (el) {{
                    el.scrollTop = {position};
                    el.dispatchEvent(new Event('scroll', {{ bubbles: true }}));
                  }}
                }})();
                """
            )
            time.sleep(0.35)
            snapshots.append(run_chrome_javascript("document.body.innerText"))
            snapshots.append(run_chrome_javascript(
                f"""
                (function() {{
                  const el = Array.from(document.querySelectorAll('body *'))[{int(element["index"])}];
                  return el ? el.innerText : '';
                }})();
                """
            ))
        run_chrome_javascript(
            f"""
            (function() {{
              const el = Array.from(document.querySelectorAll('body *'))[{int(element["index"])}];
              if (el) {{
                el.scrollTop = 0;
                el.dispatchEvent(new Event('scroll', {{ bubbles: true }}));
              }}
            }})();
            """
        )

    return snapshots


def reset_scroll_positions() -> None:
    run_chrome_javascript(
        """
        (function() {
          window.scrollTo(0, 0);
          Array.from(document.querySelectorAll('body *')).forEach((el) => {
            if (el.scrollHeight > el.clientHeight + 100) {
              el.scrollTop = 0;
              el.dispatchEvent(new Event('scroll', { bubbles: true }));
            }
          });
        })();
        """
    )
    time.sleep(0.35)


def merge_text_snapshots(snapshots: list[str]) -> str:
    seen = set()
    chunks = []
    for snapshot in snapshots:
        normalized = snapshot.strip()
        if normalized and normalized not in seen:
            seen.add(normalized)
            chunks.append(normalized)
    return "\n\n".join(chunks)


def capture_current_tab(
    index: int,
    title: str,
    url: str,
    prompt: str = "このタブを取得対象として表示できていれば Enter を押してください...",
    auto: bool = False,
    pages: int = 1,
    start_page: int = 1,
    page_numbers: list[int] | None = None,
    capture_realpro_details: bool = True,
    source_hint: str = "",
) -> dict:
    if source_hint == "realpro" or ("realnetpro.com" in url and "room_detail.php" not in url):
        index, title, url = activate_realpro_result_tab(index, page_numbers[0] if page_numbers else start_page)
    else:
        set_active_tab(index)
    print(f"\n[{index}] {title}")
    print(url)
    if auto:
        print("自動取得します。")
    else:
        input(prompt)

    # Chrome's JavaScript execution through Apple Events may be disabled.
    # We still capture title/url and leave rawText empty when unavailable.
    raw_text = ""
    js_error = ""
    page_captures = []
    api_rooms = []
    api_page_captures = []
    api_error = ""
    if "e-bukken.app" in url:
        try:
            api_result = capture_eseikatsu_api_rooms(pages)
            api_rooms = api_result.get("rooms", [])
            api_page_captures = api_result.get("pageCaptures", [])
            api_error = api_result.get("error", "")
            raw_text = "\n".join(filter(None, [
                f"いい生活API取得 {len(api_rooms)}件",
                api_page_captures and f"APIページ {len(api_page_captures)}ページ",
            ]))
            page_captures = [{
                "pageNumber": 1,
                "url": run_chrome_javascript("location.href"),
                "lineCount": max(1, len([line for line in raw_text.splitlines() if line.strip()])),
                "textLength": max(len(raw_text), 1),
                "stopReason": "api-capture-used",
            }]
        except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError) as error:
            api_error = str(error)
    elif "realnetpro.com" in url and "room_detail.php" not in url:
        try:
            api_rooms, page_captures, raw_text = capture_realpro_dom_rooms(
                pages,
                capture_details=capture_realpro_details,
                page_numbers=page_numbers,
            )
            if start_page > 1 and not page_numbers:
                for offset, page_capture in enumerate(page_captures):
                    page_capture["pageNumber"] = start_page + offset
        except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError) as error:
            api_error = str(error)
            if "ログイン画面" in api_error or "リスト検索結果画面ではありません" in api_error:
                raise SystemExit(api_error)

    structured_source = ("realnetpro.com" in url and "room_detail.php" not in url) or "e-bukken.app" in url
    if structured_source and not raw_text:
        raw_text = api_error or "構造化取得に失敗しました。"
        page_captures = [{
            "pageNumber": 1,
            "url": run_chrome_javascript("location.href"),
            "lineCount": 1,
            "textLength": len(raw_text),
            "stopReason": "structured-capture-failed",
        }]

    if not structured_source:
        try:
            raw_text, page_captures = capture_paginated_text(pages)
        except subprocess.CalledProcessError as error:
            js_error = error.stderr.strip() or error.stdout.strip()
        finally:
            try:
                restore_current_url(url)
            except subprocess.CalledProcessError:
                pass

    return {
        "index": index,
        "title": title,
        "url": url,
        "rawText": raw_text,
        "rooms": api_rooms,
        "pageCaptures": page_captures,
        "apiPageCaptures": api_page_captures,
        "apiError": api_error,
        "jsError": js_error,
        "startPage": start_page,
        "listSort": "addr:asc" if source_hint == "realpro" else "",
    }


def capture_paginated_text(pages: int) -> tuple[str, list[dict]]:
    snapshots = []
    page_captures = []
    for page_number in range(max(pages, 1)):
        wait_for_page_text_ready()
        page_text = capture_scrolled_text()
        snapshots.append(page_text)
        page_captures.append({
            "pageNumber": page_number + 1,
            "url": run_chrome_javascript("location.href"),
            "lineCount": len([line for line in page_text.splitlines() if line.strip()]),
            "textLength": len(page_text),
        })
        if page_number >= pages - 1:
            page_captures[-1]["stopReason"] = "requested-pages-reached"
            break
        try:
            next_info = click_next_page_info()
            clicked = bool(next_info.get("clicked"))
        except subprocess.CalledProcessError:
            next_info = {"clicked": False, "reason": "click-error"}
            clicked = False
        page_captures[-1]["next"] = next_info
        if not clicked:
            page_captures[-1]["stopReason"] = next_info.get("reason") or "next-not-clicked"
            break
        time.sleep(1.2)
    return merge_text_snapshots(snapshots), page_captures


def capture_realpro_parallel_pages(pages: int, page_numbers: list[int] | None = None) -> tuple[list[dict], list[dict], str]:
    status_key = "__codexRealproParallelCapture"
    script = r"""
    window.__STATUS_KEY__ = { status: 'running', completedPages: 0 };
    void (async () => {
      const requestedPages = __PAGES__;
      const requestedPageNumbers = __PAGE_NUMBERS__;
      const baseUrl = new URL(location.href);
      baseUrl.searchParams.set('key', 'addr');
      baseUrl.searchParams.set('odr', 'asc');
      const firstPage = Number(baseUrl.searchParams.get('page') || '0') || 0;
      const pagerPages = Array.from(document.querySelectorAll('td.pager'))
        .map((el) => (el.getAttribute('onclick') || '').match(/pager\('([^']+)','([^']+)'\)/))
        .filter(Boolean)
        .map((match) => Number(match[2]))
        .filter(Number.isFinite);
      const maxPage = Math.max(firstPage, ...pagerPages);
      const lastPage = Math.min(firstPage + requestedPages - 1, maxPage);
      const pageIndexes = requestedPageNumbers.length
        ? requestedPageNumbers.map((pageNumber) => pageNumber - 1).filter((pageIndex) => pageIndex >= 0 && pageIndex <= maxPage)
        : Array.from(
            { length: Math.max(0, lastPage - firstPage + 1) },
            (_, index) => firstPage + index
          );
      const pageResults = [];

      const normalize = (value) => String(value || '').normalize('NFKC').replace(/\s+/g, ' ').trim();
      const cleanRoom = (value) => String(value || '').normalize('NFKC').match(/^[A-Za-z0-9-]+/)?.[0] || normalize(value);
      const yen = (value) => Number(String(value || '').normalize('NFKC').replace(/[^0-9]/g, '')) || 0;
      const parseAccess = (value) => {
        const match = String(value || '').match(/^沿線：(.+?)「(.+?)」(徒歩|バス|自動車|車|自転車)([0-9０-９]+)分/);
        if (!match) return { line: '', station: '', accessMethod: '徒歩', walkMinutes: 0 };
        return {
          line: normalize(match[1]),
          station: normalize(match[2]),
          accessMethod: match[3] === '自動車' ? '車' : match[3],
          walkMinutes: Number(String(match[4]).normalize('NFKC')),
        };
      };
      const textOf = (element) => String(element?.textContent || '');
      const splitCell = (td) => textOf(td).split(/\n+/).map((line) => line.trim()).filter(Boolean);
      const equipmentMarkers = ['家電', '家具', '駐車場有り', '駐車場あり', '駐車場空有', '駐車場空きあり', '駐車可', 'ペット', 'ネット無料', 'エアコン', 'オートロック', '宅配BOX'];
      __REALPRO_STATUS_HELPERS__

      const parseDocument = (doc, pageUrl) => {
        const rooms = [];
        const roomRowCount = doc.querySelectorAll('tr.room_info_tr').length;
        let building = { building: '', address: '', line: '', station: '', accessMethod: '徒歩', walkMinutes: 0 };
        for (const tr of Array.from(doc.querySelectorAll('tr'))) {
          const text = textOf(tr).trim();
          const lines = text.split(/\n+/).map((line) => line.trim()).filter(Boolean);
          const addressIndex = lines.findIndex((line) => line.startsWith('住所：'));
          const accessIndex = lines.findIndex((line) => line.startsWith('沿線：'));
          if (!tr.classList.contains('room_info_tr') && addressIndex > 0 && accessIndex > addressIndex) {
            building = {
              building: normalize(lines[addressIndex - 1]),
              address: normalize(lines[addressIndex].replace(/^住所：/, '')),
              ...parseAccess(lines[accessIndex]),
            };
            continue;
          }
          if (!tr.classList.contains('room_info_tr') || !building.building) continue;
          const cells = Array.from(tr.querySelectorAll('td'));
          const roomAnchor = tr.querySelector('a.room_number');
          const onclick = roomAnchor?.getAttribute('onclick') || '';
          const id = onclick.match(/go_detail\(event,'([^']+)'/)?.[1] || '';
          const roomLabel = normalize(textOf(roomAnchor) || textOf(cells[0]) || '');
          const status = realproRoomRowStatus(
            Array.from(tr.querySelectorAll('.st')).map((el) => normalize(textOf(el))).filter(Boolean).join(' '),
            textOf(cells[4])
          );
          const dateLines = splitCell(cells[5]);
          const layoutLines = splitCell(cells[6]);
          const rentLines = splitCell(cells[7]);
          const equipmentText = normalize(textOf(cells[1]) || '');
          rooms.push({
            ...building,
            room: cleanRoom(roomLabel),
            roomLabel,
            realproRoomId: id,
            layout: normalize(layoutLines[0]),
            area: normalize(layoutLines[1]).replace('m2', '㎡'),
            rent: yen(rentLines[0]),
            fee: yen(rentLines[1]),
            status,
            availableDate: normalize(dateLines[0]),
            adFee: '',
            adFeeStatus: '未確認',
            managementCompany: '',
            equipment: equipmentMarkers.filter((marker) => equipmentText.includes(marker)),
            webAd: '判定不可',
            imageReuse: '判定不可',
            floorPlanReuse: '判定不可',
            priorContact: '判定不可',
            applicationCount: null,
            applicationCountStatus: '未取得',
            detailCaptureStatus: id ? '未取得' : '詳細IDなし',
            detailCaptureReason: id ? '詳細取得前' : '一覧から詳細IDを取得できませんでした',
            detailHttpStatus: '',
            detailTextLength: 0,
            url: id ? `${location.origin}/room_detail.php?id=${encodeURIComponent(id)}&type=room` : '',
          });
        }
        const text = doc.body?.innerText || '';
        return {
          pageUrl,
          rooms,
          roomRowCount,
          roomIds: rooms.map((room) => room.realproRoomId).filter(Boolean),
          textLength: text.length,
          summary: (text.match(/[0-9,]+\s*棟\s*[0-9,]+\s*戸/) || [''])[0],
          loginDetected: /ログインID|パスワード/.test(text) && !/検索結果|部屋番号|空室|退去予定/.test(text),
          maintenanceDetected: /メンテナンス(?:中|を実施)|アクセスが集中|しばらく(?:時間をおいて|してから)|一時的に利用できません/.test(text),
        };
      };

      for (let offset = 0; offset < pageIndexes.length; offset += 2) {
        const batch = pageIndexes.slice(offset, offset + 2);
        const results = await Promise.all(batch.map(async (pageIndex) => {
          const pageUrl = new URL(baseUrl.href);
          pageUrl.searchParams.set('method', 'estate');
          pageUrl.searchParams.set('display', 'building');
          pageUrl.searchParams.set('key', 'addr');
          pageUrl.searchParams.set('odr', 'asc');
          pageUrl.searchParams.set('page', String(pageIndex));
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 20000);
          let response;
          let html;
          try {
            response = await fetch(pageUrl.href, { credentials: 'include', signal: controller.signal });
            if (!response.ok) throw new Error(`HTTP ${response.status}: page ${pageIndex + 1}`);
            html = await response.text();
          } catch (error) {
            if (controller.signal.aborted) throw new Error(`REALPRO_PAGE_TIMEOUT: page ${pageIndex + 1}`);
            throw error;
          } finally {
            clearTimeout(timeout);
          }
          const doc = new DOMParser().parseFromString(html, 'text/html');
          const parsed = parseDocument(doc, pageUrl.href);
          if (parsed.maintenanceDetected) throw new Error(`REALPRO_MAINTENANCE: page ${pageIndex + 1}`);
          return { pageIndex, ...parsed };
        }));
        pageResults.push(...results);
        window.__STATUS_KEY__ = {
          status: 'running',
          completedPages: pageResults.length,
          totalPages: pageIndexes.length,
          roomCount: pageResults.reduce((sum, page) => sum + page.rooms.length, 0),
        };
      }
      window.__STATUS_KEY__ = {
        status: 'done',
        firstPage,
        maxPage,
        pageResults: pageResults.sort((a, b) => a.pageIndex - b.pageIndex),
      };
    })().catch((error) => {
      window.__STATUS_KEY__ = { status: 'error', error: String(error), stack: error?.stack || '' };
    });
    """.replace("__REALPRO_STATUS_HELPERS__", REALPRO_STATUS_HELPERS_JS).replace("__STATUS_KEY__", status_key).replace("__PAGES__", str(max(pages, 1))).replace(
        "__PAGE_NUMBERS__", json.dumps(page_numbers or [])
    )
    run_chrome_javascript(script)

    deadline = time.time() + max(90, pages * 4)
    payload = {}
    last_completed_pages = 0
    while time.time() < deadline:
        payload = json.loads(run_chrome_javascript(
            f"JSON.stringify(window.{status_key} || {{ status: 'missing' }})"
        ))
        completed_pages = int(payload.get("completedPages") or 0)
        if payload.get("status") == "running" and completed_pages > 0 and completed_pages != last_completed_pages:
            print(
                f"リアプロ一覧取得: {completed_pages}/{int(payload.get('totalPages') or pages)}ページ / "
                f"{int(payload.get('roomCount') or 0)}戸",
                flush=True,
            )
            last_completed_pages = completed_pages
        if payload.get("status") == "done":
            break
        if payload.get("status") == "error":
            raise ValueError(payload.get("error") or "リアプロ並列取得に失敗しました。")
        time.sleep(0.5)
    if payload.get("status") != "done":
        raise ValueError("リアプロ並列取得がタイムアウトしました。")

    rooms = []
    page_captures = []
    raw_text_parts = []
    seen_ids = set()
    seen_keys = set()
    for result in payload.get("pageResults") or []:
        if result.get("loginDetected"):
            raise ValueError("リアプロがログイン画面です。")
        page_rooms = result.get("rooms") or []
        source_page = int(result.get("pageIndex") or 0) + 1
        for room in page_rooms:
            room["sourcePage"] = source_page
            room_id = str(room.get("realproRoomId") or "")
            key = "::".join(str(room.get(part) or "") for part in ["building", "room", "layout", "rent"])
            if room_id and room_id in seen_ids:
                continue
            if not room_id and key in seen_keys:
                continue
            rooms.append(room)
            if room_id:
                seen_ids.add(room_id)
            seen_keys.add(key)
        summary = result.get("summary") or ""
        summary_match = re.search(r"([0-9,]+)\s*棟\s*([0-9,]+)\s*戸", summary)
        raw_text_parts.append("\n".join(filter(None, [summary, f"DOM取得戸数 {len(page_rooms)}件"])))
        page_captures.append({
            "pageNumber": int(result.get("pageIndex") or 0) + 1,
            "url": result.get("pageUrl") or "",
            "lineCount": 2,
            "textLength": max(int(result.get("textLength") or 0), 1),
            "expandedRoomButtons": 0,
            "roomCount": len(page_rooms),
            "roomRowCount": int(result.get("roomRowCount") or 0),
            "roomAnchorCount": sum(1 for room in page_rooms if room.get("realproRoomId")),
            "roomIds": result.get("roomIds") or [],
            "listSort": "addr:asc",
            "summaryRooms": int(summary_match.group(2).replace(",", "")) if summary_match else 0,
            "loginDetected": False,
            "captureMode": "parallel-fetch",
        })
    if page_captures:
        final_page = page_captures[-1]["pageNumber"] - 1
        max_page = int(payload.get("maxPage") or 0)
        page_captures[-1]["stopReason"] = (
            "last-page-reached" if final_page >= max_page else "requested-pages-reached"
        )
    if not rooms:
        raise ValueError("リアプロ並列取得で号室を取得できませんでした。")
    return rooms, page_captures, merge_text_snapshots(raw_text_parts)


def capture_realpro_dom_rooms(
    pages: int,
    capture_details: bool = True,
    page_numbers: list[int] | None = None,
) -> tuple[list[dict], list[dict], str]:
    initial_url = run_chrome_javascript("location.href")
    try:
        print(f"リアプロ一覧直接取得: 最大2ページ同時 / 対象{max(pages, 1)}ページ", flush=True)
        rooms, page_captures, raw_text = capture_realpro_parallel_pages(pages, page_numbers=page_numbers)
        raw_text_parts = [raw_text]
    except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError) as parallel_error:
        parallel_error_text = str(parallel_error)
        if re.search(r"HTTP\s+(?:429|503)|REALPRO_MAINTENANCE|メンテナンス|アクセスが集中", parallel_error_text, re.IGNORECASE):
            raise ValueError("リアプロ側の一時制限またはメンテナンス表示を検知しました。取得済み位置を保存して停止します。") from parallel_error
        if "REALPRO_PAGE_TIMEOUT" in parallel_error_text or "timed out" in parallel_error_text.lower():
            raise ValueError("リアプロ一覧ページが時間内に応答しませんでした。取得済み位置を保存して停止します。") from parallel_error
        print(f"リアプロ並列取得を従来方式へ切替: {parallel_error}", flush=True)
        rooms = []
        page_captures = []
        raw_text_parts = []
        try:
            selected_pages = page_numbers or list(range(1, max(pages, 1) + 1))
            for selected_index, actual_page_number in enumerate(selected_pages):
                if page_numbers:
                    move_realpro_to_page(actual_page_number)
                print(f"リアプロ一覧取得: {selected_index + 1}/{len(selected_pages)}ページ（{actual_page_number}ページ目）", flush=True)
                wait_for_page_text_ready()
                page_status = realpro_page_status()
                if page_status.get("loginDetected"):
                    raise ValueError("リアプロがログイン画面です。Chromeでリアプロにログインし、リスト検索結果一覧を開いてから再取得してください。")
                if not page_status.get("isResultPage"):
                    raise ValueError(f"リアプロのリスト検索結果画面ではありません: {page_status.get('url') or ''}")
                expanded_count = expand_realpro_all_rooms()
                page_rooms = json.loads(run_chrome_javascript(REALPRO_DOM_ROOMS_JS))
                summary = json.loads(run_chrome_javascript(
                    """
                    JSON.stringify((() => {
                      const text = document.body && document.body.textContent || '';
                      return {
                        summary: (text.match(/[0-9,]+\\s*棟\\s*[0-9,]+\\s*戸/) || [''])[0],
                        textLength: text.length,
                        url: location.href,
                      };
                    })())
                    """
                ))
                raw_text = "\n".join(filter(None, [
                    summary.get("summary", ""),
                    f"DOM取得戸数 {len(page_rooms)}件",
                ]))
                raw_text_parts.append(raw_text)
                summary_match = re.search(r"([0-9,]+)\s*棟\s*([0-9,]+)\s*戸", summary.get("summary") or "")
                page_capture = {
                    "pageNumber": actual_page_number,
                    "url": summary.get("url") or run_chrome_javascript("location.href"),
                    "lineCount": max(1, len([line for line in raw_text.splitlines() if line.strip()])),
                    "textLength": max(len(raw_text), int(summary.get("textLength") or 0), 1),
                    "expandedRoomButtons": expanded_count,
                    "roomCount": len(page_rooms),
                    "roomRowCount": page_status.get("roomRowCount", 0),
                    "roomAnchorCount": page_status.get("roomAnchorCount", 0),
                    "roomIds": [str(room.get("realproRoomId") or "") for room in page_rooms if room.get("realproRoomId")],
                    "listSort": "addr:asc",
                    "summaryRooms": int(summary_match.group(2).replace(",", "")) if summary_match else 0,
                    "loginDetected": False,
                    "captureMode": "sequential-fallback",
                }
                existing_ids = {str(room.get("realproRoomId") or "") for room in rooms if room.get("realproRoomId")}
                existing_keys = {
                    "::".join(str(room.get(part) or "") for part in ["building", "room", "layout", "rent"])
                    for room in rooms
                }
                for room in page_rooms:
                    room["sourcePage"] = actual_page_number
                    room_id = str(room.get("realproRoomId") or "")
                    key = "::".join(str(room.get(part) or "") for part in ["building", "room", "layout", "rent"])
                    if room_id and room_id in existing_ids:
                        continue
                    if not room_id and key in existing_keys:
                        continue
                    rooms.append(room)
                    if room_id:
                        existing_ids.add(room_id)
                    existing_keys.add(key)
                if selected_index >= len(selected_pages) - 1:
                    page_capture["stopReason"] = "requested-pages-reached"
                    page_captures.append(page_capture)
                    break
                if page_numbers:
                    page_captures.append(page_capture)
                    continue
                try:
                    next_info = click_next_page_info()
                    clicked = bool(next_info.get("clicked"))
                except subprocess.CalledProcessError:
                    next_info = {"clicked": False, "reason": "click-error"}
                    clicked = False
                page_capture["next"] = next_info
                if not clicked:
                    page_capture["stopReason"] = next_info.get("reason") or "next-not-clicked"
                    page_captures.append(page_capture)
                    break
                page_captures.append(page_capture)
                time.sleep(1.2)
        finally:
            restore_current_url(initial_url)
            time.sleep(1.0)
            wait_for_page_text_ready()

    if not capture_details:
        return rooms, page_captures, merge_text_snapshots(raw_text_parts)

    detail_summaries = []
    detail_targets = [room for room in rooms if room.get("realproRoomId")]
    for index in range(0, len(detail_targets), 10):
        chunk = detail_targets[index:index + 10]
        print(f"リアプロ詳細確認: {min(index + 10, len(detail_targets))}/{len(detail_targets)}件", flush=True)
        try:
            detail_summaries.extend(capture_realpro_detail_summaries(chunk))
        except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError) as error:
            reason = str(error)
            detail_summaries.extend({
                "realproRoomId": str(room.get("realproRoomId") or ""),
                "webAd": "判定不可",
                "equipment": [],
                "applicationCount": None,
                "applicationCountStatus": "取得不可",
                "applicationCountReason": "詳細取得処理が実行できませんでした",
                "title": "",
                "url": room.get("url", ""),
                "detailCaptureStatus": "詳細確認失敗",
                "detailCaptureReason": reason,
                "status": "",
                "detailTextLength": 0,
            } for room in chunk if room.get("realproRoomId"))
        detail_rooms_by_id = {str(room.get("realproRoomId") or ""): room for room in detail_targets}
        confirmed_candidates = sum(
            1 for detail in detail_summaries
            if detail.get("detailCaptureStatus") == "取得OK"
            and detail.get("webAd") in {"可", "管理会社に確認"}
            and application_count_known(detail)
            and int(detail.get("applicationCount")) == 0
            and not re.search(
                r"商談中|審査中|申込あり",
                str(detail_rooms_by_id.get(str(detail.get("realproRoomId") or ""), {}).get("status") or ""),
            )
        )
        print(
            f"候補判定: {min(index + 10, len(detail_targets))}/{len(detail_targets)}件 / 候補{confirmed_candidates}件",
            flush=True,
        )
        time.sleep(0.4)
    details_by_id = {str(detail.get("realproRoomId")): detail for detail in detail_summaries}
    for room in rooms:
        detail = details_by_id.get(str(room.get("realproRoomId") or ""))
        if detail:
            room.update({
                "status": detail.get("detailAvailabilityStatus") or room.get("status", ""),
                "webAd": detail.get("webAd", room.get("webAd", "判定不可")),
                "adFee": detail.get("adFee", room.get("adFee", "")),
                "adFeeStatus": detail.get("adFeeStatus", room.get("adFeeStatus", "未確認")),
                "managementCompany": detail.get("managementCompany", room.get("managementCompany", "")),
                "equipment": sorted(set((room.get("equipment") or []) + (detail.get("equipment") or []))),
                "applicationCount": (
                    int(detail.get("applicationCount"))
                    if application_count_known(detail)
                    else None
                ),
                "applicationCountStatus": detail.get("applicationCountStatus", "取得不可"),
                "applicationCountReason": detail.get("applicationCountReason", ""),
                "detailTitle": detail.get("title", ""),
                "url": detail.get("url", room.get("url", "")),
                "detailCaptureStatus": detail.get("detailCaptureStatus") or ("詳細確認不完全" if detail.get("webAd") == "判定不可" else "取得OK"),
                "detailRuleVersion": DETAIL_RULE_VERSION,
                "detailCaptureReason": detail.get("detailCaptureReason", ""),
                "detailHttpStatus": detail.get("status", ""),
                "detailTextLength": detail.get("detailTextLength", 0),
            })

    return rooms, page_captures, merge_text_snapshots(raw_text_parts)


def realpro_page_status() -> dict:
    try:
        return json.loads(run_chrome_javascript(
            """
            JSON.stringify((() => {
              const text = document.body && document.body.innerText || '';
              const normalized = text.normalize('NFKC');
              const url = location.href;
              const loginDetected = /ログインID|パスワード|ログイン/.test(normalized)
                && !/検索結果|部屋番号|空室|退去予定/.test(normalized);
              return {
                url,
                title: document.title || '',
                textLength: text.length,
                isResultPage: location.hostname.includes('realnetpro.com')
                  && location.pathname.includes('main.php')
                  && location.search.includes('method=estate'),
                loginDetected,
                roomRowCount: document.querySelectorAll('tr.room_info_tr').length,
                roomAnchorCount: document.querySelectorAll('a.room_number').length,
                expandButtonCount: document.querySelectorAll('.all_room_open, .hide_room_open').length,
                summary: (normalized.match(/[0-9,]+\\s*棟\\s*[0-9,]+\\s*戸/) || [''])[0],
              };
            })())
            """
        ))
    except (subprocess.CalledProcessError, json.JSONDecodeError):
        return {"isResultPage": False, "loginDetected": False, "url": ""}


def expand_realpro_all_rooms() -> int:
    total_clicked = 0
    for _ in range(3):
        try:
            clicked = int(run_chrome_javascript(
                """
                (() => {
                  const isVisible = (el) => {
                    const style = window.getComputedStyle(el);
                    const rect = el.getBoundingClientRect();
                    return style.display !== 'none' && style.visibility !== 'hidden' && rect.width >= 0 && rect.height >= 0;
                  };
                  const targets = Array.from(document.querySelectorAll('.all_room_open, .hide_room_open'))
                    .filter((el) => {
                      const text = String(el.textContent || el.value || '').replace(/\\s+/g, '');
                      return isVisible(el) && (text.includes('全部屋を表示') || text.includes('表示する'));
                    });
                  targets.forEach((el) => el.click());
                  return targets.length;
                })()
                """
            ) or "0")
        except (subprocess.CalledProcessError, ValueError):
            clicked = 0
        total_clicked += clicked
        if not clicked:
            break
        time.sleep(0.8)
        wait_for_page_text_ready()
    return total_clicked


def capture_realpro_detail_summaries(
    rooms: list[dict],
    concurrency: int = 4,
    timeout_ms: int = 20000,
) -> list[dict]:
    ids = []
    seen = set()
    for room in rooms:
        room_id = str(room.get("realproRoomId") or "")
        if room_id and room_id not in seen:
            ids.append(room_id)
            seen.add(room_id)

    if not ids:
        return []

    status_key = "__codexRealproDetailCapture"
    run_chrome_javascript(
        f"""
        window.{status_key} = {{ status: 'running' }};
        void (async () => {{
          const ids = {json.dumps(ids, ensure_ascii=False)};
          {REALPRO_STATUS_HELPERS_JS}
          const details = [];
          const requestedConcurrency = Math.max(1, Math.min(Number({concurrency}) || 4, 4));
          const maxConcurrency = document.visibilityState === 'visible'
            ? requestedConcurrency : Math.min(requestedConcurrency, 3);
          let currentConcurrency = maxConcurrency;
          let index = 0;
          const captureOne = async (id) => {{
            try {{
              const url = `${{location.origin}}/room_detail.php?id=${{encodeURIComponent(id)}}&type=room`;
              const {{ response, text: html }} = await fetchTextWithTimeout(url, {{ credentials: 'include' }}, {timeout_ms});
              const loginRequired = response.redirected && /\\/index\\.php(?:[?#]|$)/i.test(response.url || '');
              if (loginRequired) {{
                return {{
                  realproRoomId: id,
                  title: 'LOGIN_REQUIRED',
                  url,
                  status: response.status,
                  webAd: '\\u5224\\u5b9a\\u4e0d\\u53ef',
                  equipment: [],
                  applicationCount: null,
                  applicationCountStatus: 'LOGIN_REQUIRED',
                  applicationCountReason: 'RealPro redirected the detail request to the login page.',
                  detailCaptureStatus: 'LOGIN_REQUIRED',
                  detailCaptureReason: 'Sign in again in the dedicated Chrome before retrying details.',
                  detailTextLength: 0,
                }};
              }}
              const doc = new DOMParser().parseFromString(html, 'text/html');
              const text = (doc.body && doc.body.innerText || '').normalize('NFKC');
              const maintenanceDetected = [429, 503].includes(response.status)
                || /メンテナンス(?:中|を実施)|アクセスが集中|しばらく(?:時間をおいて|してから)|一時的に利用できません/.test(text);
              if (maintenanceDetected) {{
                return {{
                  realproRoomId: id,
                  title: 'MAINTENANCE',
                  url,
                  status: response.status,
                  webAd: '判定不可',
                  equipment: [],
                  applicationCount: null,
                  applicationCountStatus: '取得待機',
                  applicationCountReason: 'リアプロの混雑またはメンテナンスを検知しました',
                  detailCaptureStatus: 'MAINTENANCE',
                  detailCaptureReason: 'リアプロの混雑またはメンテナンスを検知したため取得を停止しました',
                  detailTextLength: text.length,
                }};
              }}
              const blockedStatus = realproBlockedDetailStatus(text);
              if (blockedStatus) {{
                return {{
                  realproRoomId: id,
                  title: (doc.querySelector('title') && doc.querySelector('title').innerText || '').trim(),
                  url,
                  status: response.status,
                  webAd: '判定不可',
                  adFee: '',
                  adFeeStatus: '未確認',
                  managementCompany: '',
                  equipment: [],
                  applicationCount: null,
                  applicationCountStatus: '募集対象外',
                  applicationCountReason: `リアプロ詳細で${{blockedStatus}}を確認`,
                  detailCaptureStatus: '募集対象外',
                  detailCaptureReason: `リアプロ詳細で${{blockedStatus}}を確認`,
                  detailAvailabilityStatus: blockedStatus,
                  detailTextLength: text.length,
                }};
              }}
              const adSection = (text.match(/(?:webサービスにこの物件の広告を掲載|WEB広告掲載|広告掲載)[\\s\\S]{{0,500}}/i) || [''])[0];
              const webAd = extractWebAd(text);
              const adFeeResult = extractAdFee(doc);
              const managementCompany = extractManagementCompany(doc, text);
              const application = await fetchApplicationCount(doc);
              const pageRoomId = (doc.querySelector('#room_id') && doc.querySelector('#room_id').value || '').trim();
              const detailReasons = detailCaptureReasons({{ response, text, adSection, webAd, adFeeResult, application, pageRoomId, expectedRoomId: id }});
              return {{
                realproRoomId: id,
                title: (doc.querySelector('title') && doc.querySelector('title').innerText || '').trim(),
                url,
                status: response.status,
                webAd,
                adFee: adFeeResult.value,
                adFeeStatus: adFeeResult.status,
                managementCompany,
                equipment: extractEquipment(text),
                applicationCount: application.count,
                applicationCountStatus: application.status,
                applicationCountReason: application.reason,
                detailCaptureStatus: detailReasons.length ? '詳細確認不完全' : '取得OK',
                detailCaptureReason: detailReasons.join(' / '),
                detailTextLength: text.length,
              }};
            }} catch (error) {{
              return {{
                realproRoomId: id,
                title: '',
                url: `${{location.origin}}/room_detail.php?id=${{encodeURIComponent(id)}}&type=room`,
                status: 0,
                webAd: '判定不可',
                equipment: [],
                applicationCount: null,
                applicationCountStatus: '取得不可',
                applicationCountReason: '詳細ページの取得に失敗しました',
                detailCaptureStatus: '取得エラー',
                detailCaptureReason: String(error),
                detailTextLength: 0,
                error: String(error),
              }};
            }}
          }};
          // Keep at most four requests active, but refill an open slot as soon
          // as one detail finishes. This removes the old per-batch idle time
          // without increasing RealPro's peak request concurrency.
          const inFlight = new Map();
          let failedCount = 0;
          let consecutiveSuccesses = 0;
          let maintenanceDetected = false;
          let loginRequired = false;
          const launchOne = async (id) => {{
            const task = captureOne(id).then((detail) => ({{ id, detail }}));
            inFlight.set(id, task);
            // Background Chrome tabs can throttle short timers to a minute.
            // Cap hidden tabs at three requests instead of timer-based staggering.
            if (document.visibilityState === 'visible') await sleep(150);
          }};
          while ((index < ids.length || inFlight.size) && !maintenanceDetected && !loginRequired) {{
            while (index < ids.length && inFlight.size < currentConcurrency) {{
              const id = ids[index];
              index += 1;
              await launchOne(id);
            }}
            if (!inFlight.size) break;
            const completed = await Promise.race([...inFlight.values()]);
            inFlight.delete(completed.id);
            const detail = completed.detail;
            details.push(detail);
            maintenanceDetected = detail.detailCaptureStatus === 'MAINTENANCE';
            loginRequired = detail.detailCaptureStatus === 'LOGIN_REQUIRED';
            if (detail.detailCaptureStatus === '取得エラー') {{
              failedCount += 1;
              consecutiveSuccesses = 0;
              currentConcurrency = Math.min(currentConcurrency, 2);
              await sleep(failedCount >= 2 ? 2000 : 600);
            }} else if (!maintenanceDetected && !loginRequired) {{
              consecutiveSuccesses += 1;
              if (currentConcurrency < maxConcurrency && consecutiveSuccesses >= 8) {{
                currentConcurrency = maxConcurrency;
                failedCount = 0;
              }}
            }}
            window.{status_key} = {{
              status: 'running',
              details,
              currentConcurrency,
              maintenanceDetected,
              loginRequired,
              failedCount,
              completed: details.length,
              total: ids.length,
            }};
          }}
          // Requests already in progress are allowed to finish, but no new
          // request is started after maintenance/login detection.
          if (inFlight.size) {{
            const remaining = await Promise.all([...inFlight.values()]);
            for (const completed of remaining) {{
              if (!details.some((detail) => String(detail.realproRoomId || '') === String(completed.id))) {{
                details.push(completed.detail);
              }}
            }}
          }}
          window.{status_key} = {{
            status: 'done',
            details,
            currentConcurrency,
            maintenanceDetected: maintenanceDetected || details.some((detail) => detail.detailCaptureStatus === 'MAINTENANCE'),
            loginRequired: loginRequired || details.some((detail) => detail.detailCaptureStatus === 'LOGIN_REQUIRED'),
          }};

          function sleep(ms) {{
            return new Promise((resolve) => setTimeout(resolve, ms));
          }}

          async function fetchWithTimeout(url, options = {{}}, timeoutMs = 10000) {{
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), timeoutMs);
            try {{
              return await fetch(url, {{ ...options, signal: controller.signal }});
            }} finally {{
              clearTimeout(timer);
            }}
          }}

          async function fetchTextWithTimeout(url, options = {{}}, timeoutMs = 10000) {{
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), timeoutMs);
            try {{
              const response = await fetch(url, {{ ...options, signal: controller.signal }});
              const text = await response.text();
              return {{ response, text }};
            }} finally {{
              clearTimeout(timer);
            }}
          }}

          function extractWebAd(text) {{
            const normalized = String(text || '').normalize('NFKC').replace(/\\s+/g, ' ');
            const marker = normalized.search(/webサービスにこの物件の広告を掲載|WEB広告掲載|広告掲載/i);
            const webSection = marker >= 0 ? normalized.slice(marker, marker + 500) : '';
            if (/許可されていません|掲載不可|不可/.test(webSection)) return '許可されていません';
            if (/管理会社に確認|要確認|管理会社へご確認|掲載希望の場合は管理会社/.test(webSection)) return '管理会社に確認';
            if (/[［\\[]?\\s*可\\s*[］\\]]?|掲載可|許可されています/.test(webSection)) return '可';
            return '判定不可';
          }}

          function extractAdFee(doc) {{
            const label = Array.from(doc.querySelectorAll('th,td')).find((element) =>
              String(element.textContent || '').normalize('NFKC').replace(/\\s+/g, '').toUpperCase() === 'AD'
            );
            if (!label) return {{ value: '', status: '未確認' }};
            const value = String(label.nextElementSibling && label.nextElementSibling.textContent || '')
              .normalize('NFKC').replace(/\\s+/g, ' ').trim();
            return {{ value: value || 'なし', status: '確認済み' }};
          }}

          function extractManagementCompany(doc, text) {{
            const labelPattern = /^(?:管理会社(?:名|情報)?|元付(?:会社|業者)(?:名)?)$/;
            const clean = (value) => String(value || '')
              .normalize('NFKC')
              .replace(/\\s+/g, ' ')
              .trim();
            const companyName = doc.querySelector('.company-name');
            if (companyName && clean(companyName.textContent)) {{
              return clean(companyName.textContent).slice(0, 120);
            }}
            const labels = Array.from(doc.querySelectorAll('th, td, dt'));
            for (const label of labels) {{
              const labelText = clean(label.textContent).replace(/[:：]$/, '');
              if (!labelPattern.test(labelText)) continue;
              const candidates = [
                label.nextElementSibling,
                label.parentElement && label.parentElement.querySelector('td:last-child, dd'),
              ];
              for (const candidate of candidates) {{
                if (!candidate || candidate === label) continue;
                const value = clean(candidate.textContent);
                if (value && value !== labelText) return value.slice(0, 120);
              }}
            }}
            const input = Array.from(doc.querySelectorAll('input[type="hidden"], input[type="text"]')).find((element) => {{
              const key = `${{element.id || ''}} ${{element.name || ''}}`.toLowerCase();
              return /(?:management|kanri|moto).*(?:company|kaisha).*(?:name)?/.test(key) && clean(element.value);
            }});
            if (input) return clean(input.value).slice(0, 120);
            const normalized = String(text || '').normalize('NFKC');
            const match = normalized.match(/(?:^|\\n)\\s*(?:管理会社(?:名|情報)?|元付(?:会社|業者)(?:名)?)\\s*(?:\\n|[:：])\\s*([^\\n]{{1,120}})/im);
            return clean(match && match[1] || '').slice(0, 120);
          }}

          function detailCaptureReasons({{ response, text, adSection, webAd, adFeeResult, application, pageRoomId, expectedRoomId }}) {{
            const reasons = [];
            if (!response.ok) reasons.push(`HTTP ${{response.status}}`);
            if (!text) reasons.push('詳細本文が空です');
            if (response.url && /\\/login(?:[/?]|$)/i.test(response.url)) reasons.push('ログイン画面へ転送されました');
            if (expectedRoomId && !pageRoomId) reasons.push('詳細IDを確認できません');
            if (pageRoomId && expectedRoomId && pageRoomId !== expectedRoomId) reasons.push('詳細IDが一致しません');
            if (adSection && webAd === '判定不可') reasons.push('WEB広告掲載可否の文言を検出できませんでした');
            if (adFeeResult.status !== '確認済み') reasons.push('AD欄を検出できませんでした');
            if (application.status === '取得不可') reasons.push(application.reason || '電子入居申込件数を確認できませんでした');
            return reasons;
          }}

          function extractApplicationCount(text) {{
            const normalized = String(text || '').normalize('NFKC').replace(/\\s+/g, ' ');
            const match = normalized.match(/(?:電子入居申込|入居申込|申込|申し込み)\\s*(?:件数|数)?\\s*[:：]?\\s*([0-9]+)\\s*件?/);
            return match ? Number(match[1]) : null;
          }}

          function extractEquipment(text) {{
            const value = String(text || '').normalize('NFKC');
            const rules = [
              ['バス・トイレ別', /バス・トイレ別|BT別|セパレート/],
              ['独立洗面台', /独立洗面|洗面化粧台|シャンプードレッサー/],
              ['エアコン', /エアコン/],
              ['暖房', /暖房/],
              ['オートロック', /オートロック/],
              ['宅配ボックス', /宅配ボックス|宅配BOX/],
              ['インターネット無料', /インターネット無料|ネット無料/],
              ['Wi-Fi無料', /Wi-?Fi無料|Wifi無料|ワイファイ無料/i],
              ['駐輪場あり', /駐輪場(?:有り|あり|可)/],
              ['ペット相談', /ペット相談|ペット可|ペット飼育/],
              ['灯油暖房', /灯油暖房|灯油FF/],
              ['都市ガス', /都市ガス/],
              ['プロパンガス', /プロパンガス|LPガス/],
              ['エレベーター', /エレベーター/],
              ['防犯カメラ', /防犯カメラ/],
            ];
            const equipment = rules.filter(([, pattern]) => pattern.test(value)).map(([label]) => label);
            const parkingText = (value.match(/駐車場[\\s\\S]{{0,180}}/) || [''])[0];
            if (parkingText && !/空きなし|空なし|無し|なし|無|不可|要確認|満車/.test(parkingText) && /空きあり|空有|空車|有り|あり|可/.test(parkingText)) {{
              equipment.push('駐車場空きあり');
            }}
            return equipment;
          }}

          async function fetchApplicationCount(doc) {{
            const text = doc.body && doc.body.innerText || '';
            const fallbackCount = extractApplicationCount(text);
            try {{
              const value = (selector) => doc.querySelector(selector) && doc.querySelector(selector).value || '';
              const displayFlag = value('#njc_apply_display_flag') || 'N';
              const body = new URLSearchParams();
              body.set('bk_type', '1');
              body.set('rnp_bk_id', value('#building_id'));
              body.set('rnp_hy_id', value('#room_id'));
              body.set('residence_type', value('#residence_type') || 'room');
              body.set('company_id', value('#company_id'));
              body.set('user_id', value('#user_id'));
              body.set('func', 'request');
              body.set('option_break_flag', value('#mylist_njc_apply_option_break_flag') || '0');
              const {{ text: raw }} = await fetchTextWithTimeout('./ajax/starfruit_auth_tyukai.php', {{
                method: 'POST',
                credentials: 'include',
                headers: {{ 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }},
                body: body.toString(),
              }}, 10000);
              const result = JSON.parse(raw);
              const rawCount = result && result.count;
              const apiCount = rawCount === null || rawCount === undefined || rawCount === '' ? null : Number(rawCount);
              const rawErrorCode = result && result.error_code;
              const apiErrorCode = rawErrorCode === null || rawErrorCode === undefined || rawErrorCode === '' ? null : Number(rawErrorCode);
              const noApplicationFeature = apiErrorCode === 1
                && apiCount === 0
                && !String(result && result.error || '').trim()
                && Array.isArray(result && result.request)
                && result.request.length === 0;
              const applicationNotAccepted = apiErrorCode === 6
                && apiCount === 0
                && String(result && result.error || '').trim() === '電子入居申込を受け付けられていません。'
                && (!Array.isArray(result && result.request) || result.request.length === 0)
                && !Boolean(result && result.jisya_mousikomi);
              if (Number.isFinite(apiCount) && apiCount >= 0 && (!Number.isFinite(apiErrorCode) || apiErrorCode === 0 || noApplicationFeature || applicationNotAccepted)) {{
                return {{
                  count: apiCount,
                  status: 'API確認',
                  reason: applicationNotAccepted
                    ? '電子入居申込受付対象外・申込0件を確認'
                    : (noApplicationFeature
                      ? '申込API機能対象外・申込一覧0件を確認'
                      : (displayFlag === 'Y' ? '' : '申込表示外のためAPIで確認')),
                }};
              }}
              if (Number.isFinite(apiErrorCode) && apiErrorCode !== 0) {{
                const diagnostic = JSON.stringify({{
                  error_code: apiErrorCode,
                  count: Number.isFinite(apiCount) ? apiCount : null,
                  error: String(result && result.error || ''),
                  requestCount: Array.isArray(result && result.request) ? result.request.length : null,
                  jisya_mousikomi: Boolean(result && result.jisya_mousikomi),
                }});
                throw new Error(`Application API error_code=${{apiErrorCode}} ${{diagnostic}}`);
              }}
              throw new Error('申込APIの件数が不正です');
            }} catch (error) {{
              return fallbackCount === null
                ? {{ count: null, status: '取得不可', reason: `申込API取得失敗: ${{String(error)}}` }}
                : {{ count: fallbackCount, status: '本文確認', reason: '申込API取得失敗後に本文で確認' }};
            }}
          }}
        }})().catch((error) => {{
          window.{status_key} = {{ status: 'error', error: String(error), stack: error && error.stack }};
        }});
        true;
        """
    )

    deadline = time.monotonic() + min(900, max(300, len(ids) * 30))
    last_payload = {}
    while time.monotonic() < deadline:
        payload = json.loads(run_chrome_javascript(f"JSON.stringify(window.{status_key} || {{ status: 'missing' }})"))
        last_payload = payload
        if payload.get("status") == "done":
            return payload.get("details", [])
        if payload.get("status") == "error":
            break
        time.sleep(0.5)

    details = last_payload.get("details", [])
    returned_ids = {str(detail.get("realproRoomId") or "") for detail in details}
    for room_id in ids:
        if room_id not in returned_ids:
            details.append({
                "realproRoomId": room_id,
                "detailCaptureStatus": "取得エラー",
                "detailCaptureReason": "詳細取得の待機上限を超えました。未確認のまま再試行してください。",
                "applicationCount": None,
                "applicationCountStatus": "取得不可",
                "webAd": "判定不可",
                "adFeeStatus": "未確認",
            })
    return details


def restore_current_url(url: str) -> None:
    run_chrome_javascript(
        f"""
        if (location.href !== {json.dumps(url, ensure_ascii=False)}) {{
          location.href = {json.dumps(url, ensure_ascii=False)};
        }}
        """
    )


def refresh_execution_tab(index: int, url: str) -> None:
    separator = "&" if "?" in url else "?"
    refresh_url = f"{url}{separator}codex_detail_refresh={int(time.time() * 1000)}"
    if not IS_MAC:
        if not is_realpro_tab_url(url):
            raise ValueError("リアプロ以外のURLを詳細再読込しようとしました。")
        tab = next((item for item in bridge_tabs().get("tabs", []) if int(item.get("index") or 0) == int(index)), None)
        if not tab or not tab.get("id") or not is_realpro_tab_url(tab.get("url")):
            raise ValueError("リアプロタブの位置が変わりました。システムタブは再読込しません。")
        bridge_request("/navigate", {"id": tab["id"], "url": refresh_url, "activate": False})
    else:
        set_active_tab(index)
        run_chrome_javascript(f"location.href = {json.dumps(refresh_url, ensure_ascii=False)}; true")
    time.sleep(2.0)


REALPRO_DOM_ROOMS_JS = r"""
JSON.stringify((() => {
  const normalize = (value) => String(value || '').normalize('NFKC').replace(/\s+/g, ' ').trim();
  const cleanRoom = (value) => String(value || '').normalize('NFKC').match(/^[A-Za-z0-9-]+/)?.[0] || normalize(value);
  const yen = (value) => Number(String(value || '').normalize('NFKC').replace(/[^0-9]/g, '')) || 0;
  const parseAccess = (value) => {
    const match = String(value || '').match(/^沿線：(.+?)「(.+?)」(徒歩|バス|自動車|車|自転車)([0-9０-９]+)分/);
    if (!match) return { line: '', station: '', accessMethod: '徒歩', walkMinutes: 0 };
    return {
      line: normalize(match[1]),
      station: normalize(match[2]),
      accessMethod: match[3] === '自動車' ? '車' : match[3],
      walkMinutes: Number(String(match[4]).normalize('NFKC')),
    };
  };
  const textOf = (element) => String(element?.textContent || '');
  const splitCell = (td) => textOf(td).split(/\n+/).map((line) => line.trim()).filter(Boolean);
  const equipmentMarkers = ['家電', '家具', '駐車場有り', '駐車場あり', '駐車場空有', '駐車場空きあり', '駐車可', 'ペット', 'ネット無料', 'エアコン', 'オートロック', '宅配BOX'];
  __REALPRO_STATUS_HELPERS__
  const rooms = [];
  let building = { building: '', address: '', line: '', station: '', accessMethod: '徒歩', walkMinutes: 0 };

  for (const tr of Array.from(document.querySelectorAll('tr'))) {
    const text = textOf(tr).trim();
    const lines = text.split(/\n+/).map((line) => line.trim()).filter(Boolean);
    const addressIndex = lines.findIndex((line) => line.startsWith('住所：'));
    const accessIndex = lines.findIndex((line) => line.startsWith('沿線：'));
    if (!tr.classList.contains('room_info_tr') && addressIndex > 0 && accessIndex > addressIndex) {
      building = {
        building: normalize(lines[addressIndex - 1]),
        address: normalize(lines[addressIndex].replace(/^住所：/, '')),
        ...parseAccess(lines[accessIndex]),
      };
      continue;
    }

    if (!tr.classList.contains('room_info_tr') || !building.building) continue;

    const cells = Array.from(tr.querySelectorAll('td'));
    const roomAnchor = tr.querySelector('a.room_number');
    const onclick = roomAnchor?.getAttribute('onclick') || '';
    const id = onclick.match(/go_detail\(event,'([^']+)'/)?.[1] || '';
    const roomLabel = normalize(textOf(roomAnchor) || textOf(cells[0]) || '');
    const status = realproRoomRowStatus(
      Array.from(tr.querySelectorAll('.st')).map((el) => normalize(textOf(el))).filter(Boolean).join(' '),
      textOf(cells[4])
    );
    const dateLines = splitCell(cells[5]);
    const layoutLines = splitCell(cells[6]);
    const rentLines = splitCell(cells[7]);
    const equipmentText = normalize(textOf(cells[1]) || '');

    rooms.push({
      ...building,
      room: cleanRoom(roomLabel),
      roomLabel,
      realproRoomId: id,
      layout: normalize(layoutLines[0]),
      area: normalize(layoutLines[1]).replace('m2', '㎡'),
      rent: yen(rentLines[0]),
      fee: yen(rentLines[1]),
      status,
      availableDate: normalize(dateLines[0]),
      adFee: '',
      adFeeStatus: '未確認',
      managementCompany: '',
      equipment: equipmentMarkers.filter((marker) => equipmentText.includes(marker)),
      webAd: '判定不可',
      imageReuse: '判定不可',
      floorPlanReuse: '判定不可',
      priorContact: '判定不可',
      applicationCount: null,
      applicationCountStatus: '未取得',
      detailCaptureStatus: id ? '未取得' : '詳細IDなし',
      detailCaptureReason: id ? '詳細取得前' : '一覧から詳細IDを取得できませんでした',
      detailHttpStatus: '',
      detailTextLength: 0,
      url: id ? `${location.origin}/room_detail.php?id=${encodeURIComponent(id)}&type=room` : '',
    });
  }
  return rooms;
})())
""".replace("__REALPRO_STATUS_HELPERS__", REALPRO_STATUS_HELPERS_JS)


def wait_for_page_text_ready(timeout_seconds: float = 12.0) -> None:
    started_at = time.time()
    last_length = 0
    stable_count = 0
    while time.time() - started_at < timeout_seconds:
        try:
            metrics = json.loads(run_chrome_javascript(
                """
                JSON.stringify({
                  url: location.href,
                  readyState: document.readyState,
                  textLength: (document.body && document.body.textContent || '').length
                })
                """
            ))
        except (subprocess.CalledProcessError, json.JSONDecodeError):
            time.sleep(0.5)
            continue

        text_length = int(metrics.get("textLength") or 0)
        url = str(metrics.get("url") or "")
        required_length = 900 if "e-bukken.app" in url else 1200
        if metrics.get("readyState") == "complete" and text_length >= required_length:
            return
        if text_length == last_length and text_length > 300:
            stable_count += 1
            if stable_count >= 4 and "e-bukken.app" not in url:
                return
        else:
            stable_count = 0
        last_length = text_length
        time.sleep(0.5)


def click_next_page_info() -> dict:
    result = run_chrome_javascript(
        """
        JSON.stringify((function() {
          const normalize = (value) => String(value || '').replace(/\\s+/g, '').trim();
          const isDisabled = (el) => {
            const className = String(el.className || '');
            return Boolean(el.disabled) || el.getAttribute('aria-disabled') === 'true' || /disabled|disable|Mui-disabled/.test(className);
          };
          const candidates = Array.from(document.querySelectorAll('a, button, [role="button"], input[type="button"], input[type="submit"], td, span, li'));
          const realproNext = Array.from(document.querySelectorAll('td.pager'))
            .find((el) => !isDisabled(el) && String(el.textContent || '').includes('次'));
          if (location.hostname.includes('realnetpro.com') && location.pathname.includes('main.php')) {
            const url = new URL(location.href);
            const currentPage = Number(url.searchParams.get('page') || '0') || 0;
            const pagerPages = Array.from(document.querySelectorAll('td.pager'))
              .map((el) => (el.getAttribute('onclick') || '').match(/pager\\('([^']+)','([^']+)'\\)/))
              .filter(Boolean)
              .map((match) => Number(match[2]))
              .filter(Number.isFinite);
            const maxPage = Math.max(-1, ...pagerPages);
            if (maxPage >= 0) {
              if (currentPage >= maxPage && !realproNext) {
                return { clicked: false, reason: 'last-page-reached', url: location.href, currentPage, maxPage };
              }
              const nextPage = currentPage + 1;
              url.searchParams.set('method', 'estate');
              url.searchParams.set('display', 'building');
              url.searchParams.set('page', String(nextPage));
              const nextUrl = url.href;
              location.href = nextUrl;
              return { clicked: true, reason: 'realpro-direct-page', url: location.href, nextUrl, currentPage, nextPage, maxPage };
            }
          }
          const next = realproNext || candidates.find((el) => {
            const text = normalize(el.textContent || el.value);
            const aria = (el.getAttribute('aria-label') || '').trim();
            const onclick = (el.getAttribute('onclick') || '').trim();
            const className = String(el.className || '');
            const isRealproPager = text === '次' && (onclick.includes('pager(') || className.includes('pager'));
            const isESeikatsuPager = aria === 'Go to next page';
            const isPlainPager = ['次', '次へ', 'Next', '›', '>'].includes(text) && text.length <= 4;
            return !isDisabled(el) && (isRealproPager || isESeikatsuPager || isPlainPager);
          });
          if (!next) return { clicked: false, reason: 'next-not-found', url: location.href };
          const before = location.href;
          const text = normalize(next.textContent || next.value);
          const onclick = next.getAttribute('onclick') || '';
          const className = String(next.className || '');
          if (onclick && onclick.includes('pager(')) {
            const match = onclick.match(/pager\\('([^']+)','([^']+)'\\)/);
            if (match) {
              const nextUrl = `${location.origin}${location.pathname}?${match[1]}&page=${match[2]}`;
              if (nextUrl === before) return { clicked: false, reason: 'next-url-same', url: before, nextUrl, text, onclick, className };
              location.href = nextUrl;
              return { clicked: true, reason: 'pager-url', url: before, nextUrl, text, onclick, className };
            }
            setTimeout(() => Function(onclick).call(next), 0);
            return { clicked: true, reason: 'pager-scheduled', url: before, text, onclick, className };
          }
          setTimeout(() => next.click(), 0);
          return { clicked: true, reason: 'click-scheduled', url: before, text, onclick, className };
        })())
        """
    )
    try:
        return json.loads(result)
    except json.JSONDecodeError:
        normalized = result.strip().lower()
        return {"clicked": normalized in {"true", "missing value", ""}, "reason": "legacy-result", "raw": result}


def click_next_page() -> bool:
    return bool(click_next_page_info().get("clicked"))


def ensure_eseikatsu_page_ready(index: int, url: str, reload_if_needed: bool = True) -> dict:
    def read_state() -> dict:
        raw = run_chrome_javascript(
            """
            JSON.stringify({
              readyState: document.readyState || '',
              hasBody: Boolean(document.body),
              href: location.href,
              pathname: location.pathname,
              title: document.title || ''
            })
            """
        )
        return json.loads(raw)

    set_active_tab(index)
    deadline = time.time() + 3
    state = {}
    while time.time() < deadline:
        state = read_state()
        if state.get("hasBody") and state.get("readyState") in {"interactive", "complete"}:
            break
        time.sleep(0.25)

    if not (state.get("hasBody") and state.get("readyState") in {"interactive", "complete"}):
        if not reload_if_needed:
            raise RuntimeError("いい生活画面が読み込み途中です。")
        navigate_dedicated_chrome(state.get("href") or url, index)
        deadline = time.time() + 20
        while time.time() < deadline:
            set_active_tab(index)
            state = read_state()
            if state.get("hasBody") and state.get("readyState") in {"interactive", "complete"}:
                break
            time.sleep(0.5)

    if not state.get("hasBody"):
        raise RuntimeError("いい生活画面を再読み込みしても本文を読み込めませんでした。")
    if str(state.get("pathname") or "").rstrip("/") == "/login":
        raise RuntimeError("いい生活のログインが必要です。専用Chromeでログインしてください。")
    return state


def capture_eseikatsu_api_rooms(pages: int, page_size: int = 100, concurrency: int = 5) -> dict:
    status_key = "__codexESeikatsuApiCapture"
    safe_page_size = max(20, min(int(page_size or 100), 200))
    safe_concurrency = max(1, min(int(concurrency or 5), 10))
    run_chrome_javascript(
        f"""
        window.{status_key} = {{ status: 'running' }};
        (async () => {{
          const apiUrl = buildESeikatsuApiUrl();
          const pageCount = {max(pages, 1)};
          const requestedItemsPerPage = {safe_page_size};
          const concurrency = {safe_concurrency};
          const baseUrl = new URL(apiUrl);
          baseUrl.searchParams.set('items_per_page', String(requestedItemsPerPage));
          const itemsPerPage = Number(baseUrl.searchParams.get('items_per_page') || String(requestedItemsPerPage));
          const baseStartIndex = 1;
          const rooms = [];
          const pageCaptures = [];
          let token = await getESeikatsuAccessToken();

          const fetchOnePage = async (pageIndex) => {{
            window.{status_key} = {{
              status: 'running',
              currentPage: pageIndex + 1,
              pageCount,
              fetchedCount: rooms.length,
              pageCaptures,
              requestedItemsPerPage,
              concurrency,
            }};
            const pageUrl = new URL(baseUrl.href);
            const startIndex = baseStartIndex + (pageIndex * itemsPerPage);
            pageUrl.searchParams.set('start_index', String(startIndex));
            let response = await fetchESeikatsuPage(pageUrl.href, token);
            if (response.status === 401) {{
              window.__codexESeikatsuAccessToken = '';
              token = await getESeikatsuAccessToken();
              response = await fetchESeikatsuPage(pageUrl.href, token);
            }}
            const data = await response.json();
            const items = Array.isArray(data.items) ? data.items : [];
            return {{
              pageIndex,
              rooms: items.map(normalizeESeikatsuApiRoom),
              pageCapture: {{
              pageNumber: pageIndex + 1,
              url: pageUrl.href,
              status: response.status,
              totalCount: data.total_counts ?? null,
              itemCount: items.length,
                requestedItemsPerPage,
                itemsPerPage,
              startIndex,
              }},
            }};
          }};

          for (let start = 0; start < pageCount; start += concurrency) {{
            const indexes = [];
            for (let pageIndex = start; pageIndex < Math.min(start + concurrency, pageCount); pageIndex += 1) {{
              indexes.push(pageIndex);
            }}
            const results = await Promise.all(indexes.map(fetchOnePage));
            results
              .sort((a, b) => a.pageIndex - b.pageIndex)
              .forEach((result) => {{
                pageCaptures.push(result.pageCapture);
                rooms.push(...result.rooms);
              }});
            window.{status_key} = {{
              status: 'running',
              currentPage: Math.min(start + concurrency, pageCount),
              pageCount,
              fetchedCount: rooms.length,
              pageCaptures,
              requestedItemsPerPage,
              concurrency,
            }};
          }}

          window.{status_key} = {{ status: 'done', rooms, pageCaptures, requestedItemsPerPage, concurrency }};
        }})().catch((error) => {{
          window.{status_key} = {{ status: 'error', error: String(error), stack: error && error.stack }};
        }});

        function buildESeikatsuApiUrl() {{
          const currentUrl = new URL(location.href);
          const parts = currentUrl.pathname.split('/').filter(Boolean);
          const organizationGuid = currentUrl.searchParams.get('organization_guid') || parts[0] || '';
          if (!organizationGuid) {{
            const stored = sessionStorage.getItem('IiseikatsuApiRequestKey');
            if (stored) return stored;
          }}
          const params = new URLSearchParams();
          params.set('organization_guid', organizationGuid);
          params.set('order_organization_guid', organizationGuid);
          params.set('order', currentUrl.searchParams.get('order') || 'saishu_koshin_time.desc,tatemono_name.asc,sort_heya_kukaku_number.asc');
          params.set('items_per_page', currentUrl.searchParams.get('items_per_page') || '20');
          const page = Number(currentUrl.searchParams.get('p') || '1');
          params.set('start_index', String(((page || 1) - 1) * Number(params.get('items_per_page')) + 1));
          for (const value of currentUrl.searchParams.getAll('bukken_status_code')) {{
            if (value && value !== '0') params.append('bukken_status_code', value);
          }}
          if (!params.has('bukken_status_code')) {{
            params.append('bukken_status_code', '2');
            params.append('bukken_status_code', '1');
          }}
          params.set('type', 'chinshaku');
          params.set('suppress_null', 'true');
          return `https://api.e-bukken-1.com/bukken/1.0/search/?${{params.toString()}}`;
        }}

        async function fetchESeikatsuPage(url, token) {{
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 20000);
          try {{
            return await fetch(url, {{
            headers: {{
              Authorization: `Bearer ${{token}}`,
              Accept: 'application/json',
              'X-Es-Consumer-Key': 'eb_chintai',
            }},
            credentials: 'omit',
            signal: controller.signal,
          }});
          }} finally {{
            clearTimeout(timer);
          }}
        }}

        function normalizeESeikatsuApiRoom(item) {{
          const bukken = item.chinshaku_bukken_view || {{}};
          const condition = item.chinshaku_boshu_joken_view || {{}};
          const advertisements = Array.isArray(bukken.chinshaku_kokoku) ? bukken.chinshaku_kokoku : [];
          const isListed = advertisements.some((ad) =>
            ad.baitai_keisai_flag === true ||
            (Array.isArray(ad.chinshaku_keisai) && ad.chinshaku_keisai.some((entry) => entry.keisai_flag === true))
          );
          const organizationGuid = new URL(location.href).pathname.split('/').filter(Boolean)[0] || item.domain_guid || '';
          const guid = bukken.chinshaku_bukken_guid || bukken.chinshaku_view_guid || item.spec_bukken_view_guid || '';

          return {{
            building: item.tatemono_name || item.tatemono_to_name || '',
            room: item.heya_kukaku_number || '',
            layout: item.madori_name || item.madori || '',
            status: bukken.bukken_status || (condition.boshu_chu_flag ? '募集中' : '不明'),
            listing: isListed ? '掲載中' : '未掲載',
            url: guid ? `${{location.origin}}/${{organizationGuid}}/bukken/${{guid}}` : '',
          }};
        }}

        async function getESeikatsuAccessToken() {{
          if (window.__codexESeikatsuAccessToken) return window.__codexESeikatsuAccessToken;

          const state = Math.random().toString(36).slice(2);
          const nonce = Math.random().toString(36).slice(2);
          const params = new URLSearchParams({{
            client_id: 'Pek8UZpyPfkN5v9gQc4YY6CyRHGCZvwl',
            redirect_uri: 'https://rent.e-bukken.app',
            audience: 'https://api.es-account.com/',
            scope: 'openid profile email',
            response_type: 'token id_token',
            response_mode: 'web_message',
            prompt: 'none',
            state,
            nonce,
          }});
          const authUrl = `https://auth.es-account.com/authorize?${{params.toString()}}`;
          const response = await new Promise((resolve, reject) => {{
            const iframe = document.createElement('iframe');
            iframe.style.display = 'none';
            // Auth0のサイレント認証は初回だけ遅れることがあるため、通常の通信より長く待つ。
            const timer = setTimeout(() => {{
              cleanup();
              reject(new Error('Auth0 silent token timeout'));
            }}, 30000);
            const cleanup = () => {{
              clearTimeout(timer);
              window.removeEventListener('message', onMessage);
              iframe.remove();
            }};
            const onMessage = (event) => {{
              if (event.origin !== 'https://auth.es-account.com') return;
              cleanup();
              resolve(event.data && event.data.response ? event.data.response : event.data);
            }};
            window.addEventListener('message', onMessage);
            iframe.src = authUrl;
            const mount = document.body || document.documentElement;
            if (!mount) {{
              cleanup();
              reject(new Error('ESEIKATSU_PAGE_NOT_READY'));
              return;
            }}
            mount.appendChild(iframe);
          }});

          if (!response || !response.access_token) {{
            throw new Error(response && response.error ? `${{response.error}}: ${{response.error_description || ''}}` : 'Auth0 silent token missing');
          }}
          window.__codexESeikatsuAccessToken = response.access_token;
          return response.access_token;
        }}
        """
    )

    deadline = time.time() + max(60, min(1200, max(pages, 1) * 8))
    last_reported_page = -1
    while time.time() < deadline:
        payload = json.loads(run_chrome_javascript(f"JSON.stringify(window.{status_key} || {{ status: 'missing' }})"))
        if payload.get("status") == "running":
            current_page = int(payload.get("currentPage") or 0)
            if current_page and current_page != last_reported_page:
                print(
                    f"いい生活全件取得: {current_page}/{int(payload.get('pageCount') or pages)}ページ / "
                    f"{int(payload.get('fetchedCount') or 0)}件 / "
                    f"{int(payload.get('requestedItemsPerPage') or safe_page_size)}件ずつ / "
                    f"同時{int(payload.get('concurrency') or safe_concurrency)}",
                    flush=True,
                )
                last_reported_page = current_page
        if payload.get("status") == "done":
            return payload
        if payload.get("status") == "error":
            return {"rooms": [], "pageCaptures": [], "error": payload.get("error", "unknown error")}
        time.sleep(0.5)

    return {"rooms": [], "pageCaptures": [], "error": "いい生活API取得がタイムアウトしました。"}


def parse_tab_indexes(raw_value: str) -> list[int]:
    if not raw_value.strip():
        return []

    indexes = []
    for item in raw_value.replace("、", ",").split(","):
        item = item.strip()
        if item:
            indexes.append(int(item))
    return indexes


def suggest_realpro_index(urls: list[str], titles: Optional[list[str]] = None, active_index: Optional[int] = None) -> Optional[int]:
    candidates = []
    for index, url in enumerate(urls, start=1):
        if "realnetpro.com" not in url or "room_detail.php" in url:
            continue
        if "method=estate" not in url:
            continue
        title = (titles[index - 1] if titles and index - 1 < len(titles) else "").lower()
        score = 1
        if "リアルネットプロ" in title or "リアプロ" in title:
            score += 8
        if "gmail" in title or "mail" in title:
            score -= 5
        if "main.php" in url or "method=estate" in url or "display=building" in url:
            score += 4
        if active_index == index:
            score += 20
        candidates.append((score, index))
    if not candidates:
        return None
    return sorted(candidates, reverse=True)[0][1]


def suggest_realpro_open_index(urls: list[str], titles: Optional[list[str]] = None, active_index: Optional[int] = None) -> Optional[int]:
    candidates = []
    for index, url in enumerate(urls, start=1):
        if "realnetpro.com" not in url or "room_detail.php" in url:
            continue
        title = (titles[index - 1] if titles and index - 1 < len(titles) else "").lower()
        score = 1
        if "リアルネットプロ" in title or "リアプロ" in title:
            score += 8
        if "login" in url or "index.php" in url:
            score += 2
        if active_index == index:
            score += 10
        candidates.append((score, index))
    if not candidates:
        return None
    return sorted(candidates, reverse=True)[0][1]


def suggest_eseikatsu_index(urls: list[str], titles: Optional[list[str]] = None) -> Optional[int]:
    candidates = []
    for index, url in enumerate(urls, start=1):
        if "rent.e-bukken.app" not in url:
            continue
        title = titles[index - 1] if titles and index - 1 < len(titles) else ""
        score = 1
        if "物件広告" in title or "いい生活賃貸クラウド" in title:
            score += 8
        if "login" in url:
            score -= 4
        if "realnetpro" in title.lower() or "リアルネットプロ" in title:
            score -= 5
        candidates.append((score, index))
    if not candidates:
        return None
    return sorted(candidates, reverse=True)[0][1]


def suggest_detail_indexes(urls: list[str]) -> list[int]:
    return [
        index
        for index, url in enumerate(urls, start=1)
        if "realnetpro.com" in url and "room_detail.php" in url
    ]


def chrome_tab_status(titles: list[str], urls: list[str]) -> dict:
    active_index = chrome_active_tab_index()
    return {
        "tabs": [
            {
                "index": index,
                "title": title,
                "url": url,
            }
            for index, (title, url) in enumerate(zip(titles, urls), start=1)
        ],
        "activeIndex": active_index,
        "suggestedRealpro": suggest_realpro_index(urls, titles, active_index),
        "suggestedESeikatsu": suggest_eseikatsu_index(urls, titles),
        "suggestedDetails": suggest_detail_indexes(urls),
    }


def eseikatsu_total_status(titles: list[str], urls: list[str], page_size: int = 100, concurrency: int = 5) -> dict:
    suggested_eseikatsu = suggest_eseikatsu_index(urls, titles)
    if not suggested_eseikatsu:
        raise SystemExit("いい生活は rent.e-bukken.app の物件一覧/広告画面を開いてください。")

    title = titles[suggested_eseikatsu - 1]
    url = urls[suggested_eseikatsu - 1]
    ensure_eseikatsu_page_ready(suggested_eseikatsu, url)
    requested_page_size = max(20, min(int(page_size or 100), 200))
    safe_concurrency = max(1, min(int(concurrency or 5), 10))
    api_result = capture_eseikatsu_api_rooms(1, page_size=requested_page_size, concurrency=safe_concurrency)
    page_captures = api_result.get("pageCaptures", [])
    first_page = page_captures[0] if page_captures else {}
    item_count = int(first_page.get("itemCount") or len(api_result.get("rooms", [])) or 20)
    total_count = int(first_page.get("totalCount") or 0)
    page_size = requested_page_size
    required_pages = (total_count + page_size - 1) // page_size if total_count else 0

    return {
        "index": suggested_eseikatsu,
        "title": title,
        "url": url,
        "host": "rent.e-bukken.app",
        "totalCount": total_count,
        "itemCount": item_count,
        "pageSize": page_size,
        "requestedPageSize": requested_page_size,
        "concurrency": safe_concurrency,
        "requiredPages": required_pages,
        "apiError": api_result.get("error", ""),
    }


def capture_eseikatsu_cache(
    titles: list[str],
    urls: list[str],
    pages: int,
    page_size: int = 100,
    concurrency: int = 5,
) -> dict:
    suggested_eseikatsu = suggest_eseikatsu_index(urls, titles)
    if not suggested_eseikatsu:
        raise SystemExit("いい生活は rent.e-bukken.app の物件一覧/広告画面を開いてください。")

    title = titles[suggested_eseikatsu - 1]
    url = urls[suggested_eseikatsu - 1]
    ensure_eseikatsu_page_ready(suggested_eseikatsu, url)
    requested_page_size = max(20, min(int(page_size or 100), 200))
    safe_concurrency = max(1, min(int(concurrency or 5), 10))
    started_at = time.time()
    api_result = capture_eseikatsu_api_rooms(pages, page_size=requested_page_size, concurrency=safe_concurrency)
    page_captures = api_result.get("pageCaptures", [])
    rooms = api_result.get("rooms", [])
    total_count = int((page_captures[0] if page_captures else {}).get("totalCount") or len(rooms) or 0)
    item_count = max([int(page.get("itemCount") or 0) for page in page_captures] or [20], default=20)
    page_size = requested_page_size
    required_pages = (total_count + page_size - 1) // page_size if total_count else 0
    raw_fetched_count = sum(int(page.get("itemCount") or 0) for page in page_captures)
    has_all_pages = bool(required_pages and len(page_captures) >= required_pages)
    # APIの総件数に重複号室が含まれる場合、重複整理後のrooms件数は総件数を下回る。
    # 取得中に掲載件数が増減するため、必要ページをエラーなく走査できたことも完了条件にする。
    is_full = bool(total_count and (
        len(rooms) >= total_count or
        (has_all_pages and not api_result.get("error"))
    ))
    payload = {
        "capturedAt": datetime.now(timezone.utc).isoformat(),
        "eSeikatsu": {
            "index": suggested_eseikatsu,
            "title": title,
            "url": url,
            "rooms": rooms,
            "apiPageCaptures": page_captures,
            "apiError": api_result.get("error", ""),
        },
        "meta": {
            "totalCount": total_count,
            "fetchedCount": len(rooms),
            "rawFetchedCount": raw_fetched_count,
            "pageSize": page_size,
            "requestedPageSize": requested_page_size,
            "concurrency": safe_concurrency,
            "requestedPages": pages,
            "requiredPages": required_pages,
            "isFull": is_full,
            "elapsedSeconds": round(time.time() - started_at, 2),
        },
    }
    preserved_existing_full_cache = False
    if not is_full and ESEIKATSU_CACHE_FILE.exists():
        try:
            existing = json.loads(ESEIKATSU_CACHE_FILE.read_text(encoding="utf-8"))
            preserved_existing_full_cache = bool((existing.get("meta") or {}).get("isFull"))
        except (json.JSONDecodeError, OSError):
            preserved_existing_full_cache = False
    if not preserved_existing_full_cache:
        ESEIKATSU_CACHE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {
        "filename": str(ESEIKATSU_CACHE_FILE.relative_to(ROOT)),
        "capturedAt": payload["capturedAt"],
        "totalCount": total_count,
        "fetchedCount": len(rooms),
        "rawFetchedCount": raw_fetched_count,
        "requestedPages": pages,
        "requiredPages": required_pages,
        "isFull": is_full,
        "preservedExistingFullCache": preserved_existing_full_cache,
        "apiError": api_result.get("error", ""),
        "pageSize": page_size,
        "requestedPageSize": requested_page_size,
        "concurrency": safe_concurrency,
        "elapsedSeconds": round(time.time() - started_at, 2),
    }


def apply_realpro_detail_results(rooms: list[dict], details: list[dict]) -> int:
    details_by_id = {str(detail.get("realproRoomId")): detail for detail in details}
    updated = 0
    for room in rooms:
        detail = details_by_id.get(str(room.get("realproRoomId") or ""))
        if not detail:
            continue
        room.update({
            "status": detail.get("detailAvailabilityStatus") or room.get("status", ""),
            "webAd": detail.get("webAd", room.get("webAd", "判定不可")),
            "adFee": detail.get("adFee", room.get("adFee", "")),
            "adFeeStatus": detail.get("adFeeStatus", room.get("adFeeStatus", "未確認")),
            "managementCompany": detail.get("managementCompany", room.get("managementCompany", "")),
            "equipment": sorted(set((room.get("equipment") or []) + (detail.get("equipment") or []))),
            "applicationCount": (
                int(detail.get("applicationCount"))
                if application_count_known(detail)
                else None
            ),
            "applicationCountStatus": detail.get("applicationCountStatus", "取得不可"),
            "applicationCountReason": detail.get("applicationCountReason", ""),
            "detailTitle": detail.get("title", ""),
            "url": detail.get("url", room.get("url", "")),
            "detailCaptureStatus": detail.get("detailCaptureStatus") or ("詳細確認不完全" if detail.get("webAd") == "判定不可" else "取得OK"),
            "detailRuleVersion": DETAIL_RULE_VERSION,
            "detailCaptureReason": detail.get("detailCaptureReason", ""),
            "detailHttpStatus": detail.get("status", ""),
            "detailTextLength": detail.get("detailTextLength", 0),
        })
        updated += 1
    return updated


def retry_realpro_details_from_capture(
    titles: list[str],
    urls: list[str],
    target_ids: Optional[list[str]] = None,
) -> dict:
    if not OUTPUT_FILE.exists():
        raise SystemExit("data/chrome_capture.json が見つかりません。先にリアプロを取得してください。")
    data = json.loads(OUTPUT_FILE.read_text(encoding="utf-8"))
    rooms = ((data.get("realpro") or {}).get("rooms") or [])
    requested_ids = {str(value) for value in (target_ids or []) if str(value)}
    targets = [
        room for room in rooms
        if room.get("realproRoomId") and (
            str(room.get("realproRoomId")) in requested_ids
            if requested_ids
            else (
                room.get("webAd") == "判定不可" or
                not application_count_known(room) or
                room.get("detailCaptureStatus") in {"未取得", "詳細確認失敗", "詳細確認不完全"} or
                room.get("detailRuleVersion") != DETAIL_RULE_VERSION
            )
        )
    ]
    suggested_realpro = suggest_realpro_index(urls, titles, chrome_active_tab_index())
    if targets and not suggested_realpro:
        raise SystemExit("リアプロ一覧タブを確認できません。")
    if targets:
        set_active_tab(suggested_realpro)

    details = []
    errors = []
    reliable_retry = len(targets) < 200
    for index in range(0, len(targets), 20):
        chunk = targets[index:index + 20]
        processed_count = min(index + len(chunk), len(targets))
        print(f"リアプロ詳細再確認: {processed_count}/{len(targets)}件", flush=True)
        try:
            details.extend(capture_realpro_detail_summaries(
                chunk,
                concurrency=4,
                timeout_ms=30000 if reliable_retry else 20000,
            ))
        except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError) as error:
            errors.append(str(error))
        if any(detail.get("detailCaptureStatus") == "LOGIN_REQUIRED" for detail in details):
            raise SystemExit("RealPro login expired in the dedicated Chrome. Sign in again before retrying details.")
        if any(detail.get("detailCaptureStatus") == "MAINTENANCE" for detail in details):
            errors.append("リアプロの混雑またはメンテナンスを検知したため、残りの詳細取得を停止しました。")
            apply_realpro_detail_results(rooms, details)
            OUTPUT_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            break
        target_rooms_by_id = {str(room.get("realproRoomId") or ""): room for room in targets}
        confirmed_candidates = sum(
            1 for detail in details
            if detail.get("detailCaptureStatus") == "取得OK"
            and detail.get("webAd") in {"可", "管理会社に確認"}
            and application_count_known(detail)
            and int(detail.get("applicationCount")) == 0
            and not re.search(
                r"商談中|審査中|申込あり",
                str(target_rooms_by_id.get(str(detail.get("realproRoomId") or ""), {}).get("status") or ""),
            )
        )
        print(
            f"候補判定: {processed_count}/{len(targets)}件 / 候補{confirmed_candidates}件",
            flush=True,
        )
        apply_realpro_detail_results(rooms, details)
        OUTPUT_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        if processed_count < len(targets):
            try:
                refresh_execution_tab(suggested_realpro, urls[suggested_realpro - 1])
            except (subprocess.CalledProcessError, ValueError, IndexError):
                errors.append("詳細20件保存後のリアプロタブ再読み込みに失敗しました。次の詳細取得で再接続します。")

    updated = apply_realpro_detail_results(rooms, details)
    OUTPUT_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    remaining = sum(
        1 for room in rooms
        if room.get("detailCaptureStatus") not in {"候補外のため省略", "募集対象外"}
        and not application_count_known(room)
    )
    return {
        "filename": str(OUTPUT_FILE.relative_to(ROOT)),
        "requestedTargetCount": len(requested_ids),
        "targetCount": len(targets),
        "updatedCount": updated,
        "remainingUnknownWebAd": remaining,
        "remainingApplicationCountUnknown": remaining,
        "errors": errors[:3],
    }


def apply_realpro_conditions(titles: list[str], urls: list[str], encoded_conditions: str) -> dict:
    suggested_realpro = suggest_realpro_index(urls, titles, chrome_active_tab_index())
    if not suggested_realpro:
        suggested_realpro = suggest_realpro_open_index(urls, titles, chrome_active_tab_index())
    if not suggested_realpro:
        if IS_MAC:
            raise SystemExit("Chromeでリアプロのタブを開いてから、もう一度検索してください。")
        # A missing Realpro tab must never turn the selected system tab into Realpro.
        created = bridge_request("/new", {"url": "https://www.realnetpro.com/"})
        created_id = created.get("id")
        if not created_id:
            raise SystemExit("専用Chromeにリアプロ用タブを作成できませんでした。")
        time.sleep(3.0)
        current_tabs = bridge_tabs().get("tabs", [])
        created_tab = next((tab for tab in current_tabs if tab.get("id") == created_id), None)
        if not created_tab or not is_realpro_tab_url(created_tab.get("url")):
            raise SystemExit("作成したリアプロタブを確認できませんでした。システムタブは変更していません。")
        titles = [str(tab.get("title") or "") for tab in current_tabs]
        urls = [str(tab.get("url") or "") for tab in current_tabs]
        suggested_realpro = int(created_tab.get("index") or 0)
        if suggested_realpro < 1 or suggested_realpro > len(urls) or not is_realpro_tab_url(urls[suggested_realpro - 1]):
            raise SystemExit("リアプロタブの位置を確認できませんでした。システムタブは変更していません。")
    if not suggested_realpro:
        raise SystemExit("専用Chromeでリアプロを開けませんでした。ログイン状態を確認してから、もう一度「反映してリアプロ検索」を押してください。")

    raw_json = base64.b64decode(encoded_conditions.encode("ascii")).decode("utf-8")
    conditions = json.loads(raw_json)
    title = titles[suggested_realpro - 1]
    url = urls[suggested_realpro - 1]
    set_active_tab(suggested_realpro)
    if "method=estate" not in url or "main.php" not in url:
        move_realpro_to_page(1)
        wait_for_page_text_ready()
        page_status = realpro_page_status()
        if page_status.get("loginDetected"):
            raise SystemExit("リアプロがログイン画面です。Chromeでリアプロにログインしてから、もう一度「反映してリアプロ検索」を押してください。")
        if not page_status.get("isResultPage"):
            raise SystemExit(f"リアプロの検索画面を確認できませんでした: {page_status.get('url') or ''}")
        title = run_chrome_javascript("document.title")
        url = run_chrome_javascript("location.href")

    result = json.loads(run_chrome_javascript(
        f"""
        JSON.stringify((() => {{
          const conditions = {json.dumps(conditions, ensure_ascii=False)};
          const applied = [];
          const skipped = [];
          const layoutMap = {{
            'ワンルーム': ['1'],
            '1K': ['3'],
            '1DK': ['4'],
            '1LDK': ['6'],
            '2K': ['7'],
            '2DK': ['8'],
            '2LDK': ['9'],
            '3K': ['10'],
            '3DK': ['11'],
            '3LDK': ['12'],
            '3LDK〜': ['12', '13', '14', '15', '16', '17', '18'],
            '4LDK': ['15'],
          }};
          const routeMap = {{
            '南北線': '1082',
            '地下南北線': '1082',
            '札幌市南北線': '1082',
            '東西線': '1083',
            '地下東西線': '1083',
            '札幌市東西線': '1083',
            '札幌市電': '1084',
            '札幌市軌道線': '1084',
            '東豊線': '1085',
            '地下東豊線': '1085',
            '札幌市東豊線': '1085',
            'JR函館本線': '1051',
            '函館本線': '1051',
            'JR千歳線': '1056',
            '千歳線': '1056',
            'JR学園都市線': '1055',
            'JR札沼線': '1055',
            '札沼線': '1055',
          }};
          const transportationMap = {{ '徒歩': '1', 'バス': '2', '車': '3', '自動車': '3' }};
          const updatedMap = {{ '当日': '1', '3日以内': '3', '7日以内': '7', '14日以内': '14' }};
          const normalizeStationName = (value) => String(value || '')
            .normalize('NFKC')
            .replace(/\\s+/g, '')
            .replace(/駅$/g, '');

          const byName = (name) => document.querySelector(`[name="${{CSS.escape(name)}}"]`);
          const setSelect = (name, value, label) => {{
            const select = byName(name);
            if (!select || !value) return false;
            const stringValue = String(value);
            const option = Array.from(select.options).find((item) => item.value === stringValue);
            if (!option) {{
              skipped.push(`${{label}}=${{stringValue}}`);
              return false;
            }}
            select.value = stringValue;
            select.dispatchEvent(new Event('change', {{ bubbles: true }}));
            applied.push(label);
            return true;
          }};
          const setInput = (name, value, label) => {{
            const input = byName(name);
            if (!input) return false;
            input.value = value ? String(value) : '';
            input.dispatchEvent(new Event('input', {{ bubbles: true }}));
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
            applied.push(label);
            return true;
          }};
          const setCheckbox = (name, checked, label) => {{
            const input = byName(name);
            if (!input) return false;
            input.checked = Boolean(checked);
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
            if (checked) applied.push(label);
            return true;
          }};

          setInput('keyword', '', 'フリーワードクリア');
          setSelect('rental_cost1', conditions.rentMin || '-1', '賃料下限');
          setSelect('rental_cost2', conditions.rentMax || '-1', '賃料上限');
          setSelect('update_date', updatedMap[conditions.updated] || '-1', '更新日');
          setSelect('transportation_id', transportationMap[conditions.accessMethod] || '-1', '駅までの移動手段');
          setInput('required_time', conditions.walkMinutes || '', '駅までの分数');
          setCheckbox('include_common_fee', conditions.includeManagementFee, '管理費・共益費含む');
          setCheckbox('enable_enter_flag', conditions.immediate, '即入物件');
          setCheckbox('diversion', false, 'WEB広告掲載条件クリア');

          const sapporoCityCodes = new Set([
            '01101', '01102', '01103', '01104', '01105',
            '01106', '01107', '01108', '01109', '01110',
          ]);
          document.querySelectorAll('input[name="city_code[]"]').forEach((input) => {{
            input.checked = Boolean(conditions.sapporoOnly && sapporoCityCodes.has(input.value));
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
          }});
          if (conditions.sapporoOnly) applied.push('札幌市10区');

          const requestedLayouts = Array.isArray(conditions.layouts) ? conditions.layouts : [];
          const layoutValues = new Set(requestedLayouts.flatMap((layout) => layoutMap[layout] || []).filter(Boolean));
          document.querySelectorAll('input[name="room_layout_id[]"]').forEach((input) => {{
            input.checked = layoutValues.has(input.value);
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
          }});
          if (requestedLayouts.length) {{
            applied.push(`間取${{layoutValues.size}}件`);
            requestedLayouts.filter((layout) => !layoutMap[layout]).forEach((layout) => skipped.push(`間取:${{layout}}`));
          }}

          const requestedLineNames = new Set(Array.isArray(conditions.lines) ? conditions.lines : []);
          (Array.isArray(conditions.stations) ? conditions.stations : []).forEach((stationKey) => {{
            const [lineName] = String(stationKey).split(':');
            if (lineName) requestedLineNames.add(lineName);
          }});
          const routeValues = new Set([...requestedLineNames].map((lineName) => routeMap[lineName]).filter(Boolean));
          document.querySelectorAll('input[name="route_id[]"]').forEach((input) => {{
            const nextChecked = routeValues.has(input.value);
            input.checked = nextChecked;
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
          }});
          if (requestedLineNames.size) {{
            applied.push(`路線${{routeValues.size}}件`);
            [...requestedLineNames].filter((lineName) => !routeMap[lineName]).forEach((lineName) => skipped.push(`路線:${{lineName}}`));
          }}

          const requestedStationNames = new Set((Array.isArray(conditions.stations) ? conditions.stations : [])
            .map((stationKey) => normalizeStationName(String(stationKey).split(':').slice(1).join(':')))
            .filter(Boolean));
          const matchedStationNames = new Set();
          const stationCodesByName = loadStationCodes(routeValues);
          document.querySelectorAll('.codex-condition-hidden').forEach((input) => input.remove());
          document.querySelectorAll('input[name="station_id[]"]').forEach((input) => {{
            const label = input.closest('label')?.innerText || input.parentElement?.innerText || '';
            const stationName = normalizeStationName(label);
            const nextChecked = requestedStationNames.has(stationName);
            input.checked = nextChecked;
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
            if (nextChecked) matchedStationNames.add(stationName);
          }});
          const hiddenStationCodes = [];
          requestedStationNames.forEach((stationName) => {{
            const code = stationCodesByName.get(stationName);
            if (code && !matchedStationNames.has(stationName)) {{
              hiddenStationCodes.push(code);
              matchedStationNames.add(stationName);
            }}
          }});
          if (hiddenStationCodes.length) {{
            appendHiddenArray('station_id[]', hiddenStationCodes);
          }}
          const setAlong = document.querySelector('#set_along');
          if (setAlong && routeValues.size) setAlong.value = [...routeValues].join(',');
          const setStation = document.querySelector('#set_station');
          if (setStation && hiddenStationCodes.length) setStation.value = hiddenStationCodes.join(',');
          if (requestedStationNames.size) {{
            applied.push(`駅${{matchedStationNames.size}}件`);
            [...requestedStationNames]
              .filter((stationName) => !matchedStationNames.has(stationName))
              .forEach((stationName) => skipped.push(`駅:${{stationName}}`));
          }}

          const equipment = Array.isArray(conditions.equipment) ? conditions.equipment : [];
          const wantsParking = equipment.includes('駐車場空きあり');
          setCheckbox('parking_flag', wantsParking, '駐車場有り');
          setCheckbox('available_parking_flag', wantsParking, '駐車場空きあり');
          const equipmentMap = {{
            'バス・トイレ別': 'input[name="eq_rm[]"][value="151"]',
            'BT別': 'input[name="eq_rm[]"][value="151"]',
            'セパレート': 'input[name="eq_rm[]"][value="151"]',
            'オートロック': 'input[name="eq_bld[]"][value="1"]',
          }};
          const equipmentLabelMap = {{
            'エアコン': ['エアコン'],
            'インターネット無料': ['インターネット無料', 'ネット無料', '無料インターネット'],
          }};
          const handledEquipment = new Set(['駐車場空きあり']);
          equipment.forEach((item) => {{
            if (handledEquipment.has(item)) return;
            const selector = equipmentMap[item];
            const input = selector ? document.querySelector(selector) : findCheckboxByLabel(equipmentLabelMap[item] || [item]);
            if (!input) {{
              skipped.push(`設備:${{item}}`);
              return;
            }}
            input.checked = true;
            input.dispatchEvent(new Event('change', {{ bubbles: true }}));
            handledEquipment.add(item);
            applied.push(`設備:${{item}}`);
          }});
          equipment
            .filter((item) => !handledEquipment.has(item))
            .forEach((item) => skipped.push(`設備:${{item}}`));
          if (conditions.webAllowed) skipped.push('WEB広告掲載可否は取得後判定（管理会社確認を残す）');
          if (conditions.excludeNegotiating) skipped.push('商談中・審査中は取得後判定');

          function appendHiddenArray(name, values) {{
            const form = document.getElementById('main_form') || document.forms[0] || document.body;
            values.forEach((value) => {{
              const input = document.createElement('input');
              input.type = 'hidden';
              input.name = name;
              input.value = value;
              input.className = 'codex-condition-hidden';
              form.appendChild(input);
            }});
          }}

          function findCheckboxByLabel(keywords) {{
            const normalizedKeywords = keywords.map((keyword) => normalizeStationName(keyword));
            const inputs = [...document.querySelectorAll('input[type="checkbox"]')];
            return inputs.find((input) => {{
              const label = input.closest('label')?.innerText || input.parentElement?.innerText || '';
              const text = normalizeStationName(label);
              return normalizedKeywords.some((keyword) => text.includes(keyword));
            }});
          }}

          function loadStationCodes(routeValues) {{
            const map = new Map();
            if (!routeValues.size) return map;
            try {{
              const body = [...routeValues]
                .map((value) => `along_code%5B%5D=${{encodeURIComponent(value)}}`)
                .join('&');
              const request = new XMLHttpRequest();
              request.open('POST', 'ajax/get_station_code.php', false);
              request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
              request.send(body);
              if (request.status < 200 || request.status >= 300 || !request.responseText || request.responseText === 'false') return map;
              const payload = JSON.parse(request.responseText);
              Object.values(payload || {{}}).forEach((route) => {{
                (route.station || []).forEach((station) => {{
                  const name = normalizeStationName(station.StationName);
                  if (name && station.StationCode7) map.set(name, String(station.StationCode7));
                }});
              }});
            }} catch (error) {{
              skipped.push(`駅コード取得失敗:${{String(error)}}`);
            }}
            return map;
          }}

          const searchButton = document.querySelector('.go_search_submit') || document.querySelector('.go_search');
          const form = document.getElementById('main_form') || document.forms[0];
          const submitted = Boolean(conditions.submitSearch && (searchButton || form));
          if (submitted) {{
            document.documentElement.dataset.codexSearchSubmitted = '1';
            setTimeout(() => {{
              if (searchButton) {{
                searchButton.click();
              }} else {{
                form.submit();
              }}
            }}, 100);
          }}

          return {{
            href: location.href,
            title: document.title,
            applied,
            skipped,
            submitted,
            searchSummary: (document.body && document.body.innerText || '').match(/[0-9,]+\\s*棟\\s*[0-9,]+\\s*戸/)?.[0] || '',
            searchTotalPages: Math.max(0, ...Array.from(document.querySelectorAll('td.pager'))
              .map((el) => (el.getAttribute('onclick') || '').match(/pager\\('([^']+)','([^']+)'\\)/))
              .filter(Boolean)
              .map((match) => Number(match[2]) + 1)
              .filter(Number.isFinite)),
          }};
        }})())
        """
    ))
    if result.get("submitted"):
        # リアプロは検索ボタン押下後、件数とページャーが遅れて描画されることがある。
        # 1回だけ読むと「検索済み・件数未確認」で止まるため、結果表示まで継続確認する。
        deadline = time.time() + 30
        last_snapshot = {}
        while time.time() < deadline:
            try:
                snapshot = json.loads(run_chrome_javascript(
                    """
                    JSON.stringify((() => {
                      const text = (document.body && document.body.innerText || '').normalize('NFKC');
                      const searchSummary = (text.match(/[0-9,]+\\s*棟\\s*[0-9,]+\\s*戸/) || [''])[0];
                      const pagerPages = Math.max(0, ...Array.from(document.querySelectorAll('td.pager'))
                        .map((el) => (el.getAttribute('onclick') || '').match(/pager\\('([^']+)','([^']+)'\\)/))
                        .filter(Boolean)
                        .map((match) => Number(match[2]) + 1)
                        .filter(Number.isFinite));
                      return {
                        href: location.href,
                        title: document.title || '',
                        searchSummary,
                        searchTotalPages: searchSummary ? Math.max(pagerPages, 1) : 0,
                        submissionPending: document.documentElement.dataset.codexSearchSubmitted === '1',
                        readyState: document.readyState,
                      };
                    })())
                    """
                ))
                last_snapshot = snapshot
                if (
                    not snapshot.get("submissionPending") and
                    snapshot.get("searchSummary") and
                    int(snapshot.get("searchTotalPages") or 0) > 0
                ):
                    break
            except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError):
                pass
            time.sleep(0.75)
        valid_snapshot = last_snapshot if (
            not last_snapshot.get("submissionPending") and
            last_snapshot.get("searchSummary") and
            int(last_snapshot.get("searchTotalPages") or 0) > 0
        ) else {}
        if valid_snapshot:
            result["href"] = valid_snapshot.get("href") or result.get("href") or ""
            result["url"] = result["href"]
            result["title"] = valid_snapshot.get("title") or result.get("title") or ""
            result["searchSummary"] = valid_snapshot.get("searchSummary") or ""
            result["searchTotalPages"] = int(valid_snapshot.get("searchTotalPages") or 0)
        else:
            result["searchSummary"] = ""
            result["searchTotalPages"] = 0

    return {
        "index": suggested_realpro,
        "title": title,
        "url": url,
        **result,
    }


def prompt_index(label: str, default_index: Optional[int], required: bool = True) -> Optional[int]:
    default_label = f" [{default_index}]" if default_index else ""
    while True:
        raw_value = input(f"{label}{default_label}: ").strip()
        if raw_value:
            return int(raw_value)
        if default_index:
            return default_index
        if not required:
            return None
        print("タブ番号を入力してください。")


def prompt_detail_indexes(default_indexes: list[int]) -> list[int]:
    default_label = ",".join(str(index) for index in default_indexes)
    raw_value = input(f"リアプロ詳細タブ番号をカンマ区切りで入力してください（なければEnter） [{default_label}]: ").strip()
    if raw_value:
        return parse_tab_indexes(raw_value)
    return default_indexes


def main() -> None:
    parser = argparse.ArgumentParser(description="Chromeで開いているリアプロ・いい生活画面から本文テキストを取得します。")
    parser.add_argument("--auto", action="store_true", help="推定したタブを確認なしで取得します。")
    parser.add_argument("--tabs-json", action="store_true", help="Chromeタブのタイトル・URLと自動判定結果だけをJSON出力します。")
    parser.add_argument("--eseikatsu-total-json", action="store_true", help="いい生活の全件数と必要ページ数だけをJSON出力します。")
    parser.add_argument("--eseikatsu-cache-json", action="store_true", help="いい生活APIだけを取得してキャッシュJSONに保存します。")
    parser.add_argument("--retry-realpro-details-json", action="store_true", help="保存済み取得JSONのリアプロ詳細未確認だけを再取得します。")
    parser.add_argument("--retry-realpro-detail-ids-json", help="base64 JSONの部屋ID配列に一致するリアプロ詳細だけを再取得します。")
    parser.add_argument("--skip-realpro-details", action="store_true", help="リアプロ一覧だけを取得し、詳細確認を後回しにします。")
    parser.add_argument("--apply-realpro-conditions-json", help="base64 JSONの検索条件をリアプロ画面へ反映します。")
    parser.add_argument("--realpro-pages", type=int, default=1, help="リアプロ一覧で取得するページ数。初期値は1。")
    parser.add_argument("--realpro-start-page", type=int, default=1, help="リアプロ一覧で取得を開始するページ番号。初期値は1。")
    parser.add_argument("--realpro-page-numbers", default="", help="取得するリアプロページ番号のカンマ区切り一覧。指定時は取得済みページを飛ばせます。")
    parser.add_argument("--eseikatsu-pages", type=int, default=1, help="いい生活一覧で取得するページ数。初期値は1。")
    parser.add_argument("--skip-eseikatsu-capture", action="store_true", help="いい生活一覧を操作せず、サーバー側で全件キャッシュを結合します。")
    parser.add_argument("--eseikatsu-page-size", type=int, default=100, help="いい生活APIの1ページ取得件数。初期値は100。旧方式比較は20。")
    parser.add_argument("--eseikatsu-concurrency", type=int, default=5, help="いい生活APIの同時取得数。初期値は5。旧方式比較は1。")
    args = parser.parse_args()
    realpro_page_numbers = sorted({
        int(value)
        for value in str(args.realpro_page_numbers or "").split(",")
        if value.strip().isdigit() and 1 <= int(value) <= 10000
    })[:200]

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    original_active_index = chrome_active_tab_index()
    if not args.tabs_json:
        atexit.register(lambda: restore_active_tab(original_active_index))

    titles = chrome_titles()
    urls = chrome_urls()
    active_index = chrome_active_tab_index()
    suggested_realpro = suggest_realpro_index(urls, titles, active_index)
    suggested_eseikatsu = suggest_eseikatsu_index(urls, titles)
    suggested_details = suggest_detail_indexes(urls)

    if args.tabs_json:
        print(json.dumps(chrome_tab_status(titles, urls), ensure_ascii=False))
        return

    if args.eseikatsu_total_json:
        print(json.dumps(
            eseikatsu_total_status(
                titles,
                urls,
                page_size=args.eseikatsu_page_size,
                concurrency=args.eseikatsu_concurrency,
            ),
            ensure_ascii=False,
        ))
        return

    if args.eseikatsu_cache_json:
        print(json.dumps(
            capture_eseikatsu_cache(
                titles,
                urls,
                max(args.eseikatsu_pages, 1),
                page_size=args.eseikatsu_page_size,
                concurrency=args.eseikatsu_concurrency,
            ),
            ensure_ascii=False,
        ))
        return

    if args.retry_realpro_details_json:
        print(json.dumps(retry_realpro_details_from_capture(titles, urls), ensure_ascii=False))
        return

    if args.retry_realpro_detail_ids_json:
        try:
            decoded = base64.b64decode(args.retry_realpro_detail_ids_json).decode("utf-8")
            target_ids = json.loads(decoded)
            if not isinstance(target_ids, list):
                raise ValueError("部屋IDは配列で指定してください。")
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError) as error:
            raise SystemExit(f"部屋ID指定を読み取れませんでした: {error}")
        print(json.dumps(retry_realpro_details_from_capture(titles, urls, target_ids), ensure_ascii=False))
        return

    if args.apply_realpro_conditions_json:
        print(json.dumps(apply_realpro_conditions(titles, urls, args.apply_realpro_conditions_json), ensure_ascii=False))
        return

    print("Chromeで開いているタブ:")
    for index, (title, url) in enumerate(zip(titles, urls), start=1):
        print(f"{index}: {title} - {url}")

    if args.auto:
        if not suggested_realpro or (not args.skip_eseikatsu_capture and not suggested_eseikatsu):
            raise SystemExit(
                "--auto では必要なリアプロ一覧タブまたはいい生活タブを自動判定できませんでした。"
                "いい生活は rent.e-bukken.app の物件一覧/広告画面を開いてください。"
                "sfa.e-bukken.app の営業支援/追客画面は取得対象外です。"
            )
        realpro_index = suggested_realpro
        eseikatsu_index = suggested_eseikatsu
        detail_indexes = []
        print(
            f"\n自動判定: リアプロ一覧={realpro_index}, いい生活={eseikatsu_index}, "
            f"リアプロ詳細={suggested_details or 'なし'}（自動取得では追加詳細タブを省略）"
        )
    else:
        realpro_index = prompt_index("\nリアプロのタブ番号を入力してください", suggested_realpro)
        eseikatsu_index = prompt_index("いい生活のタブ番号を入力してください", suggested_eseikatsu)
        detail_indexes = prompt_detail_indexes(suggested_details)

    print("処理段階: リアプロ一覧と詳細を取得中", flush=True)
    realpro_capture = capture_current_tab(
        realpro_index,
        titles[realpro_index - 1],
        urls[realpro_index - 1],
        auto=args.auto,
        pages=args.realpro_pages,
        start_page=args.realpro_start_page,
        page_numbers=realpro_page_numbers,
        capture_realpro_details=not args.skip_realpro_details,
        source_hint="realpro",
    )

    print("処理段階: 開いているリアプロ詳細タブを確認中", flush=True)
    realpro_detail_captures = [
        capture_current_tab(
            index,
            titles[index - 1],
            urls[index - 1],
            "このリアプロ詳細画面で広告掲載条件と電子入居申込件数が見えていれば Enter を押してください...",
            auto=args.auto,
        )
        for index in detail_indexes
    ]

    if args.skip_eseikatsu_capture:
        print("処理段階: いい生活は全件キャッシュを使用", flush=True)
        e_seikatsu_capture = {
            "title": "",
            "url": "",
            "text": "",
            "rooms": [],
            "source": "server-cache-pending",
        }
    else:
        print("処理段階: いい生活の掲載情報を確認中", flush=True)
        e_seikatsu_capture = capture_current_tab(
            eseikatsu_index,
            titles[eseikatsu_index - 1],
            urls[eseikatsu_index - 1],
            auto=args.auto,
            pages=args.eseikatsu_pages,
        )

    captures = {
        "capturedAt": datetime.now(timezone.utc).isoformat(),
        "realpro": realpro_capture,
        "realproDetails": realpro_detail_captures,
        "eSeikatsu": e_seikatsu_capture,
    }

    print("処理段階: 取得結果を保存中", flush=True)
    OUTPUT_FILE.write_text(json.dumps(captures, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"\n取得結果を書き出しました: {OUTPUT_FILE}")
    if IS_MAC and (captures["realpro"]["jsError"] or captures["eSeikatsu"]["jsError"]):
        print("ChromeのApple Events JavaScript実行がオフのため、本文取得できないタブがありました。")
        print("Chromeの 表示 > デベロッパー > Apple Events からのJavaScriptを許可 をオンにすると本文取得できます。")


if __name__ == "__main__":
    main()
