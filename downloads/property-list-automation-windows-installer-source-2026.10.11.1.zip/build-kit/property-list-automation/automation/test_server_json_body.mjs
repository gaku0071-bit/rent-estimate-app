import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import fs from "node:fs/promises";
import vm from "node:vm";

const source = await fs.readFile(new URL("./server.mjs", import.meta.url), "utf8");
const start = source.indexOf("function readJsonBody(");
const end = source.indexOf("\nasync function saveCsvExport(", start);
assert(start >= 0 && end > start);
const readJsonBody = vm.runInNewContext(`${source.slice(start, end)}\nreadJsonBody`, { Buffer });

const csv = "status\n\u5bfe\u8c61\u5916";
const payload = { filename: "utf8-test.csv", csv };
const bytes = Buffer.from(JSON.stringify(payload), "utf8");
const split = bytes.indexOf(Buffer.from("\u5916")) + 1;
assert(split > 1);
const request = new EventEmitter();
request.destroy = () => {};
const result = readJsonBody(request, bytes.length);
request.emit("data", bytes.subarray(0, split));
request.emit("data", bytes.subarray(split));
request.emit("end");
assert.deepEqual(JSON.parse(JSON.stringify(await result)), payload);

const oversized = new EventEmitter();
oversized.destroy = () => {};
const rejection = readJsonBody(oversized, bytes.length - 1);
oversized.emit("data", bytes);
await assert.rejects(rejection);

console.log("JSON body UTF-8 chunk boundary and byte limit: OK");
