import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const CAPTURE_PATH = path.join(ROOT, "data", "chrome_capture.json");
const BASE_URL = process.env.PROPERTY_LIST_SERVER_URL || "http://127.0.0.1:8765";

const before = JSON.parse(fs.readFileSync(CAPTURE_PATH, "utf8"));
const criteriaJson = before.meta?.criteriaJson || before.realpro?.criteriaJson || "";
const beforeRooms = before.realpro?.rooms?.length || 0;
const beforeKnownDetails = (before.realpro?.rooms || []).filter(
  (room) => room.applicationCount !== null && room.applicationCount !== undefined && room.applicationCount !== "",
).length;
const beforeESeikatsuRooms = before.eSeikatsu?.rooms?.length || 0;
const totalPages = Number(
  before.realpro?.chunkMeta?.expectedPages
    || before.realpro?.totalPages
    || before.realpro?.pageCaptures?.length
    || 1,
);

async function capturePage(sessionId) {
  const params = new URLSearchParams({
    startPage: "1",
    pages: "1",
    realproPageNumbers: "1",
    realproTotalPages: String(totalPages),
    useESeikatsuCache: "1",
    reset: "0",
    preservePrevious: "1",
    searchSessionId: sessionId,
    criteriaJson,
    ts: String(Date.now()),
  });
  const response = await fetch(`${BASE_URL}/api/realpro-chunk?${params}`);
  const body = await response.json();
  if (!response.ok) throw new Error(JSON.stringify(body));
  return body;
}

const first = await capturePage("qa-priority-session-a");
const repeated = await capturePage("qa-priority-session-a");
const refreshed = await capturePage("qa-priority-session-b");
const afterFirstKnownDetails = (first.data?.realpro?.rooms || []).filter(
  (room) => room.applicationCount !== null && room.applicationCount !== undefined && room.applicationCount !== "",
).length;
const firstChangedRooms = first.realproChunkCache?.changedRoomIds?.length || 0;

const checks = {
  firstPageCaptured: (first.realproChunkCache?.capturedPageNumbers || []).includes(1),
  previousRoomsRetained: (first.data?.realpro?.rooms?.length || 0) >= beforeRooms,
  previousDetailResultsRetained: afterFirstKnownDetails >= beforeKnownDetails - firstChangedRooms,
  eSeikatsuUnchanged: (first.data?.eSeikatsu?.rooms?.length || 0) === beforeESeikatsuRooms,
  sameSessionPageSkipped: (repeated.skippedPageNumbers || []).includes(1),
  newSessionPageRefetched:
    !(refreshed.skippedPageNumbers || []).includes(1)
    && (refreshed.realproChunkCache?.capturedPageNumbers || []).includes(1),
  newSessionTagged: (refreshed.data?.realpro?.pageCaptures || []).some(
    (page) => Number(page.pageNumber) === 1 && page.searchSessionId === "qa-priority-session-b",
  ),
  changedRoomIdsReturned: Array.isArray(refreshed.realproChunkCache?.changedRoomIds),
};

console.log(JSON.stringify({
  beforeRooms,
  beforeKnownDetails,
  beforeESeikatsuRooms,
  totalPages,
  afterFirstRooms: first.data?.realpro?.rooms?.length || 0,
  afterFirstKnownDetails,
  firstChangedRooms,
  repeatedSkippedPages: repeated.skippedPageNumbers || [],
  refreshedSkippedPages: refreshed.skippedPageNumbers || [],
  checks,
}, null, 2));

if (Object.values(checks).some((passed) => !passed)) process.exitCode = 1;
