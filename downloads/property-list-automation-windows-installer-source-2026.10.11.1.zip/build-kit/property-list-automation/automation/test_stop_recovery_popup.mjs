import { chromium } from "playwright";
import fs from "node:fs/promises";
import http from "node:http";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const chromePath = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
const staticFiles = new Map([
  ["/", ["index.html", "text/html; charset=utf-8"]],
  ["/index.html", ["index.html", "text/html; charset=utf-8"]],
  ["/app.js", ["app.js", "text/javascript; charset=utf-8"]],
  ["/styles.css", ["styles.css", "text/css; charset=utf-8"]],
]);
const staticServer = http.createServer(async (request, response) => {
  const pathname = new URL(request.url || "/", "http://127.0.0.1").pathname;
  const target = staticFiles.get(pathname);
  if (!target) {
    response.writeHead(404, { "content-type": "application/json; charset=utf-8" });
    response.end(JSON.stringify({ error: "test endpoint not available" }));
    return;
  }
  const [filename, contentType] = target;
  response.writeHead(200, { "content-type": contentType });
  response.end(await fs.readFile(path.join(root, "src", filename)));
});
await new Promise((resolve) => staticServer.listen(0, "127.0.0.1", resolve));
const testPort = staticServer.address().port;
const browser = await chromium.launch({ headless: true, executablePath: chromePath });

try {
  const page = await browser.newPage();
  await page.goto(`http://127.0.0.1:${testPort}/index.html`);
  await page.waitForLoadState("domcontentloaded");
  await page.waitForFunction(() => typeof selectedConditionJson === "function");
  // Let the page's normal startup rendering finish before injecting the stopped state.
  await page.waitForTimeout(1000);
  await page.evaluate(() => {
    const searchSessionId = "stop-recovery-test";
    const pages = Array.from({ length: 151 }, (_item, index) => ({
      pageNumber: index + 1,
      searchSessionId,
    }));
    currentImportMeta = {
      criteriaJson: selectedConditionJson(),
      realproPages: pages,
      realproCoverage: {
        hasTotal: true,
        isFull: false,
        capturedPages: 151,
        requiredPages: 258,
      },
      eSeikatsuCoverage: { isFull: true, total: 2882 },
    };
    lastRealproSearchResult = {
      totalPages: 258,
      criteriaJson: selectedConditionJson(),
    };
    importedRealproRooms = Array.from({ length: 5302 }, (_item, index) => ({
      detailCaptureStatus: index < 5100 ? "取得OK" : "",
      applicationCount: index < 5100 ? 0 : null,
      applicationCountStatus: index < 5100 ? "本文確認" : "",
    }));
    importedESeikatsuRooms = Array.from({ length: 2882 }, () => ({}));
    hasLoadedCaptureData = true;
    latestStats = { total: 5302, shown: 688, excluded: 0, duplicated: 0 };
    lastLiveCaptureProgress = {
      phase: "details",
      status: "error",
      currentDetails: 40,
      totalDetails: 227,
      candidates: 3,
    };
    showWorkflowProblem(
      "指定ページ優先取得を停止しました: リアプロのリスト検索結果画面を確認できませんでした。",
      "list",
    );
  });

  const resumePosition = await page.evaluate(() => ({
    nextPage: captureResumeSnapshot().nextPage,
    priorityPages: priorityRealproPagesForRun({ pageNumbers: [252, 253, 254] }, 258, true),
    normalPriorityPages: priorityRealproPagesForRun({ pageNumbers: [252, 253, 259] }, 258, false),
  }));
  if (resumePosition.nextPage !== 152 || resumePosition.priorityPages.length ||
      JSON.stringify(resumePosition.normalPriorityPages) !== JSON.stringify([252, 253])) {
    throw new Error(`Unexpected resume selection: ${JSON.stringify(resumePosition)}`);
  }

  const actual = await page.locator("#operationPopup").evaluate((node) => ({
    hidden: node.hidden,
    state: node.dataset.state,
    label: node.querySelector("#operationPopupState")?.textContent,
    title: node.querySelector("#operationPopupTitle")?.textContent,
    message: node.querySelector("#operationPopupMessage")?.textContent,
    position: node.querySelector("#operationPopupCurrentPosition")?.textContent,
    counts: node.querySelector("#operationPopupCurrentCounts")?.textContent,
    primary: node.querySelector("#operationPopupPrimary")?.textContent,
    primaryHidden: node.querySelector("#operationPopupPrimary")?.hidden,
    headerBackground: getComputedStyle(node.querySelector(".operation-popup-header")).backgroundColor,
  }));

  const expected = {
    hidden: false,
    state: "error",
    label: "停止・確認が必要",
    title: "リアプロ取得が停止しました",
    position: "151/258ページ完了・次は152ページ目",
    counts: "リアプロ 5,302戸 / いい生活 2,882件",
    primary: "原因を確認して続きから再開",
    primaryHidden: false,
  };

  for (const [key, value] of Object.entries(expected)) {
    if (actual[key] !== value) {
      throw new Error(`${key}: expected ${JSON.stringify(value)}, got ${JSON.stringify(actual[key])}`);
    }
  }
  if (!actual.message?.startsWith("原因:")) throw new Error(`message: ${actual.message}`);
  if (actual.headerBackground !== "rgb(255, 240, 237)") {
    throw new Error(`error header color: ${actual.headerBackground}`);
  }

  const panel = await page.locator(".ops-progress-panel").evaluate((node) => ({
    stopped: node.classList.contains("is-stopped"),
    state: node.querySelector("#opsProgressState")?.textContent,
    title: node.querySelector("#opsProgressTitle")?.textContent,
    pages: node.querySelector("#opsMetricPages")?.textContent,
    rooms: node.querySelector("#opsMetricRealpro")?.textContent,
    judged: node.querySelector("#opsMetricJudged")?.textContent,
    candidates: node.querySelector("#opsMetricCandidates")?.textContent,
    eSeikatsu: node.querySelector("#opsMetricESeikatsu")?.textContent,
    position: node.querySelector("#opsCurrentPosition")?.textContent,
    recoveryHidden: node.querySelector("#opsRecoveryPanel")?.hidden,
    recoveryButton: node.querySelector("#opsRecoveryButton")?.textContent,
  }));
  const expectedPanel = {
    stopped: true,
    state: "停止中",
    title: "リアプロ取得を停止しました",
    pages: "151/258ページ",
    rooms: "5,302戸",
    judged: "5,100 / 5,302（今回 40/227を処理中）",
    candidates: "688件",
    eSeikatsu: "確認済み 2,882件",
    position: "151/258ページ完了・次は152ページ目",
    recoveryHidden: false,
    recoveryButton: "原因を確認して続きから再開",
  };
  for (const [key, value] of Object.entries(expectedPanel)) {
    if (panel[key] !== value) {
      throw new Error(`panel.${key}: expected ${JSON.stringify(value)}, got ${JSON.stringify(panel[key])}`);
    }
  }

  console.log(JSON.stringify({ ok: true, popup: actual, panel }, null, 2));
} finally {
  await browser.close();
  await new Promise((resolve) => staticServer.close(resolve));
}
