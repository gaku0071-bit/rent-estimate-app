import assert from "node:assert/strict";
import fs from "node:fs/promises";
import vm from "node:vm";
import { spawnSync } from "node:child_process";

const code = await fs.readFile(new URL("./realpro_status.js", import.meta.url), "utf8");
const context = vm.createContext({});
vm.runInContext(code, context);
const blocked = vm.runInContext("realproBlockedDetailStatus", context);
const rowStatus = vm.runInContext("realproRoomRowStatus", context);

assert.equal(blocked("状態\t空室 商談中\n入居可能時期\t2026年10月中旬"), "商談中");
assert.equal(blocked("状態\t退去予定 (退去予定日:2026年11月01日) 商談中\n入居可能時期\t相談"), "商談中");
assert.equal(blocked("この部屋の情報は入居中であるか公開されていません。"), "非公開・募集終了");
assert.equal(blocked("状態\t空室\n申込はWEB申込\n電子入居申込 0件"), "");
assert.equal(blocked("状態\t審査中\n入居可能時期\t相談"), "審査中");
assert.equal(rowStatus("空室", "315 空室 商談中 1LDK 90,000円"), "空室 商談中");
assert.equal(rowStatus("退去予定", "303 退去予定 審査中 1K 50,000円"), "退去予定 審査中");
assert.equal(rowStatus("空室", "301 空室 1LDK 90,000円"), "空室");

const python = process.env.PYTHON || (process.platform === "win32" ? "python" : "python3");
for (const target of ["detail", "parallel", "dom"]) {
  const program = `
import base64
import os
import sys
sys.path.insert(0, os.getcwd())
import automation.capture_chrome_mac as capture
def emit(script):
    print(base64.b64encode(script.encode("utf-8")).decode("ascii"))
    raise SystemExit(0)
capture.run_chrome_javascript = emit
if ${JSON.stringify(target)} == "detail":
    capture.capture_realpro_detail_summaries([{"realproRoomId": "123"}])
elif ${JSON.stringify(target)} == "parallel":
    capture.capture_realpro_parallel_pages(1)
else:
    emit(capture.REALPRO_DOM_ROOMS_JS)
`;
  const result = spawnSync(python, ["-c", program], { encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr || `${target}: Python failed`);
  const script = Buffer.from(result.stdout.trim(), "base64").toString("utf8");
  assert(script.includes("realproBlockedDetailStatus") && script.includes("realproRoomRowStatus"));
  new vm.Script(script);
  if (target === "detail") {
    const start = script.indexOf("function detailCaptureReasons(");
    const end = script.indexOf("function extractApplicationCount(", start);
    assert(start >= 0 && end > start);
    const reasons = vm.runInNewContext(`${script.slice(start, end)}\ndetailCaptureReasons`);
    const valid = {
      response: { ok: true, url: "https://www.realnetpro.com/room_detail.php?id=123" },
      text: "募集情報", adSection: "", webAd: "判定不可",
      adFeeResult: { status: "確認済み" }, application: { status: "API確認" },
      pageRoomId: "123", expectedRoomId: "123",
    };
    assert.equal(JSON.stringify(reasons(valid)), "[]", "表示のないWEB広告欄は取得失敗にしない");
    assert.match(reasons({ ...valid, adSection: "WEB広告掲載" }).join(" "), /WEB広告掲載可否/);
    assert.match(reasons({ ...valid, pageRoomId: "456" }).join(" "), /詳細IDが一致しません/);
  }
}

const mergeProgram = `
import os
import sys
sys.path.insert(0, os.getcwd())
from automation.capture_chrome_mac import apply_realpro_detail_results, DETAIL_RULE_VERSION
rooms = [{"realproRoomId": "123", "status": "空室", "applicationCount": 0}]
details = [{"realproRoomId": "123", "detailCaptureStatus": "募集対象外", "detailAvailabilityStatus": "商談中", "applicationCount": None}]
assert apply_realpro_detail_results(rooms, details) == 1
assert rooms[0]["status"] == "商談中"
assert rooms[0]["detailCaptureStatus"] == "募集対象外"
assert rooms[0]["detailRuleVersion"] == DETAIL_RULE_VERSION
assert rooms[0]["applicationCount"] is None
`;
const mergeResult = spawnSync(python, ["-c", mergeProgram], { encoding: "utf8" });
assert.equal(mergeResult.status, 0, mergeResult.stderr || "Detail merge failed");

console.log("リアプロ状態判定: 8件合格 / Chrome用スクリプト3件構文OK / 詳細反映OK");
