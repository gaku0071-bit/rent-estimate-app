import assert from "node:assert/strict";
import { buildLoopTestReport } from "./loop_test.mjs";

const now = "2026-10-05T08:00:00.000Z";
const cache = { exists: true, isFull: true, fetchedCount: 3000, totalCount: 3000, reloadOk: true, filename: "data/eseikatsu_full_cache.json" };
const capture = { exists: true, isFull: true, realproRooms: 5000, detailChecked: 5000, detailTargets: 5000, compareCompleted: true, csvSaved: true };
const check = (report, key) => report.checks.find((item) => item.key === key);

const freshCache = buildLoopTestReport({ scope: "cache", cacheStatus: { ...cache, capturedAt: "2026-10-05T07:00:00Z" }, now });
assert.equal(check(freshCache, "fresh").passed, true);
const oldCache = buildLoopTestReport({ scope: "cache", cacheStatus: { ...cache, capturedAt: "2026-10-04T07:00:00Z" }, now });
assert.equal(check(oldCache, "fresh").passed, false);
assert.equal(oldCache.categories.find((item) => item.key === "cache").passed, false);

const freshCapture = buildLoopTestReport({ scope: "capture", captureStatus: { ...capture, capturedAt: "2026-10-05T07:00:00Z" }, now });
assert.equal(check(freshCapture, "fresh").passed, true);
const oldCapture = buildLoopTestReport({ scope: "capture", captureStatus: { ...capture, capturedAt: "2026-10-04T07:00:00Z" }, now });
assert.equal(check(oldCapture, "fresh").passed, false);
assert.equal(oldCapture.categories.find((item) => item.key === "capture").passed, false);

console.log("ループテスト当日判定: いい生活・リアプロの新旧4ケース合格");
