import importlib.util
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CAPTURE_SCRIPT = ROOT / "automation" / "capture_chrome_mac.py"
SERVER_SCRIPT = ROOT / "automation" / "server.mjs"
APP_SCRIPT = ROOT / "src" / "app.js"
NODE = shutil.which("node") or str(ROOT / "runtime" / "node" / "node.exe")

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def load_capture_module():
    spec = importlib.util.spec_from_file_location("capture_speed_test", CAPTURE_SCRIPT)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def generated_detail_javascript(module) -> str:
    captured = []

    def capture_first_script(script):
        captured.append(script)
        raise RuntimeError("captured")

    original = module.run_chrome_javascript
    module.run_chrome_javascript = capture_first_script
    try:
        module.capture_realpro_detail_summaries(
            [{"realproRoomId": "speed-test-room"}],
            concurrency=4,
            timeout_ms=20000,
        )
    except RuntimeError as error:
        assert str(error) == "captured"
    finally:
        module.run_chrome_javascript = original
    assert captured, "詳細取得JavaScriptを生成できませんでした。"
    return captured[0]


def main() -> None:
    capture_source = CAPTURE_SCRIPT.read_text(encoding="utf-8")
    server_source = SERVER_SCRIPT.read_text(encoding="utf-8")
    app_source = APP_SCRIPT.read_text(encoding="utf-8")

    required_capture_markers = [
        "const requestedConcurrency = Math.max(1, Math.min(Number({concurrency}) || 4, 4));",
        "document.visibilityState === 'visible'",
        "Math.min(requestedConcurrency, 3)",
        "const inFlight = new Map();",
        "currentConcurrency = Math.min(currentConcurrency, 2);",
        "consecutiveSuccesses >= 8",
        "offset += 2",
        "batch = pageIndexes.slice(offset, offset + 2)",
        "REALPRO_MAINTENANCE",
        "captureMode\": \"parallel-fetch",
    ]
    for marker in required_capture_markers:
        assert marker in capture_source, f"速度改善マーカーがありません: {marker}"
    assert "await sleep(800);" not in capture_source, "旧バッチ待機が残っています。"

    assert "existingPageNumbers.has(page)" in server_source, "同日取得済みページのスキップがありません。"
    assert "roomListFingerprint(previousRoom) !== roomListFingerprint(room)" in server_source, "変更部屋の抽出がありません。"
    assert "window.setTimeout(pollCaptureProgress, 1200)" in app_source, "画面更新間隔が最適化されていません。"
    assert "buildESeikatsuRoomMap" in app_source, "いい生活照合の索引がありません。"

    module = load_capture_module()
    detail_javascript = generated_detail_javascript(module)
    syntax = subprocess.run(
        [NODE, "--check", "-"],
        input=detail_javascript,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=False,
    )
    assert syntax.returncode == 0, syntax.stderr or syntax.stdout

    print("安全高速化テスト: OK / 最大4件 / 連続処理 / エラー時2件 / 同日重複回避 / 直接読み取り")


if __name__ == "__main__":
    main()
