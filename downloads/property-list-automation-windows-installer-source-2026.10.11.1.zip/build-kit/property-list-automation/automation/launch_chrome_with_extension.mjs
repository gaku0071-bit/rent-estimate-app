import { spawn } from "node:child_process";
import fs from "node:fs";
import http from "node:http";
import path from "node:path";

const args = process.argv.slice(2);

function readArg(name, fallback = "") {
  const index = args.indexOf(name);
  if (index === -1 || index + 1 >= args.length) return fallback;
  return args[index + 1] || fallback;
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function requestJson(url, timeoutMs = 2500) {
  return new Promise((resolve, reject) => {
    const request = http.get(url, (response) => {
      let body = "";
      response.on("data", (chunk) => {
        body += chunk;
      });
      response.on("end", () => {
        try {
          resolve(JSON.parse(body));
        } catch (error) {
          reject(error);
        }
      });
    });
    request.on("error", reject);
    request.setTimeout(timeoutMs, () => {
      request.destroy(new Error("timeout"));
    });
  });
}

async function waitForPort(port, attempts = 20) {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      const version = await requestJson(`http://127.0.0.1:${port}/json/version`, 1500);
      if (version?.Browser) return version;
    } catch {
      // Retry while Chrome is starting.
    }
    await wait(500);
  }
  return null;
}

function createPipeClient(chrome) {
  const pipeWrite = chrome.stdio[3];
  const pipeRead = chrome.stdio[4];
  let nextId = 0;
  let buffer = Buffer.alloc(0);
  const pending = new Map();

  pipeRead.on("data", (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    let delimiterIndex = buffer.indexOf(0);
    while (delimiterIndex >= 0) {
      const raw = buffer.slice(0, delimiterIndex).toString("utf8");
      buffer = buffer.slice(delimiterIndex + 1);
      delimiterIndex = buffer.indexOf(0);
      if (!raw.trim()) continue;

      let message;
      try {
        message = JSON.parse(raw);
      } catch {
        continue;
      }

      if (!message.id || !pending.has(message.id)) continue;
      const callbacks = pending.get(message.id);
      pending.delete(message.id);
      if (message.error) {
        callbacks.reject(new Error(JSON.stringify(message.error)));
      } else {
        callbacks.resolve(message.result);
      }
    }
  });

  function send(method, params = {}, timeoutMs = 12000) {
    const id = ++nextId;
    pipeWrite.write(`${JSON.stringify({ id, method, params })}\0`);
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        if (!pending.has(id)) return;
        pending.delete(id);
        reject(new Error(`timeout ${method}`));
      }, timeoutMs);
      pending.set(id, {
        resolve: (value) => {
          clearTimeout(timeout);
          resolve(value);
        },
        reject: (error) => {
          clearTimeout(timeout);
          reject(error);
        },
      });
    });
  }

  return { send };
}

const chromePath = readArg("--chrome");
const profilePath = readArg("--profile");
const extensionPath = readArg("--extension");
const port = Number(readArg("--port", "9222")) || 9222;
const url = readArg("--url", `http://127.0.0.1:8765/index.html`);
const logPath = readArg("--log");

function log(message) {
  const line = `[${new Date().toISOString()}] ${message}\n`;
  if (logPath) {
    try {
      fs.mkdirSync(path.dirname(logPath), { recursive: true });
      fs.appendFileSync(logPath, line, "utf8");
    } catch {
      // Logging must never stop Chrome startup.
    }
  }
  process.stdout.write(line);
}

if (!chromePath || !profilePath || !extensionPath) {
  log("Missing required arguments.");
  process.exit(1);
}

if (!fs.existsSync(chromePath)) {
  log(`Chrome not found: ${chromePath}`);
  process.exit(1);
}

if (!fs.existsSync(path.join(extensionPath, "manifest.json"))) {
  log(`Extension manifest not found: ${extensionPath}`);
  process.exit(1);
}

fs.mkdirSync(profilePath, { recursive: true });

const chromeArgs = [
  "--remote-debugging-pipe",
  `--remote-debugging-address=127.0.0.1`,
  `--remote-debugging-port=${port}`,
  `--user-data-dir=${profilePath}`,
  "--enable-unsafe-extension-debugging",
  "--no-first-run",
  "--no-default-browser-check",
  "--new-window",
  url,
];

const chrome = spawn(chromePath, chromeArgs, {
  stdio: ["ignore", "ignore", "pipe", "pipe", "pipe"],
  windowsHide: false,
});

chrome.stderr.on("data", (chunk) => {
  const text = chunk.toString("utf8").trim();
  if (!text) return;
  if (/ERROR|extension|remote|pipe/i.test(text)) log(text);
});

chrome.on("exit", (code, signal) => {
  log(`Chrome exited: code=${code ?? ""} signal=${signal ?? ""}`);
  process.exit(code ?? 0);
});

const pipe = createPipeClient(chrome);

try {
  const version = await pipe.send("Browser.getVersion");
  log(`Chrome pipe ready: ${version.product || "unknown"}`);
  const loaded = await pipe.send("Extensions.loadUnpacked", {
    path: extensionPath,
    enableInIncognito: false,
  });
  log(`Extension loaded: ${loaded.id || "unknown"}`);
} catch (error) {
  log(`Extension load failed: ${error.message}`);
}

const version = await waitForPort(port, 20);
if (version?.Browser) {
  log(`Chrome debug port ready: ${version.Browser}`);
} else {
  log(`Chrome debug port ${port} did not become ready.`);
}

// Keep the pipe alive. In Chrome 137+ branded builds, unpacked extension loading
// is tied to the pipe-based debugging session that loaded the extension.
setInterval(() => {}, 60 * 60 * 1000);
