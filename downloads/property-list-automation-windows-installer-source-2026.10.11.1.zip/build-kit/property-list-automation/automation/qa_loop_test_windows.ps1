$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$node = Join-Path $root "runtime\node\node.exe"
$python = Join-Path $root "runtime\python\python.exe"
$cases = @()

function Add-Case($Name, $Points, $Passed, $Detail) {
  $script:cases += [pscustomobject]@{
    name = [string](@($Name)[0])
    points = [int](@($Points)[0])
    passed = [bool](@($Passed)[0])
    detail = [string](@($Detail)[0])
  }
}

function Get-Json([string]$Uri, [int]$TimeoutSec = 60) {
  Invoke-RestMethod -Uri $Uri -TimeoutSec $TimeoutSec
}

try {
  & $node --check (Join-Path $root "automation\server.mjs") | Out-Null
  $syntaxOk = ($LASTEXITCODE -eq 0)
  & $node --check (Join-Path $root "automation\chrome_bridge.mjs") | Out-Null
  $syntaxOk = $syntaxOk -and ($LASTEXITCODE -eq 0)
  & $node --check (Join-Path $root "src\app.js") | Out-Null
  $syntaxOk = $syntaxOk -and ($LASTEXITCODE -eq 0)
  & $python -m py_compile (Join-Path $root "automation\capture_chrome_mac.py") | Out-Null
  $syntaxOk = $syntaxOk -and ($LASTEXITCODE -eq 0)
  Add-Case "syntax" 10 $syntaxOk "node3 python1"

  $stamp = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
  $status = Get-Json "http://127.0.0.1:8765/api/status?qa=$stamp" 30
  $statusOk = [bool]($status.ok -and $status.requiredFilesAvailable -and $status.nodeVersion -and $status.python3.available -and $status.chromeBridge.available)
  Add-Case "server-runtime" 10 $statusOk "Node=$($status.nodeVersion); Python=$($status.python3.detail); Bridge=$($status.chromeBridge.detail)"

  $total = Get-Json "http://127.0.0.1:8765/api/eseikatsu-total?qa=$stamp" 90
  $expectedTotal = [int]$total.totalCount
  $expectedPages = [int][Math]::Ceiling($expectedTotal / 100)
  $totalOk = $expectedTotal -gt 0 -and [int]$total.requiredPages -eq [Math]::Ceiling($expectedTotal / [int]$total.pageSize) -and [string]::IsNullOrEmpty([string]$total.apiError)
  Add-Case "eseikatsu-total" 10 $totalOk "total=$expectedTotal pages=$($total.requiredPages)"

  $loops = @()
  foreach ($i in 1..3) {
    $query = "pages=$expectedPages" + [char]38 + "pageSize=100" + [char]38 + "concurrency=5" + [char]38 + "totalCount=$expectedTotal" + [char]38 + "qa=loop-$i-$([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())"
    $result = Get-Json ("http://127.0.0.1:8765/api/eseikatsu-cache?" + $query) 300
    $loops += [pscustomobject]@{
      loop = $i
      isFull = [bool]$result.cache.isFull
      total = [int]$result.cache.totalCount
      fetched = [int]$result.cache.fetchedCount
      pages = [int]$result.cache.requiredPages
      apiError = [string]$result.cache.apiError
      elapsedMs = [int]$result.timing.elapsedMs
    }
  }
  $loopsOk = @($loops | Where-Object { $_.isFull -and $_.total -eq $expectedTotal -and $_.fetched -eq $expectedTotal -and $_.pages -eq $expectedPages -and [string]::IsNullOrEmpty($_.apiError) }).Count -eq 3
  Add-Case "eseikatsu-loop-3x" 15 $loopsOk (($loops | ConvertTo-Json -Compress))

  $cachePath = Join-Path $root "data\eseikatsu_full_cache.json"
  $probe = & $node -e "const fs=require('fs');const p=process.argv[1];try{const x=JSON.parse(fs.readFileSync(p,'utf8'));console.log(JSON.stringify({ok:true,isFull:!!x.meta?.isFull,total:Number(x.meta?.totalCount||0),fetched:Number(x.meta?.fetchedCount||0),pages:Number(x.meta?.requiredPages||0)}))}catch(e){console.log(JSON.stringify({ok:false,error:e.message}))}" $cachePath
  $cache = ($probe | Select-Object -Last 1) | ConvertFrom-Json
  $cacheOk = [bool]($cache.ok -and $cache.isFull -and $cache.total -eq $expectedTotal -and $cache.fetched -eq $expectedTotal -and $cache.pages -eq $expectedPages)
  Add-Case "cache-readback" 5 $cacheOk "isFull=$($cache.isFull) total=$($cache.total) fetched=$($cache.fetched) pages=$($cache.pages)"

  $runtime = Get-Content -Raw -LiteralPath (Join-Path $root "data\chrome-runtime.json") | ConvertFrom-Json
  $owner = Get-CimInstance Win32_Process -Filter "ProcessId = $($runtime.pid)"
  $profileOk = [bool]($owner -and ($owner.CommandLine -match [regex]::Escape($runtime.profile)) -and ($runtime.port -ge 9222) -and ($runtime.port -le 9242))
  Add-Case "dedicated-chrome" 10 $profileOk "pid=$($runtime.pid) port=$($runtime.port)"

  $bridgeRuns = @()
  foreach ($i in 1..3) { $bridgeRuns += Get-Json "http://127.0.0.1:9223/status?qa=$i" 30 }
  $bridgeOk = @($bridgeRuns | Where-Object { $_.ok -and $_.tabCount -ge 2 }).Count -eq 3
  Add-Case "bridge-repeat" 5 $bridgeOk "3 consecutive status checks"

  $bridgeTabs = Get-Json "http://127.0.0.1:9223/tabs?qa=$stamp" 30
  $systemTarget = @($bridgeTabs.tabs | Where-Object { $_.url -match "^http://127\.0\.0\.1:\d+/(index\.html)?" }) | Select-Object -First 1
  $target = @($bridgeTabs.tabs | Where-Object { $_.url -match "realnetpro\.com" }) | Select-Object -First 1
  $stableIds = @($bridgeTabs.tabs | Where-Object { $_.id }).Count -eq @($bridgeTabs.tabs).Count
  $backgroundEval = $null
  $afterBackground = $null
  if ($systemTarget -and $target) {
    $systemBody = @{ id = $systemTarget.id } | ConvertTo-Json -Compress
    Invoke-RestMethod -Uri "http://127.0.0.1:9223/activate" -Method Post -ContentType "application/json" -Body $systemBody -TimeoutSec 30 | Out-Null
    $body = @{ id = $target.id; script = "location.hostname" } | ConvertTo-Json -Compress
    $backgroundEval = Invoke-RestMethod -Uri "http://127.0.0.1:9223/eval" -Method Post -ContentType "application/json" -Body $body -TimeoutSec 30
    $afterBackground = Get-Json "http://127.0.0.1:9223/tabs?qa=background-$stamp" 30
  }
  $backgroundOk = [bool]($stableIds -and $systemTarget -and $target -and $backgroundEval.result -eq "www.realnetpro.com" -and [int]$afterBackground.activeIndex -eq [int]$systemTarget.index)
  Add-Case "background-tab-control" 10 $backgroundOk "RealPro background evaluation; system tab remains foreground"

  $tabs = Get-Json "http://127.0.0.1:8765/api/chrome-tabs?qa=$stamp" 30
  $classifyOk = [bool]($tabs.ok -and $tabs.realproList.host -eq "www.realnetpro.com" -and $tabs.eSeikatsuList.host -eq "rent.e-bukken.app" -and [int]$tabs.realproList.index -gt 0 -and [int]$tabs.eSeikatsuList.index -gt 0)
  Add-Case "tab-classification" 10 $classifyOk "realpro=$($tabs.realproList.index) eseikatsu=$($tabs.eSeikatsuList.index)"

  $runText = Get-Content -Raw -LiteralPath (Join-Path $root "automation\run_windows.ps1")
  $portableOk = [bool]($runText -match "Find-FreeChromePort" -and $runText -match "chrome-runtime\.json" -and $runText -notmatch "Stop-WrongChromeOwner")
  Add-Case "portable-startup" 10 $portableOk "dynamic port and isolated profile"
  $chromeProcesses = @(Get-CimInstance Win32_Process -Filter "Name = 'chrome.exe'")
  $normalChromeExists = @($chromeProcesses | Where-Object { $_.CommandLine -notmatch [regex]::Escape($runtime.profile) }).Count -gt 0
  Add-Case "normal-chrome-safety" 5 ($portableOk -and $normalChromeExists) "normal Chrome process remains outside dedicated profile"

  $score = ($cases | Where-Object passed | Measure-Object -Property points -Sum).Sum
  [pscustomobject]@{
    ok = ($score -eq 100)
    score = [int]$score
    maxScore = 100
    version = (Get-Content -Raw (Join-Path $root "app-version.json") | ConvertFrom-Json).version
    runAt = (Get-Date).ToUniversalTime().ToString("o")
    cases = $cases
    loops = $loops
  } | ConvertTo-Json -Depth 8
} catch {
  $score = ($cases | Where-Object passed | Measure-Object -Property points -Sum).Sum
  [pscustomobject]@{ ok = $false; score = [int]$score; maxScore = 100; error = $_.Exception.Message; cases = $cases } | ConvertTo-Json -Depth 8
  exit 1
}
