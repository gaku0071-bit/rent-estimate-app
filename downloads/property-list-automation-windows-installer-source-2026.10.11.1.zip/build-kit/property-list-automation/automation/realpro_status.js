function realproBlockedDetailStatus(text) {
  const normalized = String(text || '').normalize('NFKC');
  if (/この部屋の情報は入居中であるか公開されていません|この部屋は(?:現在)?公開されていません/.test(normalized)) {
    return '非公開・募集終了';
  }
  const lines = normalized.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const blocked = /商談中|審査中|申込あり|申込中|募集終了|募集停止|成約済|入居中|他決/;
  for (let index = 0; index < lines.length; index += 1) {
    const match = lines[index].match(/^(?:募集状況|募集状態|現況|状態)\s*[:：]?\s*(.*)$/);
    if (!match) continue;
    const value = match[1] || lines[index + 1] || '';
    const status = value.match(blocked);
    if (status) return status[0];
  }
  return '';
}

function realproRoomRowStatus(statusText, rowText) {
  const current = String(statusText || '').normalize('NFKC').trim();
  const row = String(rowText || '').normalize('NFKC');
  const blocked = row.match(/商談中|審査中|申込あり|申込中|募集終了|募集停止|成約済|他決/);
  return blocked && !current.includes(blocked[0]) ? `${current} ${blocked[0]}`.trim() : current;
}
