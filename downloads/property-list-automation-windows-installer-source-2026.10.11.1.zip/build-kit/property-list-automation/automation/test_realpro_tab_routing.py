import base64
import importlib.util
import json
import unittest
from pathlib import Path
from unittest.mock import patch


spec = importlib.util.spec_from_file_location("capture_chrome_mac", Path(__file__).with_name("capture_chrome_mac.py"))
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
conditions = base64.b64encode(json.dumps({}).encode()).decode()


class ReachedSearchTab(Exception):
    pass


class RealproTabRoutingTest(unittest.TestCase):
    def test_detail_timeout_keeps_unfinished_room_unverified(self):
        partial = {"status": "running", "details": [{"realproRoomId": "1", "detailCaptureStatus": "取得OK"}]}
        with patch.object(capture, "run_chrome_javascript", side_effect=["true", json.dumps(partial)]), \
             patch.object(capture.time, "monotonic", side_effect=[0, 1, 901]), \
             patch.object(capture.time, "sleep"):
            details = capture.capture_realpro_detail_summaries([{"realproRoomId": "1"}, {"realproRoomId": "2"}])
        self.assertEqual(len(details), 2)
        self.assertEqual(details[1]["detailCaptureStatus"], "取得エラー")
        self.assertIsNone(details[1]["applicationCount"])

    def test_missing_realpro_creates_own_tab_without_navigating_system(self):
        original = ["http://127.0.0.1:8765/index.html", "https://rent.e-bukken.app/list"]
        current = original.copy()
        calls = []

        def bridge(path, payload=None):
            calls.append((path, payload))
            self.assertEqual(path, "/new")
            self.assertEqual(payload, {"url": "https://www.realnetpro.com/"})
            current.append("https://www.realnetpro.com/index.php")
            return {"id": "new-realpro", "activeIndex": 3}

        def tabs():
            return {"tabs": [{"id": "system", "index": 1, "url": current[0]},
                             {"id": "eseikatsu", "index": 2, "url": current[1]},
                             {"id": "new-realpro", "index": 3, "url": current[2]}]}

        with patch.object(capture, "IS_MAC", False), patch.object(capture, "chrome_active_tab_index", return_value=1), \
             patch.object(capture, "bridge_request", side_effect=bridge), patch.object(capture, "bridge_tabs", side_effect=tabs), \
             patch.object(capture, "chrome_titles", side_effect=lambda: ["System", "いい生活", "リアプロ"]), \
             patch.object(capture, "chrome_urls", side_effect=lambda: current.copy()), \
             patch.object(capture, "navigate_dedicated_chrome", side_effect=AssertionError("Existing tab was navigated")), \
             patch.object(capture.time, "sleep"), patch.object(capture, "set_active_tab", side_effect=ReachedSearchTab) as selected:
            with self.assertRaises(ReachedSearchTab):
                capture.apply_realpro_conditions(["System", "いい生活"], original, conditions)
        self.assertEqual(selected.call_args.args, (3,))
        self.assertEqual(current[:2], original)
        self.assertEqual(len(calls), 1)

    def test_existing_realpro_is_reused(self):
        urls = ["http://127.0.0.1:8765/index.html", "https://www.realnetpro.com/main.php?method=estate"]
        with patch.object(capture, "chrome_active_tab_index", return_value=1), \
             patch.object(capture, "bridge_request", side_effect=AssertionError("New tab should not be created")), \
             patch.object(capture, "navigate_dedicated_chrome", side_effect=AssertionError("Existing tab was navigated")), \
             patch.object(capture, "set_active_tab", side_effect=ReachedSearchTab) as selected:
            with self.assertRaises(ReachedSearchTab):
                capture.apply_realpro_conditions(["System", "Realpro"], urls, conditions)
        self.assertEqual(selected.call_args.args, (2,))

    def test_created_tab_mismatch_stops_without_touching_system(self):
        system = "http://127.0.0.1:8765/index.html"
        with patch.object(capture, "IS_MAC", False), patch.object(capture, "chrome_active_tab_index", return_value=1), \
             patch.object(capture, "bridge_request", return_value={"id": "new-realpro"}), \
             patch.object(capture, "bridge_tabs", return_value={"tabs": [{"id": "new-realpro", "index": 2, "url": "http://127.0.0.1:8765/?next=realnetpro.com"}]}), \
             patch.object(capture.time, "sleep"), \
             patch.object(capture, "navigate_dedicated_chrome", side_effect=AssertionError("Existing tab was navigated")), \
             patch.object(capture, "set_active_tab", side_effect=AssertionError("Wrong tab selected")):
            with self.assertRaisesRegex(SystemExit, "システムタブは変更していません"):
                capture.apply_realpro_conditions(["System"], [system], conditions)
        self.assertFalse(capture.is_realpro_tab_url("http://127.0.0.1:8765/?next=realnetpro.com"))

    def test_mac_without_tab_requests_manual_open(self):
        with patch.object(capture, "IS_MAC", True), patch.object(capture, "chrome_active_tab_index", return_value=1), \
             patch.object(capture, "bridge_request", side_effect=AssertionError("Windows bridge called")), \
             patch.object(capture, "navigate_dedicated_chrome", side_effect=AssertionError("Existing tab was navigated")):
            with self.assertRaisesRegex(SystemExit, "タブを開いて"):
                capture.apply_realpro_conditions(["System"], ["http://127.0.0.1:8765/index.html"], conditions)

    def test_detail_refresh_rejects_system_tab_after_index_shift(self):
        with patch.object(capture, "IS_MAC", False), \
             patch.object(capture, "bridge_tabs", return_value={"tabs": [
                 {"id": "system", "index": 1, "url": "http://127.0.0.1:8765/index.html"},
                 {"id": "realpro", "index": 2, "url": "https://www.realnetpro.com/main.php?method=estate"},
             ]}), patch.object(capture, "bridge_request", side_effect=AssertionError("Wrong tab navigated")):
            with self.assertRaisesRegex(ValueError, "システムタブは再読込しません"):
                capture.refresh_execution_tab(1, "https://www.realnetpro.com/main.php?method=estate")

    def test_detail_refresh_uses_confirmed_tab_id(self):
        with patch.object(capture, "IS_MAC", False), \
             patch.object(capture, "bridge_tabs", return_value={"tabs": [
                 {"id": "system", "index": 1, "url": "http://127.0.0.1:8765/index.html"},
                 {"id": "realpro", "index": 2, "url": "https://www.realnetpro.com/main.php?method=estate"},
             ]}), patch.object(capture, "bridge_request", return_value={}) as request, \
             patch.object(capture.time, "sleep"):
            capture.refresh_execution_tab(2, "https://www.realnetpro.com/main.php?method=estate")
        path, payload = request.call_args.args
        self.assertEqual(path, "/navigate")
        self.assertEqual(payload["id"], "realpro")
        self.assertNotIn("index", payload)
        self.assertFalse(payload["activate"])

    def test_page_move_uses_realpro_tab_id_without_eval(self):
        tabs = {"tabs": [
            {"id": "system", "index": 1, "url": "http://127.0.0.1:8765/index.html"},
            {"id": "realpro", "index": 2, "url": "https://www.realnetpro.com/main.php?method=estate&display=building&page=261"},
        ]}
        with patch.object(capture, "IS_MAC", False), patch.object(capture, "CHROME_EXECUTION_TAB_INDEX", 2), \
             patch.object(capture, "bridge_tabs", return_value=tabs), \
             patch.object(capture, "bridge_request", return_value={}) as request, \
             patch.object(capture, "run_chrome_javascript", side_effect=AssertionError("Renderer eval must not move page")), \
             patch.object(capture.time, "sleep"):
            capture.move_realpro_to_page(61)
        path, payload = request.call_args.args
        self.assertEqual(path, "/navigate")
        self.assertEqual(payload["id"], "realpro")
        self.assertIn("page=60", payload["url"])
        self.assertIn("key=addr", payload["url"])
        self.assertIn("odr=asc", payload["url"])
        self.assertFalse(payload["activate"])

    def test_old_sort_is_replaced_before_first_page_capture(self):
        old_url = "https://www.realnetpro.com/main.php?method=estate&display=building&key=upd&odr=desc&page=17"
        with patch.object(capture, "IS_MAC", False), \
             patch.object(capture, "realpro_candidate_indexes", return_value=[2]), \
             patch.object(capture, "set_active_tab"), \
             patch.object(capture, "read_current_tab_info", return_value={"title": "Realpro", "url": old_url}), \
             patch.object(capture, "move_realpro_to_page") as move, \
             patch.object(capture, "wait_for_page_text_ready"), \
             patch.object(capture, "realpro_page_status", return_value={
                 "isResultPage": True,
                 "url": "https://www.realnetpro.com/main.php?method=estate&display=building&key=addr&odr=asc",
             }), patch.object(capture.time, "sleep"):
            capture.activate_realpro_result_tab(2, 1)
        move.assert_called_once_with(1)


if __name__ == "__main__":
    unittest.main()
