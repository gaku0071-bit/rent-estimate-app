import fs from "node:fs";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const data = JSON.parse(fs.readFileSync(path.join(root, "data", "chrome_capture.json"), "utf8"));

function normalize(value) {
  return String(value ?? "").normalize("NFKC").replace(/\s+/g, "").toLowerCase();
}

function normalizeBuilding(value) {
  return normalize(value)
    .replace(/\(.+?\)/g, "")
    .replace(/\[.+?\]/g, "")
    .replace(/\u3010.+?\u3011/g, "")
    .replace(/<.+?>/g, "")
    .replace(/no\.?i{1,3}$/g, (series) => ({ noi: "no1", noii: "no2", noiii: "no3" }[series.replace(".", "")] || series));
}

function normalizeRoom(value) {
  const normalized = normalize(value)
    .replace(/\(.+?\)/g, "")
    .replace(/\uFF08.+?\uFF09/g, "")
    .replace(/号室$/g, "")
    .replace(/部屋$/g, "");
  return /^[0-9]+$/.test(normalized) ? String(Number(normalized)) : normalized;
}

function relaxedBuilding(value) {
  return normalizeBuilding(value)
    .replace(/[・･.．,，\-‐‑‒–—―ー_＿'’`]/g, "")
    .replace(/(マンション|アパート|ハイツ|コーポ|レジデンス)$/g, "");
}

function levenshtein(left, right) {
  const row = Array.from({ length: right.length + 1 }, (_item, index) => index);
  for (let i = 1; i <= left.length; i += 1) {
    let diagonal = row[0];
    row[0] = i;
    for (let j = 1; j <= right.length; j += 1) {
      const previous = row[j];
      row[j] = Math.min(row[j] + 1, row[j - 1] + 1, diagonal + (left[i - 1] === right[j - 1] ? 0 : 1));
      diagonal = previous;
    }
  }
  return row[right.length];
}

const realproRooms = data.realpro?.rooms || [];
const listedRooms = (data.eSeikatsu?.rooms || []).filter((room) => room.status === "募集中" && room.listing === "掲載中");
const exactKeys = new Set(listedRooms.map((room) => `${normalizeBuilding(room.building)}::${normalizeRoom(room.room)}`));
const listedByRoom = new Map();
for (const room of listedRooms) {
  const key = normalizeRoom(room.room);
  if (!listedByRoom.has(key)) listedByRoom.set(key, []);
  listedByRoom.get(key).push(room);
}

const possibleMismatches = [];
for (const realpro of realproRooms) {
  const exactKey = `${normalizeBuilding(realpro.building)}::${normalizeRoom(realpro.room)}`;
  if (exactKeys.has(exactKey)) continue;
  for (const eseikatsu of listedByRoom.get(normalizeRoom(realpro.room)) || []) {
    const left = relaxedBuilding(realpro.building);
    const right = relaxedBuilding(eseikatsu.building);
    const similarity = 1 - levenshtein(left, right) / Math.max(left.length, right.length, 1);
    if (left.includes(right) || right.includes(left) || similarity >= 0.65) {
      possibleMismatches.push({
        similarity: Number(similarity.toFixed(2)),
        realproBuilding: realpro.building,
        room: realpro.room,
        eseikatsuBuilding: eseikatsu.building,
        realproRoomId: realpro.realproRoomId || "",
        eseikatsuUrl: eseikatsu.url || "",
      });
    }
  }
}

possibleMismatches.sort((left, right) => right.similarity - left.similarity);
console.log(JSON.stringify({
  capturedAt: data.capturedAt,
  realproRooms: realproRooms.length,
  listedRooms: listedRooms.length,
  exactListedMatches: realproRooms.filter((room) => exactKeys.has(`${normalizeBuilding(room.building)}::${normalizeRoom(room.room)}`)).length,
  possibleMismatches,
}, null, 2));
