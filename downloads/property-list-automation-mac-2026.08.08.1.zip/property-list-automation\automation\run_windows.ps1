﻿Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ProjectRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location $ProjectRoot

function Resolve-NodeRuntime {
  $BundledNode = Join-Path $ProjectRoot "runtime\node\node.exe"
  if (Test-Path $BundledNode) {
    return $BundledNode
  }
  $PathNode = Get-Command node -ErrorAction SilentlyContinue
  if ($PathNode) {
    return $PathNode.Source
  }
  throw "Node.js が見つかりません。同梱Node.jsが壊れている可能性があります。インストーラーを再ダウンロードして入れ直してください。"
}

function Resolve-NpmRuntime {
  $BundledNpmCmd = Join-Path $ProjectRoot "runtime\node\npm.cmd"
  if (Test-Path $BundledNpmCmd) {
    return @{ Command = $BundledNpmCmd; Prefix = @() }
  }

  $BundledNpmCli = Join-Path $ProjectRoot "runtime\node\node_modules\npm\bin\npm-cli.js"
  if (Test-Path $BundledNpmCli) {
    return @{ Command = $script:NodeExe; Prefix = @($BundledNpmCli) }
  }

  $PathNpm = Get-Command npm -ErrorAction SilentlyContinue
  if ($PathNpm) {
    return @{ Command = $PathNpm.Source; Prefix = @() }
  }

  throw "npm が見つかりません。同梱Node.jsが壊れている可能性があります。インストーラーを再ダウンロードして入れ直してください。"
}

function Resolve-PythonRuntime {
  $BundledPython = Join-Path $ProjectRoot "runtime\python\python.exe"
  if (Test-Path $BundledPython) {
    return @{ Command = $BundledPython; Prefix = @() }
  }

  if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 --version *> $null
    if ($LASTEXITCODE -eq 0) {
      return @{ Command = "py"; Prefix = @("-3") }
    }
  }

  $PathPython = Get-Command python -ErrorAction SilentlyContinue
  if ($PathPython) {
    & $PathPython.Source --version *> $null
    if ($LASTEXITCODE -eq 0) {
      return @{ Command = $PathPython.Source; Prefix = @() }
    }
  }

  throw "Python 3 が見つかりません。同梱Pythonが壊れている可能性があります。インストーラーを再ダウンロードして入れ直してください。"
}

$script:NodeExe = Resolve-NodeRuntime
$NpmRuntime = Resolve-NpmRuntime
$PythonRuntime = Resolve-PythonRuntime
$NpmCommand = $NpmRuntime["Command"]
$PythonCommand = $PythonRuntime["Command"]

$NodeDir = Split-Path $script:NodeExe -Parent
$PythonDir = Split-Path $PythonCommand -Parent
$env:PATH = "$NodeDir;$PythonDir;$env:PATH"
if (@($PythonRuntime["Prefix"]).Count -eq 0) {
  $env:PYTHON = $PythonCommand
} else {
  Remove-Item Env:PYTHON -ErrorAction SilentlyContinue
}

Write-Host "使用するNode.js: $script:NodeExe"
Write-Host "使用するPython: $PythonCommand"

if (-not (Test-Path (Join-Path $ProjectRoot "node_modules\playwright\package.json"))) {
  Write-Host "初回準備として必要な部品をインストールします..."
  $NpmArgs = @($NpmRuntime["Prefix"]) + @("install", "--omit=dev", "--no-audit", "--no-fund")
  & $NpmCommand @NpmArgs
  if ($LASTEXITCODE -ne 0) {
    throw "npm install に失敗しました。"
  }
}

$ChromeCandidates = @(@(
  $(if ($env:PROGRAMFILES) { Join-Path $env:PROGRAMFILES "Google\Chrome\Application\chrome.exe" }),
  $(if (${env:PROGRAMFILES(X86)}) { Join-Path ${env:PROGRAMFILES(X86)} "Google\Chrome\Application\chrome.exe" }),
  $(if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA "Google\Chrome\Application\chrome.exe" })
) | Where-Object { $_ -and (Test-Path $_) })

if (-not $ChromeCandidates.Count) {
  throw "Google Chrome が見つかりません。Chromeをインストールしてください。"
}

$ChromePath = $ChromeCandidates[0]
$ChromeProfile = Join-Path $ProjectRoot "data\chrome-profile-windows"
New-Item -ItemType Directory -Force -Path $ChromeProfile | Out-Null

function Test-DedicatedChromeProcess {
  $connection = Get-NetTCPConnection -State Listen -LocalPort 9222 -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $connection) { return $false }
  $process = Get-CimInstance Win32_Process -Filter "ProcessId=$($connection.OwningProcess)" -ErrorAction SilentlyContinue
  if (-not $process -or $process.Name -ne "chrome.exe") { return $false }
  $commandLine = ([string]$process.CommandLine).Replace('"', '').ToLowerInvariant()
  if ([string]::IsNullOrWhiteSpace($commandLine)) {
    # Standard-user launches may not expose Chrome's command line. Do not kill
    # the browser that owns the dedicated debugging port in that case.
    return $true
  }
  $normalizedProfile = ([IO.Path]::GetFullPath($ChromeProfile)).TrimEnd('\').ToLowerInvariant()
  return $commandLine -like "*--user-data-dir=$normalizedProfile*"
}

function Test-ChromeHasPages {
  try {
    $pages = @(Invoke-RestMethod -Uri "http://127.0.0.1:9222/json/list" -TimeoutSec 2)
    return @($pages | Where-Object { $_.type -eq "page" }).Count -gt 0
  } catch {
    return $false
  }
}

function Stop-WrongChromeOwner {
  $connection = Get-NetTCPConnection -State Listen -LocalPort 9222 -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $connection) { return }
  $process = Get-CimInstance Win32_Process -Filter "ProcessId=$($connection.OwningProcess)" -ErrorAction SilentlyContinue
  $commandLine = [string]$process.CommandLine
  if ($process -and $process.Name -eq "chrome.exe" -and $commandLine -and -not (Test-DedicatedChromeProcess)) {
    Stop-Process -Id $connection.OwningProcess -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
  }
}

$CdpReady = $false
try {
  Invoke-WebRequest -Uri "http://127.0.0.1:9222/json/version" -UseBasicParsing -TimeoutSec 2 | Out-Null
  $CdpReady = (Test-DedicatedChromeProcess) -and (Test-ChromeHasPages)
} catch {
  $CdpReady = $false
}

if (-not $CdpReady) {
  Stop-WrongChromeOwner
  Write-Host "Windows取得用Chromeを起動します。初回はリアプロといい生活へログインしてください。"
  $ChromeArgs = @(
    "--remote-debugging-address=127.0.0.1",
    "--remote-debugging-port=9222",
    "--user-data-dir=$ChromeProfile",
    "--no-first-run",
    "--new-window"
  )
  Start-Process -FilePath $ChromePath -ArgumentList $ChromeArgs
  foreach ($Attempt in 1..15) {
    Start-Sleep -Seconds 1
    try {
      Invoke-WebRequest -Uri "http://127.0.0.1:9222/json/version" -UseBasicParsing -TimeoutSec 2 | Out-Null
      $CdpReady = (Test-DedicatedChromeProcess) -and (Test-ChromeHasPages)
      if (-not $CdpReady) { throw "専用Chromeの起動確認に失敗しました。" }
      break
    } catch {
      # Chromeの起動完了を待つ。
    }
  }
}

if (-not $CdpReady) {
  if ((Test-DedicatedChromeProcess) -and -not (Test-ChromeHasPages)) {
    throw "専用Chromeは起動していますが、表示中のページがありません。Chromeを閉じずに、もう一度 START_WINDOWS.bat を実行してください。"
  }
  if (Test-DedicatedChromeProcess) {
    throw "専用Chromeは起動しましたが、接続確認に失敗しました。Chromeを閉じてから、もう一度このファイルを開いてください。"
  }
  throw "Windows取得用Chromeへ接続できませんでした。Chromeを閉じてから、もう一度このファイルを開いてください。"
}

$BridgeReady = $false
try {
  Invoke-WebRequest -Uri "http://127.0.0.1:9223/status" -UseBasicParsing -TimeoutSec 2 | Out-Null
  $BridgeReady = $true
} catch {
  Write-Host "Chrome接続ブリッジを起動します..."
  $BridgeLog = Join-Path $ProjectRoot "data\chrome-bridge-windows.log"
  $BridgeErrorLog = Join-Path $ProjectRoot "data\chrome-bridge-windows-error.log"
  Start-Process -FilePath $script:NodeExe `
    -ArgumentList @("automation/chrome_bridge.mjs") `
    -WorkingDirectory $ProjectRoot `
    -WindowStyle Hidden `
    -RedirectStandardOutput $BridgeLog `
    -RedirectStandardError $BridgeErrorLog
  foreach ($Attempt in 1..10) {
    Start-Sleep -Seconds 1
    try {
      Invoke-WebRequest -Uri "http://127.0.0.1:9223/status" -UseBasicParsing -TimeoutSec 2 | Out-Null
      $BridgeReady = $true
      break
    } catch {
      # 接続ブリッジの起動完了を待つ。
    }
  }
}

if (-not $BridgeReady) {
  throw "Chrome接続ブリッジを起動できませんでした。data\chrome-bridge-windows-error.log を確認してください。"
}

try {
  $bridgeReconnect = Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:9223/reconnect" -TimeoutSec 5
  if (-not $bridgeReconnect.ok) {
    throw "Chrome接続ブリッジの再接続確認に失敗しました。"
  }
  Write-Host "専用Chromeへ再接続しました。タブ数: $($bridgeReconnect.tabCount)"
} catch {
  throw "専用Chromeへの再接続に失敗しました。Chromeを閉じずに、もう一度 START_WINDOWS.bat を実行してください。詳細: $($_.Exception.Message)"
}

try {
  $serviceTabsBody = @{
    realproUrl = "https://www.realnetpro.com/"
    eSeikatsuUrl = "https://rent.e-bukken.app/login"
  } | ConvertTo-Json -Compress
  $serviceTabs = Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:9223/prepare" -ContentType "application/json" -Body $serviceTabsBody -TimeoutSec 15
  Write-Host "専用Chromeのリアプロ・いい生活タブを確認しました。新規作成: $($serviceTabs.created -join ', ')"
} catch {
  throw "専用Chromeのリアプロ・いい生活タブ準備に失敗しました。専用Chromeを閉じずに再実行してください。詳細: $($_.Exception.Message)"
}

Write-Host "画面を起動します。8765番が使用中の場合は別ポートを自動で試します。"
foreach ($Port in 8765..8775) {
  try {
    $response = Invoke-WebRequest -Uri "http://127.0.0.1:$Port/api/status" -UseBasicParsing -TimeoutSec 2
    if ($response.StatusCode -eq 200) {
      Write-Host "既に起動しています。ブラウザで画面を開きます。"
      $appUrl = "http://127.0.0.1:$Port/index.html"
      $tabs = Invoke-RestMethod -Uri "http://127.0.0.1:9223/tabs" -TimeoutSec 10
      $existingApp = @($tabs.tabs | Where-Object { [string]$_.url -match '^http://127\.0\.0\.1:\d+/(index\.html)?' }) | Select-Object -First 1
      $blankTab = @($tabs.tabs | Where-Object { [string]$_.url -eq 'chrome://newtab/' }) | Select-Object -First 1
      $targetTab = if ($existingApp) { $existingApp } else { $blankTab }
      if ($targetTab) {
        $navigation = @{ index = [int]$targetTab.index; url = $appUrl } | ConvertTo-Json -Compress
        Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:9223/navigate" -ContentType "application/json" -Body $navigation -TimeoutSec 10 | Out-Null
      } else {
        $navigation = @{ url = $appUrl } | ConvertTo-Json -Compress
        Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:9223/new" -ContentType "application/json" -Body $navigation -TimeoutSec 10 | Out-Null
      }
      exit 0
    }
  } catch {
    # このポートで起動していない場合は次のポートを確認する。
  }
}

$env:OPEN_BROWSER = "1"
& $script:NodeExe automation/server.mjs
