import fs from "node:fs/promises";
import fsSync from "node:fs";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const buildRoot = path.resolve(projectRoot, "..");
const extensionRoot = path.join(projectRoot, "extension");
const outputRoot = path.join(buildRoot, "public-update-files");
const workRoot = path.join(buildRoot, ".extension-package-work");
const defaultKeyPath = path.join(buildRoot, "secrets", "property-list-automation-extension.pem");
const defaultUpdateUrl = "https://raw.githubusercontent.com/gaku0071-bit/rent-estimate-app/property-list-updates/extension-updates.xml";
const defaultDownloadRoot = "https://raw.githubusercontent.com/gaku0071-bit/rent-estimate-app/property-list-updates/downloads";

const keyPath = argumentValue("--key") || process.env.PROPERTY_LIST_EXTENSION_KEY || defaultKeyPath;
const chromePath = argumentValue("--chrome") || findChrome();
const updateUrl = argumentValue("--update-url") || defaultUpdateUrl;
const downloadRoot = argumentValue("--download-root") || defaultDownloadRoot;

async function main() {
  const manifest = JSON.parse(await fs.readFile(path.join(extensionRoot, "manifest.json"), "utf8"));
  const version = String(manifest.version || "").trim();
  const publicKey = String(manifest.key || "").trim();
  if (!version || !publicKey) throw new Error("manifest.json に version または key がありません。");
  if (String(manifest.update_url || "") !== updateUrl) {
    throw new Error(`manifest.json の update_url が想定値と一致しません: ${manifest.update_url}`);
  }

  const extensionId = extensionIdFromPublicKey(publicKey);
  const packageName = `property-list-automation-extension-${version}`;
  const packageSource = path.join(workRoot, packageName);
  const generatedCrx = `${packageSource}.crx`;
  const outputCrx = path.join(outputRoot, `${packageName}.crx`);

  await fs.rm(workRoot, { recursive: true, force: true });
  await fs.rm(outputRoot, { recursive: true, force: true });
  await fs.mkdir(workRoot, { recursive: true });
  await fs.mkdir(outputRoot, { recursive: true });
  await fs.access(keyPath);
  await fs.cp(extensionRoot, packageSource, { recursive: true });

  const result = spawnSync(chromePath, [
    `--pack-extension=${packageSource}`,
    `--pack-extension-key=${keyPath}`,
  ], { stdio: "inherit", windowsHide: true });
  if (result.status !== 0 || !(await exists(generatedCrx))) {
    throw new Error("ChromeによるCRX作成に失敗しました。");
  }

  await fs.copyFile(generatedCrx, outputCrx);
  const sha256 = await sha256File(outputCrx);
  const release = {
    schemaVersion: 1,
    extensionId,
    version,
    updateUrl,
    crxUrl: `${downloadRoot.replace(/\/+$/, "")}/${encodeURIComponent(path.basename(outputCrx))}`,
    sha256,
    builtAt: new Date().toISOString(),
  };
  const xml = buildUpdateXml({ extensionId, version, crxUrl: release.crxUrl });
  await fs.writeFile(path.join(outputRoot, "extension-updates.xml"), `${xml}\n`, "utf8");
  await fs.writeFile(path.join(outputRoot, "extension-release.json"), `${JSON.stringify(release, null, 2)}\n`, "utf8");

  console.log(JSON.stringify({
    ok: true,
    extensionId,
    version,
    crx: outputCrx,
    sha256,
    updateManifest: path.join(outputRoot, "extension-updates.xml"),
  }, null, 2));
}

function buildUpdateXml({ extensionId, version, crxUrl }) {
  return [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<gupdate xmlns="http://www.google.com/update2/response" protocol="2">',
    `  <app appid="${escapeXml(extensionId)}">`,
    `    <updatecheck codebase="${escapeXml(crxUrl)}" version="${escapeXml(version)}" />`,
    "  </app>",
    "</gupdate>",
  ].join("\n");
}

function extensionIdFromPublicKey(publicKeyBase64) {
  const digest = createHash("sha256").update(Buffer.from(publicKeyBase64, "base64")).digest();
  const alphabet = "abcdefghijklmnop";
  return [...digest.subarray(0, 16)]
    .map((byte) => alphabet[byte >> 4] + alphabet[byte & 15])
    .join("");
}

function findChrome() {
  const candidates = [
    process.env.PROGRAMFILES ? path.join(process.env.PROGRAMFILES, "Google", "Chrome", "Application", "chrome.exe") : "",
    process.env["PROGRAMFILES(X86)"] ? path.join(process.env["PROGRAMFILES(X86)"], "Google", "Chrome", "Application", "chrome.exe") : "",
    process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, "Google", "Chrome", "Application", "chrome.exe") : "",
  ];
  const found = candidates.find((candidate) => candidate && requireFile(candidate));
  if (!found) throw new Error("Google Chromeが見つかりません。--chromeで指定してください。");
  return found;
}

function requireFile(filePath) {
  return fsSync.existsSync(filePath);
}

function argumentValue(name) {
  const prefix = `${name}=`;
  const value = process.argv.find((arg) => arg.startsWith(prefix));
  return value ? value.slice(prefix.length).trim() : "";
}

async function exists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function sha256File(filePath) {
  const hash = createHash("sha256");
  hash.update(await fs.readFile(filePath));
  return hash.digest("hex");
}

function escapeXml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&apos;");
}

main().catch((error) => {
  console.error(`拡張機能パッケージ作成 NG: ${error.message}`);
  process.exitCode = 1;
});
