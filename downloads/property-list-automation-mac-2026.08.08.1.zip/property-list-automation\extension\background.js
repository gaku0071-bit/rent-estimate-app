const EXTENSION_VERSION = "0.3.1";

let activeSystemRequest = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "SYSTEM_EXTENSION_PING") {
    sendResponse({
      ok: true,
      version: EXTENSION_VERSION,
      requestId: message.requestId || "",
      from: "property-list-extension",
    });
    return false;
  }

  if (message?.type === "SYSTEM_EXTENSION_STATUS") {
    collectTargetStatus(message.requestId || "")
      .then(sendResponse)
      .catch((error) => sendResponse({
        ok: false,
        version: EXTENSION_VERSION,
        requestId: message.requestId || "",
        summary: `Chrome拡張のタブ確認に失敗しました: ${String(error?.message || error)}`,
        tabs: [],
      }));
    return true;
  }

  if (message?.type === "REALPRO_EXTENSION_PROGRESS") {
    relayProgress(message);
    return false;
  }

  if (message?.type === "SYSTEM_APPLY_REALPRO_CONDITIONS") {
    const systemTabId = sender.tab?.id;
    const requestId = message.requestId || `conditions-${Date.now()}`;
    applyRealproConditions(requestId, systemTabId, message.payload || {})
      .catch((error) => {
        sendSystemEvent(systemTabId, requestId, "error", { error: String(error?.message || error) });
      });
    sendResponse({ ok: true, accepted: true, requestId });
    return true;
  }

  if (message?.type !== "SYSTEM_CAPTURE_REALPRO") return false;

  const systemTabId = sender.tab?.id;
  const requestId = message.requestId || `extension-${Date.now()}`;
  const payload = message.payload || {};
  activeSystemRequest = { requestId, systemTabId };
  sendSystemEvent(systemTabId, requestId, "accepted", { ok: true });
  runSystemCapture(requestId, systemTabId, payload)
    .catch((error) => {
      sendSystemEvent(systemTabId, requestId, "error", { error: String(error?.message || error) });
    })
    .finally(() => {
      if (activeSystemRequest?.requestId === requestId) activeSystemRequest = null;
    });
  sendResponse({ ok: true, accepted: true, requestId });
  return true;
});

async function runSystemCapture(requestId, systemTabId, payload = {}) {
  const pages = clamp(Number(payload.pages || 2), 1, 200);
  const startPage = clamp(Number(payload.startPage || 1), 1, 10000);
  const withDetails = payload.withDetails !== false;
  const serverUrl = serverBaseUrl(payload.serverUrl);
  const realproTab = await targetRealproTab();
  if (!realproTab?.id) {
    throw new Error("リアプロのリスト検索結果タブが見つかりません。リアプロ検索結果一覧を開いてください。");
  }
  await focusTab(realproTab);

  sendSystemEvent(systemTabId, requestId, "progress", {
    phase: "list",
    current: 0,
    total: pages,
    text: `Chrome拡張でリアプロ${startPage}ページ目から${pages}ページ取得します。`,
  });

  const capture = await sendTabMessage(realproTab.id, {
    type: "REALPRO_CAPTURE",
    pages,
    startPage,
    withDetails,
  });
  if (!capture?.ok) throw new Error(capture?.error || "リアプロ取得に失敗しました。");

  sendSystemEvent(systemTabId, requestId, "progress", {
    phase: "saving",
    current: pages,
    total: pages,
    text: "取得結果をローカルシステムへ保存しています。",
  });

  const saved = await fetchJson(`${serverUrl}/api/extension/realpro-capture`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      extensionVersion: EXTENSION_VERSION,
      capturedAt: new Date().toISOString(),
      realpro: capture.realpro,
      pages,
      startPage,
      reset: payload.reset !== false && startPage <= 1,
      mergeChunk: true,
      criteriaJson: payload.criteriaJson || "",
      criteriaText: payload.criteriaText || "",
    }),
  });

  sendSystemEvent(systemTabId, requestId, "done", {
    ok: true,
    saved,
    text: `保存OK。リアプロ${saved.realproRooms}戸 / いい生活${saved.eSeikatsuRooms}件。`,
  });
}

async function applyRealproConditions(requestId, systemTabId, payload = {}) {
  const realproTab = await targetRealproTab();
  if (!realproTab?.id) {
    throw new Error("リアプロのリスト検索結果タブが見つかりません。リアプロ検索結果一覧を開いてください。");
  }
  await focusTab(realproTab);

  sendSystemEvent(systemTabId, requestId, "progress", {
    text: "Chrome拡張でリアプロへ検索条件を反映しています。",
  });
  const result = await sendTabMessage(realproTab.id, {
    type: "REALPRO_APPLY_CONDITIONS",
    payload,
  });
  if (!result?.ok) throw new Error(result?.error || "リアプロ検索条件の反映に失敗しました。");
  sendSystemEvent(systemTabId, requestId, "done", result);
}

function relayProgress(message = {}) {
  const request = activeSystemRequest;
  if (!request?.systemTabId) return;
  sendSystemEvent(request.systemTabId, request.requestId, "progress", {
    phase: message.phase || "list",
    current: Number(message.current || 0),
    total: Number(message.total || 0),
    text: message.text || "取得中...",
  });
}

function sendSystemEvent(tabId, requestId, event, payload = {}) {
  if (!tabId) return;
  chrome.tabs.sendMessage(tabId, {
    type: "SYSTEM_CAPTURE_EVENT",
    requestId,
    event,
    payload,
  }).catch(() => {});
}

async function targetRealproTab() {
  const tabs = await chrome.tabs.query({});
  const realproTabs = tabs.filter((tab) => isRealproHost(tab));
  return realproTabs.find(isRealproListTab) || realproTabs.find((tab) => !String(tab.url || "").includes("/login")) || realproTabs[0] || null;
}

async function focusTab(tab) {
  if (!tab?.id) return;
  try {
    if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
  } catch {
    // The browser may reject focusing a window that is not currently available.
  }
  try {
    await chrome.tabs.update(tab.id, { active: true });
  } catch {
    // Sending the message can still work even when tab activation is unavailable.
  }
}

async function collectTargetStatus(requestId = "") {
  const tabs = await chrome.tabs.query({});
  const targetTabs = tabs.map(describeTargetTab).filter(Boolean);
  const realproList = targetTabs.find((tab) => tab.kind === "リアプロ一覧") || null;
  const eSeikatsuList = targetTabs.find((tab) => tab.kind === "いい生活 物件一覧/広告") || null;
  const realproDetails = targetTabs.filter((tab) => tab.kind === "リアプロ詳細");
  const ok = Boolean(realproList && eSeikatsuList);
  return {
    ok,
    version: EXTENSION_VERSION,
    requestId,
    summary: ok
      ? "Chrome拡張でリアプロ一覧といい生活画面を確認しました。"
      : missingTargetSummary(realproList, eSeikatsuList),
    realproList,
    eSeikatsuList,
    realproDetails,
    tabs: targetTabs.slice(0, 30),
  };
}

function isRealproListTab(tab) {
  const url = String(tab?.url || "");
  return isRealproHost(tab) &&
    url.includes("method=estate") &&
    url.includes("display=building");
}

function isRealproHost(tab) {
  try {
    const hostname = new URL(String(tab?.url || "")).hostname;
    return hostname === "realnetpro.com" || hostname === "www.realnetpro.com";
  } catch {
    return false;
  }
}

function isRealproDetailTab(tab) {
  const url = String(tab?.url || "");
  return url.includes("realnetpro.com") &&
    url.includes("method=room");
}

function isESeikatsuListTab(tab) {
  const url = String(tab?.url || "");
  return url.includes("rent.e-bukken.app") &&
    !url.includes("/login");
}

function describeTargetTab(tab) {
  const url = String(tab?.url || "");
  let kind = "";
  if (isRealproListTab(tab)) {
    kind = "リアプロ一覧";
  } else if (isRealproDetailTab(tab)) {
    kind = "リアプロ詳細";
  } else if (url.includes("realnetpro.com")) {
    kind = "リアプロ対象外";
  } else if (isESeikatsuListTab(tab)) {
    kind = "いい生活 物件一覧/広告";
  } else if (url.includes("rent.e-bukken.app")) {
    kind = "いい生活対象外";
  }
  if (!kind) return null;
  return {
    index: Number(tab?.index ?? 0) + 1,
    kind,
    host: hostFromUrl(url),
    title: tab?.title || "",
    url,
  };
}

function missingTargetSummary(realproList, eSeikatsuList) {
  const missing = [];
  if (!realproList) missing.push("リアプロ一覧");
  if (!eSeikatsuList) missing.push("いい生活画面");
  return `${missing.join("・")}が見つかりません。ログイン済みのタブを開いてから再確認してください。`;
}

function hostFromUrl(value) {
  try {
    return new URL(value).host;
  } catch {
    return "";
  }
}

async function sendTabMessage(tabId, message) {
  try {
    return await sendRawTabMessage(tabId, message);
  } catch (error) {
    if (!/Receiving end does not exist|Could not establish connection/i.test(String(error?.message || error))) {
      throw error;
    }
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content/realpro.js"],
    });
    return sendRawTabMessage(tabId, message);
  }
}

function sendRawTabMessage(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(`${error.message}。リアプロタブを再読み込みしてからもう一度試してください。`));
        return;
      }
      resolve(response);
    });
  });
}

async function fetchJson(url, options) {
  const response = await fetch(url, options);
  const text = await response.text();
  const payload = text ? JSON.parse(text) : {};
  if (!response.ok) throw new Error(payload.detail || payload.error || `HTTP ${response.status}`);
  return payload;
}

function serverBaseUrl(value) {
  return String(value || "http://127.0.0.1:8765").replace(/\/+$/, "");
}

function clamp(value, min, max) {
  if (!Number.isFinite(value)) return min;
  return Math.min(Math.max(Math.trunc(value), min), max);
}
