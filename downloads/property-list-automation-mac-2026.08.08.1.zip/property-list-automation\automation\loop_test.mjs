import fs from "node:fs/promises";
import path from "node:path";

export const LOOP_TEST_HISTORY_FILE = "data/loop_test_history.json";

const CATEGORY_DEFINITIONS = [
  { key: "install", label: "インストール", weight: 15 },
  { key: "startup", label: "起動", weight: 15 },
  { key: "chrome", label: "専用Chrome・タブ接続", weight: 20 },
  { key: "cache", label: "いい生活キャッシュ更新", weight: 20 },
  { key: "capture", label: "リアプロ取得・詳細", weight: 15 },
  { key: "compare", label: "照合・CSV出力", weight: 10 },
  { key: "update", label: "更新後再テスト", weight: 5 },
];

export function buildLoopTestReport({
  serverStatus = null,
  tabStatus = null,
  cacheStatus = null,
  captureStatus = null,
  updateStatus = null,
  scope = "all",
  now = new Date().toISOString(),
} = {}) {
  const checks = [];
  const addCheck = (category, key, label, passed, detail, verified = true) => {
    checks.push({
      category,
      key,
      label,
      state: !verified ? "unverified" : passed ? "pass" : "fail",
      passed: Boolean(verified && passed),
      detail: String(detail || ""),
    });
  };
  const enabled = (category) => scope === "all" || scope === category;

  if (enabled("install")) {
    addCheck("install", "requiredFiles", "必要ファイル", serverStatus?.requiredFilesAvailable === true, serverStatus?.requiredFilesAvailable === true ? "必要ファイルOK" : (serverStatus?.missingFiles?.join(", ") || "必要ファイル未確認"), serverStatus !== null);
    addCheck("install", "runtime", "Node.js・Python", Boolean(serverStatus?.nodeVersion && serverStatus?.python3?.available), serverStatus?.nodeVersion && serverStatus?.python3?.available ? `${serverStatus.nodeVersion} / ${serverStatus.python3.detail || "Python OK"}` : "ランタイム未確認", serverStatus !== null);
    addCheck("install", "chrome", "Google Chrome", serverStatus?.chrome?.available === true, serverStatus?.chrome?.detail || "Chrome未確認", serverStatus !== null);
  }

  if (enabled("startup")) {
    addCheck("startup", "server", "ローカルサーバー", serverStatus?.ok === true, serverStatus?.ok ? `ポート ${serverStatus.port}` : "サーバー未確認", serverStatus !== null);
    addCheck("startup", "bridge", "Chromeブリッジ", serverStatus?.chromeBridge?.available === true, serverStatus?.chromeBridge?.detail || "ブリッジ未確認", serverStatus !== null);
    addCheck("startup", "appVersion", "アプリバージョン", Boolean(serverStatus?.appVersion?.version), serverStatus?.appVersion?.version || "バージョン未確認", serverStatus !== null);
  }

  if (enabled("chrome")) {
    addCheck("chrome", "systemTab", "システム画面", Boolean(tabStatus?.systemTab), tabStatus?.systemTab ? "専用Chrome内で確認" : "専用Chrome内のシステム画面未確認", tabStatus !== null);
    addCheck("chrome", "realproTab", "リアプロ一覧", Boolean(tabStatus?.realproList), tabStatus?.realproList ? "リアプロ一覧を確認" : "リアプロ一覧未確認", tabStatus !== null);
    addCheck("chrome", "eSeikatsuTab", "いい生活一覧", Boolean(tabStatus?.eSeikatsuList), tabStatus?.eSeikatsuList ? "いい生活物件一覧を確認" : "いい生活物件一覧未確認", tabStatus !== null);
  }

  if (enabled("cache")) {
    const hasCache = cacheStatus?.exists === true;
    const full = cacheStatus?.isFull === true;
    const countsMatch = Number(cacheStatus?.fetchedCount || 0) >= Number(cacheStatus?.totalCount || 0) && Number(cacheStatus?.totalCount || 0) > 0;
    addCheck("cache", "exists", "キャッシュファイル", hasCache, hasCache ? cacheStatus.filename : "キャッシュ未作成", cacheStatus !== null);
    addCheck("cache", "complete", "全件取得完了", full && countsMatch, full && countsMatch ? `${cacheStatus.fetchedCount}件 / 全${cacheStatus.totalCount}件` : (hasCache ? "未完成キャッシュ" : "キャッシュ更新未実施"), cacheStatus !== null && hasCache);
    addCheck("cache", "reload", "キャッシュ再読込", cacheStatus?.reloadOk === true, cacheStatus?.reloadOk ? "保存後の再読込OK" : "保存後の再読込未確認", cacheStatus !== null && hasCache);
  }

  if (enabled("capture")) {
    const hasCapture = captureStatus?.exists === true;
    const fullCapture = captureStatus?.isFull === true;
    const partialDetail = hasCapture
      ? `${captureStatus.realproRooms || 0}戸 / ${captureStatus.capturedPages || 0}ページ取得済み（全件取得未完了）`
      : "取得未実施";
    addCheck("capture", "realpro", "リアプロ取得", hasCapture && fullCapture && Number(captureStatus?.realproRooms || 0) > 0, fullCapture ? `${captureStatus.realproRooms || 0}戸` : partialDetail, captureStatus !== null && hasCapture && fullCapture);
    const detailsDone = Number(captureStatus?.detailChecked || 0) >= Number(captureStatus?.detailTargets || 0) && Number(captureStatus?.detailTargets || 0) > 0;
    const partialDetails = hasCapture
      ? `${captureStatus.detailChecked || 0} / ${captureStatus.detailTargets || 0}戸を確認（全件取得未完了）`
      : "詳細確認未実施";
    addCheck("capture", "details", "詳細確認", fullCapture && detailsDone, fullCapture ? `${captureStatus.detailChecked || 0} / ${captureStatus.detailTargets || 0}戸` : partialDetails, captureStatus !== null && hasCapture && fullCapture);
  }

  if (enabled("compare")) {
    const hasCapture = captureStatus?.exists === true;
    const fullCapture = captureStatus?.isFull === true;
    const partialCompare = hasCapture && captureStatus.compareCompleted === true ? "部分照合済み（全件取得未完了）" : "照合未確認";
    addCheck("compare", "compare", "いい生活照合", hasCapture && fullCapture && captureStatus.compareCompleted === true, fullCapture && captureStatus.compareCompleted ? "照合完了" : partialCompare, captureStatus !== null && hasCapture && fullCapture);
    addCheck("compare", "csv", "CSV出力", fullCapture && captureStatus?.csvSaved === true, fullCapture && captureStatus?.csvSaved ? "CSV保存完了" : (hasCapture && !fullCapture ? "全件取得後にCSV出力を確認" : "CSV出力未確認"), captureStatus !== null && hasCapture && fullCapture);
  }

  if (enabled("update")) {
    addCheck("update", "postUpdate", "更新後再テスト", updateStatus?.passed === true, updateStatus?.detail || "更新後テスト未実施", updateStatus !== null);
  }

  const categories = CATEGORY_DEFINITIONS.map((definition) => {
    const categoryChecks = checks.filter((check) => check.category === definition.key);
    const unverified = categoryChecks.some((check) => check.state === "unverified");
    const passed = categoryChecks.length > 0 && !unverified && categoryChecks.every((check) => check.passed);
    const failed = categoryChecks.some((check) => check.state === "fail");
    return {
      ...definition,
      state: !categoryChecks.length ? "unverified" : passed ? "pass" : unverified && !failed ? "unverified" : "fail",
      passed,
      checks: categoryChecks,
    };
  });
  const score = categories.reduce((sum, category) => sum + (category.passed ? category.weight : 0), 0);
  const failedCount = checks.filter((check) => check.state === "fail").length;
  const unverifiedCount = checks.filter((check) => check.state === "unverified").length;
  return {
    schemaVersion: 1,
    checkedAt: now,
    scope,
    score,
    maxScore: 100,
    passed: score === 100 && failedCount === 0 && unverifiedCount === 0,
    failedCount,
    unverifiedCount,
    categories,
    checks,
  };
}

export async function readLoopTestHistory(root, limit = 20) {
  try {
    const content = await fs.readFile(path.join(root, LOOP_TEST_HISTORY_FILE), "utf8");
    const history = JSON.parse(content);
    return Array.isArray(history) ? history.slice(-limit).reverse() : [];
  } catch {
    return [];
  }
}

export async function appendLoopTestHistory(root, report, limit = 50) {
  const history = await readLoopTestHistory(root, limit);
  const next = [...history.reverse(), report].slice(-limit);
  const target = path.join(root, LOOP_TEST_HISTORY_FILE);
  await fs.mkdir(path.dirname(target), { recursive: true });
  await fs.writeFile(target, `${JSON.stringify(next, null, 2)}\n`, "utf8");
  return report;
}
