[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)]
  [string]$Source,

  [Parameter(Mandatory = $true)]
  [string]$Destination
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$sourcePath = [IO.Path]::GetFullPath($Source)
$destinationPath = [IO.Path]::GetFullPath($Destination)

if (-not (Test-Path -LiteralPath $sourcePath -PathType Container)) {
  throw "拡張機能の配布元が見つかりません: $sourcePath"
}

$destinationParent = Split-Path -Parent $destinationPath
$destinationName = Split-Path -Leaf $destinationPath
$temporaryPath = Join-Path $destinationParent (".$destinationName.tmp-$PID")

New-Item -ItemType Directory -Force -Path $destinationParent | Out-Null
Remove-Item -LiteralPath $temporaryPath -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $temporaryPath | Out-Null

try {
  Get-ChildItem -LiteralPath $sourcePath -Force | ForEach-Object {
    $targetPath = Join-Path $temporaryPath $_.Name
    Copy-Item -LiteralPath $_.FullName -Destination $targetPath -Recurse -Force
  }

  Remove-Item -LiteralPath $destinationPath -Recurse -Force -ErrorAction SilentlyContinue
  Move-Item -LiteralPath $temporaryPath -Destination $destinationPath
  Write-Host "Chrome拡張機能をデスクトップへ更新しました: $destinationPath"
}
finally {
  if (Test-Path -LiteralPath $temporaryPath) {
    Remove-Item -LiteralPath $temporaryPath -Recurse -Force -ErrorAction SilentlyContinue
  }
}
