import { spawn } from "node:child_process";
import { createRequire } from "node:module";
import { readFile } from "node:fs/promises";

const jsonOnly = process.argv.includes("--json-only");
const rulesOnly = process.argv.includes("--rules-only");
const docsOnly = process.argv.includes("--docs-only");
const allBasic = process.argv.includes("--all-basic");
const serverOnly = process.argv.includes("--server-only");

if (serverOnly) {
  const summary = await verifyServerStatus();
  console.log(`サーバー確認: OK / ${summary.url} / CSV形式 ${summary.csvSchemaVersion} / ドキュメント${summary.docsAvailable ? "OK" : "NG"}`);
  process.exit(0);
}

if (allBasic) {
  const rulesSummary = await verifyRulesJson();
  const docsSummary = await verifyDocumentationConsistency();
  const sampleSummary = await verifySampleJson();
  console.log(`総合確認: OK / サンプル${sampleSummary.realproCount}件 / いい生活${sampleSummary.eSeikatsuCount}件 / 詳細未確認${sampleSummary.detailUnconfirmedCount}件 / ルール${rulesSummary.requiredCount}項目 / ドキュメント${docsSummary.checkedFiles}件`);
  process.exit(0);
}

if (docsOnly) {
  const docsSummary = await verifyDocumentationConsistency();
  console.log(`ドキュメント確認: OK / ${docsSummary.checkedFiles}件`);
  process.exit(0);
}

if (rulesOnly) {
  const rulesSummary = await verifyRulesJson();
  console.log(`検証ルールJSON確認: OK / 必須項目${rulesSummary.requiredCount}項目 / リアプロ ${rulesSummary.realproHost} / いい生活 ${rulesSummary.eSeikatsuHost}`);
  process.exit(0);
}

const jsonSummary = await verifySampleJson();
const docsSummary = await verifyDocumentationConsistency();
console.log(`検証サンプルJSON確認: OK / リアプロ${jsonSummary.realproCount}件(raw ${jsonSummary.realproRawCount.buildings}棟${jsonSummary.realproRawCount.rooms}戸/${jsonSummary.realproPageSummary.pages}ページ) / いい生活${jsonSummary.eSeikatsuCount}件(API ${jsonSummary.eSeikatsuApiCount.total}件/${jsonSummary.eSeikatsuApiCount.pages}ページ) / 詳細未確認${jsonSummary.detailUnconfirmedCount}件 / 必須項目OK / リンクOK (${jsonSummary.realproHost}, ${jsonSummary.eSeikatsuHost}) / ドキュメントOK ${docsSummary.checkedFiles}件`);

if (jsonOnly) {
  process.exit(0);
}

let chromium;

try {
  ({ chromium } = await import("playwright"));
} catch (error) {
  if (error.code === "ERR_MODULE_NOT_FOUND") {
    try {
      ({ chromium } = createRequire(import.meta.url)("playwright"));
    } catch {
      console.error("Playwright が未インストールです。npm が使える環境で `npm install` を実行してから `npm run verify:sample` を実行してください。");
      process.exit(1);
    }
  } else {
    throw error;
  }
}

if (!chromium) {
    console.error("Playwright が未インストールです。npm が使える環境で `npm install` を実行してから `npm run verify:sample` を実行してください。");
    process.exit(1);
}

const PORT = Number(process.env.PORT ?? 8765);
const BASE_URL = `http://127.0.0.1:${PORT}`;

const server = spawn(process.execPath, ["automation/server.mjs"], {
  cwd: new URL("..", import.meta.url),
  stdio: ["ignore", "pipe", "pipe"],
});
let serverStdout = "";
let serverStderr = "";
server.stdout.on("data", (chunk) => {
  serverStdout += chunk;
});
server.stderr.on("data", (chunk) => {
  serverStderr += chunk;
});

let browser;

try {
  await waitForServer();
  browser = await launchVerificationBrowser(chromium);
  const context = await browser.newContext({ acceptDownloads: true });
  const page = await context.newPage();
  // 検証ボタンは実務モードでは隠すため、自動確認は保守モードで実行する。
  await page.goto(`${BASE_URL}/index.html?mode=maintenance`, { waitUntil: "load" });
  await page.locator("#advancedTools > summary").click();
  await page.getByRole("button", { name: "検証サンプルを読み込み" }).click();
  await page.waitForSelector("#verificationStatus:not([hidden])");

  const result = await page.$eval("#verificationStatus", (element) => ({
    text: element.textContent,
    className: element.className,
  }));

  if (!result.className.includes("status-ok")) {
    throw new Error(result.text || "検証サンプル確認がOKではありません。");
  }

  const csv = await exportCsv(page, "作業対象CSVを出力");
  verifyCsv(csv, {
    exportType: "作業対象CSV",
    count: "4",
    workSummary: "作業対象4件",
  });

  const detailUnconfirmedCsv = await exportCsv(page, "詳細未確認CSVを出力");
  verifyCsv(detailUnconfirmedCsv, {
    exportType: "詳細未確認CSV",
    count: "1",
    workSummary: "対象外1件",
    detailCauseRequired: true,
  });
  await verifyCandidateDecisionRules(page);

  console.log(result.text);
  console.log("CSV・候補判定確認: OK");
} finally {
  if (browser) await browser.close();
  server.kill();
}

async function verifyCandidateDecisionRules(page) {
  const result = await page.evaluate(() => {
    for (const element of searchForm.elements) {
      if (element.type === "checkbox") element.checked = false;
      else if (["rentMin", "rentMax", "walkMinutes"].includes(element.name)) element.value = "0";
      else if (element.tagName === "SELECT") element.value = "";
    }
    const base = {
      address: "", line: "", station: "", accessMethod: "", walkMinutes: 0,
      layout: "1LDK", area: "30", rent: 60000, fee: 0, availableDate: "",
      equipment: [], webAd: "可", applicationCount: 0, applicationCountStatus: "",
      detailCaptureStatus: "", adFee: "1ヶ月", adFeeStatus: "確認済み",
    };
    const realpro = [
      { ...base, building: "空室ブロック", room: "101", status: "空室" },
      { ...base, building: "空室ブロック", room: "102", status: "空室" },
      { ...base, building: "終了差替", room: "201", status: "募集停止" },
      { ...base, building: "終了差替", room: "202", status: "空室" },
      { ...base, building: "未取得確認", room: "302", status: "空室" },
      { ...base, building: "ADなし", room: "401", status: "空室", adFee: "なし" },
      { ...base, building: "ADゼロ", room: "501", status: "空室", adFee: "0" },
    ];
    const eSeikatsu = [
      { building: "空室ブロック", room: "101", layout: "1LDK", status: "募集中", listing: "掲載中" },
      { building: "終了差替", room: "201", layout: "1LDK", status: "募集中", listing: "掲載中" },
      { building: "未取得確認", room: "301", layout: "1LDK", status: "募集中", listing: "掲載中" },
    ];
    importCaptureData({
      realpro: {
        rawText: "1棟 2戸",
        rooms: realpro.slice(0, 1),
        pageCaptures: [{ pageNumber: 1, roomCount: 1, lineCount: 10, textLength: 100 }],
        chunkMeta: { expectedPages: 2 },
      },
      eSeikatsu: { rooms: eSeikatsu },
    }, "途中取得回帰テスト");
    const partialCandidateCount = buildCandidateRows({ includeExcluded: true }).length;
    importCaptureData({ realpro: { rooms: realpro }, eSeikatsu: { rooms: eSeikatsu } }, "候補判定回帰テスト");
    const rows = buildCandidateRows({ includeExcluded: true });
    return {
      partialCandidateCount,
      decisions: Object.fromEntries(["102", "202", "302", "401", "501"].map((room) => [
        room,
        rows.find((rowData) => rowData.room === room)?.type ?? "見つからない",
      ])),
    };
  });

  const expected = {
    102: "同間取募集中・候補外",
    202: "掲載差替候補",
    302: "同間取状況要確認",
    401: "ADなし・除外",
    501: "ADなし・除外",
  };
  if (result.partialCandidateCount !== 0 || JSON.stringify(result.decisions) !== JSON.stringify(expected)) {
    throw new Error(`候補判定回帰テストに失敗しました: ${JSON.stringify(result)}`);
  }
}

async function waitForServer() {
  const deadline = Date.now() + 10000;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(`${BASE_URL}/index.html`);
      if (response.ok) return;
    } catch {
      await sleep(250);
    }
  }

  const serverLog = [serverStdout.trim(), serverStderr.trim()].filter(Boolean).join(" / ");
  throw new Error(`ローカルサーバーの起動を確認できませんでした。${serverLog ? ` ${serverLog}` : ""}`);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function launchVerificationBrowser(chromium) {
  try {
    return await chromium.launch();
  } catch (error) {
    if (!String(error.message || "").includes("Executable doesn't exist")) {
      throw error;
    }
    return chromium.launch({ channel: "chrome" });
  }
}

async function verifyServerStatus() {
  const port = Number(process.env.PORT ?? 8765);
  const baseUrl = `http://127.0.0.1:${port}`;
  const currentCsvSchemaVersion = await readCurrentCsvSchemaVersion();
  let response;
  try {
    response = await fetch(`${baseUrl}/api/status?ts=${Date.now()}`);
  } catch (error) {
    throw new Error(`サーバーに接続できません: ${baseUrl} / ${error.message}`);
  }
  if (!response.ok) {
    throw new Error(`サーバー状態を取得できません: HTTP ${response.status}。サーバーを再起動してください。`);
  }
  const status = await response.json();
  if (status.csvSchemaVersion !== currentCsvSchemaVersion) {
    throw new Error(`CSV形式が一致しません: ソース ${currentCsvSchemaVersion} / サーバー ${status.csvSchemaVersion || "不明"}。サーバーを再起動してください。`);
  }
  if (!status.docsAvailable) {
    throw new Error("ドキュメント配信を確認できません。サーバーを再起動してください。");
  }
  if (!status.nodeVersion || status.requiredFilesAvailable !== true || !status.chrome || !status.python3) {
    throw new Error("サーバー状態に環境確認情報がありません。サーバーを再起動してください。");
  }
  return {
    url: baseUrl,
    csvSchemaVersion: status.csvSchemaVersion,
    docsAvailable: Boolean(status.docsAvailable),
    nodeVersion: status.nodeVersion,
  };
}

async function readCurrentCsvSchemaVersion() {
  const appUrl = new URL("../src/app.js", import.meta.url);
  const appJs = await readFile(appUrl, "utf8");
  const version = appJs.match(/CSV_SCHEMA_VERSION\s*=\s*"([^"]+)"/)?.[1];
  if (!version) throw new Error("src/app.js のCSV形式を読み取れません。");
  return version;
}

async function verifySampleJson() {
  const sampleUrl = new URL("../data/verification_sample.json", import.meta.url);
  const sample = JSON.parse(await readFile(sampleUrl, "utf8"));
  const expected = sample.meta?.expectedStats;
  const capturedAt = sample.meta?.capturedAt;
  const realproRooms = sample.realpro?.rooms;
  const eSeikatsuRooms = sample.eSeikatsu?.rooms;
  const ruleSummary = await verifyRulesJson();
  const realproHost = ruleSummary.realproHost;
  const eSeikatsuHost = ruleSummary.eSeikatsuHost;
  const requiredRealproFields = ruleSummary.requiredRealproFields;
  const requiredESeikatsuFields = ruleSummary.requiredESeikatsuFields;

  if (!capturedAt || Number.isNaN(new Date(capturedAt).getTime())) {
    throw new Error("検証サンプルJSONの meta.capturedAt が不正です。");
  }
  if (!expected) {
    throw new Error("検証サンプルJSONの meta.expectedStats がありません。");
  }
  ["total", "shown", "excluded", "duplicated", "detailUnconfirmedCsv"].forEach((field) => {
    if (!Number.isFinite(Number(expected[field]))) {
      throw new Error(`検証サンプルJSONの meta.expectedStats.${field} が不正です。`);
    }
  });
  const excludedBreakdown = expected.excludedBreakdown ?? {};
  const excludedBreakdownTotal = Object.values(excludedBreakdown).reduce((total, count) => total + Number(count || 0), 0);
  if (excludedBreakdownTotal !== Number(expected.excluded)) {
    throw new Error(`検証サンプルJSONの除外内訳合計が不正です: ${excludedBreakdownTotal} / ${expected.excluded}`);
  }
  if (!Array.isArray(realproRooms) || realproRooms.length !== expected.total) {
    throw new Error(`検証サンプルJSONのリアプロ件数が不正です: ${realproRooms?.length ?? "なし"}`);
  }
  const realproPageSummary = validateRealproPageCaptures(sample.realpro?.pageCaptures);
  const realproRawCount = validateRealproRawCount(sample.realpro?.rawText, realproRooms);
  const detailUnconfirmedCount = validateDetailUnconfirmedCoverage(realproRooms, excludedBreakdown, expected.detailUnconfirmedCsv);
  if (!Array.isArray(eSeikatsuRooms) || !eSeikatsuRooms.length) {
    throw new Error("検証サンプルJSONのいい生活データがありません。");
  }
  const eSeikatsuApiCount = validateESeikatsuApiCount(sample.eSeikatsu?.apiPageCaptures, eSeikatsuRooms);

  realproRooms.forEach((room, index) => {
    requiredRealproFields.forEach((field) => {
      if (room[field] === undefined || room[field] === "") {
        throw new Error(`検証サンプルJSONのリアプロ${index + 1}件目に ${field} がありません。`);
      }
    });
    validateSampleUrl(room.url, `検証サンプルJSONのリアプロ${index + 1}件目`, [realproHost]);
  });

  eSeikatsuRooms.forEach((room, index) => {
    requiredESeikatsuFields.forEach((field) => {
      if (room[field] === undefined || room[field] === "") {
        throw new Error(`検証サンプルJSONのいい生活${index + 1}件目に ${field} がありません。`);
      }
    });
    validateSampleUrl(room.url, `検証サンプルJSONのいい生活${index + 1}件目`, [eSeikatsuHost]);
  });

  return {
    realproCount: realproRooms.length,
    eSeikatsuCount: eSeikatsuRooms.length,
    eSeikatsuApiCount,
    detailUnconfirmedCount,
    realproRawCount,
    realproPageSummary,
    realproHost,
    eSeikatsuHost,
  };
}

function validateRealproPageCaptures(pageCaptures) {
  if (!Array.isArray(pageCaptures) || !pageCaptures.length) {
    throw new Error("検証サンプルJSONのリアプロpageCapturesがありません。");
  }
  pageCaptures.forEach((page, index) => {
    if (Number(page.pageNumber) !== index + 1) {
      throw new Error(`検証サンプルJSONのリアプロページ番号が不正です: ${page.pageNumber} / 期待 ${index + 1}`);
    }
    if (!page.url || typeof page.url !== "string") {
      throw new Error(`検証サンプルJSONのリアプロ${index + 1}ページ目URLがありません。`);
    }
    if (!Number.isFinite(Number(page.lineCount)) || Number(page.lineCount) <= 0) {
      throw new Error(`検証サンプルJSONのリアプロ${index + 1}ページ目lineCountが不正です: ${page.lineCount}`);
    }
    if (!Number.isFinite(Number(page.textLength)) || Number(page.textLength) <= 0) {
      throw new Error(`検証サンプルJSONのリアプロ${index + 1}ページ目textLengthが不正です: ${page.textLength}`);
    }
  });
  return {
    pages: pageCaptures.length,
    lines: pageCaptures.reduce((total, page) => total + Number(page.lineCount), 0),
    textLength: pageCaptures.reduce((total, page) => total + Number(page.textLength), 0),
  };
}

function validateESeikatsuApiCount(apiPageCaptures, eSeikatsuRooms) {
  if (!Array.isArray(apiPageCaptures) || !apiPageCaptures.length) {
    throw new Error("検証サンプルJSONのいい生活apiPageCapturesがありません。");
  }
  const totalCount = Number(apiPageCaptures[0]?.totalCount);
  const itemCountTotal = apiPageCaptures.reduce((total, page, index) => {
    const pageNumber = Number(page.pageNumber);
    const itemCount = Number(page.itemCount);
    const pageTotalCount = Number(page.totalCount);
    if (pageNumber !== index + 1) {
      throw new Error(`検証サンプルJSONのいい生活ページ番号が不正です: ${page.pageNumber} / 期待 ${index + 1}`);
    }
    if (!Number.isFinite(itemCount) || itemCount < 0) {
      throw new Error(`検証サンプルJSONのいい生活itemCountが不正です: ${page.itemCount}`);
    }
    if (!Number.isFinite(pageTotalCount) || pageTotalCount !== totalCount) {
      throw new Error(`検証サンプルJSONのいい生活totalCountがページ間で一致しません: ${page.totalCount} / 期待 ${totalCount}`);
    }
    return total + itemCount;
  }, 0);
  if (!Number.isFinite(totalCount) || totalCount <= 0) {
    throw new Error("検証サンプルJSONのいい生活totalCountが不正です。");
  }
  if (totalCount !== eSeikatsuRooms.length || itemCountTotal !== eSeikatsuRooms.length) {
    throw new Error(`検証サンプルJSONのいい生活API件数が不正です: total ${totalCount}件 / item ${itemCountTotal}件 / 実データ ${eSeikatsuRooms.length}件`);
  }
  return {
    total: totalCount,
    items: itemCountTotal,
    pages: apiPageCaptures.length,
  };
}

function validateRealproRawCount(rawText, realproRooms) {
  const match = String(rawText ?? "").normalize("NFKC").match(/([0-9,]+)\s*棟\s*([0-9,]+)\s*戸/);
  if (!match) {
    throw new Error("検証サンプルJSONのリアプロrawTextに棟数・戸数がありません。");
  }
  const buildingCount = new Set(realproRooms.map((room) => room.building)).size;
  const roomCount = realproRooms.length;
  const rawBuildingCount = Number(match[1].replaceAll(",", ""));
  const rawRoomCount = Number(match[2].replaceAll(",", ""));
  if (rawBuildingCount !== buildingCount || rawRoomCount !== roomCount) {
    throw new Error(`検証サンプルJSONのリアプロrawText件数が不正です: raw ${rawBuildingCount}棟${rawRoomCount}戸 / 実データ ${buildingCount}棟${roomCount}戸`);
  }
  return {
    buildings: rawBuildingCount,
    rooms: rawRoomCount,
  };
}

function validateDetailUnconfirmedCoverage(realproRooms, excludedBreakdown, expectedCsvCount) {
  const detailUnconfirmedRooms = realproRooms.filter((room) => room.webAd === "判定不可");
  const expectedCount = Number(excludedBreakdown["詳細未確認・除外"] ?? 0);
  if (!expectedCount) {
    throw new Error("検証サンプルJSONの除外内訳に 詳細未確認・除外 がありません。");
  }
  if (detailUnconfirmedRooms.length !== expectedCount) {
    throw new Error(`検証サンプルJSONの詳細未確認件数が不正です: 判定不可${detailUnconfirmedRooms.length}件 / 期待値${expectedCount}件`);
  }
  if (detailUnconfirmedRooms.length !== Number(expectedCsvCount)) {
    throw new Error(`検証サンプルJSONの詳細未確認CSV件数が不正です: 判定不可${detailUnconfirmedRooms.length}件 / 期待値${expectedCsvCount}件`);
  }
  detailUnconfirmedRooms.forEach((room) => {
    if (!room.building || !room.room || !room.url) {
      throw new Error("検証サンプルJSONの詳細未確認サンプルに建物名・号室・URLの不足があります。");
    }
    if (!room.detailCaptureStatus || !room.detailCaptureReason) {
      throw new Error("検証サンプルJSONの詳細未確認サンプルに詳細取得状態または詳細取得理由がありません。");
    }
    if (!Number.isFinite(Number(room.detailHttpStatus)) || Number(room.detailHttpStatus) <= 0) {
      throw new Error(`検証サンプルJSONの詳細未確認サンプルのHTTP状態が不正です: ${room.detailHttpStatus}`);
    }
    if (!Number.isFinite(Number(room.detailTextLength)) || Number(room.detailTextLength) <= 0) {
      throw new Error(`検証サンプルJSONの詳細未確認サンプルの詳細文字数が不正です: ${room.detailTextLength}`);
    }
  });
  return detailUnconfirmedRooms.length;
}

async function verifyDocumentationConsistency() {
  const docs = [
    ["README.md", "../README.md"],
    ["docs/spec.md", "../docs/spec.md"],
    ["docs/automation.md", "../docs/automation.md"],
    ["docs/verification.md", "../docs/verification.md"],
  ];
  const forbidden = [
    "判定不可・要確認",
    "広告判定不可",
    "判定総数: 12件",
    "除外: 6件",
  ];
  const requiredByFile = {
    "README.md": ["詳細未確認検証状態", "詳細未確認CSV", "取得規模", "本番前確認履歴", "未確認原因分類"],
    "docs/spec.md": ["詳細未確認・除外", "詳細未確認CSV", "リアプロ詳細取得状態", "大量取得", "リアプロ詳細未確認原因分類"],
    "docs/automation.md": ["詳細未確認検証状態", "詳細未確認CSV", "取得規模"],
    "docs/verification.md": ["判定総数: 13件", "詳細未確認CSV: 1件", "詳細未確認検証状態", "取得規模", "本番前確認履歴", "リアプロ詳細未確認原因分類"],
  };

  for (const [label, path] of docs) {
    const content = await readFile(new URL(path, import.meta.url), "utf8");
    forbidden.forEach((text) => {
      if (content.includes(text)) {
        throw new Error(`${label} に古い表現が残っています: ${text}`);
      }
    });
    (requiredByFile[label] ?? []).forEach((text) => {
      if (!content.includes(text)) {
        throw new Error(`${label} に必要な説明がありません: ${text}`);
      }
    });
  }

  const appSource = await readFile(new URL("../src/app.js", import.meta.url), "utf8");
  const serverSource = await readFile(new URL("server.mjs", import.meta.url), "utf8");
  [
    "/api/chrome-tabs",
    "/api/eseikatsu-total",
    "buildChromeTabStatus",
    "buildESeikatsuTotalStatus",
    "sanitizeChromeTabStatus",
    "clampPageCount(url.searchParams.get(\"realproPages\"), 1, 200, 2)",
    "clampPageCount(url.searchParams.get(\"eseikatsuPages\"), 1, 200, 2)",
    "いい生活 営業支援/追客 対象外",
    "url.searchParams.set(\"skipRealproDetails\", \"1\")",
    "realproChunkSessionMatches(previous.data, chunkData)",
    "isFull: rooms.length > 0 && pagesComplete",
    "markSkippedRealproDetails(skippedIds)",
  ].forEach((text) => {
    if (!serverSource.includes(text)) {
      throw new Error(`automation/server.mjs にChromeタブ確認APIがありません: ${text}`);
    }
  });

  [
    "function buildCaptureScaleSummary",
    "function captureScaleQualityMessages",
    "function renderCurrentServerUrl",
    "function updateServerUrlStripStatus",
    "function refreshServerUrlStatus",
    "function handlePreflightCheck",
    "function savePreflightHistory",
    "function renderPreflightHistory",
    "preflight-ok",
    "preflight-failed",
    "preflight-latest-ok",
    "preflight-latest-failed",
    "function detailUnconfirmedCauseBreakdownText",
    "function detailUnconfirmedDecisionNote",
    "原因分類:",
    "detail-cause-pill",
    "未確認原因 ",
    "actionPillClass",
    "resultTextFilter.value === nextQuery",
    "resultTypeFilter.value === nextType",
    "function resultFilterSummaryText",
    "絞り込み中",
    "絞り込みなし",
    "出力時表示絞り込み:",
    "label: \"未確認原因\"",
    "preflightHistory",
    "data-clear-preflight-history",
    "serverUrlState",
    "runPreflightCheck",
    "copyCurrentServerUrl",
    "reloadCurrentPage",
    "eSeikatsuListingOpen",
    "いい生活の物件一覧/広告画面を開いている",
    "handleChromeTabsCheck",
    "fetchChromeTabStatus",
    "Chromeタブ確認の結果を見て",
    "clampCapturePages(realproCapturePages?.value, 2, 200)",
    "clampCapturePages(eSeikatsuCapturePages?.value, 2, 200)",
    "renderChromeTabStatus",
    "syncListingOpenCheckFromTabStatus",
    "renderChromeTabHistory",
    "renderCapturePlan",
    "applyCaptureStep",
    "handleESeikatsuFullPagesSet",
    "eSeikatsuCoverageBlockingText",
    "requireESeikatsuFullCoverage",
    "いい生活全件未取得",
    "取得目安",
    "分割取得を推奨",
    "段階取得を${pages}ページずつに設定しました。",
    "realproCapturePages?.addEventListener(\"input\", renderCapturePlan)",
    "eSeikatsuCapturePages?.addEventListener(\"input\", renderCapturePlan)",
    "data-clear-chrome-tab-history",
    "リアプロ取得が${count}件あります",
    "label: \"取得規模\"",
    "\"取得規模\"",
    "\"取得規模詳細\"",
    "function csvExportScopeText",
    "function handleRealproFullCaptureRun",
    "全ページ取得後にいい生活と照合し、候補を表示します。",
    "ADなし・除外",
    "CSV出力範囲:",
    "直近:${formatDateTime(latest.exportedAt)}",
    "const CSV_SCHEMA_VERSION = \"2026-06-22.1\"",
  ].forEach((text) => {
    if (!appSource.includes(text)) {
      throw new Error(`src/app.js に取得規模の確認ロジックがありません: ${text}`);
    }
  });

  const styleSource = await readFile(new URL("../src/styles.css", import.meta.url), "utf8");
  [
    ".action-pill.active",
    ".detail-cause-pill",
    ".csv-guide-important",
    ".preflight-ok",
    ".preflight-failed",
    ".preflight-latest-ok",
    ".preflight-latest-failed",
    ".chrome-tab-pill-ok",
    ".chrome-tab-pill-warn",
    ".chrome-tab-history",
    ".capture-plan",
    ".capture-step-controls",
  ].forEach((text) => {
    if (!styleSource.includes(text)) {
      throw new Error(`src/styles.css に必要な表示スタイルがありません: ${text}`);
    }
  });

  const htmlSource = await readFile(new URL("../src/index.html", import.meta.url), "utf8");
  [
    "csv-guide-important",
    "表示区分・結果検索の絞り込みを反映",
    "絞り込み対象外",
    "id=\"eSeikatsuListingOpen\"",
    "id=\"checkChromeTabs\"",
    "id=\"chromeTabStatus\"",
    "id=\"chromeTabHistory\"",
    "id=\"capturePlan\"",
    "id=\"setESeikatsuFullPages\"",
    "data-capture-step=\"1\"",
    "data-capture-step=\"2\"",
    "data-capture-step=\"3\"",
    "max=\"200\"",
    "rent.e-bukken.app の物件一覧/広告画面を対象にします。",
  ].forEach((text) => {
    if (!htmlSource.includes(text)) {
      throw new Error(`src/index.html に必要なCSVガイドがありません: ${text}`);
    }
  });

  const chromeCaptureSource = await readFile(new URL("capture_chrome_mac.py", import.meta.url), "utf8");
  [
    "def suggest_eseikatsu_index",
    "chrome_tab_status",
    "eseikatsu_total_status",
    "\"rent.e-bukken.app\" not in url",
    "value !== '0'",
    "sfa.e-bukken.app の営業支援/追客画面は取得対象外です。",
  ].forEach((text) => {
    if (!chromeCaptureSource.includes(text)) {
      throw new Error(`capture_chrome_mac.py にいい生活タブ判定の確認ロジックがありません: ${text}`);
    }
  });
  const suggestESeikatsuBlock = chromeCaptureSource.match(
    /def suggest_eseikatsu_index[\s\S]*?\n\ndef /,
  )?.[0] ?? "";
  if (suggestESeikatsuBlock.includes("\"e-bukken.app\" in url")) {
    throw new Error("capture_chrome_mac.py が sfa.e-bukken.app などを誤っていい生活タブ扱いする可能性があります。");
  }

  const windowsScripts = [
    ["本番前確認.command", "../本番前確認.command", ["automation/env_check.mjs", "--all-basic", "automation/verify_sample.mjs"]],
    ["本番前確認.bat", "../本番前確認.bat", ["-Mode env", "-Mode all-basic", "-Mode sample"]],
    ["環境確認.command", "../環境確認.command", ["automation/env_check.mjs"]],
    ["環境確認.bat", "../環境確認.bat", ["verify_windows.ps1", "-Mode env"]],
    ["automation/env_check.mjs", "../automation/env_check.mjs", ["環境確認:", "CSV形式", "Google Chrome", "本番前確認.command", "CSV生成確認.bat"]],
    ["CSV生成確認.command", "../CSV生成確認.command", ["automation/verify_sample.mjs", "NODE_PATH"]],
    ["automation/run_mac.command", "../automation/run_mac.command", ["8775", "/api/status"]],
    ["automation/run_windows.ps1", "../automation/run_windows.ps1", ["$script:NodeExe", "automation/server.mjs", "chrome_bridge.mjs", "remote-debugging-port=9222", "8775", "/api/status"]],
    ["automation/chrome_bridge.mjs", "../automation/chrome_bridge.mjs", ["cdpRequest", "Runtime.evaluate", "/tabs", "/activate", "/eval"]],
    ["automation/test_chrome_bridge.mjs", "../automation/test_chrome_bridge.mjs", ["CHROME_TRANSPORT", "JavaScript実行42", "Python連携OK"]],
    ["automation/verify_windows.ps1", "../automation/verify_windows.ps1", ["param(", "sample", "all-basic", "server-only"]],
    ["automation/verify_rules_windows.ps1", "../automation/verify_rules_windows.ps1", ["verify_windows.ps1", "-Mode rules"]],
    ["automation/verify_sample_json_windows.ps1", "../automation/verify_sample_json_windows.ps1", ["verify_windows.ps1", "-Mode json"]],
    ["Windows接続確認.bat", "../Windows接続確認.bat", ["chrome-bridge", "Windows Chrome接続確認OK"]],
    ["CSV生成確認.bat", "../CSV生成確認.bat", ["verify_windows.ps1", "-Mode sample"]],
    ["総合確認.bat", "../総合確認.bat", ["verify_windows.ps1", "-Mode all-basic"]],
    ["サーバー確認.bat", "../サーバー確認.bat", ["verify_windows.ps1", "-Mode server"]],
  ];
  for (const [label, path, requiredTexts] of windowsScripts) {
    const fileUrl = new URL(path, import.meta.url);
    const bytes = await readFile(fileUrl);
    const content = bytes.toString("utf8").replace(/^\uFEFF/, "");
    requiredTexts.forEach((text) => {
      if (!content.includes(text)) {
        throw new Error(`${label} に必要なWindows確認設定がありません: ${text}`);
      }
    });
    if (path.endsWith(".ps1") && !(bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF)) {
      throw new Error(`${label} はWindows PowerShell 5向けのUTF-8 BOM付きではありません。`);
    }
  }
  if (!windowsScripts.find(([label]) => label === "automation/run_windows.ps1")) {
    throw new Error("Windows起動スクリプト確認がありません。");
  }
  const runWindowsSource = (await readFile(new URL("../automation/run_windows.ps1", import.meta.url), "utf8")).replace(/^\uFEFF/, "");
  if (!runWindowsSource.includes("$ChromeCandidates = @(@(")) {
    throw new Error("automation/run_windows.ps1 のChrome候補が必ず配列になる実装ではありません。");
  }

  return { checkedFiles: docs.length };
}

async function verifyRulesJson() {
  const rulesUrl = new URL("../data/verification_rules.json", import.meta.url);
  const rules = JSON.parse(await readFile(rulesUrl, "utf8"));
  const summary = validateVerificationRules(rules);

  return {
    ...summary,
    requiredCount: summary.requiredRealproFields.length + summary.requiredESeikatsuFields.length,
  };
}

function validateVerificationRules(rules) {
  const realproHost = rules?.hosts?.realpro;
  const eSeikatsuHost = rules?.hosts?.eSeikatsu;
  const requiredRealproFields = rules?.requiredFields?.realpro ?? [];
  const requiredESeikatsuFields = rules?.requiredFields?.eSeikatsu ?? [];

  validateRuleHost(realproHost, "リアプロ");
  validateRuleHost(eSeikatsuHost, "いい生活");
  validateRequiredFieldList(requiredRealproFields, "リアプロ");
  validateRequiredFieldList(requiredESeikatsuFields, "いい生活");

  return {
    realproHost,
    eSeikatsuHost,
    requiredRealproFields,
    requiredESeikatsuFields,
  };
}

function validateRuleHost(host, label) {
  if (!host || typeof host !== "string" || host.includes("/") || host.includes(":")) {
    throw new Error(`検証ルールJSONの${label}ドメインが不正です。`);
  }
}

function validateRequiredFieldList(fields, label) {
  if (!Array.isArray(fields) || !fields.length) {
    throw new Error(`検証ルールJSONの${label}必須項目がありません。`);
  }
  const unique = new Set(fields);
  if (unique.size !== fields.length || fields.some((field) => !field || typeof field !== "string")) {
    throw new Error(`検証ルールJSONの${label}必須項目が不正です。`);
  }
}

function validateSampleUrl(value, label, allowedHosts = []) {
  try {
    const url = new URL(value);
    if (!["https:", "http:", "verification:"].includes(url.protocol)) {
      throw new Error("unsupported");
    }
    if (allowedHosts.length && !allowedHosts.includes(url.hostname)) {
      throw new Error("unexpected-host");
    }
  } catch {
    throw new Error(`${label}のURLが不正です。`);
  }
}

async function exportCsv(page, buttonName) {
  const downloadPromise = page.waitForEvent("download");
  await page.getByRole("button", { name: buttonName }).click();
  const download = await downloadPromise;
  const stream = await download.createReadStream();
  const chunks = [];

  for await (const chunk of stream) {
    chunks.push(chunk);
  }

  return Buffer.concat(chunks).toString("utf8").replace(/^\uFEFF/, "");
}

function verifyCsv(csv, expected) {
  const [headerLine, firstDataLine] = csv.split(/\r?\n/);
  const headers = parseCsvLine(headerLine);
  const firstData = parseCsvLine(firstDataLine);
  const requiredHeaders = ["CSV形式バージョン", "CSV種別", "CSV対象件数", "CSV作業内訳", "作業指示", "次にやること", "作業対象", "確認理由", "リアプロ号室ID", "リアプロURL"];
  const requiredMetaHeaders = ["CSV出力範囲", "データ取得日時ISO", "データ鮮度", "データ鮮度確認履歴(出力時点)", "CSV出力日時ISO", "出力時検索条件JSON", "出力時表示絞り込み", "検索条件復元履歴(出力時点)", "取得規模", "取得規模詳細", "候補内訳", "確認理由内訳", "リアプロ詳細取得状態", "リアプロ詳細取得理由", "リアプロ詳細未確認原因分類", "リアプロ詳細HTTP", "リアプロ詳細文字数", "詳細未確認検証状態", "詳細未確認検証", "詳細未確認検証履歴(出力時点)", "取得品質注意件数", "取得品質確認", "取得品質確認履歴(出力時点)", "システム範囲"];

  [...requiredHeaders, ...requiredMetaHeaders].forEach((header) => {
    if (!headers.includes(header)) {
      throw new Error(`CSVヘッダーに ${header} がありません。`);
    }
  });

  const row = Object.fromEntries(headers.map((header, index) => [header, firstData[index] ?? ""]));
  if (!row.CSV形式バージョン) {
    throw new Error("CSV形式バージョンが空です。");
  }
  if (row.CSV種別 !== expected.exportType) {
    throw new Error(`CSV種別が不正です: ${row.CSV種別}`);
  }
  if (row.CSV対象件数 !== expected.count) {
    throw new Error(`CSV対象件数が不正です: ${row.CSV対象件数}`);
  }
  if (row.CSV作業内訳 !== expected.workSummary) {
    throw new Error(`CSV作業内訳が不正です: ${row.CSV作業内訳}`);
  }
  if (!row.次にやること) {
    throw new Error("次にやることが空です。");
  }
  if (!row.確認理由) {
    throw new Error("確認理由が空です。");
  }
  if (!row.リアプロ号室ID || !row.リアプロURL.includes(`/room_detail.php?id=${encodeURIComponent(row.リアプロ号室ID)}&type=room`)) {
    throw new Error(`リアプロ号室リンクが不正です: ${row.リアプロ号室ID} / ${row.リアプロURL}`);
  }
  if (Number(row.取得品質注意件数) < 1) {
    throw new Error(`取得品質注意件数が不正です: ${row.取得品質注意件数}`);
  }
  if (!row.取得品質確認.includes("リアプロ詳細未確認")) {
    throw new Error("取得品質確認にリアプロ詳細未確認の注意がありません。");
  }
  if (!["未実施", "検証済み"].includes(row.詳細未確認検証状態)) {
    throw new Error(`詳細未確認検証状態が不正です: ${row.詳細未確認検証状態}`);
  }
  if (expected.detailCauseRequired && !row.リアプロ詳細未確認原因分類) {
    throw new Error("リアプロ詳細未確認原因分類が空です。");
  }
  if (!row.出力時検索条件JSON.includes("\"webAllowed\":true")) {
    throw new Error(`出力時検索条件JSONが不正です: ${row.出力時検索条件JSON}`);
  }
  if (!expected.detailCauseRequired && (!row.候補内訳.includes("差替1") || !row.候補内訳.includes("募集開始1"))) {
    throw new Error(`候補内訳が不正です: ${row.候補内訳}`);
  }
  if (!row.取得規模 || !row.取得規模詳細.includes("取得規模:")) {
    throw new Error(`取得規模が不正です: ${row.取得規模} / ${row.取得規模詳細}`);
  }
  if (!expected.detailCauseRequired && !row.確認理由内訳.includes("いい生活未登録")) {
    throw new Error(`確認理由内訳が不正です: ${row.確認理由内訳}`);
  }
  if (!row.データ取得日時ISO.includes("2026-06-01")) {
    throw new Error(`データ取得日時ISOが不正です: ${row.データ取得日時ISO}`);
  }
  if (Number.isNaN(new Date(row.CSV出力日時ISO).getTime())) {
    throw new Error(`CSV出力日時ISOが不正です: ${row.CSV出力日時ISO}`);
  }
  if (!row.システム範囲.includes("自動登録なし")) {
    throw new Error(`システム範囲が不正です: ${row.システム範囲}`);
  }
}

function parseCsvLine(line = "") {
  const values = [];
  let current = "";
  let inQuote = false;

  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    const next = line[index + 1];

    if (char === "\"" && inQuote && next === "\"") {
      current += "\"";
      index += 1;
    } else if (char === "\"") {
      inQuote = !inQuote;
    } else if (char === "," && !inQuote) {
      values.push(current);
      current = "";
    } else {
      current += char;
    }
  }

  values.push(current);
  return values;
}
