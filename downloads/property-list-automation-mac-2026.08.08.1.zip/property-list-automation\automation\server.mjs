import fs from "node:fs/promises";
import http from "node:http";
import path from "node:path";
import { createHash } from "node:crypto";
import { spawn, spawnSync } from "node:child_process";
import { appendLoopTestHistory, buildLoopTestReport, readLoopTestHistory } from "./loop_test.mjs";

const ROOT = path.resolve(import.meta.dirname, "..");
const SRC_DIR = path.join(ROOT, "src");
const DATA_DIR = path.join(ROOT, "data");
const DOCS_DIR = path.join(ROOT, "docs");
const EXPORTS_DIR = path.join(ROOT, "exports");
const BACKUPS_DIR = path.join(ROOT, "backups");
const VERSION_FILE = path.join(ROOT, "app-version.json");
const UPDATE_MANIFEST_FILE = path.join(ROOT, "updates", "update-manifest.json");
const UPDATE_SETTINGS_FILE = path.join(ROOT, "updates", "update-settings.json");
const UPDATE_DOWNLOADS_DIR = path.join(ROOT, "updates", "downloads");
const UPDATE_STAGING_DIR = path.join(ROOT, "updates", "staged");
const EXTENSION_CAPTURE_FILE = path.join(DATA_DIR, "extension_capture.json");
const MANUAL_DETAIL_REVIEWS_FILE = path.join(DATA_DIR, "manual_detail_reviews.json");
const UPDATE_MANIFEST_URL = process.env.UPDATE_MANIFEST_URL || "";
const REQUESTED_PORT = Number(process.env.PORT ?? 8765);
const PORT_WAS_EXPLICIT = Boolean(process.env.PORT);
let PORT = REQUESTED_PORT;
const UPDATE_BACKUP_SKIP_DIRS = new Set([
  ".git",
  ".idea",
  ".vscode",
  "__pycache__",
  "backups",
  "data",
  "dist",
  "downloads",
  "exports",
  "node_modules",
  "outputs",
  "staged"
]);
const UPDATE_BACKUP_SKIP_FILES = new Set([
  ".DS_Store",
  "Thumbs.db",
  "desktop.ini"
]);
const UPDATE_APPLY_SKIP_DIRS = new Set([
  ".git",
  "__pycache__",
  "backups",
  "data",
  "dist",
  "downloads",
  "exports",
  "node_modules",
  "outputs",
  "staged"
]);
const UPDATE_APPLY_SKIP_FILES = new Set([
  ".DS_Store",
  "Thumbs.db",
  "desktop.ini"
]);
const REQUIRED_FILES = [
  "src/index.html",
  "src/app.js",
  "src/styles.css",
  "automation/server.mjs",
  "automation/chrome_bridge.mjs",
  "automation/test_chrome_bridge.mjs",
  "automation/env_check.mjs",
  "automation/node_runner.command",
  "automation/verify_sample.mjs",
  "automation/verify_update_flow.mjs",
  "automation/loop_test.mjs",
  "automation/verify_windows.ps1",
  "automation/build_windows_installer_source.mjs",
  "automation/build_release_package.mjs",
  "automation/build_update_server_public.mjs",
  "automation/finalize_release_manifest.mjs",
  "automation/set_update_manifest_url.mjs",
  "app-version.json",
  "data/verification_sample.json",
  "data/verification_rules.json",
  "README.md",
  "docs/setup.md",
  "docs/spec.md",
  "docs/automation.md",
  "docs/hybrid-saas-spec.md",
  "docs/verification.md",
  "docs/windows_installer.md",
  "updates/update-manifest.json",
  "updates/update-settings.json",
  "UPDATE_FLOW_CHECK_WINDOWS.bat",
  "BUILD_RELEASE_PACKAGE.bat",
  "BUILD_UPDATE_SERVER_PUBLIC.bat",
  "FINALIZE_RELEASE_MANIFEST.bat",
  "SET_UPDATE_SERVER_URL.bat",
];

const contentTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
};

let captureProgress = createCaptureProgress();
let activeESeikatsuCacheCapture = null;

function createCaptureProgress(overrides = {}) {
  return {
    status: "idle",
    phase: "idle",
    label: "待機中",
    startedAt: "",
    updatedAt: new Date().toISOString(),
    startPage: 1,
    currentPage: 0,
    totalPages: 0,
    rooms: 0,
    realproRooms: 0,
    eSeikatsuRows: 0,
    eSeikatsuCurrentPage: 0,
    eSeikatsuTotalPages: 0,
    currentDetails: 0,
    totalDetails: 0,
    judged: 0,
    candidates: 0,
    message: "",
    ...overrides,
  };
}

function beginCaptureProgress(overrides = {}) {
  captureProgress = createCaptureProgress({
    status: "running",
    startedAt: new Date().toISOString(),
    ...overrides,
  });
}

function updateCaptureProgressFromOutput(text = "") {
  for (const line of String(text).split(/\r?\n/).map((value) => value.trim()).filter(Boolean)) {
    const list = line.match(/リアプロ一覧取得:\s*(\d+)\/(\d+)ページ(?:\s*\/\s*(\d+)戸)?/);
    if (list) {
      captureProgress.phase = "list";
      captureProgress.label = "リアプロ一覧を取得中";
      captureProgress.currentPage = Number(list[1]);
      captureProgress.totalPages = Number(list[2]);
      captureProgress.rooms = Number(list[3] || captureProgress.rooms || 0);
      captureProgress.realproRooms = Number(list[3] || captureProgress.realproRooms || 0);
      captureProgress.message = `${list[1]} / ${list[2]}ページを取得`;
    }
    if (/処理段階:\s*リアプロ一覧と詳細を取得中/.test(line)) {
      captureProgress.phase = "list";
      captureProgress.label = "リアプロ一覧を取得中";
      captureProgress.message = "リアプロの検索結果を読み込んでいます";
    }
    const details = line.match(/リアプロ詳細(?:再)?確認:\s*(\d+)\/(\d+)件/);
    if (details) {
      captureProgress.phase = "details";
      captureProgress.label = "候補の詳細を確認中";
      captureProgress.currentDetails = Number(details[1]);
      captureProgress.totalDetails = Number(details[2]);
      captureProgress.rooms = Math.max(
        Number(captureProgress.rooms || 0),
        Number(details[2] || 0),
      );
      captureProgress.realproRooms = Math.max(
        Number(captureProgress.realproRooms || 0),
        Number(details[2] || 0),
      );
      captureProgress.judged = Number(details[1]);
      captureProgress.message = `${details[1]} / ${details[2]}戸を判定`;
    }
    const candidates = line.match(/候補判定:\s*(\d+)\/(\d+)件\s*\/\s*候補(\d+)件/);
    if (candidates) {
      captureProgress.phase = "details";
      captureProgress.currentDetails = Number(candidates[1]);
      captureProgress.totalDetails = Number(candidates[2]);
      captureProgress.rooms = Math.max(
        Number(captureProgress.rooms || 0),
        Number(candidates[2] || 0),
      );
      captureProgress.realproRooms = Math.max(
        Number(captureProgress.realproRooms || 0),
        Number(candidates[2] || 0),
      );
      captureProgress.judged = Number(candidates[1]);
      captureProgress.candidates = Number(candidates[3]);
      captureProgress.message = `${candidates[1]} / ${candidates[2]}戸を判定、候補${candidates[3]}件`;
    }
    if (/処理段階:\s*開いているリアプロ詳細タブを確認中/.test(line)) {
      captureProgress.phase = "details";
      captureProgress.label = "リアプロ詳細タブを確認中";
      captureProgress.currentDetails = captureProgress.totalDetails || captureProgress.currentDetails;
      captureProgress.judged = captureProgress.totalDetails || captureProgress.judged;
      captureProgress.message = "開いている詳細タブの情報を確認しています";
    }
    if (/処理段階:\s*いい生活の掲載情報を確認中/.test(line)) {
      captureProgress.phase = "compare";
      captureProgress.label = "いい生活掲載情報を確認中";
      captureProgress.currentPage = 0;
      captureProgress.totalPages = Math.max(1, Number(captureProgress.totalPages || 1));
      captureProgress.message = "いい生活の掲載情報を読み込み、全件キャッシュと照合します";
    }
    const eSeikatsu = line.match(/いい生活全件取得:\s*(\d+)\/(\d+)ページ(?:\s*\/\s*(\d+)件)?/);
    if (eSeikatsu) {
      captureProgress.phase = "compare";
      captureProgress.label = "いい生活全件情報を取得中";
      captureProgress.currentPage = Number(eSeikatsu[1]);
      captureProgress.totalPages = Number(eSeikatsu[2]);
      captureProgress.eSeikatsuCurrentPage = Number(eSeikatsu[1]);
      captureProgress.eSeikatsuTotalPages = Number(eSeikatsu[2]);
      captureProgress.eSeikatsuRows = Number(eSeikatsu[3] || captureProgress.eSeikatsuRows || 0);
      captureProgress.message = `いい生活 ${eSeikatsu[1]} / ${eSeikatsu[2]}ページを取得、${Number(eSeikatsu[3] || 0)}件`;
    }
    if (/処理段階:\s*取得結果を保存中/.test(line)) {
      captureProgress.phase = "saving";
      captureProgress.label = "取得結果を保存中";
      captureProgress.message = "取得結果を保存して候補リストへ反映しています";
    }
    captureProgress.updatedAt = new Date().toISOString();
  }
}

function applicationCountKnown(room = {}) {
  const value = room.applicationCount;
  if (value === null || value === undefined || value === "") return false;
  const status = String(room.applicationCountStatus || "").trim();
  return !status || status === "API確認" || status === "本文確認";
}

function completeCaptureProgress(data = {}) {
  const rooms = Array.isArray(data?.realpro?.rooms) ? data.realpro.rooms : [];
  const eSeikatsuRows = Array.isArray(data?.eSeikatsu?.rooms) ? data.eSeikatsu.rooms.length : 0;
  const candidates = rooms.filter((room) => (
    room.webAd !== "許可されていません" &&
    room.webAd !== "判定不可" &&
    !/(商談中|審査中|申込あり)/.test(String(room.status || "")) &&
    applicationCountKnown(room) &&
    Number(room.applicationCount) === 0
  )).length;
  captureProgress = {
    ...captureProgress,
    status: "complete",
    phase: "complete",
    label: "候補判定が完了",
    rooms: rooms.length || captureProgress.rooms,
    realproRooms: rooms.length || captureProgress.realproRooms || captureProgress.rooms,
    eSeikatsuRows: eSeikatsuRows || captureProgress.eSeikatsuRows,
    eSeikatsuCurrentPage: captureProgress.eSeikatsuTotalPages || captureProgress.eSeikatsuCurrentPage,
    currentPage: captureProgress.totalPages || captureProgress.currentPage,
    currentDetails: captureProgress.totalDetails || captureProgress.currentDetails,
    judged: rooms.length,
    candidates,
    message: `${rooms.length}戸の取得が完了`,
    updatedAt: new Date().toISOString(),
  };
}

function failCaptureProgress(error = "") {
  captureProgress = {
    ...captureProgress,
    status: "error",
    phase: "error",
    label: "取得に失敗",
    message: String(error).trim().split(/\r?\n/).at(-1)?.slice(0, 300) || "取得に失敗しました",
    updatedAt: new Date().toISOString(),
  };
}

function parseLastJsonLine(output = "") {
  const jsonLine = String(output).trim().split(/\n+/).reverse().find((line) => line.trim().startsWith("{"));
  return JSON.parse(jsonLine || "{}");
}

function currentCaptureProgress() {
  const startedAt = captureProgress.startedAt ? new Date(captureProgress.startedAt).getTime() : 0;
  const elapsedMs = startedAt ? Math.max(Date.now() - startedAt, 0) : 0;
  const current = captureProgress.phase === "details"
    ? captureProgress.currentDetails
    : captureProgress.currentPage;
  const total = captureProgress.phase === "details"
    ? captureProgress.totalDetails
    : captureProgress.totalPages;
  const remainingMs = current > 0 && total > current
    ? Math.round((elapsedMs / current) * (total - current))
    : 0;
  return { ...captureProgress, elapsedMs, remainingMs };
}

const server = http.createServer(async (request, response) => {
  try {
    const url = new URL(request.url ?? "/", `http://${request.headers.host}`);
    if (request.method === "OPTIONS") {
      sendOptions(response);
      return;
    }
    if (url.pathname === "/api/capture") {
      try {
        const result = await runChromeCapture(url);
        sendJson(response, 200, result);
      } catch (error) {
        sendJson(response, 500, {
          error: "Chrome取得に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/realpro-chunk") {
      try {
        const result = await runRealproChunkCapture(url);
        sendJson(response, 200, result);
      } catch (error) {
        sendJson(response, 500, {
          error: "リアプロ分割取得に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/realpro-detail-retry") {
      try {
        const result = await retryRealproDetails();
        sendJson(response, 200, result);
      } catch (error) {
        sendJson(response, 500, {
          error: "リアプロ詳細未確認の再取得に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/realpro-detail-targets") {
      try {
        const body = await readJsonBody(request, 1_000_000);
        const result = await retryRealproDetailTargets(body.roomIds, body.skippedRoomIds);
        sendJson(response, 200, result);
      } catch (error) {
        sendJson(response, 500, {
          error: "リアプロ対象詳細の取得に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/eseikatsu-cache") {
      try {
        const result = await runESeikatsuCacheCapture(url);
        sendJson(response, 200, result);
      } catch (error) {
        sendJson(response, 500, {
          error: "いい生活全件キャッシュ更新に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/merge-eseikatsu-cache") {
      try {
        sendJson(response, 200, await mergeLatestCaptureWithESeikatsuCache());
      } catch (error) {
        sendJson(response, 500, {
          error: "いい生活全件キャッシュの反映に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/extension/status") {
      sendJson(response, 200, await buildExtensionStatus());
      return;
    }

    if (url.pathname === "/api/extension/realpro-capture") {
      try {
        const body = await readJsonBody(request, 30_000_000);
        sendJson(response, 200, await saveExtensionRealproCapture(body));
      } catch (error) {
        failCaptureProgress(error.message);
        sendJson(response, 500, {
          error: "Chrome拡張のリアプロ取得保存に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/status") {
      sendJson(response, 200, await buildServerStatus());
      return;
    }

    if (url.pathname === "/api/diagnostics") {
      sendJson(response, 200, await buildLocalDiagnostics());
      return;
    }

    if (url.pathname === "/api/loop-test") {
      try {
        sendJson(response, 200, await runLoopTest(url));
      } catch (error) {
        sendJson(response, 500, {
          error: "PC接続ループテストに失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/loop-test-history") {
      sendJson(response, 200, {
        ok: true,
        history: await readLoopTestHistory(ROOT),
      });
      return;
    }

    if (url.pathname === "/api/app-version") {
      sendJson(response, 200, await readAppVersion());
      return;
    }

    if (url.pathname === "/api/update-check") {
      sendJson(response, 200, await buildUpdateCheck());
      return;
    }

    if (url.pathname === "/api/update-backups") {
      try {
        sendJson(response, 200, await listUpdateBackups());
      } catch (error) {
        sendJson(response, 500, {
          error: "更新バックアップ一覧の取得に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/update-backup") {
      try {
        const body = await readJsonBody(request, 1_000_000);
        sendJson(response, 200, await createUpdateBackup(body));
      } catch (error) {
        sendJson(response, 500, {
          error: "更新前バックアップに失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/update-restore") {
      try {
        const body = await readJsonBody(request, 1_000_000);
        sendJson(response, 200, await restoreUpdateBackup(body));
      } catch (error) {
        sendJson(response, 500, {
          error: "更新バックアップからの復元に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/update-prepare") {
      try {
        const body = await readJsonBody(request, 1_000_000);
        sendJson(response, 200, await prepareUpdatePackage(body));
      } catch (error) {
        sendJson(response, 500, {
          error: "更新ファイルの準備に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/update-prepared" && request.method === "GET") {
      try {
        sendJson(response, 200, await readPreparedUpdateStatus());
      } catch (error) {
        sendJson(response, 500, {
          error: "保存済み更新ファイルの確認に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/update-open-downloads" && request.method === "POST") {
      try {
        sendJson(response, 200, await openUpdateDownloadsFolder());
      } catch (error) {
        sendJson(response, 500, {
          error: "更新ファイルの保存先を開けませんでした。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/update-apply") {
      try {
        const body = await readJsonBody(request, 1_000_000);
        sendJson(response, 200, await applyPreparedUpdate(body));
      } catch (error) {
        sendJson(response, 500, {
          error: "更新ファイルの適用に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/capture-progress") {
      sendJson(response, 200, currentCaptureProgress());
      return;
    }

    if (url.pathname === "/api/manual-detail-reviews" && request.method === "GET") {
      sendJson(response, 200, await readManualDetailReviews());
      return;
    }

    if (url.pathname === "/api/manual-detail-reviews" && request.method === "POST") {
      try {
        const body = await readJsonBody(request);
        sendJson(response, 200, await saveManualDetailReview(body));
      } catch (error) {
        sendJson(response, 400, { error: "手動確認の保存に失敗しました。", detail: error.message });
      }
      return;
    }

    if (url.pathname === "/api/save-csv") {
      try {
        const body = await readJsonBody(request, 15_000_000);
        sendJson(response, 200, await saveCsvExport(body));
      } catch (error) {
        sendJson(response, 500, {
          error: "CSV保存に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/exports") {
      try {
        sendJson(response, 200, await listCsvExports());
      } catch (error) {
        sendJson(response, 500, {
          error: "CSV保存一覧の取得に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/chrome-tabs") {
      try {
        sendJson(response, 200, await buildChromeTabStatus());
      } catch (error) {
        sendJson(response, 500, {
          error: "Chromeタブ確認に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/open-realpro") {
      try {
        sendJson(response, 200, await openRealproInDedicatedChrome());
      } catch (error) {
        sendJson(response, 500, {
          error: "専用Chromeでリアプロを開けませんでした。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/open-service") {
      try {
        sendJson(response, 200, await openServiceInDedicatedChrome(url.searchParams.get("service")));
      } catch (error) {
        sendJson(response, 500, {
          error: "専用Chromeのサービス画面を開けませんでした。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/reload-service") {
      try {
        sendJson(response, 200, await reloadServiceInDedicatedChrome(url.searchParams.get("service")));
      } catch (error) {
        sendJson(response, 500, {
          error: "専用Chromeのサービス画面を再読み込みできませんでした。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/eseikatsu-total") {
      try {
        sendJson(response, 200, await buildESeikatsuTotalStatus(url));
      } catch (error) {
        // The total-tab check runs before cache capture starts, so record its
        // failure here instead of leaving the previous progress timestamp.
        failCaptureProgress(error.message);
        sendJson(response, 500, {
          error: "いい生活全体確認に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    if (url.pathname === "/api/realpro-conditions") {
      try {
        const body = await readJsonBody(request);
        sendJson(response, 200, await applyRealproConditions(body));
      } catch (error) {
        sendJson(response, error?.code === "REQUIRED_CHROME_TABS" ? 409 : 500, {
          error: "リアプロ検索条件の反映に失敗しました。",
          detail: error.message,
        });
      }
      return;
    }

    const filePath = resolveFilePath(url.pathname);
    const body = await fs.readFile(filePath);
    response.writeHead(200, {
      "Content-Type": contentTypes[path.extname(filePath)] ?? "application/octet-stream",
      "Cache-Control": "no-store",
    });
    response.end(body);
  } catch (error) {
    const status = error.code === "ENOENT" ? 404 : 500;
    response.writeHead(status, { "Content-Type": "text/plain; charset=utf-8" });
    response.end(status === 404 ? "Not found" : "Server error");
  }
});

function sendJson(response, status, body) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    ...corsHeaders(),
  });
  response.end(JSON.stringify(body));
}

function sendOptions(response) {
  response.writeHead(204, corsHeaders());
  response.end();
}

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };
}

function readJsonBody(request, maxBytes = 100_000) {
  return new Promise((resolve, reject) => {
    let body = "";
    request.on("data", (chunk) => {
      body += chunk;
      if (body.length > maxBytes) {
        reject(new Error("リクエストが大きすぎます。"));
        request.destroy();
      }
    });
    request.on("end", () => {
      if (!body.trim()) {
        resolve({});
        return;
      }
      try {
        resolve(JSON.parse(body));
      } catch {
        reject(new Error("JSONを読み取れませんでした。"));
      }
    });
    request.on("error", reject);
  });
}

async function saveCsvExport(payload = {}) {
  const filename = safeExportFilename(payload.filename || "");
  const csv = String(payload.csv || "");
  if (!filename.endsWith(".csv")) throw new Error("CSVファイル名が不正です。");
  if (!csv.trim()) throw new Error("CSV内容が空です。");
  await fs.mkdir(EXPORTS_DIR, { recursive: true });
  const filePath = path.join(EXPORTS_DIR, filename);
  await fs.writeFile(filePath, csv.startsWith("\uFEFF") ? csv : `\uFEFF${csv}`, "utf8");
  const latestFilename = latestExportFilename(filename);
  if (latestFilename) {
    await fs.copyFile(filePath, path.join(EXPORTS_DIR, latestFilename));
  }
  return {
    filename: `exports/${filename}`,
    latestFilename: latestFilename ? `exports/${latestFilename}` : "",
    bytes: Buffer.byteLength(csv, "utf8"),
  };
}

async function readManualDetailReviews() {
  try {
    const payload = JSON.parse(await fs.readFile(MANUAL_DETAIL_REVIEWS_FILE, "utf8"));
    return {
      schemaVersion: 1,
      updatedAt: String(payload.updatedAt || ""),
      reviews: payload.reviews && typeof payload.reviews === "object" ? payload.reviews : {},
    };
  } catch (error) {
    if (error.code === "ENOENT") return { schemaVersion: 1, updatedAt: "", reviews: {} };
    throw error;
  }
}

async function saveManualDetailReview(payload = {}) {
  const roomId = String(payload.roomId ?? "").trim();
  if (!/^\d{1,32}$/.test(roomId)) throw new Error("リアプロ号室IDが不正です。");
  const state = await readManualDetailReviews();
  const reviews = { ...state.reviews };
  if (payload.clear === true) {
    delete reviews[roomId];
  } else {
    const current = reviews[roomId] && typeof reviews[roomId] === "object" ? reviews[roomId] : {};
    const next = { ...current, roomId };
    if (Object.hasOwn(payload, "webAd")) {
      const webAd = String(payload.webAd ?? "").trim();
      if (!["可", "管理会社に確認", "許可されていません"].includes(webAd)) throw new Error("WEB広告掲載可否が不正です。");
      next.webAd = webAd;
    }
    if (Object.hasOwn(payload, "applicationCount")) {
      const applicationCount = Number(payload.applicationCount);
      if (!Number.isInteger(applicationCount) || applicationCount < 0) throw new Error("申込件数は0以上の整数で指定してください。");
      next.applicationCount = applicationCount;
    }
    if (!next.webAd && !Number.isInteger(next.applicationCount)) throw new Error("保存する確認結果がありません。");
    next.confirmedAt = new Date().toISOString();
    reviews[roomId] = next;
  }
  const updatedAt = new Date().toISOString();
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.writeFile(MANUAL_DETAIL_REVIEWS_FILE, `${JSON.stringify({ schemaVersion: 1, updatedAt, reviews }, null, 2)}\n`, "utf8");
  return { schemaVersion: 1, updatedAt, reviews };
}

async function buildExtensionStatus() {
  const status = {
    ok: true,
    server: `http://127.0.0.1:${PORT}`,
    extensionCapture: null,
    latestCapture: null,
  };
  try {
    const stats = await fs.stat(EXTENSION_CAPTURE_FILE);
    const payload = JSON.parse(await fs.readFile(EXTENSION_CAPTURE_FILE, "utf8"));
    status.extensionCapture = {
      filename: "data/extension_capture.json",
      updatedAt: stats.mtime.toISOString(),
      source: payload.source || payload.meta?.source || "",
      realproRooms: Array.isArray(payload.realpro?.rooms) ? payload.realpro.rooms.length : 0,
      eSeikatsuRooms: Array.isArray(payload.eSeikatsu?.rooms) ? payload.eSeikatsu.rooms.length : 0,
      capturedAt: payload.capturedAt || "",
    };
  } catch {
    status.extensionCapture = null;
  }

  try {
    const latestPath = path.join(DATA_DIR, "chrome_capture.json");
    const stats = await fs.stat(latestPath);
    const payload = JSON.parse(await fs.readFile(latestPath, "utf8"));
    status.latestCapture = {
      filename: "data/chrome_capture.json",
      updatedAt: stats.mtime.toISOString(),
      source: payload.source || payload.meta?.source || "",
      realproRooms: Array.isArray(payload.realpro?.rooms) ? payload.realpro.rooms.length : 0,
      eSeikatsuRooms: Array.isArray(payload.eSeikatsu?.rooms) ? payload.eSeikatsu.rooms.length : 0,
      capturedAt: payload.capturedAt || "",
    };
  } catch {
    status.latestCapture = null;
  }

  return status;
}

async function saveExtensionRealproCapture(payload = {}) {
  const realproPayload = payload.realpro || payload;
  const rooms = dedupeRooms(Array.isArray(realproPayload.rooms) ? realproPayload.rooms : []);
  if (!rooms.length) throw new Error("リアプロの号室データがありません。リアプロのリスト検索結果画面で実行してください。");

  const pageCaptures = mergePageCaptures(Array.isArray(realproPayload.pageCaptures) ? realproPayload.pageCaptures : []);
  const fallbackPageCapture = {
    pageNumber: 1,
    url: realproPayload.url || "",
    lineCount: 1,
    textLength: 1,
    roomCount: rooms.length,
    stopReason: "extension-capture",
    captureMode: "chrome-extension",
  };
  const normalizedPageCaptures = pageCaptures.length ? pageCaptures : [fallbackPageCapture];
  const rawText = realproPayload.rawText || buildExtensionRealproRawText(realproPayload, rooms, normalizedPageCaptures);
  const capturedAt = payload.capturedAt || new Date().toISOString();
  const data = {
    capturedAt,
    source: "chrome-extension",
    realpro: {
      index: 0,
      title: realproPayload.title || "リアプロ Chrome拡張取得",
      url: realproPayload.url || "",
      rawText,
      rooms,
      pageCaptures: normalizedPageCaptures,
      apiError: realproPayload.apiError || "",
      jsError: "",
      startPage: Number(realproPayload.startPage || 1),
    },
    meta: {
      source: "chrome-extension",
      extensionVersion: payload.extensionVersion || "",
      criteriaJson: normalizeCriteriaJson(payload.criteriaJson || realproPayload.criteriaJson || ""),
      criteriaText: payload.criteriaText || realproPayload.criteriaText || "",
      realproCapturedAt: capturedAt,
      receivedAt: new Date().toISOString(),
    },
  };
  data.realpro.criteriaJson = data.meta.criteriaJson;
  data.realpro.criteriaText = data.meta.criteriaText;

  // 拡張取得の保存はリアプロ結果を先に確定する。古い全件キャッシュの
  // 更新は画面側の照合処理で行い、保存リクエストを長時間ブロックしない。
  const merged = await mergeESeikatsuCache(data, { refreshStale: false });
  let mergedData = merged.data;
  let realproChunkCache = null;
  if (payload.mergeChunk) {
    const chunkMerge = await mergeRealproChunk(mergedData, {
      realproStartPage: Number(payload.startPage || realproPayload.startPage || 1),
      realproPages: Number(payload.pages || normalizedPageCaptures.length || 1),
      reset: payload.reset === true || String(payload.reset) === "1",
    });
    mergedData = chunkMerge.data;
    realproChunkCache = chunkMerge.cacheMeta;
  }
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.writeFile(EXTENSION_CAPTURE_FILE, `${JSON.stringify(mergedData, null, 2)}\n`, "utf8");
  if (!payload.mergeChunk) {
    await fs.writeFile(path.join(DATA_DIR, "chrome_capture.json"), `${JSON.stringify(mergedData, null, 2)}\n`, "utf8");
  }
  completeCaptureProgress(mergedData);

  return {
    ok: true,
    filename: "data/chrome_capture.json",
    extensionFilename: "data/extension_capture.json",
    realproRooms: rooms.length,
    realproPages: normalizedPageCaptures.length,
    eSeikatsuRooms: Array.isArray(mergedData.eSeikatsu?.rooms) ? mergedData.eSeikatsu.rooms.length : 0,
    eSeikatsuCache: mergedData.eSeikatsuCache || null,
    realproChunkCache,
    capturedAt,
  };
}

function buildExtensionRealproRawText(realproPayload = {}, rooms = [], pageCaptures = []) {
  const summary = String(realproPayload.summary || pageCaptures.find((page) => page.summary)?.summary || "").trim();
  const pageLines = pageCaptures.map((page) => {
    const count = Number(page.roomCount || 0);
    return `DOM取得戸数 ${count || rooms.length}件`;
  });
  return [summary, ...pageLines].filter(Boolean).join("\n");
}

async function listCsvExports() {
  await fs.mkdir(EXPORTS_DIR, { recursive: true });
  const entries = await fs.readdir(EXPORTS_DIR, { withFileTypes: true });
  const files = await Promise.all(entries
    .filter((entry) => entry.isFile() && entry.name.endsWith(".csv"))
    .map(async (entry) => {
      const filePath = path.join(EXPORTS_DIR, entry.name);
      const stats = await fs.stat(filePath);
      return {
        filename: `exports/${entry.name}`,
        bytes: stats.size,
        updatedAt: stats.mtime.toISOString(),
      };
    }));
  files.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
  return {
    files: files.slice(0, 20),
    count: files.length,
  };
}

function safeExportFilename(value) {
  const base = path.basename(String(value || "").replace(/[\\/:*?"<>|]/g, "-"));
  return base || "export.csv";
}

function latestExportFilename(filename) {
  if (/^property-candidates-practical-/.test(filename)) return "latest-practical.csv";
  if (/^property-candidates-work-/.test(filename)) return "latest-work.csv";
  if (/^property-candidates-review-/.test(filename)) return "latest-review.csv";
  if (/^property-candidates-all-/.test(filename)) return "latest-all.csv";
  if (/^property-candidates-[0-9]/.test(filename)) return "latest-candidates.csv";
  return "";
}

async function buildServerStatus() {
  const appJs = await fs.readFile(path.join(SRC_DIR, "app.js"), "utf8");
  const appVersion = await readAppVersion();
  const csvSchemaVersion = appJs.match(/CSV_SCHEMA_VERSION\s*=\s*"([^"]+)"/)?.[1] || "";
  const missingFiles = await missingRequiredFiles();
  const docs = await Promise.all([
    fs.access(path.join(ROOT, "README.md")).then(() => true, () => false),
    fs.access(path.join(DOCS_DIR, "spec.md")).then(() => true, () => false),
    fs.access(path.join(DOCS_DIR, "automation.md")).then(() => true, () => false),
    fs.access(path.join(DOCS_DIR, "hybrid-saas-spec.md")).then(() => true, () => false),
    fs.access(path.join(DOCS_DIR, "verification.md")).then(() => true, () => false),
  ]);

  return {
    ok: true,
    port: PORT,
    appVersion,
    csvSchemaVersion,
    docsAvailable: docs.every(Boolean),
    nodeVersion: process.versions.node,
    requiredFilesAvailable: missingFiles.length === 0,
    missingFiles,
    chrome: await chromeStatus(),
    python3: python3Status(),
    chromeBridge: await chromeBridgeStatus(),
    checkedAt: new Date().toISOString(),
  };
}

async function buildLocalDiagnostics() {
  const serverStatus = await buildServerStatus();
  let tabStatus = null;
  if (serverStatus.chromeBridge?.available !== true) {
    tabStatus = {
      ok: false,
      tabs: [],
      error: serverStatus.chromeBridge?.detail || "Chromeブリッジ未接続",
      summary: "専用Chromeブリッジ未接続。専用Chromeを起動してください。",
    };
  } else {
    try {
      tabStatus = await buildChromeTabStatus();
    } catch (error) {
      tabStatus = {
        ok: false,
        tabs: [],
        error: error.message,
        summary: `Chromeタブ確認失敗: ${error.message}`,
      };
    }
  }
  return {
    ok: serverStatus.ok && Boolean(tabStatus?.ok),
    checkedAt: new Date().toISOString(),
    server: serverStatus,
    chromeTabs: tabStatus,
    eSeikatsuCache: await readESeikatsuCacheStatus(),
  };
}

async function runLoopTest(url) {
  const scope = String(url.searchParams.get("scope") || "all");
  const diagnostics = await buildLocalDiagnostics();
  const report = buildLoopTestReport({
    serverStatus: diagnostics.server,
    tabStatus: diagnostics.chromeTabs,
    cacheStatus: diagnostics.eSeikatsuCache,
    captureStatus: await readLatestCaptureStatus(),
    updateStatus: await readUpdateFlowVerificationStatus(),
    scope,
  });
  await appendLoopTestHistory(ROOT, report);
  return {
    ok: true,
    report,
    diagnostics,
  };
}

async function readUpdateFlowVerificationStatus() {
  const verificationFile = path.join(DATA_DIR, "update_flow_verification.json");
  try {
    const verification = JSON.parse(await fs.readFile(verificationFile, "utf8"));
    const currentVersion = (await readAppVersion()).version;
    const versionMatches = Boolean(
      currentVersion
      && String(verification.testedVersion || "") === currentVersion
    );
    const passed = verification.passed === true && versionMatches;
    return {
      passed,
      checkedAt: String(verification.checkedAt || ""),
      testedVersion: String(verification.testedVersion || ""),
      detail: passed
        ? `更新フロー確認OK / ${currentVersion} / 適用${Number(verification.appliedFiles || 0)}ファイル / 復元${Number(verification.restoreFiles || 0)}ファイル`
        : `更新フローの検証バージョンが一致しません（検証 ${verification.testedVersion || "不明"} / 現在 ${currentVersion || "不明"}）`,
    };
  } catch (error) {
    if (error?.code === "ENOENT") return null;
    return {
      passed: false,
      detail: `更新フロー検証結果を読み込めません: ${error.message}`,
    };
  }
}

async function readLatestCaptureStatus() {
  const captureCandidates = ["chrome_capture.json", "extension_capture.json"];
  for (const filename of captureCandidates) {
    try {
      const filePath = path.join(DATA_DIR, filename);
      const stats = await fs.stat(filePath);
      const data = JSON.parse(await fs.readFile(filePath, "utf8"));
      const rooms = Array.isArray(data?.realpro?.rooms) ? data.realpro.rooms : [];
      const pageCaptures = Array.isArray(data?.realpro?.pageCaptures) ? data.realpro.pageCaptures : [];
      const chunkMeta = data?.realpro?.chunkMeta || {};
      const completedDetails = rooms.filter((room) => {
        const status = String(room?.detailCaptureStatus || "").trim();
        return applicationCountKnown(room) || status === "候補外のため省略";
      }).length;
      const compared = rooms.length > 0
        && Array.isArray(data?.eSeikatsu?.rooms)
        && data.eSeikatsu.rooms.length > 0;
      const accumulatedPages = Number(chunkMeta.accumulatedPages || pageCaptures.length || 0);
      const expectedPages = Number(chunkMeta.expectedPages || 0);
      const listedRoomMatch = String(data?.realpro?.rawText || "").match(/([0-9,]+)\s*戸/);
      const listedRooms = Number(String(listedRoomMatch?.[1] || "").replace(/,/g, "")) || 0;
      const fetchedRoomRows = pageCaptures.reduce((sum, page) => sum + Number(page?.roomCount || 0), 0);
      const capturedPageNumbers = new Set(
        pageCaptures
          .map((page) => Number(page?.pageNumber || 0))
          .filter((pageNumber) => Number.isInteger(pageNumber) && pageNumber > 0)
      );
      const missingPages = expectedPages > 0
        ? Array.from({ length: expectedPages }, (_, index) => index + 1)
          .filter((pageNumber) => !capturedPageNumbers.has(pageNumber))
        : [];
      const pagesComplete = expectedPages > 0
        ? missingPages.length === 0 && capturedPageNumbers.size >= expectedPages
        : listedRooms > 0 && fetchedRoomRows >= listedRooms;
      const requiredCsvFiles = [
        "latest-practical.csv",
        "latest-work.csv",
        "latest-review.csv",
        "latest-candidates.csv",
        "latest-all.csv",
      ];
      const csvStats = await Promise.all(requiredCsvFiles.map(async (csvFilename) => {
        try {
          return await fs.stat(path.join(EXPORTS_DIR, csvFilename));
        } catch {
          return null;
        }
      }));
      const csvSaved = csvStats.every((csvStat) => (
        csvStat
        && csvStat.size > 3
        && csvStat.mtimeMs >= stats.mtimeMs
      ));

      return {
        exists: true,
        filename: `data/${filename}`,
        updatedAt: stats.mtime.toISOString(),
        realproRooms: rooms.length,
        capturedPages: accumulatedPages,
        expectedPages,
        detailChecked: completedDetails,
        detailTargets: rooms.length,
        compareCompleted: compared,
        listedRooms,
        fetchedRoomRows,
        missingPages,
        isFull: rooms.length > 0 && pagesComplete,
        csvSaved,
      };
    } catch (error) {
      if (error?.code !== "ENOENT") {
        return {
          exists: false,
          filename: `data/${filename}`,
          error: error.message,
        };
      }
    }
  }

  return {
    exists: false,
    filename: "data/chrome_capture.json",
  };
}

async function readESeikatsuCacheStatus() {
  const relativePath = "data/eseikatsu_full_cache.json";
  const cachePath = path.join(ROOT, relativePath);
  try {
    const cache = JSON.parse(await fs.readFile(cachePath, "utf8"));
    const meta = cache?.meta && typeof cache.meta === "object" ? cache.meta : {};
    const rooms = Array.isArray(cache?.eSeikatsu?.rooms) ? cache.eSeikatsu.rooms : [];
    const fetchedCount = Number(meta.fetchedCount || rooms.length || 0);
    const totalCount = Number(meta.totalCount || 0);
    return {
      exists: true,
      filename: relativePath,
      isFull: meta.isFull === true,
      totalCount,
      fetchedCount,
      roomCount: rooms.length,
      capturedAt: String(cache?.capturedAt || meta.capturedAt || ""),
      reloadOk: true,
    };
  } catch (error) {
    return {
      exists: false,
      filename: relativePath,
      isFull: false,
      totalCount: 0,
      fetchedCount: 0,
      roomCount: 0,
      capturedAt: "",
      reloadOk: false,
      error: error.code === "ENOENT" ? "キャッシュ未作成" : error.message,
    };
  }
}

async function readAppVersion() {
  try {
    const version = JSON.parse(await fs.readFile(VERSION_FILE, "utf8"));
    return {
      version: String(version.version || ""),
      channel: String(version.channel || "stable"),
      updatedAt: String(version.updatedAt || ""),
      platforms: Array.isArray(version.platforms) ? version.platforms : [],
    };
  } catch {
    return {
      version: "",
      channel: "unknown",
      updatedAt: "",
      platforms: [],
    };
  }
}

async function buildUpdateCheck() {
  const current = await readAppVersion();
  const manifestResult = await readUpdateManifest();
  const platform = currentPlatformKey();
  const platformInfo = manifestResult.manifest?.[platform] || manifestResult.manifest?.all || null;
  const latestVersion = String(platformInfo?.version || "");
  const updateAvailable = Boolean(
    latestVersion &&
    current.version &&
    compareVersionStrings(latestVersion, current.version) > 0
  );

  return {
    ok: true,
    configured: Boolean(manifestResult.manifest),
    platform,
    currentVersion: current.version,
    latestVersion,
    updateAvailable,
    required: Boolean(platformInfo?.required),
    downloadUrl: String(platformInfo?.url || ""),
    sha256: String(platformInfo?.sha256 || ""),
    packageType: String(platformInfo?.packageType || ""),
    fileName: String(platformInfo?.fileName || ""),
    notes: Array.isArray(platformInfo?.notes) ? platformInfo.notes.map(String) : [],
    publishedAt: String(manifestResult.manifest?.publishedAt || ""),
    source: manifestResult.source,
    error: manifestResult.error,
    checkedAt: new Date().toISOString(),
  };
}

async function readUpdateManifest() {
  const settings = await readUpdateSettings();
  if (settings.error) {
    return { manifest: null, source: "updates/update-settings.json", error: settings.error };
  }
  const manifestUrl = UPDATE_MANIFEST_URL || settings.manifestUrl || "";
  if (manifestUrl) {
    try {
      const githubApiUrl = githubContentsApiUrl(manifestUrl);
      const requestUrl = githubApiUrl || new URL(manifestUrl);
      requestUrl.searchParams.set("_updateCheck", String(Date.now()));
      const response = await fetch(requestUrl, {
        cache: "no-store",
        headers: {
          Accept: githubApiUrl ? "application/vnd.github.raw+json" : "application/json",
          "Cache-Control": "no-cache, no-store, max-age=0",
          Pragma: "no-cache",
          "User-Agent": "PropertyListAutomation-Updater",
        },
        signal: AbortSignal.timeout(5000),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return { manifest: await response.json(), source: manifestUrl, error: "" };
    } catch (error) {
      return { manifest: null, source: manifestUrl, error: error.message };
    }
  }

  try {
    return {
      manifest: JSON.parse(await fs.readFile(UPDATE_MANIFEST_FILE, "utf8")),
      source: "updates/update-manifest.json",
      error: "",
    };
  } catch (error) {
    if (error.code === "ENOENT") return { manifest: null, source: "", error: "" };
    return { manifest: null, source: "updates/update-manifest.json", error: error.message };
  }
}

function githubContentsApiUrl(manifestUrl) {
  try {
    const url = new URL(manifestUrl);
    if (url.hostname !== "raw.githubusercontent.com") return null;
    const [owner, repository, ref, ...fileParts] = url.pathname.split("/").filter(Boolean);
    if (!owner || !repository || !ref || !fileParts.length) return null;
    const apiUrl = new URL(
      `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repository)}/contents/${fileParts.map(encodeURIComponent).join("/")}`,
    );
    apiUrl.searchParams.set("ref", ref);
    return apiUrl;
  } catch {
    return null;
  }
}

async function readUpdateSettings() {
  try {
    const settings = JSON.parse(await fs.readFile(UPDATE_SETTINGS_FILE, "utf8"));
    const manifestUrl = String(settings.manifestUrl || "").trim();
    if (manifestUrl && !/^https?:\/\//.test(manifestUrl)) {
      return { manifestUrl: "", error: "manifestUrl は http または https のURLにしてください。" };
    }
    return { manifestUrl, error: "" };
  } catch (error) {
    if (error.code === "ENOENT") return { manifestUrl: "", error: "" };
    return { manifestUrl: "", error: error.message };
  }
}

function currentPlatformKey() {
  if (process.platform === "win32") return "windows";
  if (process.platform === "darwin") return "mac";
  return "all";
}

function compareVersionStrings(a = "", b = "") {
  const left = String(a).split(/[^0-9]+/).filter(Boolean).map(Number);
  const right = String(b).split(/[^0-9]+/).filter(Boolean).map(Number);
  const length = Math.max(left.length, right.length);
  for (let index = 0; index < length; index += 1) {
    const diff = (left[index] || 0) - (right[index] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

async function prepareUpdatePackage(updateInfo = {}) {
  const downloadUrl = String(updateInfo.downloadUrl || updateInfo.url || "").trim();
  if (!downloadUrl) throw new Error("最新版のダウンロードURLが設定されていません。");

  const parsedUrl = new URL(downloadUrl);
  if (!["http:", "https:"].includes(parsedUrl.protocol)) {
    throw new Error("ダウンロードURLは http または https にしてください。");
  }

  const timestamp = timestampForFilename();
  const packageType = normalizeUpdatePackageType(updateInfo.packageType, parsedUrl.pathname);
  const urlFileName = path.basename(parsedUrl.pathname);
  const requestedFileName = String(updateInfo.fileName || "").trim();
  const filename = safeDownloadFilename(
    requestedFileName ||
    (path.extname(urlFileName) ? urlFileName : "") ||
    `update-${timestamp}.${packageType}`
  );
  const downloadDir = path.join(UPDATE_DOWNLOADS_DIR, `update-${timestamp}`);
  const downloadPath = path.join(downloadDir, filename);
  let extractDir = "";
  try {
    await fs.mkdir(downloadDir, { recursive: true });

    const downloaded = await downloadUpdateFile(downloadUrl, downloadPath);
    const sha256 = await sha256File(downloadPath);
    const expectedSha256 = normalizeSha256(updateInfo.sha256 || "");
    if (expectedSha256 && sha256 !== expectedSha256) {
      throw new Error(`SHA-256が一致しません。期待値 ${expectedSha256} / 実際 ${sha256}`);
    }

    const result = {
      ok: true,
      packageType,
      downloadedFile: path.relative(ROOT, downloadPath),
      downloadedFileAbsolute: downloadPath,
      downloadedDirectory: downloadDir,
      bytes: downloaded.bytes,
      sha256,
      verifiedSha256: Boolean(expectedSha256),
      readyToApply: false,
      readyToInstall: packageType === "exe",
      stagedPath: "",
      packageRoot: "",
      packageVersion: null,
      message: "",
    };

    if (packageType === "exe") {
      result.message = "Windowsインストーラーを取得しました。インストーラーは手動で実行します。";
      await writePreparedUpdateManifest(result, updateInfo);
      return result;
    }

    if (packageType !== "zip") {
      throw new Error("更新ファイルは .zip または .exe にしてください。");
    }

    extractDir = path.join(UPDATE_STAGING_DIR, `update-${timestamp}`);
    await fs.rm(extractDir, { recursive: true, force: true });
    await fs.mkdir(extractDir, { recursive: true });
    await extractZipArchive(downloadPath, extractDir);
    const packageRoot = await findUpdatePackageRoot(extractDir);
    const packageVersion = await readPackageVersionFromRoot(packageRoot);
    result.readyToApply = true;
    result.stagedPath = path.relative(ROOT, extractDir);
    result.packageRoot = path.relative(ROOT, packageRoot);
    result.packageVersion = packageVersion;
    result.message = "更新ファイルを一時フォルダへ展開し、必須ファイルを確認しました。";
    await writePreparedUpdateManifest(result, updateInfo);
    return result;
  } catch (error) {
    // 途中まで保存した更新ファイルを残すと、次回の空き容量をさらに圧迫する。
    await fs.rm(downloadDir, { recursive: true, force: true }).catch(() => {});
    if (extractDir) await fs.rm(extractDir, { recursive: true, force: true }).catch(() => {});
    throw error;
  }
}

async function openUpdateDownloadsFolder() {
  await fs.mkdir(UPDATE_DOWNLOADS_DIR, { recursive: true });
  const commands = process.platform === "win32"
    ? [["explorer.exe", [UPDATE_DOWNLOADS_DIR]]]
    : process.platform === "darwin"
      ? [["open", [UPDATE_DOWNLOADS_DIR]]]
      : [["xdg-open", [UPDATE_DOWNLOADS_DIR]]];
  const [command, args] = commands[0];
  const child = spawn(command, args, {
    detached: true,
    stdio: "ignore",
    windowsHide: false,
  });
  child.unref();
  return { ok: true, path: UPDATE_DOWNLOADS_DIR };
}

function updatePackageType(pathname = "") {
  const ext = path.extname(pathname).toLowerCase();
  if (ext === ".exe") return "exe";
  if (ext === ".zip") return "zip";
  return ext.replace(/^\./, "") || "zip";
}

function normalizeUpdatePackageType(value = "", pathname = "") {
  const explicit = String(value || "").trim().toLowerCase().replace(/^\./, "");
  if (["exe", "zip"].includes(explicit)) return explicit;
  return updatePackageType(pathname);
}

function safeDownloadFilename(value) {
  const filename = path.basename(String(value || "update.zip")).replace(/[\\/:*?"<>|]/g, "-");
  return filename || "update.zip";
}

async function downloadUpdateFile(url, destinationPath) {
  const response = await fetch(url, { signal: AbortSignal.timeout(120_000) });
  if (!response.ok) throw new Error(`ダウンロードに失敗しました。HTTP ${response.status}`);
  const contentLength = Number(response.headers.get("content-length") || 0);
  const availableBeforeDownload = await availableSpaceBytes(path.dirname(destinationPath));
  const requiredBeforeDownload = contentLength + 128 * 1024 * 1024;
  if (contentLength > 0 && availableBeforeDownload < requiredBeforeDownload) {
    throw new Error(`保存先の空き容量が不足しています。必要な空き容量の目安: ${formatBytes(requiredBeforeDownload)} / 現在: ${formatBytes(availableBeforeDownload)}`);
  }
  const arrayBuffer = await response.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  const availableBeforeWrite = await availableSpaceBytes(path.dirname(destinationPath));
  const requiredBeforeWrite = buffer.byteLength + 128 * 1024 * 1024;
  if (availableBeforeWrite < requiredBeforeWrite) {
    throw new Error(`保存先の空き容量が不足しています。必要な空き容量の目安: ${formatBytes(requiredBeforeWrite)} / 現在: ${formatBytes(availableBeforeWrite)}`);
  }
  await fs.writeFile(destinationPath, buffer);
  return { bytes: buffer.byteLength };
}

async function availableSpaceBytes(directory) {
  try {
    const stats = await fs.statfs(directory);
    return Number(stats.bavail) * Number(stats.bsize);
  } catch {
    return Number.POSITIVE_INFINITY;
  }
}

function formatBytes(value) {
  const bytes = Number(value);
  if (!Number.isFinite(bytes)) return "不明";
  if (bytes >= 1024 ** 3) return `${(bytes / 1024 ** 3).toFixed(1)}GB`;
  return `${Math.ceil(bytes / 1024 ** 2)}MB`;
}

async function sha256File(filePath) {
  const hash = createHash("sha256");
  hash.update(await fs.readFile(filePath));
  return hash.digest("hex");
}

function normalizeSha256(value = "") {
  return String(value).trim().toLowerCase().replace(/[^a-f0-9]/g, "");
}

async function extractZipArchive(zipPath, destinationDir) {
  if (process.platform === "win32") {
    const powershell = await findPowerShellCommand();
    if (!powershell) throw new Error("PowerShell が見つからないためZIPを展開できません。");
    const result = spawnSync(powershell, [
      "-NoProfile",
      "-ExecutionPolicy",
      "Bypass",
      "-Command",
      "Expand-Archive -LiteralPath $env:PROPERTY_UPDATE_ZIP -DestinationPath $env:PROPERTY_UPDATE_DESTINATION -Force",
    ], {
      encoding: "utf8",
      windowsHide: true,
      env: {
        ...process.env,
        PROPERTY_UPDATE_ZIP: zipPath,
        PROPERTY_UPDATE_DESTINATION: destinationDir,
      },
    });
    if (result.status !== 0) {
      throw new Error((result.stderr || result.stdout || "ZIP展開に失敗しました。").trim());
    }
    return;
  }

  const result = spawnSync("unzip", ["-q", zipPath, "-d", destinationDir], { encoding: "utf8" });
  if (result.status !== 0) {
    throw new Error((result.stderr || result.stdout || "ZIP展開に失敗しました。").trim());
  }
}

async function findPowerShellCommand() {
  for (const command of ["powershell", "pwsh"]) {
    const result = spawnSync(command, ["-NoProfile", "-Command", "$PSVersionTable.PSVersion.ToString()"], {
      encoding: "utf8",
      windowsHide: true,
    });
    if (result.status === 0) return command;
  }
  return "";
}

async function findUpdatePackageRoot(extractDir) {
  const candidates = [extractDir];
  const entries = await fs.readdir(extractDir, { withFileTypes: true });
  for (const entry of entries) {
    if (entry.isDirectory()) candidates.push(path.join(extractDir, entry.name));
  }

  for (const candidate of candidates) {
    if (await validUpdatePackageRoot(candidate)) return candidate;
  }

  throw new Error("展開した更新ファイルに必要なシステム本体が見つかりません。");
}

async function validUpdatePackageRoot(candidateRoot) {
  const required = [
    "app-version.json",
    "package.json",
    "src/index.html",
    "src/app.js",
    "src/styles.css",
    "automation/server.mjs",
    "extension/manifest.json",
  ];
  for (const file of required) {
    if (!await pathExists(path.join(candidateRoot, file))) return false;
  }
  return true;
}

async function readPackageVersionFromRoot(packageRoot) {
  try {
    return JSON.parse(await fs.readFile(path.join(packageRoot, "app-version.json"), "utf8"));
  } catch {
    return null;
  }
}

async function writePreparedUpdateManifest(result, updateInfo = {}) {
  await fs.mkdir(UPDATE_STAGING_DIR, { recursive: true });
  const manifest = {
    schemaVersion: 1,
    preparedAt: new Date().toISOString(),
    updateInfo,
    result,
  };
  await fs.writeFile(path.join(UPDATE_STAGING_DIR, "prepared-update.json"), `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
}

async function readPreparedUpdateStatus() {
  const manifestPath = path.join(UPDATE_STAGING_DIR, "prepared-update.json");
  try {
    const prepared = JSON.parse(await fs.readFile(manifestPath, "utf8"));
    const result = prepared?.result || {};
    const downloadedFile = String(result.downloadedFileAbsolute || "").trim();
    const available = Boolean(downloadedFile) && await pathExists(downloadedFile);
    return {
      ok: true,
      available,
      preparedAt: String(prepared?.preparedAt || ""),
      updateInfo: prepared?.updateInfo || {},
      result: available ? result : {},
    };
  } catch (error) {
    if (error.code === "ENOENT") {
      return { ok: true, available: false, preparedAt: "", updateInfo: {}, result: {} };
    }
    throw error;
  }
}

async function applyPreparedUpdate(options = {}) {
  const dryRun = options.dryRun === true || String(options.dryRun || "") === "1";
  const preparedManifestPath = path.join(UPDATE_STAGING_DIR, "prepared-update.json");
  const prepared = JSON.parse(await fs.readFile(preparedManifestPath, "utf8"));
  const result = prepared.result || {};
  if (result.packageType === "exe") {
    throw new Error("Windowsインストーラーexeは自動適用せず、インストーラーを手動で実行してください。");
  }
  if (!result.readyToApply || !result.packageRoot) {
    throw new Error("適用できる更新ファイルが準備されていません。先に更新ファイルを確認してください。");
  }

  const packageRoot = safeRootRelativePath(result.packageRoot);
  if (!await validUpdatePackageRoot(packageRoot)) {
    throw new Error("更新ファイルの必須ファイル確認に失敗しました。");
  }

  const current = await readAppVersion();
  const targetVersion = await readPackageVersionFromRoot(packageRoot);
  const copied = await copyPreparedUpdateFiles(packageRoot, ROOT, { dryRun });
  const appliedAt = new Date().toISOString();
  const applyManifest = {
    schemaVersion: 1,
    appliedAt,
    dryRun,
    currentVersion: current.version,
    targetVersion: targetVersion?.version || result.packageVersion?.version || "",
    packageRoot: path.relative(ROOT, packageRoot),
    copiedFiles: copied.files,
    copiedDirectories: copied.directories,
    skipped: copied.skipped,
    preservedData: [
      "data",
      "exports",
      "outputs",
      "backups",
      "updates/downloads",
      "updates/staged"
    ],
    needsRestart: !dryRun,
  };

  await fs.mkdir(UPDATE_STAGING_DIR, { recursive: true });
  await fs.writeFile(path.join(UPDATE_STAGING_DIR, "last-applied-update.json"), `${JSON.stringify(applyManifest, null, 2)}\n`, "utf8");
  return {
    ok: true,
    dryRun,
    copiedFiles: copied.files,
    copiedDirectories: copied.directories,
    skipped: copied.skipped,
    currentVersion: current.version,
    targetVersion: applyManifest.targetVersion,
    needsRestart: !dryRun,
    manifest: path.relative(ROOT, path.join(UPDATE_STAGING_DIR, "last-applied-update.json")),
    message: dryRun
      ? "更新適用の事前確認が完了しました。"
      : "本体ファイルを更新しました。システムを再起動してください。",
  };
}

async function listUpdateBackups() {
  await fs.mkdir(BACKUPS_DIR, { recursive: true });
  const entries = await fs.readdir(BACKUPS_DIR, { withFileTypes: true });
  const backups = [];

  for (const entry of entries) {
    if (!entry.isDirectory() || !/^update-\d{8}-\d{6}$/.test(entry.name)) continue;
    const backupDir = path.join(BACKUPS_DIR, entry.name);
    const manifestPath = path.join(backupDir, "backup-manifest.json");
    let manifest = {};
    try {
      manifest = JSON.parse(await fs.readFile(manifestPath, "utf8"));
    } catch {
      manifest = {};
    }
    const stats = await fs.stat(backupDir);
    backups.push({
      backupName: entry.name,
      backupPath: path.relative(ROOT, backupDir),
      createdAt: manifest.createdAt || stats.mtime.toISOString(),
      currentVersion: manifest.currentVersion || "",
      targetVersion: manifest.targetVersion || "",
      copiedFiles: Number(manifest.copiedFiles || 0),
      manifest: path.relative(ROOT, manifestPath),
    });
  }

  backups.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return {
    ok: true,
    backups,
    count: backups.length,
  };
}

async function restoreUpdateBackup(options = {}) {
  const backupName = safeUpdateBackupName(options.backupName || "");
  const dryRun = options.dryRun === true || String(options.dryRun || "") === "1";
  const backupDir = path.join(BACKUPS_DIR, backupName);
  const backupSystemDir = path.join(backupDir, "system");
  const manifestPath = path.join(backupDir, "backup-manifest.json");

  if (!await pathExists(backupSystemDir)) {
    throw new Error("指定されたバックアップ本体が見つかりません。");
  }
  if (!await validUpdatePackageRoot(backupSystemDir)) {
    throw new Error("バックアップ内の必須ファイル確認に失敗しました。");
  }

  let backupManifest = {};
  try {
    backupManifest = JSON.parse(await fs.readFile(manifestPath, "utf8"));
  } catch {
    backupManifest = {};
  }

  const copied = await copyPreparedUpdateFiles(backupSystemDir, ROOT, { dryRun });
  const restoredAt = new Date().toISOString();
  const restoreManifest = {
    schemaVersion: 1,
    restoredAt,
    dryRun,
    backupName,
    backupPath: path.relative(ROOT, backupDir),
    restoredVersion: backupManifest.currentVersion || "",
    originallyTargetedVersion: backupManifest.targetVersion || "",
    copiedFiles: copied.files,
    copiedDirectories: copied.directories,
    skipped: copied.skipped,
    preservedData: [
      "data",
      "exports",
      "outputs",
      "backups",
      "updates/downloads",
      "updates/staged"
    ],
    needsRestart: !dryRun,
  };
  await fs.writeFile(path.join(backupDir, "restore-manifest.json"), `${JSON.stringify(restoreManifest, null, 2)}\n`, "utf8");

  return {
    ok: true,
    dryRun,
    backupName,
    restoredVersion: restoreManifest.restoredVersion,
    copiedFiles: copied.files,
    copiedDirectories: copied.directories,
    skipped: copied.skipped,
    needsRestart: !dryRun,
    manifest: path.relative(ROOT, path.join(backupDir, "restore-manifest.json")),
    message: dryRun
      ? "バックアップ復元の事前確認が完了しました。"
      : "バックアップから復元しました。システムを再起動してください。",
  };
}

function safeUpdateBackupName(value) {
  const backupName = String(value || "").trim();
  if (!/^update-\d{8}-\d{6}$/.test(backupName)) {
    throw new Error("バックアップ名が不正です。");
  }
  return backupName;
}

async function copyPreparedUpdateFiles(sourceDir, destinationDir, options = {}, relativeBase = "") {
  const entries = await fs.readdir(sourceDir, { withFileTypes: true });
  let files = 0;
  let directories = 0;
  let skipped = 0;

  for (const entry of entries) {
    const sourcePath = path.join(sourceDir, entry.name);
    const relativePath = path.join(relativeBase, entry.name);
    const destinationPath = path.join(destinationDir, relativePath);

    if (shouldSkipUpdateApplyEntry(relativePath, entry)) {
      skipped += 1;
      continue;
    }

    if (entry.isDirectory()) {
      directories += 1;
      if (!options.dryRun) await fs.mkdir(destinationPath, { recursive: true });
      const child = await copyPreparedUpdateFiles(sourcePath, destinationDir, options, relativePath);
      files += child.files;
      directories += child.directories;
      skipped += child.skipped;
    } else if (entry.isFile()) {
      files += 1;
      if (!options.dryRun) {
        await fs.mkdir(path.dirname(destinationPath), { recursive: true });
        await fs.copyFile(sourcePath, destinationPath);
        await restoreExecutableMode(destinationPath);
      }
    } else {
      skipped += 1;
    }
  }

  return { files, directories, skipped };
}

function shouldSkipUpdateApplyEntry(relativePath, entry) {
  const parts = relativePath.split(path.sep).filter(Boolean);
  const rootName = parts[0] || entry.name;
  if (entry.isDirectory()) {
    return UPDATE_APPLY_SKIP_DIRS.has(entry.name) || UPDATE_APPLY_SKIP_DIRS.has(rootName);
  }
  if (entry.isFile()) {
    return UPDATE_APPLY_SKIP_FILES.has(entry.name) || UPDATE_APPLY_SKIP_DIRS.has(rootName);
  }
  return true;
}

async function restoreExecutableMode(filePath) {
  if (process.platform === "win32") return;
  if (!filePath.endsWith(".command")) return;
  try {
    await fs.chmod(filePath, 0o755);
  } catch {
    // 実行権限が設定できなくても更新自体は継続する。
  }
}

function safeRootRelativePath(relativePath) {
  const target = path.resolve(ROOT, String(relativePath || ""));
  if (!target.startsWith(ROOT)) {
    throw Object.assign(new Error("Forbidden"), { code: "EACCES" });
  }
  return target;
}

async function createUpdateBackup(updateInfo = {}) {
  const current = await readAppVersion();
  const timestamp = timestampForFilename();
  const backupName = `update-${timestamp}`;
  const backupDir = path.join(BACKUPS_DIR, backupName);
  const bodyDir = path.join(backupDir, "system");

  await fs.mkdir(bodyDir, { recursive: true });
  const copied = await copySystemForUpdateBackup(ROOT, bodyDir);
  const manifest = {
    schemaVersion: 1,
    createdAt: new Date().toISOString(),
    backupName,
    currentVersion: current.version,
    targetVersion: String(updateInfo.latestVersion || updateInfo.version || ""),
    platform: currentPlatformKey(),
    downloadUrl: String(updateInfo.downloadUrl || ""),
    required: Boolean(updateInfo.required),
    notes: Array.isArray(updateInfo.notes) ? updateInfo.notes.map(String) : [],
    source: String(updateInfo.source || ""),
    copiedFiles: copied.files,
    copiedDirectories: copied.directories,
    preservedData: [
      "data",
      "exports",
      "outputs",
      "data/chrome-profile-windows"
    ],
    excluded: Array.from(UPDATE_BACKUP_SKIP_DIRS).sort(),
  };
  await fs.writeFile(path.join(backupDir, "backup-manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`, "utf8");

  return {
    ok: true,
    backupName,
    backupPath: path.relative(ROOT, backupDir),
    manifest: path.relative(ROOT, path.join(backupDir, "backup-manifest.json")),
    copiedFiles: copied.files,
    createdAt: manifest.createdAt,
  };
}

async function copySystemForUpdateBackup(sourceDir, destinationDir, relativeBase = "") {
  const entries = await fs.readdir(sourceDir, { withFileTypes: true });
  let files = 0;
  let directories = 0;

  for (const entry of entries) {
    const sourcePath = path.join(sourceDir, entry.name);
    const relativePath = path.join(relativeBase, entry.name);
    const destinationPath = path.join(destinationDir, entry.name);

    if (shouldSkipUpdateBackupEntry(relativePath, entry)) {
      continue;
    }

    if (entry.isDirectory()) {
      directories += 1;
      await fs.mkdir(destinationPath, { recursive: true });
      const child = await copySystemForUpdateBackup(sourcePath, destinationPath, relativePath);
      files += child.files;
      directories += child.directories;
    } else if (entry.isFile()) {
      await fs.mkdir(path.dirname(destinationPath), { recursive: true });
      await fs.copyFile(sourcePath, destinationPath);
      files += 1;
    }
  }

  return { files, directories };
}

function shouldSkipUpdateBackupEntry(relativePath, entry) {
  const parts = relativePath.split(path.sep).filter(Boolean);
  const rootName = parts[0] || entry.name;
  if (entry.isDirectory()) {
    return UPDATE_BACKUP_SKIP_DIRS.has(entry.name) || UPDATE_BACKUP_SKIP_DIRS.has(rootName);
  }
  if (entry.isFile()) {
    return UPDATE_BACKUP_SKIP_FILES.has(entry.name) || UPDATE_BACKUP_SKIP_DIRS.has(rootName);
  }
  return true;
}

function timestampForFilename(date = new Date()) {
  const pad = (number) => String(number).padStart(2, "0");
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    "-",
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join("");
}

async function missingRequiredFiles() {
  const missing = [];
  for (const file of REQUIRED_FILES) {
    try {
      await fs.access(path.join(ROOT, file));
    } catch {
      missing.push(file);
    }
  }
  return missing;
}

async function chromeStatus() {
  if (process.platform === "darwin") {
    const available = await pathExists("/Applications/Google Chrome.app");
    return { available, detail: available ? "インストール済み" : "見つかりません" };
  }
  if (process.platform === "win32") {
    const candidates = [
      process.env.PROGRAMFILES ? path.join(process.env.PROGRAMFILES, "Google", "Chrome", "Application", "chrome.exe") : "",
      process.env["PROGRAMFILES(X86)"] ? path.join(process.env["PROGRAMFILES(X86)"], "Google", "Chrome", "Application", "chrome.exe") : "",
      process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, "Google", "Chrome", "Application", "chrome.exe") : "",
    ].filter(Boolean);
    const available = await somePathExists(candidates);
    return { available, detail: available ? "インストール済み" : "見つかりません" };
  }
  return { available: false, detail: "このOSでは自動確認していません" };
}

function python3Status() {
  const invocation = resolvePythonInvocation();
  if (!invocation) return { available: false, detail: "Python 3が見つかりません" };
  const result = spawnSync(invocation.command, [...invocation.prefix, "--version"], { encoding: "utf8" });
  const detail = (result.stdout || result.stderr || "").trim();
  return { available: result.status === 0, detail: detail || "Chrome取得ランナーで必要です" };
}

async function chromeBridgeStatus() {
  if (process.platform !== "win32") {
    return { available: null, detail: "Windowsで使用します" };
  }
  try {
    const response = await fetch("http://127.0.0.1:9223/status", { signal: AbortSignal.timeout(1500) });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const status = await response.json();
    return {
      available: Boolean(status.ok),
      detail: status.ok ? `接続済み / Chromeタブ${status.tabCount || 0}件` : "未接続",
    };
  } catch (error) {
    return { available: false, detail: `未接続: ${error.message}` };
  }
}

let cachedPythonInvocation;

function resolvePythonInvocation() {
  if (cachedPythonInvocation !== undefined) return cachedPythonInvocation;
  const envPython = process.env.PYTHON ? [{ command: process.env.PYTHON, prefix: [] }] : [];
  const candidates = process.platform === "win32"
    ? [
        ...envPython,
        { command: "py", prefix: ["-3"] },
        { command: "python", prefix: [] },
        { command: "python3", prefix: [] },
      ]
    : [...envPython, { command: "python3", prefix: [] }, { command: "python", prefix: [] }];
  cachedPythonInvocation = candidates.find((candidate) => {
    const result = spawnSync(candidate.command, [...candidate.prefix, "--version"], {
      encoding: "utf8",
      windowsHide: true,
    });
    return result.status === 0;
  }) || null;
  return cachedPythonInvocation;
}

function spawnCapturePython(args) {
  const invocation = resolvePythonInvocation();
  if (!invocation) throw new Error("Python 3が見つかりません。Python 3をインストールしてください。");
  return spawn(invocation.command, [...invocation.prefix, ...args], {
    cwd: ROOT,
    windowsHide: true,
    env: {
      ...process.env,
      PYTHONIOENCODING: "utf-8",
    },
  });
}

async function pathExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function somePathExists(filePaths) {
  for (const filePath of filePaths) {
    if (await pathExists(filePath)) return true;
  }
  return false;
}

function runChromeCapture(url) {
  const realproPages = clampPageCount(url.searchParams.get("realproPages"), 1, 200, 2);
  const realproStartPage = clampPageCount(url.searchParams.get("realproStartPage"), 1, 10000, 1);
  const useESeikatsuCache = url.searchParams.get("useESeikatsuCache") !== "0";
  const requestedESeikatsuPages = clampPageCount(url.searchParams.get("eseikatsuPages"), 1, 200, 2);
  const eSeikatsuPages = useESeikatsuCache ? 1 : requestedESeikatsuPages;
  const skipRealproDetails = url.searchParams.get("skipRealproDetails") === "1";
  const criteriaJson = String(url.searchParams.get("criteriaJson") || "");
  const criteriaText = String(url.searchParams.get("criteriaText") || "");
  const startedAt = Date.now();
  beginCaptureProgress({
    phase: "list",
    label: "リアプロ一覧を取得中",
    totalPages: realproPages,
    startPage: realproStartPage,
  });
  const scriptPath = path.join(ROOT, "automation", "capture_chrome_mac.py");
  const args = [
    scriptPath,
    "--auto",
    "--realpro-pages",
    String(realproPages),
    "--realpro-start-page",
    String(realproStartPage),
    "--eseikatsu-pages",
    String(eSeikatsuPages),
  ];
  if (skipRealproDetails) args.push("--skip-realpro-details");

  return new Promise((resolve, reject) => {
    const child = spawnCapturePython(args);
    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (chunk) => {
      const text = chunk.toString();
      stdout += text;
      updateCaptureProgressFromOutput(text);
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", reject);
    child.on("close", async (code) => {
      if (code !== 0) {
        failCaptureProgress(stderr || stdout);
        reject(new Error((stderr || stdout || `Chrome取得に失敗しました。終了コード: ${code}`).trim()));
        return;
      }

      let data = JSON.parse(await fs.readFile(path.join(DATA_DIR, "chrome_capture.json"), "utf8"));
      data.meta = {
        ...(data.meta || {}),
        criteriaJson: criteriaJson || data.meta?.criteriaJson || "",
        criteriaText: criteriaText || data.meta?.criteriaText || "",
        realproCapturedAt: data.meta?.realproCapturedAt || data.capturedAt || new Date().toISOString(),
      };
      if (data.realpro) {
        data.realpro.criteriaJson = data.meta.criteriaJson;
        data.realpro.criteriaText = data.meta.criteriaText;
      }
      let eSeikatsuCache = null;
      let eSeikatsuCacheRefreshed = false;
      if (useESeikatsuCache) {
        let merged = await mergeESeikatsuCache(data);
        if (!merged.eSeikatsuCache?.used) {
          const totalStatus = await buildESeikatsuTotalStatus();
          if (totalStatus.requiredPages) {
            const refreshUrl = new URL(url);
            refreshUrl.searchParams.set("pages", String(totalStatus.requiredPages));
            await buildESeikatsuCache(refreshUrl);
            merged = await mergeESeikatsuCache(data);
            eSeikatsuCacheRefreshed = Boolean(merged.eSeikatsuCache?.used);
          }
        }
        data = merged.data;
        eSeikatsuCache = merged.eSeikatsuCache;
        data.eSeikatsuCache = eSeikatsuCache;
        if (eSeikatsuCache?.used) {
          await fs.writeFile(path.join(DATA_DIR, "chrome_capture.json"), `${JSON.stringify(data, null, 2)}\n`, "utf8");
        }
      }
      resolve({
        filename: "data/chrome_capture.json",
        realproPages,
        realproStartPage,
        eSeikatsuPages,
        eSeikatsuCache,
        eSeikatsuCacheRefreshed,
        timing: {
          mode: skipRealproDetails ? "list-only" : "full",
          elapsedMs: Date.now() - startedAt,
        },
        output: stdout.trim(),
        data,
      });
      completeCaptureProgress(data);
    });
  });
}

function retryRealproDetails() {
  const scriptPath = path.join(ROOT, "automation", "capture_chrome_mac.py");
  return new Promise((resolve, reject) => {
    const child = spawnCapturePython([scriptPath, "--retry-realpro-details-json"]);
    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (chunk) => {
      const text = chunk.toString();
      stdout += text;
      updateCaptureProgressFromOutput(text);
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", reject);
    child.on("close", async (code) => {
      if (code !== 0) {
        reject(new Error((stderr || stdout || `リアプロ詳細再取得に失敗しました。終了コード: ${code}`).trim()));
        return;
      }
      const jsonLine = stdout.trim().split(/\n+/).reverse().find((line) => line.trim().startsWith("{"));
      const result = JSON.parse(jsonLine || "{}");
      const data = JSON.parse(await fs.readFile(path.join(DATA_DIR, "chrome_capture.json"), "utf8"));
      resolve({
        ...result,
        output: stdout.trim(),
        data,
      });
    });
  });
}

function retryRealproDetailTargets(roomIds = [], skippedRoomIds = []) {
  const ids = [...new Set((Array.isArray(roomIds) ? roomIds : [])
    .map((value) => String(value || "").trim())
    .filter(Boolean))];
  const skippedIds = new Set((Array.isArray(skippedRoomIds) ? skippedRoomIds : [])
    .map((value) => String(value || "").trim())
    .filter(Boolean));
  if (!ids.length && skippedIds.size) return markSkippedRealproDetails(skippedIds);
  if (!ids.length) throw new Error("詳細取得対象の部屋IDがありません。");
  const encoded = Buffer.from(JSON.stringify(ids), "utf8").toString("base64");
  const scriptPath = path.join(ROOT, "automation", "capture_chrome_mac.py");
  const startedAt = Date.now();
  beginCaptureProgress({
    phase: "details",
    label: "候補の詳細を確認中",
    rooms: ids.length + skippedIds.size,
    totalDetails: ids.length,
  });
  return new Promise((resolve, reject) => {
    const child = spawnCapturePython([scriptPath, "--retry-realpro-detail-ids-json", encoded]);
    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (chunk) => {
      const text = chunk.toString();
      stdout += text;
      updateCaptureProgressFromOutput(text);
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", reject);
    child.on("close", async (code) => {
      if (code !== 0) {
        failCaptureProgress(stderr || stdout);
        reject(new Error((stderr || stdout || `リアプロ対象詳細取得に失敗しました。終了コード: ${code}`).trim()));
        return;
      }
      const jsonLine = stdout.trim().split(/\n+/).reverse().find((line) => line.trim().startsWith("{"));
      const result = JSON.parse(jsonLine || "{}");
      const capturePath = path.join(DATA_DIR, "chrome_capture.json");
      const data = JSON.parse(await fs.readFile(capturePath, "utf8"));
      for (const room of data?.realpro?.rooms || []) {
        if (!skippedIds.has(String(room.realproRoomId || ""))) continue;
        room.detailCaptureStatus = "候補外のため省略";
        room.detailCaptureReason = "現在の条件では候補外と確定したため詳細取得を省略";
      }
      if (skippedIds.size) {
        await fs.writeFile(capturePath, `${JSON.stringify(data, null, 2)}\n`, "utf8");
      }
      resolve({
        ...result,
        timing: {
          mode: "target-details",
          elapsedMs: Date.now() - startedAt,
        },
        output: stdout.trim(),
        data,
      });
      completeCaptureProgress(data);
    });
  });
}

async function markSkippedRealproDetails(skippedIds) {
  const capturePath = path.join(DATA_DIR, "chrome_capture.json");
  const data = JSON.parse(await fs.readFile(capturePath, "utf8"));
  let skippedCount = 0;
  for (const room of data?.realpro?.rooms || []) {
    if (!skippedIds.has(String(room.realproRoomId || ""))) continue;
    room.detailCaptureStatus = "候補外のため省略";
    room.detailCaptureReason = "現在の条件では候補外と確定したため詳細取得を省略";
    skippedCount += 1;
  }
  await fs.writeFile(capturePath, `${JSON.stringify(data, null, 2)}\n`, "utf8");
  return {
    filename: "data/chrome_capture.json",
    requestedTargetCount: 0,
    targetCount: 0,
    updatedCount: 0,
    skippedCount,
    remainingUnknownWebAd: 0,
    remainingApplicationCountUnknown: 0,
    data,
  };
}

function runESeikatsuCacheCapture(url) {
  const eSeikatsuPages = clampPageCount(url.searchParams.get("eseikatsuPages") ?? url.searchParams.get("pages"), 1, 200, 1);
  const eSeikatsuPageSize = clampPageCount(url.searchParams.get("pageSize") ?? url.searchParams.get("eseikatsuPageSize"), 20, 200, 100);
  const eSeikatsuConcurrency = clampPageCount(url.searchParams.get("concurrency") ?? url.searchParams.get("eseikatsuConcurrency"), 1, 10, 5);
  if (url.searchParams.get("restart") === "1") stopActiveESeikatsuCacheCapture();
  if (activeESeikatsuCacheCapture?.promise) return activeESeikatsuCacheCapture.promise;
  const operation = {
    child: null,
    promise: null,
    reject: null,
    cancelled: false,
  };
  const scriptPath = path.join(ROOT, "automation", "capture_chrome_mac.py");
  beginCaptureProgress({
    phase: "compare",
    label: "いい生活全件情報を取得中",
    totalPages: eSeikatsuPages,
    eSeikatsuTotalPages: eSeikatsuPages,
    currentPage: 0,
    eSeikatsuCurrentPage: 0,
    message: `いい生活全件を確認中です。0/${eSeikatsuPages}ページ`,
  });
  let operationPromise;
  operationPromise = new Promise((resolve, reject) => {
    operation.reject = reject;
    const startedAt = Date.now();
    const child = spawnCapturePython([
      scriptPath,
      "--eseikatsu-cache-json",
      "--eseikatsu-pages",
      String(eSeikatsuPages),
      "--eseikatsu-page-size",
      String(eSeikatsuPageSize),
      "--eseikatsu-concurrency",
      String(eSeikatsuConcurrency),
    ]);
    operation.child = child;
    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (chunk) => {
      const text = chunk.toString();
      stdout += text;
      updateCaptureProgressFromOutput(text);
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", (error) => {
      if (operation.cancelled) return;
      if (activeESeikatsuCacheCapture?.promise === operationPromise) activeESeikatsuCacheCapture = null;
      failCaptureProgress(error.message);
      reject(error);
    });
    child.on("close", async (code) => {
      if (operation.cancelled) return;
      try {
        if (code !== 0) {
          if (activeESeikatsuCacheCapture?.promise === operationPromise) activeESeikatsuCacheCapture = null;
          failCaptureProgress(stderr || stdout);
          reject(new Error((stderr || stdout || `いい生活全件キャッシュ更新に失敗しました。終了コード: ${code}`).trim()));
          return;
        }
        const jsonLine = stdout.trim().split(/\n+/).reverse().find((line) => line.trim().startsWith("{"));
        const cacheResult = JSON.parse(jsonLine || "{}");
        let data = {};
        try {
          data = JSON.parse(await fs.readFile(path.join(DATA_DIR, "chrome_capture.json"), "utf8"));
        } catch {
          data = {};
        }
        const merged = await mergeESeikatsuCache(data);
        await fs.writeFile(path.join(DATA_DIR, "chrome_capture.json"), `${JSON.stringify(merged.data, null, 2)}\n`, "utf8");
        completeCaptureProgress(merged.data);
        if (activeESeikatsuCacheCapture?.promise === operationPromise) activeESeikatsuCacheCapture = null;
        resolve({
          filename: "data/eseikatsu_full_cache.json",
          eSeikatsuPages,
          eSeikatsuPageSize,
          eSeikatsuConcurrency,
          cache: cacheResult,
          eSeikatsuCache: merged.eSeikatsuCache,
          data: merged.data,
          timing: {
            elapsedMs: Date.now() - startedAt,
            requestedPages: eSeikatsuPages,
            pageSize: eSeikatsuPageSize,
            concurrency: eSeikatsuConcurrency,
          },
          output: stdout.trim(),
        });
      } catch (error) {
        if (activeESeikatsuCacheCapture?.promise === operationPromise) activeESeikatsuCacheCapture = null;
        failCaptureProgress(error.message);
        reject(error);
      }
    });
  });
  operation.promise = operationPromise;
  activeESeikatsuCacheCapture = operation;
  return operationPromise;
}

function stopActiveESeikatsuCacheCapture() {
  const operation = activeESeikatsuCacheCapture;
  if (!operation) return;
  operation.cancelled = true;
  try {
    operation.child?.kill();
  } catch {
    // The process may already have exited.
  }
  operation.reject?.(new Error("いい生活全件取得を停止し、再検索を開始します。"));
  activeESeikatsuCacheCapture = null;
  failCaptureProgress("いい生活全件取得を停止し、再検索を開始します。");
}

async function mergeLatestCaptureWithESeikatsuCache() {
  const captureCandidates = ["extension_capture.json", "chrome_capture.json"];
  let capturePath = path.join(DATA_DIR, "chrome_capture.json");
  let data = {};
  for (const filename of captureCandidates) {
    const candidatePath = path.join(DATA_DIR, filename);
    try {
      data = JSON.parse(await fs.readFile(candidatePath, "utf8"));
      capturePath = candidatePath;
      break;
    } catch (error) {
      if (error?.code !== "ENOENT") throw error;
    }
  }

  const merged = await mergeESeikatsuCache(data);
  if (merged.eSeikatsuCache?.used) {
    await fs.mkdir(DATA_DIR, { recursive: true });
    await fs.writeFile(capturePath, `${JSON.stringify(merged.data, null, 2)}\n`, "utf8");
    const companionPath = path.join(DATA_DIR, capturePath.endsWith("extension_capture.json") ? "chrome_capture.json" : "extension_capture.json");
    await fs.writeFile(companionPath, `${JSON.stringify(merged.data, null, 2)}\n`, "utf8");
  }

  return {
    ok: Boolean(merged.eSeikatsuCache?.used),
    filename: capturePath.endsWith("extension_capture.json") ? "data/extension_capture.json" : "data/chrome_capture.json",
    eSeikatsuCache: merged.eSeikatsuCache,
    data: merged.data,
  };
}

async function runRealproChunkCapture(url) {
  const realproPages = clampPageCount(url.searchParams.get("realproPages") ?? url.searchParams.get("pages"), 1, 20, 10);
  const realproStartPage = clampPageCount(url.searchParams.get("realproStartPage") ?? url.searchParams.get("startPage"), 1, 10000, 1);
  const rawRealproTotalPages = url.searchParams.get("realproTotalPages");
  const realproTotalPages = rawRealproTotalPages == null || rawRealproTotalPages === ""
    ? 0
    : clampPageCount(rawRealproTotalPages, 1, 10000, 0);
  const reset = url.searchParams.has("reset") ? url.searchParams.get("reset") === "1" : realproStartPage === 1;
  url.searchParams.set("realproPages", String(realproPages));
  url.searchParams.set("realproStartPage", String(realproStartPage));
  url.searchParams.set("eseikatsuPages", url.searchParams.get("eseikatsuPages") || "1");
  url.searchParams.set("useESeikatsuCache", url.searchParams.get("useESeikatsuCache") || "1");
  url.searchParams.set("skipRealproDetails", "1");

  const result = await runChromeCapture(url);
  const merged = await mergeRealproChunk(result.data, {
    realproStartPage,
    realproPages,
    realproTotalPages,
    reset,
  });

  return {
    ...result,
    filename: "data/chrome_capture.json",
    data: merged.data,
    realproChunkCache: merged.cacheMeta,
  };
}

async function mergeRealproChunk(chunkData, options) {
  const cachePath = path.join(DATA_DIR, "realpro_chunk_cache.json");
  const chunkRooms = Array.isArray(chunkData?.realpro?.rooms) ? chunkData.realpro.rooms : [];
  const chunkPages = Array.isArray(chunkData?.realpro?.pageCaptures) ? chunkData.realpro.pageCaptures : [];
  let previous = null;
  if (!options.reset) {
    try {
      previous = JSON.parse(await fs.readFile(cachePath, "utf8"));
    } catch {
      previous = null;
    }
    if (previous && !realproChunkSessionMatches(previous.data, chunkData)) {
      previous = null;
    }
    if (!previous) {
      try {
        const currentData = JSON.parse(await fs.readFile(path.join(DATA_DIR, "chrome_capture.json"), "utf8"));
        const currentRooms = Array.isArray(currentData?.realpro?.rooms) ? currentData.realpro.rooms : [];
        const currentPages = Array.isArray(currentData?.realpro?.pageCaptures) ? currentData.realpro.pageCaptures : [];
        if ((currentRooms.length || currentPages.length) && realproChunkSessionMatches(currentData, chunkData)) {
          previous = {
            startedAt: currentData.capturedAt || new Date().toISOString(),
            chunks: [{
              startPage: Number(currentData?.realpro?.startPage || 1),
              pages: currentPages.length || 1,
              fetchedRooms: currentRooms.length,
              pageNumbers: currentPages.map((page) => page.pageNumber).filter(Boolean),
              capturedAt: currentData.capturedAt || new Date().toISOString(),
              source: "chrome_capture_fallback",
            }],
            data: currentData,
          };
        }
      } catch {
        previous = null;
      }
    }
  }

  const previousData = previous?.data || {};
  const previousRealpro = previousData.realpro || {};
  const mergedRooms = dedupeRooms([
    ...(Array.isArray(previousRealpro.rooms) ? previousRealpro.rooms : []),
    ...chunkRooms,
  ]);
  const mergedPageCaptures = mergePageCaptures([
    ...(Array.isArray(previousRealpro.pageCaptures) ? previousRealpro.pageCaptures : []),
    ...chunkPages,
  ]);
  const chunkESeikatsuRooms = Array.isArray(chunkData?.eSeikatsu?.rooms) ? chunkData.eSeikatsu.rooms : [];
  const previousESeikatsuRooms = Array.isArray(previousData?.eSeikatsu?.rooms) ? previousData.eSeikatsu.rooms : [];
  const preservePreviousESeikatsu = !options.reset && previousESeikatsuRooms.length > chunkESeikatsuRooms.length;
  const previousExpectedPagesRaw = Number(previousRealpro.chunkMeta?.expectedPages || 0);
  const previousMaxCapturedPage = Math.max(
    0,
    ...mergedPageCaptures.map((page) => Number(page?.pageNumber || 0)).filter(Number.isFinite),
  );
  const previousExpectedPages = previousExpectedPagesRaw >= previousMaxCapturedPage
    ? previousExpectedPagesRaw
    : 0;
  const latestCapturedPageNumbers = chunkPages
    .map((page) => Number(page?.pageNumber || 0))
    .filter((pageNumber) => Number.isFinite(pageNumber) && pageNumber > 0);
  const latestCapturedPages = new Set(latestCapturedPageNumbers).size;
  const endReached = latestCapturedPages < options.realproPages;
  const detectedLastPage = endReached
    ? Math.max(options.realproStartPage - 1, ...latestCapturedPageNumbers)
    : 0;
  const expectedPages = Number(
    detectedLastPage
    || options.realproTotalPages
    || previousExpectedPages
    || 0
  );
  const capturedPageNumbers = new Set(mergedPageCaptures.map((page) => Number(page?.pageNumber || 0)).filter(Boolean));
  const complete = Boolean(expectedPages && [...Array(expectedPages)].every((_, index) => capturedPageNumbers.has(index + 1)));

  const data = {
    ...chunkData,
    capturedAt: new Date().toISOString(),
    meta: {
      ...(chunkData.meta || {}),
      realproCapturedAt: chunkData.meta?.realproCapturedAt || chunkData.capturedAt || new Date().toISOString(),
    },
    eSeikatsu: preservePreviousESeikatsu ? previousData.eSeikatsu : chunkData.eSeikatsu,
    realpro: {
      ...(chunkData.realpro || {}),
      rooms: mergedRooms,
      pageCaptures: mergedPageCaptures,
      chunked: true,
      chunkMeta: {
        reset: options.reset,
        latestStartPage: options.realproStartPage,
        latestPages: options.realproPages,
        accumulatedRooms: mergedRooms.length,
        accumulatedPages: mergedPageCaptures.length,
        expectedPages,
        endReached,
        detectedLastPage,
        complete,
      },
    },
  };

  const cache = {
    startedAt: options.reset ? data.capturedAt : previous?.startedAt || data.capturedAt,
    updatedAt: data.capturedAt,
    chunks: [
      ...(options.reset ? [] : Array.isArray(previous?.chunks) ? previous.chunks : []),
      {
        startPage: options.realproStartPage,
        pages: options.realproPages,
        fetchedRooms: chunkRooms.length,
        pageNumbers: chunkPages.map((page) => page.pageNumber).filter(Boolean),
        capturedAt: chunkData.capturedAt || data.capturedAt,
      },
    ],
    data,
  };

  await fs.writeFile(cachePath, `${JSON.stringify(cache, null, 2)}\n`, "utf8");
  await fs.writeFile(path.join(DATA_DIR, "chrome_capture.json"), `${JSON.stringify(data, null, 2)}\n`, "utf8");

  return {
    data,
    cacheMeta: {
      filename: "data/realpro_chunk_cache.json",
      reset: options.reset,
      latestStartPage: options.realproStartPage,
      latestPages: options.realproPages,
      latestFetchedRooms: chunkRooms.length,
      accumulatedRooms: mergedRooms.length,
      accumulatedPages: mergedPageCaptures.length,
      expectedPages,
      endReached,
      detectedLastPage,
      complete,
      chunks: cache.chunks.length,
    },
  };
}

function realproChunkSessionMatches(previousData = {}, nextData = {}) {
  const previousCriteria = normalizeCriteriaJson(previousData?.meta?.criteriaJson ?? previousData?.realpro?.criteriaJson ?? "");
  const nextCriteria = normalizeCriteriaJson(nextData?.meta?.criteriaJson ?? nextData?.realpro?.criteriaJson ?? "");
  if (previousCriteria && nextCriteria && previousCriteria !== nextCriteria) return false;

  const previousDate = localDateKey(previousData?.meta?.realproCapturedAt ?? previousData?.capturedAt);
  const nextDate = localDateKey(nextData?.meta?.realproCapturedAt ?? nextData?.capturedAt);
  return Boolean(previousDate && nextDate && previousDate === nextDate);
}

function localDateKey(value) {
  const date = new Date(value || "");
  if (Number.isNaN(date.getTime())) return "";
  return [date.getFullYear(), String(date.getMonth() + 1).padStart(2, "0"), String(date.getDate()).padStart(2, "0")].join("-");
}

function dedupeRooms(rooms) {
  const deduped = new Map();
  for (const room of rooms) {
    const key = roomIdentityKey(room);
    if (!deduped.has(key)) deduped.set(key, room);
  }
  return [...deduped.values()];
}

function roomIdentityKey(room) {
  const realproRoomId = String(room?.realproRoomId || room?.roomId || "").trim();
  if (realproRoomId) return `id:${realproRoomId}`;
  return [
    room?.building,
    room?.room,
    room?.layout,
    room?.rent,
    room?.address,
  ].map((value) => String(value || "").replace(/\s+/g, "")).join("|");
}

function mergePageCaptures(pageCaptures) {
  const merged = new Map();
  for (const page of pageCaptures) {
    const normalized = normalizeRealproPageCapture(page);
    if (isInvalidRealproPageCapture(normalized)) continue;
    const pageNumber = Number(normalized?.pageNumber);
    const key = Number.isFinite(pageNumber) && pageNumber > 0 ? String(pageNumber) : String(merged.size + 1);
    const current = merged.get(key);
    merged.set(key, betterPageCapture(current, normalized));
  }
  return [...merged.values()].sort((a, b) => Number(a.pageNumber || 0) - Number(b.pageNumber || 0));
}

function isInvalidRealproPageCapture(page = {}) {
  const urlValue = String(page.url || "");
  if (urlValue.includes("realnetpro.com/index.php") && Number(page.roomCount || 0) <= 0) return true;
  if (!urlValue.includes("realnetpro.com/main.php") && Number(page.roomCount || 0) <= 0) return true;
  return false;
}

function normalizeRealproPageCapture(page = {}) {
  const urlPageNumber = extractPageNumberFromUrl(page.url);
  const pageNumber = urlPageNumber || Number(page.pageNumber) || 0;
  return {
    ...page,
    pageNumber,
    pageNumberSource: urlPageNumber ? "url" : page.pageNumberSource || "capture",
  };
}

function extractPageNumberFromUrl(urlValue = "") {
  try {
    const parsed = new URL(String(urlValue));
    const pageNumber = Number(parsed.searchParams.get("page"));
    return Number.isFinite(pageNumber) && pageNumber > 0 ? pageNumber + 1 : 0;
  } catch {
    const match = String(urlValue).match(/[?&]page=(\d+)/);
    const pageNumber = Number(match?.[1]);
    return Number.isFinite(pageNumber) && pageNumber > 0 ? pageNumber + 1 : 0;
  }
}

function betterPageCapture(current, incoming) {
  if (!current) return incoming;
  const currentScore = pageCaptureScore(current);
  const incomingScore = pageCaptureScore(incoming);
  return incomingScore >= currentScore ? incoming : current;
}

function pageCaptureScore(page = {}) {
  return [
    Number(page.roomCount) > 0 ? 8 : 0,
    Number(page.textLength) > 0 ? 4 : 0,
    Number(page.lineCount) > 0 ? 2 : 0,
    page.url ? 1 : 0,
  ].reduce((sum, value) => sum + value, 0);
}

async function mergeESeikatsuCache(data, options = {}) {
  const cachePath = path.join(DATA_DIR, "eseikatsu_full_cache.json");
  try {
    const cache = JSON.parse(await fs.readFile(cachePath, "utf8"));
    const meta = cache.meta || {};
    if (!meta.isFull || !cache.eSeikatsu || !Array.isArray(cache.eSeikatsu.rooms)) {
      return {
        data,
        eSeikatsuCache: {
          used: false,
          reason: "いい生活全件キャッシュが未完成です。",
          filename: "data/eseikatsu_full_cache.json",
          meta,
        },
      };
    }

    const cacheAgeMs = Date.now() - new Date(cache.capturedAt).getTime();
    if (Number.isFinite(cacheAgeMs) && cacheAgeMs >= 0 && cacheAgeMs <= 10 * 60 * 1000) {
      const mergedData = {
        ...data,
        eSeikatsu: {
          ...(data.eSeikatsu || {}),
          ...cache.eSeikatsu,
          source: "full-cache",
        },
        eSeikatsuCache: {
          used: true,
          filename: "data/eseikatsu_full_cache.json",
          capturedAt: cache.capturedAt,
          totalMismatchWarning: "いい生活全件キャッシュ作成直後のため、現在総件数の再確認を省略して使用します。",
          meta: {
            ...meta,
            currentTotalCount: meta.totalCount,
            currentRequiredPages: meta.requiredPages,
            totalDiff: 0,
          },
        },
      };
      return {
        data: mergedData,
        eSeikatsuCache: mergedData.eSeikatsuCache,
      };
    }

    if (options.refreshStale === false) {
      return {
        data,
        eSeikatsuCache: {
          used: false,
          reason: "いい生活全件確認中です。",
          filename: "data/eseikatsu_full_cache.json",
          capturedAt: cache.capturedAt,
          meta: {
            ...meta,
            currentTotalCount: meta.totalCount || 0,
            currentRequiredPages: meta.requiredPages || 0,
          },
        },
      };
    }

    let currentTotalStatus = null;
    try {
      currentTotalStatus = await buildESeikatsuTotalStatus();
    } catch (error) {
      if (isSameLocalDate(cache.capturedAt, new Date())) {
        const mergedData = {
          ...data,
          eSeikatsu: {
            ...(data.eSeikatsu || {}),
            ...cache.eSeikatsu,
            source: "full-cache",
          },
          eSeikatsuCache: {
            used: true,
            filename: "data/eseikatsu_full_cache.json",
            capturedAt: cache.capturedAt,
            totalMismatchWarning: `いい生活の現在総件数を確認できませんでした。同日作成の全件キャッシュ${meta.fetchedCount || cache.eSeikatsu.rooms.length}件を使用します。作業前に必要なら全件キャッシュ作成をやり直してください。${error.message ? ` (${error.message})` : ""}`,
            meta: {
              ...meta,
              currentTotalCount: 0,
              currentRequiredPages: 0,
              totalDiff: 0,
            },
          },
        };
        return {
          data: mergedData,
          eSeikatsuCache: mergedData.eSeikatsuCache,
        };
      }
      return {
        data,
        eSeikatsuCache: {
          used: false,
          reason: `いい生活の現在総件数を確認できませんでした。全件キャッシュを作り直してください。${error.message ? ` (${error.message})` : ""}`,
          filename: "data/eseikatsu_full_cache.json",
          capturedAt: cache.capturedAt,
          meta,
        },
      };
    }

    const currentTotalCount = Number(currentTotalStatus.totalCount || 0);
    const cachedTotalCount = Number(meta.totalCount || 0);
    const cachedFetchedCount = Number(meta.fetchedCount || 0);
    const pageSize = Math.max(Number(meta.pageSize || 0), Number(currentTotalStatus.pageSize || 0), 20);
    const canCompareCurrentTotal = currentTotalCount > 0;
    const totalDiff = canCompareCurrentTotal ? Math.abs(currentTotalCount - cachedTotalCount) : 0;
    const isSameDayCache = isSameLocalDate(cache.capturedAt, new Date());
    const isClearlyStale = !isSameDayCache || (canCompareCurrentTotal && (currentTotalCount > cachedFetchedCount + pageSize || totalDiff > pageSize));
    if (isClearlyStale) {
      return {
        data,
        eSeikatsuCache: {
          used: false,
          reason: `いい生活の現在総件数が大きく変わっています。保存済み${meta.totalCount || "不明"}件 / 取得済み${meta.fetchedCount || "不明"}件 / 現在${currentTotalStatus.totalCount || "不明"}件。全件キャッシュを作り直してください。`,
          filename: "data/eseikatsu_full_cache.json",
          capturedAt: cache.capturedAt,
          meta: {
            ...meta,
            currentTotalCount: currentTotalStatus.totalCount,
            currentRequiredPages: currentTotalStatus.requiredPages,
            totalDiff,
          },
        },
      };
    }

    const mergedData = {
      ...data,
      eSeikatsu: {
        ...(data.eSeikatsu || {}),
        ...cache.eSeikatsu,
        source: "full-cache",
      },
      eSeikatsuCache: {
        used: true,
        filename: "data/eseikatsu_full_cache.json",
        capturedAt: cache.capturedAt,
        totalMismatchWarning: !canCompareCurrentTotal
          ? "いい生活の現在総件数を確認できませんでした。同日作成の全件キャッシュとして使用します。作業前に必要なら全件キャッシュ作成をやり直してください。"
          : totalDiff
          ? `いい生活の現在総件数とキャッシュ作成時の件数に差があります。保存済み${cachedTotalCount}件 / 現在${currentTotalCount}件。同日・1ページ以内の差としてキャッシュを使用します。`
          : "",
        meta: {
          ...meta,
          currentTotalCount,
          currentRequiredPages: currentTotalStatus.requiredPages,
          totalDiff,
        },
      },
    };

    return {
      data: mergedData,
      eSeikatsuCache: mergedData.eSeikatsuCache,
    };
  } catch (error) {
    return {
      data,
      eSeikatsuCache: {
        used: false,
        reason: "いい生活全件キャッシュが見つかりません。",
        filename: "data/eseikatsu_full_cache.json",
      },
    };
  }
}

function isSameLocalDate(value, reference) {
  const date = new Date(value);
  const base = reference instanceof Date ? reference : new Date(reference);
  if (Number.isNaN(date.getTime()) || Number.isNaN(base.getTime())) return false;
  return japaneseDateKey(date) === japaneseDateKey(base);
}

function japaneseDateKey(date) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

function buildChromeTabStatus() {
  const scriptPath = path.join(ROOT, "automation", "capture_chrome_mac.py");
  return new Promise((resolve, reject) => {
    const child = spawnCapturePython([scriptPath, "--tabs-json"]);
    let stdout = "";
    let stderr = "";
    let settled = false;
    const timeout = setTimeout(() => {
      if (settled) return;
      settled = true;
      child.kill();
      reject(new Error("Chromeタブ確認がタイムアウトしました。専用Chromeと通信ブリッジを確認してください。"));
    }, 8000);

    child.stdout.on("data", (chunk) => {
      stdout += chunk;
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      reject(error);
    });
    child.on("close", (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      if (code !== 0) {
        reject(new Error((stderr || stdout || `Chromeタブ確認に失敗しました。終了コード: ${code}`).trim()));
        return;
      }
      const rawStatus = parseLastJsonLine(stdout);
      resolve(sanitizeChromeTabStatus(rawStatus));
    });
  });
}

function buildESeikatsuTotalStatus(url = new URL("http://127.0.0.1/")) {
  const pageSize = clampPageCount(url.searchParams.get("pageSize") ?? url.searchParams.get("eseikatsuPageSize"), 20, 200, 100);
  const concurrency = clampPageCount(url.searchParams.get("concurrency") ?? url.searchParams.get("eseikatsuConcurrency"), 1, 10, 5);
  const scriptPath = path.join(ROOT, "automation", "capture_chrome_mac.py");
  return new Promise((resolve, reject) => {
    const child = spawnCapturePython([
      scriptPath,
      "--eseikatsu-total-json",
      "--eseikatsu-page-size",
      String(pageSize),
      "--eseikatsu-concurrency",
      String(concurrency),
    ]);
    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (chunk) => {
      stdout += chunk;
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code !== 0) {
        reject(new Error((stderr || stdout || `いい生活全体確認に失敗しました。終了コード: ${code}`).trim()));
        return;
      }
      const rawStatus = parseLastJsonLine(stdout);
      resolve({
        ok: Boolean(rawStatus.totalCount),
        index: rawStatus.index,
        title: String(rawStatus.title || "").slice(0, 80),
        host: "rent.e-bukken.app",
        totalCount: Number(rawStatus.totalCount || 0),
        itemCount: Number(rawStatus.itemCount || 0),
        pageSize: Number(rawStatus.pageSize || 20),
        requestedPageSize: Number(rawStatus.requestedPageSize || pageSize),
        concurrency: Number(rawStatus.concurrency || concurrency),
        requiredPages: Number(rawStatus.requiredPages || 0),
        apiError: rawStatus.apiError || "",
        summary: rawStatus.totalCount
          ? `いい生活全体: 全${rawStatus.totalCount}件 / 1ページ${rawStatus.pageSize || 20}件 / 必要${rawStatus.requiredPages}ページ`
          : "いい生活全体件数を確認できませんでした。",
      });
    });
  });
}

function buildESeikatsuCache(url) {
  const pages = clampPageCount(url.searchParams.get("pages"), 1, 200, 1);
  const pageSize = clampPageCount(url.searchParams.get("pageSize") ?? url.searchParams.get("eseikatsuPageSize"), 20, 200, 100);
  const concurrency = clampPageCount(url.searchParams.get("concurrency") ?? url.searchParams.get("eseikatsuConcurrency"), 1, 10, 5);
  const scriptPath = path.join(ROOT, "automation", "capture_chrome_mac.py");
  return new Promise((resolve, reject) => {
    const startedAt = Date.now();
    const child = spawnCapturePython([
      scriptPath,
      "--eseikatsu-cache-json",
      "--eseikatsu-pages",
      String(pages),
      "--eseikatsu-page-size",
      String(pageSize),
      "--eseikatsu-concurrency",
      String(concurrency),
    ]);
    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (chunk) => {
      const text = chunk.toString();
      stdout += text;
      updateCaptureProgressFromOutput(text);
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code !== 0) {
        reject(new Error((stderr || stdout || `いい生活全体キャッシュ取得に失敗しました。終了コード: ${code}`).trim()));
        return;
      }
      const jsonLine = stdout.trim().split(/\n+/).reverse().find((line) => line.trim().startsWith("{"));
      resolve({
        ...JSON.parse(jsonLine || "{}"),
        timing: {
          elapsedMs: Date.now() - startedAt,
          requestedPages: pages,
          pageSize,
          concurrency,
        },
      });
    });
  });
}

async function ensureRealproTabForConditions() {
  const status = await buildChromeTabStatus();
  const hasRealproTab = status.tabs.some((tab) => (
    tab.host === "www.realnetpro.com" || tab.host === "realnetpro.com"
  ));
  const hasESeikatsuTab = Boolean(status.eSeikatsuList);
  if (!hasRealproTab || !hasESeikatsuTab) {
    const error = new Error("リアプロといい生活を立ち上げてから、もう一度「反映してリアプロ検索」を押してください。");
    error.code = "REQUIRED_CHROME_TABS";
    throw error;
  }
  return status;
}

async function applyRealproConditions(conditions) {
  await ensureRealproTabForConditions();
  const scriptPath = path.join(ROOT, "automation", "capture_chrome_mac.py");
  const encoded = Buffer.from(JSON.stringify(conditions || {}), "utf8").toString("base64");
  return new Promise((resolve, reject) => {
    const child = spawnCapturePython([scriptPath, "--apply-realpro-conditions-json", encoded]);
    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (chunk) => {
      stdout += chunk;
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code !== 0) {
        reject(new Error((stderr || stdout || `リアプロ検索条件の反映に失敗しました。終了コード: ${code}`).trim()));
        return;
      }
      resolve(parseLastJsonLine(stdout));
    });
  });
}

async function openRealproInDedicatedChrome() {
  const response = await fetch("http://127.0.0.1:9223/navigate", {
    method: "POST",
    headers: { "Content-Type": "application/json; charset=utf-8" },
    body: JSON.stringify({ url: "https://www.realnetpro.com/" }),
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.detail || payload.error || `Chrome bridge HTTP ${response.status}`);
  return { ok: true, ...payload };
}

async function openServiceInDedicatedChrome(service) {
  const definitions = {
    realpro: {
      url: "https://www.realnetpro.com/",
      matches: (url) => /(^|\.)realnetpro\.com$/i.test(safeHost(url)),
    },
    eSeikatsu: {
      url: "https://rent.e-bukken.app/login",
      matches: (url) => safeHost(url) === "rent.e-bukken.app",
    },
  };
  const definition = definitions[String(service || "")];
  if (!definition) throw new Error("開くサービスが指定されていません。");
  const tabsResponse = await fetch("http://127.0.0.1:9223/tabs", { signal: AbortSignal.timeout(5000) });
  if (!tabsResponse.ok) throw new Error(`Chrome bridge HTTP ${tabsResponse.status}`);
  const tabsPayload = await tabsResponse.json();
  const existing = (tabsPayload.tabs || []).find((tab) => definition.matches(String(tab.url || "")));
  if (existing) {
    const response = await fetch("http://127.0.0.1:9223/activate", {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify({ index: existing.index }),
      signal: AbortSignal.timeout(5000),
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.detail || payload.error || `Chrome bridge HTTP ${response.status}`);
    return { ok: true, reused: true, service, ...payload };
  }
  const response = await fetch("http://127.0.0.1:9223/new", {
    method: "POST",
    headers: { "Content-Type": "application/json; charset=utf-8" },
    body: JSON.stringify({ url: definition.url }),
    signal: AbortSignal.timeout(5000),
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.detail || payload.error || `Chrome bridge HTTP ${response.status}`);
  return { ok: true, reused: false, service, ...payload };
}

async function reloadServiceInDedicatedChrome(service) {
  const definitions = {
    realpro: {
      matches: (url) => /(^|\.)realnetpro\.com$/i.test(safeHost(url)),
    },
    eSeikatsu: {
      matches: (url) => safeHost(url) === "rent.e-bukken.app",
    },
  };
  const definition = definitions[String(service || "")];
  if (!definition) throw new Error("再読み込みするサービスが指定されていません。");
  const tabsResponse = await fetch("http://127.0.0.1:9223/tabs", { signal: AbortSignal.timeout(5000) });
  if (!tabsResponse.ok) throw new Error(`Chrome bridge HTTP ${tabsResponse.status}`);
  const tabsPayload = await tabsResponse.json();
  const existing = (tabsPayload.tabs || []).find((tab) => definition.matches(String(tab.url || "")));
  if (!existing) throw new Error("専用Chromeに対象タブがありません。サービス画面を開いてログインしてください。");
  const response = await fetch("http://127.0.0.1:9223/navigate", {
    method: "POST",
    headers: { "Content-Type": "application/json; charset=utf-8" },
    body: JSON.stringify({ index: existing.index, url: existing.url }),
    signal: AbortSignal.timeout(10000),
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.detail || payload.error || `Chrome bridge HTTP ${response.status}`);
  return { ok: true, reloaded: true, service, index: existing.index, url: existing.url, ...payload };
}

function sanitizeChromeTabStatus(status) {
  const tabs = Array.isArray(status.tabs) ? status.tabs : [];
  const sanitizedTabs = tabs.map((tab) => {
    const url = String(tab.url || "");
    const host = safeHost(url);
    return {
      index: tab.index,
      title: String(tab.title || "").slice(0, 80),
      host,
      kind: classifyChromeTab(url),
    };
  });
  const realproList = sanitizedTabs.find((tab) => tab.index === status.suggestedRealpro) ?? null;
  const eSeikatsuList = sanitizedTabs.find((tab) => tab.index === status.suggestedESeikatsu) ?? null;
  const systemTab = sanitizedTabs.find((tab) => tab.kind === "システム画面") ?? null;
  const realproDetails = sanitizedTabs.filter((tab) => Array.isArray(status.suggestedDetails) && status.suggestedDetails.includes(tab.index));
  return {
    ok: Boolean(realproList && eSeikatsuList),
    tabs: sanitizedTabs,
    systemTab,
    realproList,
    eSeikatsuList,
    realproDetails,
    summary: chromeTabSummary(realproList, eSeikatsuList, realproDetails, sanitizedTabs),
  };
}

function safeHost(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return "";
  }
}

function classifyChromeTab(url) {
  if (/^https?:\/\/127\.0\.0\.1:\d+\/(?:index\.html)?(?:[?#].*)?$/.test(url)) return "システム画面";
  if (url.includes("realnetpro.com") && url.includes("room_detail.php")) return "リアプロ詳細";
  if (url.includes("realnetpro.com") && url.includes("method=estate")) return "リアプロ一覧";
  if (url.includes("realnetpro.com")) return "リアプロ検索前";
  if (url.includes("rent.e-bukken.app")) return "いい生活 物件一覧/広告";
  if (url.includes("sfa.e-bukken.app")) return "いい生活 営業支援/追客 対象外";
  if (url.includes("e-bukken.app")) return "いい生活 対象外";
  return "その他";
}

function chromeTabSummary(realproList, eSeikatsuList, realproDetails, tabs) {
  const warnings = [];
  if (!realproList) warnings.push("リアプロ一覧タブなし");
  if (!eSeikatsuList) warnings.push("いい生活の物件一覧/広告タブなし");
  const sfaTabs = tabs.filter((tab) => tab.kind === "いい生活 営業支援/追客 対象外");
  const realproStartTabs = tabs.filter((tab) => tab.kind === "リアプロ検索前");
  if (realproStartTabs.length && !realproList) warnings.push("リアプロはリスト検索の検索結果画面を開いてください");
  if (sfaTabs.length && !eSeikatsuList) warnings.push("営業支援/追客画面は取得対象外");
  if (warnings.length) return `注意: ${warnings.join(" / ")}`;
  return `OK: リアプロ一覧 ${realproList.index}番 / いい生活 ${eSeikatsuList.index}番 / リアプロ詳細 ${realproDetails.length}件`;
}

function clampPageCount(value, min, max, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(Math.max(Math.trunc(number), min), max);
}

function normalizeCriteriaJson(value) {
  if (value == null) return "";
  if (typeof value !== "string") return JSON.stringify(value);
  const text = value.trim();
  if (!text) return "";
  try {
    const parsed = JSON.parse(text);
    return typeof parsed === "string" ? normalizeCriteriaJson(parsed) : JSON.stringify(parsed);
  } catch {
    return text;
  }
}

function resolveFilePath(urlPath) {
  const decodedPath = decodeURIComponent(urlPath);
  if (decodedPath === "/" || decodedPath === "/index.html") return path.join(SRC_DIR, "index.html");
  if (decodedPath === "/README.md") return path.join(ROOT, "README.md");
  if (decodedPath.startsWith("/data/")) return safeJoin(DATA_DIR, decodedPath.replace(/^\/data\//, ""));
  if (decodedPath.startsWith("/docs/")) return safeJoin(DOCS_DIR, decodedPath.replace(/^\/docs\//, ""));
  if (decodedPath.startsWith("/exports/")) return safeJoin(EXPORTS_DIR, decodedPath.replace(/^\/exports\//, ""));
  return safeJoin(SRC_DIR, decodedPath.replace(/^\//, ""));
}

function safeJoin(baseDir, relativePath) {
  const filePath = path.resolve(baseDir, relativePath);
  if (!filePath.startsWith(baseDir)) {
    throw Object.assign(new Error("Forbidden"), { code: "EACCES" });
  }
  return filePath;
}

startServer(PORT);

function startServer(port) {
  PORT = port;
  server.removeAllListeners("listening");
  server.once("listening", () => {
    const appUrl = `http://127.0.0.1:${PORT}/index.html`;
    console.log(`物件候補リスト作成システム: ${appUrl}`);
    if (process.env.OPEN_BROWSER === "1") {
      openBrowser(appUrl);
    }
  });
  server.listen(PORT, "127.0.0.1");
}

function handleServerError(error) {
  if (error.code === "EADDRINUSE" && !PORT_WAS_EXPLICIT && PORT < REQUESTED_PORT + 10) {
    const nextPort = PORT + 1;
    console.error(`ポート ${PORT} は使用中です。${nextPort} を試します。`);
    startServer(nextPort);
    return;
  }

  if (error.code === "EADDRINUSE") {
    console.error(`ポート ${PORT} は既に使用中です。既に起動している場合は http://127.0.0.1:${PORT}/index.html を開いてください。`);
    process.exit(1);
  }

  throw error;
}

function openBrowser(url) {
  if (process.platform === "win32") {
    openWindowsDedicatedBrowser(url);
    return;
  }
  const command = process.platform === "darwin"
    ? "open"
    : "xdg-open";
  const args = [url];
  spawn(command, args, {
    detached: true,
    stdio: "ignore",
  }).unref();
}

async function openWindowsDedicatedBrowser(url) {
  try {
    const tabsResponse = await fetch("http://127.0.0.1:9223/tabs");
    const tabsPayload = await tabsResponse.json();
    const existingApp = (tabsPayload.tabs || []).find((tab) => /^http:\/\/127\.0\.0\.1:\d+\/(?:index\.html)?/.test(String(tab.url || "")));
    const blankTab = (tabsPayload.tabs || []).find((tab) => String(tab.url || "") === "chrome://newtab/");
    const target = existingApp || blankTab;
    const endpoint = target ? "navigate" : "new";
    const body = target ? { index: target.index, url } : { url };
    const response = await fetch(`http://127.0.0.1:9223/${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify(body),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(payload.detail || payload.error || `Chrome bridge HTTP ${response.status}`);
    }
    console.log(`専用Chromeでシステム画面を開きました: ${url}`);
  } catch (error) {
    console.error(`専用Chromeへシステム画面を開けませんでした: ${error.message}`);
  }
}

server.on("error", handleServerError);
