# Chrome policy installation

This Windows package installs the extension through Chrome's per-user force-install policy. Chrome requires Windows devices to be managed by an organization for force-installation of extensions hosted outside the Chrome Web Store.

- The extension ID is fixed: `fnmkfpkhmnjhmkibiddnfoijigfmcoof`.
- The installer writes `HKCU\Software\Policies\Google\Chrome\ExtensionInstallForcelist`.
- The policy points to `extension-updates.xml`.
- Chrome downloads the CRX from that update manifest and checks for newer versions automatically on managed devices.
- On an unmanaged Windows device, publish the extension through the Chrome Web Store or enroll the device in Chrome management before installing this package.

The unpacked extension folder is included in the application for development and diagnostics; normal startup does not use `--load-extension`.

## Publishing an extension update

1. Keep the same signing key PEM.
2. Increase the extension version in `extension/manifest.json` and `extension/background.js`.
3. Run `npm run build:extension-package -- --key=C:\path\to\property-list-automation-extension.pem`.
4. Publish the generated CRX and `extension-updates.xml` at the URLs configured in the script.

Changing the signing key creates a different extension ID and requires a new policy registration.
