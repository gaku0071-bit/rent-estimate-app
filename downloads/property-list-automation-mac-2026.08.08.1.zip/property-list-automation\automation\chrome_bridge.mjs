import http from "node:http";

const HOST = process.env.CHROME_BRIDGE_HOST || "127.0.0.1";
const PORT = Number(process.env.CHROME_BRIDGE_PORT || 9223);
const CDP_URL = process.env.CHROME_CDP_URL || "http://127.0.0.1:9222";

let selectedTarget = null;

function resetBrowserConnection() {
  selectedTarget = null;
}

async function cdpTargets() {
  const response = await fetch(`${CDP_URL}/json/list`);
  if (!response.ok) throw new Error(`Chrome target list failed: HTTP ${response.status}`);
  const targets = await response.json();
  return targets.filter((target) => target.type === "page" && target.webSocketDebuggerUrl);
}

async function createTarget(url) {
  const response = await fetch(`${CDP_URL}/json/new?${encodeURIComponent(url)}`, { method: "PUT" });
  if (!response.ok) throw new Error(`Chrome new tab failed: HTTP ${response.status}`);
  const target = await response.json();
  if (target.type !== "page" || !target.webSocketDebuggerUrl) throw new Error("Chrome did not return a usable page tab.");
  return target;
}

function cdpRequest(target, method, params = {}) {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(target.webSocketDebuggerUrl);
    const requestId = 1;
    const timer = setTimeout(() => {
      try { socket.close(); } catch {}
      reject(new Error(`Chrome CDP request timed out: ${method}`));
    }, 30_000);
    const finish = (error, value) => {
      clearTimeout(timer);
      try { socket.close(); } catch {}
      if (error) reject(error);
      else resolve(value);
    };
    socket.addEventListener("open", () => {
      socket.send(JSON.stringify({ id: requestId, method, params }));
    });
    socket.addEventListener("message", (event) => {
      let message;
      try {
        message = JSON.parse(String(event.data));
      } catch (error) {
        finish(error);
        return;
      }
      if (message.id !== requestId) return;
      if (message.error) {
        finish(new Error(message.error.message || `Chrome CDP request failed: ${method}`));
        return;
      }
      finish(null, message.result || {});
    });
    socket.addEventListener("error", () => {
      finish(new Error(`Chrome CDP connection failed: ${method}`));
    });
  });
}

async function tabsPayload() {
  const openTargets = await cdpTargets();
  if (!selectedTarget || !openTargets.some((target) => target.id === selectedTarget.id)) {
    selectedTarget = openTargets[0] || null;
  }
  const tabs = openTargets.map((target, offset) => ({
    index: offset + 1,
    title: target.title || "",
    url: target.url || "",
  }));
  return {
    tabs,
    activeIndex: selectedTarget ? openTargets.findIndex((target) => target.id === selectedTarget.id) + 1 : null,
  };
}

async function activate(index) {
  const openTargets = await cdpTargets();
  const target = openTargets[Number(index) - 1];
  if (!target) throw new Error(`Chrome tab ${index} was not found.`);
  selectedTarget = target;
  await cdpRequest(target, "Page.bringToFront");
  return { activeIndex: Number(index), url: target.url || "" };
}

async function navigate(index, targetUrl) {
  const openTargets = await cdpTargets();
  const url = new URL(String(targetUrl || ""));
  if (!/^https?:$/.test(url.protocol)) throw new Error("Only HTTP(S) URLs can be opened in the dedicated Chrome.");
  const target = openTargets[Number(index || 1) - 1] || selectedTarget || openTargets[0] || await createTarget(url.href);
  selectedTarget = target;
  const result = target.url === url.href
    ? {}
    : await cdpRequest(target, "Page.navigate", { url: url.href });
  await cdpRequest(target, "Page.bringToFront");
  if (result.errorText) throw new Error(result.errorText);
  const activeIndex = (await cdpTargets()).findIndex((item) => item.id === target.id) + 1;
  return { activeIndex: activeIndex > 0 ? activeIndex : null, url: url.href };
}

async function openNewTab(targetUrl) {
  const url = new URL(String(targetUrl || ""));
  if (!/^https?:$/.test(url.protocol)) throw new Error("Only HTTP(S) URLs can be opened in the dedicated Chrome.");
  const target = await createTarget(url.href);
  selectedTarget = target;
  await cdpRequest(target, "Page.bringToFront");
  const activeIndex = (await cdpTargets()).findIndex((item) => item.id === target.id) + 1;
  return { activeIndex: activeIndex > 0 ? activeIndex : null, url: url.href };
}

async function prepareServiceTabs({ systemUrl = "", realproUrl = "https://www.realnetpro.com/", eSeikatsuUrl = "https://rent.e-bukken.app/login" } = {}) {
  let openTargets = await cdpTargets();
  const created = [];
  const ensureTarget = async (role, targetUrl, predicate) => {
    if (!targetUrl) return null;
    let target = openTargets.find(predicate);
    if (!target) {
      target = await createTarget(targetUrl);
      openTargets = [...openTargets, target];
      created.push(role);
    }
    return target;
  };

  await ensureTarget("system", systemUrl, (target) => /^https?:\/\/127\.0\.0\.1:\d+\/(?:index\.html)?(?:[?#].*)?$/.test(target.url || ""));
  await ensureTarget("realpro", realproUrl, (target) => /(^|\.)realnetpro\.com$/i.test(new URL(target.url || "about:blank").hostname));
  await ensureTarget("eSeikatsu", eSeikatsuUrl, (target) => new URL(target.url || "about:blank").hostname === "rent.e-bukken.app");

  const systemTarget = openTargets.find((target) => /^https?:\/\/127\.0\.0\.1:\d+\/(?:index\.html)?(?:[?#].*)?$/.test(target.url || ""));
  if (systemTarget) {
    selectedTarget = systemTarget;
    await cdpRequest(systemTarget, "Page.bringToFront");
  }
  const refreshed = await cdpTargets();
  return {
    ok: true,
    created,
    tabs: refreshed.map((target, index) => ({ index: index + 1, title: target.title || "", url: target.url || "" })),
  };
}

async function evaluate(script) {
  const openTargets = await cdpTargets();
  if (!selectedTarget || !openTargets.some((target) => target.id === selectedTarget.id)) {
    selectedTarget = openTargets[0] || null;
  }
  if (!selectedTarget) throw new Error("No Chrome tab is open.");
  const result = await cdpRequest(selectedTarget, "Runtime.evaluate", {
    expression: `window.eval(${JSON.stringify(String(script || ""))})`,
    awaitPromise: true,
    returnByValue: true,
    userGesture: true,
  });
  if (result.exceptionDetails) {
    throw new Error(result.exceptionDetails.exception?.description || "Chrome script evaluation failed.");
  }
  const value = result.result?.value;
  if (value === undefined || value === null) return "";
  return typeof value === "string" ? value : JSON.stringify(value);
}

function sendJson(response, status, payload) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  response.end(JSON.stringify(payload));
}

async function readJson(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 5_000_000) throw new Error("Request body is too large.");
    chunks.push(chunk);
  }
  return chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {};
}

const server = http.createServer(async (request, response) => {
  try {
    const url = new URL(request.url || "/", `http://${request.headers.host}`);
    if (request.method === "GET" && url.pathname === "/status") {
      const payload = await tabsPayload();
      sendJson(response, 200, {
        ok: true,
        cdpUrl: CDP_URL,
        tabCount: payload.tabs.length,
        activeIndex: payload.activeIndex,
      });
      return;
    }
    if (request.method === "GET" && url.pathname === "/tabs") {
      sendJson(response, 200, await tabsPayload());
      return;
    }
    if (request.method === "POST" && url.pathname === "/reconnect") {
      resetBrowserConnection();
      const payload = await tabsPayload();
      sendJson(response, 200, {
        ok: true,
        cdpUrl: CDP_URL,
        tabCount: payload.tabs.length,
        activeIndex: payload.activeIndex,
      });
      return;
    }
    if (request.method === "POST" && url.pathname === "/activate") {
      const body = await readJson(request);
      sendJson(response, 200, await activate(body.index));
      return;
    }
    if (request.method === "POST" && url.pathname === "/navigate") {
      const body = await readJson(request);
      sendJson(response, 200, await navigate(body.index, body.url));
      return;
    }
    if (request.method === "POST" && url.pathname === "/new") {
      const body = await readJson(request);
      sendJson(response, 200, await openNewTab(body.url));
      return;
    }
    if (request.method === "POST" && url.pathname === "/prepare") {
      const body = await readJson(request);
      sendJson(response, 200, await prepareServiceTabs(body));
      return;
    }
    if (request.method === "POST" && url.pathname === "/eval") {
      const body = await readJson(request);
      sendJson(response, 200, { result: await evaluate(body.script) });
      return;
    }
    sendJson(response, 404, { error: "Not found" });
  } catch (error) {
    sendJson(response, 500, {
      error: "Chrome bridge error.",
      detail: error.message,
    });
  }
});

server.on("error", (error) => {
  console.error(error.message);
  process.exitCode = 1;
});

server.listen(PORT, HOST, () => {
  console.log(`Chrome bridge: http://${HOST}:${PORT} -> ${CDP_URL}`);
});
