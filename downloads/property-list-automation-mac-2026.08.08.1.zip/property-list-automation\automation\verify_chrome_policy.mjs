import fs from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const buildRoot = path.resolve(projectRoot, "..");
const extensionRoot = path.join(projectRoot, "extension");
const publicRoot = path.join(buildRoot, "public-update-files");
const installerPath = path.join(buildRoot, "installer", "windows", "property-list-automation.iss");

async function main() {
  const manifest = JSON.parse(await fs.readFile(path.join(extensionRoot, "manifest.json"), "utf8"));
  const extensionId = extensionIdFromPublicKey(manifest.key);
  const releasePath = path.join(publicRoot, "extension-release.json");
  const release = JSON.parse(await fs.readFile(releasePath, "utf8"));
  const crxPath = path.join(publicRoot, path.basename(new URL(release.crxUrl).pathname));
  const xml = await fs.readFile(path.join(publicRoot, "extension-updates.xml"), "utf8");
  const installer = await fs.readFile(installerPath, "utf8");
  const runWindows = await fs.readFile(path.join(projectRoot, "automation", "run_windows.ps1"), "utf8");
  const crx = await fs.readFile(crxPath);

  assert(extensionId === release.extensionId, "manifestと公開情報の拡張機能IDが一致しません。");
  assert(manifest.version === release.version, "manifestと公開情報のバージョンが一致しません。");
  assert(manifest.update_url === release.updateUrl, "manifestの更新URLが一致しません。");
  assert(crx.subarray(0, 4).toString("ascii") === "Cr24", "CRXヘッダーが不正です。");
  assert(await sha256File(crxPath) === release.sha256, "CRXのSHA-256が一致しません。");
  assert(xml.includes(`appid=\"${extensionId}\"`), "更新XMLに拡張機能IDがありません。");
  assert(xml.includes(`version=\"${release.version}\"`), "更新XMLにバージョンがありません。");
  assert(installer.includes("ExtensionInstallForcelist"), "インストーラーにChromeポリシー登録がありません。");
  assert(installer.includes(`#define ChromeExtensionId \"${extensionId}\"`), "インストーラーの拡張機能IDが一致しません。");
  assert(!runWindows.includes("--load-extension"), "専用Chromeが手動読み込み方式のままです。");

  console.log(JSON.stringify({
    ok: true,
    extensionId,
    version: release.version,
    crxSha256: release.sha256,
    policy: "HKCU\\Software\\Policies\\Google\\Chrome\\ExtensionInstallForcelist",
    checks: ["manifest", "CRX", "update XML", "installer policy", "startup flags"],
  }, null, 2));
}

function extensionIdFromPublicKey(publicKeyBase64) {
  const digest = createHash("sha256").update(Buffer.from(publicKeyBase64, "base64")).digest();
  const alphabet = "abcdefghijklmnop";
  return [...digest.subarray(0, 16)].map((byte) => alphabet[byte >> 4] + alphabet[byte & 15]).join("");
}

async function sha256File(filePath) {
  return createHash("sha256").update(await fs.readFile(filePath)).digest("hex");
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

main().catch((error) => {
  console.error(`Chromeポリシー構成確認 NG: ${error.message}`);
  process.exitCode = 1;
});
