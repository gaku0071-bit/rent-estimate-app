import fs from "node:fs/promises";
import { createReadStream } from "node:fs";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, "..");
const buildRoot = path.resolve(projectRoot, "..");
const distRoot = path.join(buildRoot, "dist");
const installerRoot = path.join(buildRoot, "installer");
const publicRoot = path.join(buildRoot, "public-update-files");

const skipDirectories = new Set([
  ".git",
  ".extension-package-work",
  ".idea",
  ".vscode",
  "backups",
  "data",
  "dist",
  "exports",
  "node_modules",
  "outputs",
  "staged",
]);

const skipFiles = new Set([
  ".DS_Store",
  "Thumbs.db",
  "desktop.ini",
  "server.log",
  "chrome-bridge-windows.log",
  "chrome-bridge-windows-error.log",
]);

async function main() {
  const appVersion = await readJson(path.join(projectRoot, "app-version.json"));
  const version = String(appVersion.version || "").trim();
  if (!version) throw new Error("app-version.jsonのversionが空です。");

  const manifest = await readJson(path.join(projectRoot, "extension", "manifest.json"));
  const extensionVersion = String(manifest.version || "").trim();
  if (!extensionVersion) throw new Error("extension/manifest.jsonのversionが空です。");

  const bundleName = `property-list-automation-windows-update-bundle-${version}`;
  const stageRoot = path.join(distRoot, bundleName);
  const zipPath = path.join(distRoot, `${bundleName}.zip`);

  await fs.rm(stageRoot, { recursive: true, force: true });
  await fs.rm(zipPath, { force: true });
  await fs.mkdir(stageRoot, { recursive: true });

  await copyDirectory(projectRoot, path.join(stageRoot, "property-list-automation"));
  await copyDirectory(installerRoot, path.join(stageRoot, "installer"));
  await copyDirectory(publicRoot, path.join(stageRoot, "public-update-files"));
  await fs.writeFile(path.join(stageRoot, "BUILD_WINDOWS_INSTALLER.bat"), buildInstallerBat(version), "utf8");

  const extensionZipPath = path.join(
    stageRoot,
    "extension-package",
    `property-list-automation-extension-${extensionVersion}.zip`
  );
  await createZipArchive(projectRoot, "extension", extensionZipPath);

  const exeName = `property-list-automation-windows-${version}.exe`;
  const exeSource = await findExistingFile([
    path.join(distRoot, exeName),
    path.join(publicRoot, exeName),
    path.join(distRoot, "releases", version, "downloads", exeName),
  ]);
  let exeInfo = null;
  if (exeSource) {
    const exeTarget = path.join(stageRoot, "windows-installer", exeName);
    await copyFileSafe(exeSource, exeTarget);
    exeInfo = {
      fileName: exeName,
      source: exeSource,
      sha256: await sha256File(exeTarget),
      size: (await fs.stat(exeTarget)).size,
    };
    await fs.writeFile(
      path.join(stageRoot, "windows-installer", "EXE_REBUILD_REQUIRED.txt"),
      "このEXEは公開済みの既存版です。拡張機能なし方針を反映するには、BUILD_WINDOWS_INSTALLER.batで再ビルドしてください。\n",
      "utf8"
    );
  } else {
    await fs.mkdir(path.join(stageRoot, "windows-installer"), { recursive: true });
    await fs.writeFile(
      path.join(stageRoot, "windows-installer", "EXE_NOT_INCLUDED.txt"),
      `Windows EXEはこの作業フォルダにありません。\n\n作成元: installer\\windows\\property-list-automation.iss\n作成後のファイル名: ${exeName}\n`,
      "utf8"
    );
  }

  const files = await listFiles(stageRoot);
  const inventory = {
    schemaVersion: 1,
    createdAt: new Date().toISOString(),
    appVersion: version,
    extensionVersion,
    extensionId: String(manifest.key || "").trim() ? extensionIdFromPublicKey(manifest.key) : "",
    exe: exeInfo,
    extensionZip: {
      fileName: path.relative(stageRoot, extensionZipPath),
      sha256: await sha256File(extensionZipPath),
      size: (await fs.stat(extensionZipPath)).size,
    },
    files,
    notes: [
      "Windowsの通常運用は専用Chrome＋ローカルサーバー経路です。extensionは互換用に同梱しますが登録しません。",
      "Chrome Web Store公開方法は保留中です。",
      "署名秘密鍵（PEM）はこのZIPへ含めません。",
    ],
  };
  await fs.writeFile(
    path.join(stageRoot, "BUNDLE_INVENTORY.json"),
    `${JSON.stringify(inventory, null, 2)}\n`,
    "utf8"
  );
  await fs.writeFile(
    path.join(stageRoot, "UPLOAD_AND_INSTALL.md"),
    buildGuide({ version, extensionVersion, exeInfo, extensionZipPath, stageRoot }),
    "utf8"
  );

  await createZipArchive(distRoot, bundleName, zipPath);
  console.log(JSON.stringify({
    ok: true,
    bundle: zipPath,
    sha256: await sha256File(zipPath),
    size: (await fs.stat(zipPath)).size,
    exe: exeInfo,
    extensionZip: inventory.extensionZip,
  }, null, 2));
}

async function readJson(filePath) {
  return JSON.parse(await fs.readFile(filePath, "utf8"));
}

async function copyDirectory(sourceDir, destinationDir, relativeBase = "") {
  await fs.mkdir(destinationDir, { recursive: true });
  const entries = await fs.readdir(sourceDir, { withFileTypes: true });
  for (const entry of entries) {
    const relativePath = path.join(relativeBase, entry.name);
    if (shouldSkip(entry, relativePath)) continue;

    const sourcePath = path.join(sourceDir, entry.name);
    const destinationPath = path.join(destinationDir, entry.name);
    if (entry.isDirectory()) {
      await copyDirectory(sourcePath, destinationPath, relativePath);
    } else if (entry.isFile()) {
      await copyFileSafe(sourcePath, destinationPath);
    }
  }
}

function shouldSkip(entry, relativePath) {
  if (entry.isDirectory() && skipDirectories.has(entry.name)) return true;
  if (entry.isFile() && skipFiles.has(entry.name)) return true;
  return relativePath.split(path.sep).includes("secrets");
}

async function copyFileSafe(sourcePath, destinationPath) {
  await fs.mkdir(path.dirname(destinationPath), { recursive: true });
  await fs.copyFile(sourcePath, destinationPath);
}

async function findExistingFile(candidates) {
  for (const candidate of candidates) {
    try {
      const stat = await fs.stat(candidate);
      if (stat.isFile() && stat.size > 0) return candidate;
    } catch {
      // 次の候補を確認する。
    }
  }
  return "";
}

async function listFiles(root) {
  const result = [];
  await walk(root, root, result);
  return result.sort();
}

async function walk(root, current, result) {
  const entries = await fs.readdir(current, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(current, entry.name);
    if (entry.isDirectory()) {
      await walk(root, fullPath, result);
    } else if (entry.isFile()) {
      result.push(path.relative(root, fullPath));
    }
  }
}

async function createZipArchive(parentDir, packageDirName, zipPath) {
  await fs.mkdir(path.dirname(zipPath), { recursive: true });
  if (process.platform === "win32") {
    const source = powershellQuote(path.join(parentDir, packageDirName));
    const destination = powershellQuote(zipPath);
    const result = spawnSync("powershell.exe", [
      "-NoProfile",
      "-ExecutionPolicy",
      "Bypass",
      "-Command",
      `Compress-Archive -LiteralPath ${source} -DestinationPath ${destination} -Force`,
    ], { encoding: "utf8", windowsHide: true });
    if (result.status !== 0) {
      throw new Error((result.stderr || result.stdout || "ZIP作成に失敗しました。").trim());
    }
    return;
  }

  const result = spawnSync("zip", ["-qr", zipPath, packageDirName], {
    cwd: parentDir,
    encoding: "utf8",
  });
  if (result.status !== 0) {
    throw new Error((result.stderr || result.stdout || "ZIP作成に失敗しました。").trim());
  }
}

function powershellQuote(value) {
  return `'${String(value).replaceAll("'", "''")}'`;
}

function extensionIdFromPublicKey(publicKey) {
  const digest = createHash("sha256").update(Buffer.from(publicKey, "base64")).digest();
  const alphabet = "abcdefghijklmnop";
  return [...digest.subarray(0, 16)]
    .map((byte) => alphabet[byte >> 4] + alphabet[byte & 15])
    .join("");
}

async function sha256File(filePath) {
  return new Promise((resolve, reject) => {
    const hash = createHash("sha256");
    const stream = createReadStream(filePath);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.on("error", reject);
    stream.on("end", () => resolve(hash.digest("hex")));
  });
}

function buildGuide({ version, extensionVersion, exeInfo, extensionZipPath, stageRoot }) {
  const exeLine = exeInfo
    ? `EXE: windows-installer/${exeInfo.fileName}\nSHA-256: ${exeInfo.sha256}\nサイズ: ${exeInfo.size} bytes\n注意: 同梱EXEは公開済みの既存版です。今回の専用Chrome＋ローカルサーバー経路の変更を含めるにはBUILD_WINDOWS_INSTALLER.batで再ビルドしてください。`
    : "EXE: 未同梱。このZIPのinstaller\\windows\\property-list-automation.issをWindowsのInno Setupでコンパイルしてください。";
  return `# Windows更新配布セット\n\nバージョン: ${version}\n旧拡張機能バージョン: ${extensionVersion}\n\n## 含まれるもの\n\n- インストーラー作成元: installer/windows\n- Windows用ビルド補助: BUILD_WINDOWS_INSTALLER.bat\n- 本体ソースと旧方式の拡張機能フォルダ: property-list-automation\n- 旧拡張機能の個別ZIP: ${path.relative(stageRoot, extensionZipPath)}\n- GitHubアップロード用ファイル: public-update-files\n- 変更内容の在庫表: BUNDLE_INVENTORY.json\n\n## Windowsでの更新\n\n1. EXEを使う場合はwindows-installer内のEXEをSHA-256確認する。\n2. EXEを作り直す場合は、Inno Setupを入れて、同梱のBUILD_WINDOWS_INSTALLER.batを実行する。\n3. インストールまたは更新後の通常運用は、専用Chrome＋ローカルサーバー経路を使う。拡張機能の登録や再読み込みは不要。\n4. extension/は旧方式の保守・検証用として同梱するが、通常運用では使用しない。\n\n## 公開\n\npublic-update-filesの内容をGitHubの公開ブランチへ反映する。Chrome Web Store公開方法は保留中。\n\n${exeLine}\n`;
}

function buildInstallerBat(version) {
  return `@echo off\r\nsetlocal\r\nset "ROOT=%~dp0"\r\nset "ISS=%ROOT%installer\\windows\\property-list-automation.iss"\r\nset "ISCC="\r\nif exist "%ProgramFiles(x86)%\\Inno Setup 6\\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\\Inno Setup 6\\ISCC.exe"\r\nif not defined ISCC if exist "%ProgramFiles%\\Inno Setup 6\\ISCC.exe" set "ISCC=%ProgramFiles%\\Inno Setup 6\\ISCC.exe"\r\nif not defined ISCC for /f "delims=" %%I in ('where ISCC.exe 2^>nul') do if not defined ISCC set "ISCC=%%I"\r\nif not defined ISCC (\r\n  echo Inno Setup 6のISCC.exeが見つかりません。\r\n  exit /b 1\r\n)\r\n"%ISCC%" "%ISS%"\r\nif errorlevel 1 exit /b %ERRORLEVEL%\r\necho インストーラー作成完了: %ROOT%dist\\property-list-automation-windows-${version}.exe\r\nexit /b 0\r\n`;
}

main().catch((error) => {
  console.error(`Windows更新配布ZIP作成 NG: ${error.message}`);
  process.exitCode = 1;
});
