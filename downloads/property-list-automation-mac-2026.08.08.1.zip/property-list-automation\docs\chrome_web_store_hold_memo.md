# Chrome Web Store公開方法 保留メモ

作成日: 2026-07-14
状態: 保留

## 保留内容

GitHub上のCRXをChrome Web Storeへ移行し、非公開（Unlisted）で公開する方法は、当面実施しない。
現行のGitHub公開版、Windowsインストーラー、拡張機能の構成は変更しない。

## 現在の確定版

- Windows EXE: `property-list-automation-windows-2026.07.14.1.exe`
- EXE SHA-256: `6627C46AAEFD4D763AC29DCEEDAE88CA7CB6E079E8AA7356D4973167C99DBA07`
- 拡張機能バージョン: `0.3.1`
- 拡張機能ID: `fnmkfpkhmnjhmkibiddnfoijigfmcoof`
- CRX SHA-256: `1C63B0A9260CFE96C8061074D7ED961D2E4AC91309EB43EA409D191492E62CDD`

## 再開時の作業

1. Chrome Web Store Developer Dashboardで開発者登録、メール確認、2段階認証、初回登録料を完了する。
2. `manifest.json`を含む拡張機能ZIPを登録する。
3. Store Listing、Privacy、Distributionを設定し、必要に応じてUnlistedで審査提出する。
4. Chrome Web StoreのItem IDが現行ID `fnmkfpkhmnjhmkibiddnfoijigfmcoof` と一致するか確認する。異なる場合は、インストーラーのポリシー設定と更新情報を修正する。
5. Windowsインストーラーの拡張機能更新先をChrome Web Store用に切り替えて再ビルドする。
6. EXE、manifest、checksumsを更新し、Chrome再起動後に`chrome://policy`と`chrome://extensions`で自動導入を確認する。

## 再開条件

- 拡張機能ZIP、アイコン、スクリーンショット、プライバシー説明を準備できていること。
- Chrome Web Storeの審査と公開完了を確認できること。
- 公開後のItem ID、更新URL、バージョン、SHA-256を記録できること。

## 注意

- 未公開の`.2`版は正式配布へ反映しない。
- 署名秘密鍵（PEM）は公開・アップロードしない。
- 保留中はChrome Web Storeへの登録、インストーラーのポリシー変更、GitHub公開物の変更を行わない。
