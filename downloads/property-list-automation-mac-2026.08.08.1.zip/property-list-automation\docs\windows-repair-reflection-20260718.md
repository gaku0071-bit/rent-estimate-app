# Windows版 修正・反映内容メモ

更新日: 2026-07-18
対象: property-list-automation Windows版 / Chrome拡張機能 0.3.1

## 修正内容

- リアプロ対象タブを前面表示するよう修正
- 拡張機能更新後、リアプロ用スクリプトを自動注入するよう修正
- 0.3.0で処理が停止する状態を解除
- いい生活再検索ボタンを追加
- 取得エラー時にPromiseが残り、「確認中」で固まる問題を修正
- Chrome拡張機能を0.3.1としてCRX再生成

## 反映先

- ローカルインストール先
- デスクトップ拡張機能フォルダ
- ローカルサーバー再起動済み

## 生成物

- ファイル: `property-list-automation-extension-0.3.1.crx`
- ローカルパス: `public-update-files/property-list-automation-extension-0.3.1.crx`
- SHA-256: `d81fd4042c326278a26b2c32a0d4e45adc6c3699e1639b4dac418203008ea1c8`

## 検証済み項目

- JavaScript構文検査
- Chromeポリシー検証
- サーバー検証
- 検証ルール確認
- 専用Chromeのリアプロタブ確認

## 配布上の注意

GitHubへCRXと更新XMLを公開するまでは、現在のChromeには旧配布版が残る可能性があります。正式配布時は、CRX、更新XML、manifestの公開後に、公開URLからの再取得とバージョン0.3.1の反映を確認します。

総合検証は既存の `本番前確認.command` 欠落で停止しています。これは今回の修正内容とは別の既存検証環境の問題です。
