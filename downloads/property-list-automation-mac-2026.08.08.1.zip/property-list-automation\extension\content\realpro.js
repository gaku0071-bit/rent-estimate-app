(() => {
  if (globalThis.__propertyListRealproExtensionLoaded) return;
  globalThis.__propertyListRealproExtensionLoaded = true;

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "REALPRO_STATUS") {
      sendResponse(realproStatus());
      return false;
    }

    if (message?.type === "REALPRO_APPLY_CONDITIONS") {
      applyRealproConditions(message.payload || {})
        .then((result) => sendResponse(result))
        .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
      return true;
    }

    if (message?.type === "REALPRO_CAPTURE") {
      captureRealpro({
        pages: clamp(Number(message.pages || 1), 1, 200),
        startPage: clamp(Number(message.startPage || 0), 0, 10000),
        withDetails: message.withDetails !== false,
      })
        .then((realpro) => sendResponse({ ok: true, realpro }))
        .catch((error) => sendResponse({ ok: false, error: String(error?.message || error) }));
      return true;
    }

    return false;
  });

  function realproStatus() {
    const text = document.body?.innerText || "";
    return {
      ok: isRealproResultPage(),
      kind: "realpro",
      title: document.title || "",
      url: location.href,
      summary: summaryFromText(text),
      roomRows: document.querySelectorAll("tr.room_info_tr").length,
    };
  }

  async function applyRealproConditions(conditions = {}) {
    if (!isRealproResultPage()) throw new Error("リアプロのリスト検索結果画面ではありません。");

    const applied = [];
    const skipped = [];
    const layoutMap = {
      "ワンルーム": ["1"], "1K": ["3"], "1DK": ["4"], "1LDK": ["6"],
      "2K": ["7"], "2DK": ["8"], "2LDK": ["9"], "3K": ["10"],
      "3DK": ["11"], "3LDK": ["12"], "3LDK〜": ["12", "13", "14", "15", "16", "17", "18"],
      "4LDK": ["15"],
    };
    const routeMap = {
      "南北線": "1082", "地下南北線": "1082", "札幌市南北線": "1082",
      "東西線": "1083", "地下東西線": "1083", "札幌市東西線": "1083",
      "札幌市電": "1084", "札幌市軌道線": "1084",
      "東豊線": "1085", "地下東豊線": "1085", "札幌市東豊線": "1085",
      "JR函館本線": "1051", "函館本線": "1051", "JR千歳線": "1056", "千歳線": "1056",
      "JR学園都市線": "1055", "JR札沼線": "1055", "札沼線": "1055",
    };
    const transportationMap = { "徒歩": "1", "バス": "2", "車": "3", "自動車": "3" };
    const updatedMap = { "当日": "1", "3日以内": "3", "7日以内": "7", "14日以内": "14" };
    const normalize = (value) => String(value || "").normalize("NFKC").replace(/\s+/g, "").replace(/駅$/, "");
    const byName = (name) => document.querySelector(`[name="${CSS.escape(name)}"]`);
    const setSelect = (name, value, label) => {
      const select = byName(name);
      if (!select || !value) return false;
      const option = Array.from(select.options).find((item) => item.value === String(value));
      if (!option) { skipped.push(`${label}=${value}`); return false; }
      select.value = String(value);
      select.dispatchEvent(new Event("change", { bubbles: true }));
      applied.push(label);
      return true;
    };
    const setInput = (name, value, label) => {
      const input = byName(name);
      if (!input) return false;
      input.value = value ? String(value) : "";
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      applied.push(label);
      return true;
    };
    const setCheckbox = (name, checked, label) => {
      const input = byName(name);
      if (!input) return false;
      input.checked = Boolean(checked);
      input.dispatchEvent(new Event("change", { bubbles: true }));
      if (checked) applied.push(label);
      return true;
    };

    setInput("keyword", "", "フリーワードクリア");
    setSelect("rental_cost1", conditions.rentMin || "-1", "賃料下限");
    setSelect("rental_cost2", conditions.rentMax || "-1", "賃料上限");
    setSelect("update_date", updatedMap[conditions.updated] || "-1", "更新日");
    setSelect("transportation_id", transportationMap[conditions.accessMethod] || "-1", "駅までの移動手段");
    setInput("required_time", conditions.walkMinutes || "", "駅までの分数");
    setCheckbox("include_common_fee", conditions.includeManagementFee, "管理費・共益費含む");
    setCheckbox("enable_enter_flag", conditions.immediate, "即入物件");
    setCheckbox("diversion", false, "WEB広告掲載条件クリア");

    const sapporoCodes = new Set(["01101", "01102", "01103", "01104", "01105", "01106", "01107", "01108", "01109", "01110"]);
    document.querySelectorAll('input[name="city_code[]"]').forEach((input) => {
      input.checked = Boolean(conditions.sapporoOnly && sapporoCodes.has(input.value));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    });
    if (conditions.sapporoOnly) applied.push("札幌市10区");

    const layouts = new Set((Array.isArray(conditions.layouts) ? conditions.layouts : []).flatMap((layout) => layoutMap[layout] || []));
    document.querySelectorAll('input[name="room_layout_id[]"]').forEach((input) => {
      input.checked = layouts.has(input.value);
      input.dispatchEvent(new Event("change", { bubbles: true }));
    });
    if (layouts.size) applied.push(`間取${layouts.size}件`);

    const lineNames = new Set(Array.isArray(conditions.lines) ? conditions.lines : []);
    const stationNames = new Set((Array.isArray(conditions.stations) ? conditions.stations : [])
      .map((key) => normalize(String(key).split(":").slice(1).join(":"))).filter(Boolean));
    (Array.isArray(conditions.stations) ? conditions.stations : []).forEach((key) => {
      const line = String(key).split(":")[0];
      if (line) lineNames.add(line);
    });
    const routeValues = new Set([...lineNames].map((line) => routeMap[line]).filter(Boolean));
    document.querySelectorAll('input[name="route_id[]"]').forEach((input) => {
      input.checked = routeValues.has(input.value);
      input.dispatchEvent(new Event("change", { bubbles: true }));
    });
    if (lineNames.size) applied.push(`路線${routeValues.size}件`);

    const matchedStations = new Set();
    document.querySelectorAll('input[name="station_id[]"]').forEach((input) => {
      const label = input.closest("label")?.innerText || input.parentElement?.innerText || "";
      const stationName = normalize(label);
      const checked = stationNames.has(stationName);
      input.checked = checked;
      input.dispatchEvent(new Event("change", { bubbles: true }));
      if (checked) matchedStations.add(stationName);
    });
    if (stationNames.size) applied.push(`駅${matchedStations.size}件`);

    const equipment = Array.isArray(conditions.equipment) ? conditions.equipment : [];
    const wantsParking = equipment.includes("駐車場空きあり");
    setCheckbox("parking_flag", wantsParking, "駐車場有り");
    setCheckbox("available_parking_flag", wantsParking, "駐車場空きあり");
    const equipmentSelectors = {
      "バス・トイレ別": 'input[name="eq_rm[]"][value="151"]',
      "BT別": 'input[name="eq_rm[]"][value="151"]',
      "オートロック": 'input[name="eq_bld[]"][value="1"]',
    };
    const equipmentLabels = { "エアコン": ["エアコン"], "インターネット無料": ["インターネット無料", "ネット無料", "無料インターネット"] };
    const findEquipment = (keywords) => [...document.querySelectorAll('input[type="checkbox"]')].find((input) => {
      const label = input.closest("label")?.innerText || input.parentElement?.innerText || "";
      const normalized = normalize(label);
      return keywords.some((keyword) => normalized.includes(normalize(keyword)));
    });
    const handledEquipment = new Set(["駐車場空きあり"]);
    equipment.forEach((item) => {
      if (handledEquipment.has(item)) return;
      const input = equipmentSelectors[item] ? document.querySelector(equipmentSelectors[item]) : findEquipment(equipmentLabels[item] || [item]);
      if (!input) { skipped.push(`設備:${item}`); return; }
      input.checked = true;
      input.dispatchEvent(new Event("change", { bubbles: true }));
      handledEquipment.add(item);
      applied.push(`設備:${item}`);
    });
    if (conditions.webAllowed) skipped.push("WEB広告掲載可否は取得後判定");
    if (conditions.excludeNegotiating) skipped.push("商談中・審査中は取得後判定");

    const searchButton = document.querySelector(".go_search_submit") || document.querySelector(".go_search");
    const form = document.getElementById("main_form") || document.forms[0];
    const submitted = Boolean(conditions.submitSearch && (searchButton || form));
    if (submitted) setTimeout(() => (searchButton ? searchButton.click() : form.submit()), 100);
    return {
      ok: true,
      href: location.href,
      title: document.title,
      applied,
      skipped,
      submitted,
      searchSummary: (document.body?.innerText || "").match(/[0-9,]+\s*棟\s*[0-9,]+\s*戸/)?.[0] || "",
    };
  }

  async function captureRealpro({ pages, startPage, withDetails }) {
    if (!isRealproResultPage()) {
      throw new Error("リアプロのリスト検索結果画面ではありません。");
    }

    emitProgress("list", 0, pages, "リアプロ一覧を取得しています...");
    const listResult = await captureRealproPages(pages, startPage);
    let rooms = dedupeRooms(listResult.rooms);
    if (withDetails) {
      rooms = await enrichRealproDetails(rooms);
    }

    return {
      title: document.title || "リアプロ",
      url: location.href,
      rawText: listResult.rawText,
      summary: listResult.summary,
      rooms,
      pageCaptures: listResult.pageCaptures,
      startPage: listResult.startPage + 1,
    };
  }

  async function captureRealproPages(requestedPages, requestedStartPage = 0) {
    const baseUrl = new URL(location.href);
    const explicitFirstPage = Number(requestedStartPage) > 0 ? Number(requestedStartPage) - 1 : 0;
    const firstPage = Number(requestedStartPage) > 0
      ? explicitFirstPage
      : (Number(baseUrl.searchParams.get("page") || "0") || 0);
    const pagerPages = Array.from(document.querySelectorAll("td.pager"))
      .map((el) => (el.getAttribute("onclick") || "").match(/pager\('([^']+)','([^']+)'\)/))
      .filter(Boolean)
      .map((match) => Number(match[2]))
      .filter(Number.isFinite);
    const maxPage = Math.max(firstPage, ...pagerPages);
    const lastPage = Math.min(firstPage + requestedPages - 1, maxPage);
    const pageIndexes = Array.from(
      { length: Math.max(0, lastPage - firstPage + 1) },
      (_item, index) => firstPage + index
    );
    if (!pageIndexes.length) throw new Error("リアプロの取得ページを判定できませんでした。");

    const pageResults = [];
    for (let offset = 0; offset < pageIndexes.length; offset += 5) {
      const batch = pageIndexes.slice(offset, offset + 5);
      const results = await Promise.all(batch.map(fetchRealproPage));
      pageResults.push(...results);
      const roomCount = pageResults.reduce((sum, page) => sum + page.rooms.length, 0);
      emitProgress("list", pageResults.length, pageIndexes.length, `リアプロ一覧 ${pageResults.length}/${pageIndexes.length}ページ / ${roomCount}戸`);
    }

    const rooms = [];
    const pageCaptures = [];
    const rawTextParts = [];
    for (const result of pageResults.sort((a, b) => a.pageIndex - b.pageIndex)) {
      if (result.loginDetected) throw new Error("リアプロがログイン画面です。ログインし直してください。");
      rooms.push(...result.rooms);
      rawTextParts.push([result.summary, `DOM取得戸数 ${result.rooms.length}件`].filter(Boolean).join("\n"));
      pageCaptures.push({
        pageNumber: result.pageIndex + 1,
        url: result.pageUrl,
        lineCount: 2,
        textLength: Math.max(Number(result.textLength || 0), 1),
        expandedRoomButtons: 0,
        roomCount: result.rooms.length,
        roomRowCount: result.rooms.length,
        roomAnchorCount: result.rooms.filter((room) => room.realproRoomId).length,
        loginDetected: false,
        captureMode: "chrome-extension",
        summary: result.summary,
      });
    }
    if (pageCaptures.length) {
      const finalPage = pageCaptures.at(-1).pageNumber - 1;
      pageCaptures.at(-1).stopReason = finalPage >= maxPage ? "last-page-reached" : "requested-pages-reached";
    }

    return {
      rooms,
      pageCaptures,
      rawText: mergeText(rawTextParts),
      summary: pageResults.find((page) => page.summary)?.summary || "",
      startPage: firstPage,
    };
  }

  async function fetchRealproPage(pageIndex) {
    const pageUrl = new URL(location.href);
    pageUrl.searchParams.set("method", "estate");
    pageUrl.searchParams.set("display", "building");
    pageUrl.searchParams.set("page", String(pageIndex));
    const response = await fetchWithTimeout(pageUrl.href, { credentials: "include" }, 30000);
    if (!response.ok) throw new Error(`リアプロ一覧 HTTP ${response.status}: ${pageIndex + 1}ページ`);
    const html = await response.text();
    const doc = new DOMParser().parseFromString(html, "text/html");
    return {
      pageIndex,
      pageUrl: pageUrl.href,
      ...parseRealproDocument(doc, pageUrl.href),
    };
  }

  function parseRealproDocument(doc, pageUrl) {
    const rooms = [];
    let building = { building: "", address: "", line: "", station: "", accessMethod: "徒歩", walkMinutes: 0 };

    for (const tr of Array.from(doc.querySelectorAll("tr"))) {
      const text = textOf(tr).trim();
      const lines = text.split(/\n+/).map((line) => line.trim()).filter(Boolean);
      const addressIndex = lines.findIndex((line) => line.startsWith("住所："));
      const accessIndex = lines.findIndex((line) => line.startsWith("沿線："));
      if (!tr.classList.contains("room_info_tr") && addressIndex > 0 && accessIndex > addressIndex) {
        building = {
          building: normalize(lines[addressIndex - 1]),
          address: normalize(lines[addressIndex].replace(/^住所：/, "")),
          ...parseAccess(lines[accessIndex]),
        };
        continue;
      }
      if (!tr.classList.contains("room_info_tr") || !building.building) continue;

      const cells = Array.from(tr.querySelectorAll("td"));
      const roomAnchor = tr.querySelector("a.room_number");
      const onclick = roomAnchor?.getAttribute("onclick") || "";
      const id = onclick.match(/go_detail\(event,'([^']+)'/)?.[1] || "";
      const roomLabel = normalize(textOf(roomAnchor) || textOf(cells[0]) || "");
      const status = Array.from(tr.querySelectorAll(".st")).map((el) => normalize(textOf(el))).filter(Boolean).join(" ");
      const dateLines = splitCell(cells[5]);
      const layoutLines = splitCell(cells[6]);
      const rentLines = splitCell(cells[7]);
      const equipmentText = normalize(textOf(cells[1]) || "");

      rooms.push({
        ...building,
        room: cleanRoom(roomLabel),
        roomLabel,
        realproRoomId: id,
        layout: normalize(layoutLines[0]),
        area: normalize(layoutLines[1]).replace("m2", "㎡"),
        rent: yen(rentLines[0]),
        fee: yen(rentLines[1]),
        status,
        availableDate: normalize(dateLines[0]),
        adFee: "",
        equipment: equipmentMarkers().filter((marker) => equipmentText.includes(marker)),
        webAd: "判定不可",
        imageReuse: "判定不可",
        floorPlanReuse: "判定不可",
        priorContact: "判定不可",
        applicationCount: 0,
        detailCaptureStatus: id ? "未取得" : "詳細IDなし",
        detailCaptureReason: id ? "詳細取得前" : "一覧から詳細IDを取得できませんでした",
        detailHttpStatus: "",
        detailTextLength: 0,
        url: id ? `${location.origin}/room_detail.php?id=${encodeURIComponent(id)}&type=room` : "",
      });
    }

    const text = doc.body?.innerText || "";
    return {
      rooms,
      textLength: text.length,
      summary: summaryFromText(text),
      loginDetected: /ログインID|パスワード/.test(text) && !/検索結果|部屋番号|空室|退去予定/.test(text),
      pageUrl,
    };
  }

  async function enrichRealproDetails(rooms) {
    const targets = rooms.filter((room) => room.realproRoomId);
    const details = [];
    for (let index = 0; index < targets.length; index += 2) {
      const chunk = targets.slice(index, index + 2);
      const chunkDetails = await Promise.all(chunk.map((room) => captureRealproDetail(room.realproRoomId)));
      details.push(...chunkDetails);
      const checked = Math.min(index + chunk.length, targets.length);
      const candidates = countPossibleCandidates(rooms, details);
      emitProgress("details", checked, targets.length, `リアプロ詳細 ${checked}/${targets.length}戸 / 候補見込み${candidates}件`);
    }

    const detailsById = new Map(details.map((detail) => [String(detail.realproRoomId || ""), detail]));
    return rooms.map((room) => {
      const detail = detailsById.get(String(room.realproRoomId || ""));
      if (!detail) return room;
      return {
        ...room,
        webAd: detail.webAd || room.webAd,
        equipment: [...new Set([...(room.equipment || []), ...(detail.equipment || [])])].sort(),
        applicationCount: Number(detail.applicationCount || 0),
        detailTitle: detail.title || "",
        url: detail.url || room.url,
        detailCaptureStatus: detail.detailCaptureStatus || (detail.webAd === "判定不可" ? "詳細確認不完全" : "取得OK"),
        detailCaptureReason: detail.detailCaptureReason || "",
        detailHttpStatus: detail.status || "",
        detailTextLength: detail.detailTextLength || 0,
      };
    });
  }

  async function captureRealproDetail(id) {
    const url = `${location.origin}/room_detail.php?id=${encodeURIComponent(id)}&type=room`;
    try {
      const response = await fetchWithTimeout(url, { credentials: "include" }, 30000);
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const text = (doc.body?.innerText || "").normalize("NFKC");
      const adSection = (text.match(/広告掲載[\s\S]{0,260}/) || [""])[0];
      const webAd = extractWebAd(adSection || text);
      const applicationCount = await fetchApplicationCount(doc);
      return {
        realproRoomId: id,
        title: (doc.querySelector("title")?.innerText || "").trim(),
        url,
        status: response.status,
        webAd,
        equipment: extractEquipment(text),
        applicationCount,
        detailCaptureStatus: response.ok && webAd !== "判定不可" ? "取得OK" : "詳細確認不完全",
        detailCaptureReason: detailCaptureReason({ response, text, adSection, webAd }),
        detailTextLength: text.length,
      };
    } catch (error) {
      return {
        realproRoomId: id,
        title: "",
        url,
        status: 0,
        webAd: "判定不可",
        equipment: [],
        applicationCount: 0,
        detailCaptureStatus: "取得エラー",
        detailCaptureReason: String(error),
        detailTextLength: 0,
      };
    }
  }

  async function fetchApplicationCount(doc) {
    try {
      const value = (selector) => doc.querySelector(selector)?.value || "";
      const displayFlag = value("#njc_apply_display_flag") || "N";
      if (displayFlag !== "Y") return extractApplicationCount(doc.body?.innerText || "");
      const body = new URLSearchParams();
      body.set("bk_type", "1");
      body.set("rnp_bk_id", value("#building_id"));
      body.set("rnp_hy_id", value("#room_id"));
      body.set("residence_type", value("#residence_type") || "room");
      body.set("company_id", value("#company_id"));
      body.set("user_id", value("#user_id"));
      body.set("func", "request");
      body.set("option_break_flag", value("#mylist_njc_apply_option_break_flag") || "0");
      const response = await fetchWithTimeout(`${location.origin}/ajax/starfruit_auth_tyukai.php`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
        body: body.toString(),
      }, 10000);
      const result = JSON.parse(await response.text());
      return Number(result?.count || 0);
    } catch {
      return extractApplicationCount(doc.body?.innerText || "");
    }
  }

  function extractWebAd(text) {
    const webSection = (String(text || "").match(/webサービスにこの物件の広告を掲載[\s\S]{0,80}/) || [String(text || "")])[0];
    if (/許可されていません|不可/.test(webSection)) return "許可されていません";
    if (/管理会社に確認|要確認|管理会社へご確認|掲載希望の場合は管理会社/.test(webSection)) return "管理会社に確認";
    if (/[［\[]?\s*可\s*[］\]]?|許可されています/.test(webSection)) return "可";
    return "判定不可";
  }

  function detailCaptureReason({ response, text, adSection, webAd }) {
    if (!response.ok) return `HTTP ${response.status}`;
    if (!text) return "詳細本文が空です";
    if (!adSection) return "広告掲載欄を検出できませんでした";
    if (webAd === "判定不可") return "WEB広告掲載可否の文言を検出できませんでした";
    return "";
  }

  function extractApplicationCount(text) {
    const match = String(text || "").match(/(?:申込|申し込み)\s*([0-9]+)\s*件/);
    return Number(match?.[1] || 0);
  }

  function extractEquipment(text) {
    const value = String(text || "").normalize("NFKC");
    const rules = [
      ["バス・トイレ別", /バス・トイレ別|BT別|セパレート/],
      ["独立洗面台", /独立洗面|洗面化粧台|シャンプードレッサー/],
      ["エアコン", /エアコン/],
      ["暖房", /暖房/],
      ["オートロック", /オートロック/],
      ["宅配ボックス", /宅配ボックス|宅配BOX/],
      ["インターネット無料", /インターネット無料|ネット無料/],
      ["Wi-Fi無料", /Wi-?Fi無料|Wifi無料|ワイファイ無料/i],
      ["駐輪場あり", /駐輪場(?:有り|あり|可)/],
      ["ペット相談", /ペット相談|ペット可|ペット飼育/],
      ["灯油暖房", /灯油暖房|灯油FF/],
      ["都市ガス", /都市ガス/],
      ["プロパンガス", /プロパンガス|LPガス/],
      ["エレベーター", /エレベーター/],
      ["防犯カメラ", /防犯カメラ/],
    ];
    const equipment = rules.filter(([, pattern]) => pattern.test(value)).map(([label]) => label);
    const parkingText = (value.match(/駐車場[\s\S]{0,80}/) || [""])[0];
    if (parkingText && !/空きなし|無し|なし|無|不可|要確認/.test(parkingText) && /空きあり|空有|有り|あり|可/.test(parkingText)) {
      equipment.push("駐車場空きあり");
    }
    return equipment;
  }

  async function fetchWithTimeout(url, options = {}, timeoutMs = 10000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
  }

  function countPossibleCandidates(rooms, details) {
    const detailById = new Map(details.map((detail) => [String(detail.realproRoomId || ""), detail]));
    return rooms.filter((room) => {
      const detail = detailById.get(String(room.realproRoomId || ""));
      const webAd = detail?.webAd || room.webAd;
      const applicationCount = Number(detail?.applicationCount || room.applicationCount || 0);
      return webAd !== "許可されていません" &&
        webAd !== "判定不可" &&
        applicationCount === 0 &&
        !/(商談中|審査中|申込あり)/.test(String(room.status || ""));
    }).length;
  }

  function dedupeRooms(rooms) {
    const seen = new Set();
    const deduped = [];
    for (const room of rooms) {
      const key = room.realproRoomId
        ? `id:${room.realproRoomId}`
        : [room.building, room.room, room.layout, room.rent, room.address].map((value) => String(value || "").replace(/\s+/g, "")).join("|");
      if (seen.has(key)) continue;
      seen.add(key);
      deduped.push(room);
    }
    return deduped;
  }

  function emitProgress(phase, current, total, text) {
    try {
      chrome.runtime.sendMessage({
        type: "REALPRO_EXTENSION_PROGRESS",
        phase,
        current,
        total,
        text,
      });
    } catch {
      // Popupが閉じていても取得は続ける。
    }
  }

  function isRealproResultPage() {
    return location.hostname.includes("realnetpro.com") &&
      location.pathname.includes("main.php") &&
      location.search.includes("method=estate");
  }

  function normalize(value) {
    return String(value || "").normalize("NFKC").replace(/\s+/g, " ").trim();
  }

  function cleanRoom(value) {
    return String(value || "").normalize("NFKC").match(/^[A-Za-z0-9-]+/)?.[0] || normalize(value);
  }

  function yen(value) {
    return Number(String(value || "").normalize("NFKC").replace(/[^0-9]/g, "")) || 0;
  }

  function parseAccess(value) {
    const match = String(value || "").match(/^沿線：(.+?)「(.+?)」(徒歩|バス|自動車|車|自転車)([0-9０-９]+)分/);
    if (!match) return { line: "", station: "", accessMethod: "徒歩", walkMinutes: 0 };
    return {
      line: normalize(match[1]),
      station: normalize(match[2]),
      accessMethod: match[3] === "自動車" ? "車" : match[3],
      walkMinutes: Number(String(match[4]).normalize("NFKC")),
    };
  }

  function textOf(element) {
    return String(element?.textContent || "");
  }

  function splitCell(td) {
    return textOf(td).split(/\n+/).map((line) => line.trim()).filter(Boolean);
  }

  function equipmentMarkers() {
    return ["家電", "家具", "駐車場有り", "ペット", "ネット無料", "エアコン", "オートロック", "宅配BOX"];
  }

  function summaryFromText(text) {
    return (String(text || "").normalize("NFKC").match(/[0-9,]+\s*棟\s*[0-9,]+\s*戸/) || [""])[0];
  }

  function mergeText(parts) {
    const seen = new Set();
    return parts.map((part) => String(part || "").trim()).filter((part) => {
      if (!part || seen.has(part)) return false;
      seen.add(part);
      return true;
    }).join("\n\n");
  }

  function clamp(value, min, max) {
    if (!Number.isFinite(value)) return min;
    return Math.min(Math.max(Math.trunc(value), min), max);
  }
})();
